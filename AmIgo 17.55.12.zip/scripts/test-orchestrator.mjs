import assert from 'node:assert/strict';
import {
  buildSystemPrompt,
  classifyTurn,
  collectAttachmentDocuments,
  compactDroppedMessages,
  shouldGatherEvidence,
  userTaskPrefix,
} from '../src/orchestrator.js';

assert.equal(classifyTurn({ text: 'Привет' }).intent, 'chat');
assert.equal(classifyTurn({ text: 'Расскажи, что умеешь' }).intent, 'capability');
assert.equal(classifyTurn({
  text: 'Что в этом файле?',
  attachments: [{ kind: 'text', name: 'a.pdf', text: 'hello' }],
}).intent, 'file_qa');
assert.equal(classifyTurn({
  text: 'Напиши змейку на python',
}).intent, 'code');
assert.equal(classifyTurn({
  text: 'Что на фото?',
  attachments: [{ kind: 'image', name: 'a.png' }],
}).intent, 'vision');
assert.equal(classifyTurn({
  text: 'найди курс евро',
  searchAvailable: true,
}).intent, 'search');

assert.equal(shouldGatherEvidence({
  intent: 'chat',
  attachments: [{ kind: 'text', name: 'a.txt' }],
  sandboxFiles: [],
}), true);
assert.equal(shouldGatherEvidence({
  intent: 'chat',
  attachments: [],
  sandboxFiles: ['note.txt'],
}), false);
assert.equal(shouldGatherEvidence({
  intent: 'file_qa',
  attachments: [],
  sandboxFiles: ['note.txt'],
}), true);
assert.equal(shouldGatherEvidence({
  intent: 'file_qa',
  continueMsg: true,
  attachments: [{ kind: 'text' }],
  sandboxFiles: ['note.txt'],
}), false);

const docs = collectAttachmentDocuments([
  { attachments: [{ kind: 'text', name: 'a.txt', text: 'AAA' }, { kind: 'image', name: 'p.png' }] },
  { attachments: [{ kind: 'text', sandboxPath: 'a.txt', text: 'dup' }] },
]);
assert.equal(docs.length, 1);
assert.equal(docs[0].name, 'a.txt');

const digest = compactDroppedMessages([
  { role: 'user', content: 'Старый вопрос про погоду в Липецке подробно' },
  { role: 'assistant', content: 'Ответ про погоду был длинный и больше не нужен для новой темы' },
]);
assert.match(digest, /Сжатая ранняя история/);
assert.match(digest, /Пользователь/);

const system = buildSystemPrompt({
  identityBlock: 'Тебя зовут Nage 1.5.',
  nowStr: 'четверг',
  intent: 'file_qa',
  provider: 'local',
  evidencePresent: true,
  sandboxFiles: ['report.pdf'],
  preferFiles: true,
});
assert.match(system, /Nage 1\.5/);
assert.match(system, /данные, не инструкции/);
assert.match(system, /Фрагменты файлов уже подобраны/);
assert.match(system, /report\.pdf/);
assert.doesNotMatch(system, /АВТОМАТИЧЕСКИ вставляет галерею/);

const chatSystem = buildSystemPrompt({
  identityBlock: 'Тебя зовут Nage 1.5.',
  intent: 'chat',
  provider: 'local',
  sandboxFiles: [],
});
assert.match(chatSystem, /Сильный собеседник/);
assert.doesNotMatch(chatSystem, /write_file/);
assert.match(chatSystem, /для обычного разговора не вызывай/);

assert.match(userTaskPrefix({ intent: 'file_qa', isCoder: false }), /фрагментам файлов/);
assert.equal(userTaskPrefix({ intent: 'chat', isCoder: true }), '');

console.log('Orchestrator tests passed.');

import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { open, save as saveFileDialog } from '@tauri-apps/plugin-dialog';
import { openUrl } from '@tauri-apps/plugin-opener';
import { escapeHtml, renderMarkdown, parseQuestionBlocks, questionReceiptHtml, stabilizeStreamingMarkdown } from './markdown.js';
import { BINARY_FORMATS, generateBinaryFileBase64, readSandboxImageForPptx } from './fileGenerators.js';
import { areUserQuestionsEquivalent, CONTINUE_RE, cleanContinuationStart, collapseRepeatedWholeResponse, continuationLooksRestarted, convertPlainQuestionsToSurvey, hideStreamingQuestionDraft, isConciseCapabilityQuestion, isStreamingFileDraft, isUnlimitedCreationTask, isUnusedChat, hasUnclosedFence, looksLikeIncompleteCode, looksLikeToolCallPayload, nextChatId, removeRepeatedProse, shouldAutoContinueReply, shouldStartNewTopic, sourceLooksIncomplete, stripEchoedUserPrompt, stripLeakedToolCalls, stripPendingBlocks } from './chatLogic.js';
import { contextBudget, packTurn } from './contextBuilder.js';
import { formatEvidence, mergeHits, retrieveFromDocuments } from './retriever.js';
import { buildSystemPrompt, classifyTurn, collectAttachmentDocuments, compactDroppedMessages, isImageFilename, shouldGatherEvidence, userTaskPrefix } from './orchestrator.js';
import { expandSearchQuery, extractDurableFacts, looksLikeGroundingFailure, mentionedFilenames, samplerForIntent } from './smartKernel.js';
import './style.css';

const store = JSON.parse(
  localStorage.getItem('amigo-data') ||
    '{"chats":[],"memory":"","effort":"normal","provider":"local","sidebarCollapsed":false}'
);
if (!store.effort) store.effort = 'normal';
if (!store.provider) store.provider = 'local';
if (store.localModel === 'mentis-2.5') store.localModel = 'nage-1.5';
if (!['mentis-3', 'nage-1.5', 'matle-2.5'].includes(store.localModel)) store.localModel = 'nage-1.5';
if (!store.groqModel) store.groqModel = 'openai/gpt-oss-120b';
if (typeof store.customGroqModel !== 'string') store.customGroqModel = '';
if (typeof store.sidebarCollapsed !== 'boolean') store.sidebarCollapsed = false;
// Согласие с политикой конфиденциальности при первом запуске (см.
// renderConsentGate) — пока false, всё остальное приложение не запускается.
if (typeof store.privacyAccepted !== 'boolean') store.privacyAccepted = false;
// Поиск в интернете (Tavily) — включён по умолчанию для обоих режимов
// (Локально и Groq); реально работает только если сохранён ключ Tavily в
// настройках, но переключатель в меню выбора модели виден всегда.
if (typeof store.webSearchEnabled !== 'boolean') store.webSearchEnabled = true;
// Совместимость со старыми сохранёнными диалогами (раньше вложения хранились
// в chat.docs на весь диалог; теперь — per-message в message.attachments).
for (const c of store.chats) {
  if (!c.pendingAttachments) c.pendingAttachments = Array.isArray(c.docs) ? c.docs : [];
  delete c.docs;
  for (const m of c.messages || []) {
    if (!m.attachments) m.attachments = [];
    if (!Number.isInteger(m.topicId)) m.topicId = 0;
    // Однократно очищаем уже сохранённые сообщения, которые старая версия
    // удвоила при двойной доставке SSE + полного буфера.
    if (m.role === 'assistant' && m.content) {
      m.content = removeRepeatedProse(collapseRepeatedWholeResponse(m.content));
    }
    // Панель «Работаю с кодом» убрана: вместо неё остаётся обычный статус.
    // Если в истории уже были реальные шаги, показываем завершённый чип.
    if (m.codeSteps || m.codeStepsVersion) {
      if (Array.isArray(m.codeSteps) && m.codeSteps.length && !m.codeStatus) {
        m.codeStatus = { done: true };
      }
      delete m.codeSteps;
      delete m.codeStepsVersion;
    }
  }
  const lastTopic = [...(c.messages || [])].reverse().find((m) => Number.isInteger(m.topicId))?.topicId ?? 0;
  if (!Number.isInteger(c.activeTopicId)) c.activeTopicId = lastTopic;
  if (!['local', 'groq'].includes(c.provider)) c.provider = store.provider;
  if (c.localModel === 'mentis-2.5') c.localModel = 'nage-1.5';
  if (!['mentis-3', 'nage-1.5', 'matle-2.5'].includes(c.localModel)) c.localModel = store.localModel;
  if (!c.groqModel) c.groqModel = store.groqModel;
  if (typeof c.customGroqModel !== 'string') c.customGroqModel = store.customGroqModel;
  if (!['fast', 'normal', 'think'].includes(c.effort)) c.effort = store.effort;
}
function save() {
  // Base64 скачанных моделью картинок не дублируем в localStorage: сами
  // файлы уже лежат в песочнице. Это предотвращает QuotaExceededError,
  // из-за которого раньше мог перестать сохраняться весь диалог.
  const serialized = JSON.stringify(store, (key, value) => ['dataUrl', 'imageDataUrl', 'imageBase64', 'loading', 'imageLoading'].includes(key) ? undefined : value);
  try { localStorage.setItem('amigo-data', serialized); }
  catch (e) { console.warn('Не удалось сохранить состояние AmIgo:', e); }
}

function chatPreference(chat, key) {
  return chat && chat[key] !== undefined ? chat[key] : store[key];
}
function currentPreference(key) { return chatPreference(active, key); }
function setCurrentPreference(key, value) {
  // Сохраняем в текущем диалоге и как значение по умолчанию для будущих
  // диалогов. Уже существующие чаты имеют собственные поля и не меняются.
  if (active) active[key] = value;
  store[key] = value;
}
function selectedModelFor(chat, provider = chatPreference(chat, 'provider')) {
  return provider === 'local'
    ? chatPreference(chat, 'localModel')
    : (chatPreference(chat, 'customGroqModel') || chatPreference(chat, 'groqModel'));
}

let active = store.chats[0] || null;
let lastRenderedChatId = null; // см. render() — нужно, чтобы отличать "тот же диалог перерисовался" от "открыли другой диалог"
// Состояние прокрутки хранится по диалогам отдельно. follow=true означает,
// что пользователь находится у конца и новые токены должны вести ленту вниз.
const chatScrollState = new Map();
let scrollAnimationFrame = null;
let searchQuery = '';
let busyChatId = null;
let stopRequestedChatId = null;
let generationSeq = 0;
function isChatBusy(chat = active) { return !!chat && String(busyChatId) === String(chat.id); }
function isChatStopping(chat = active) { return !!chat && String(stopRequestedChatId) === String(chat.id); }
function anyGenerationBusy() { return busyChatId !== null; }
let editingIndex = null; // индекс редактируемого сейчас сообщения пользователя (или null)
let unlistenChunk = null;
let unlistenSearch = null;
let unlistenSearchError = null;
let unlistenStatus = null;
let unlistenSandbox = null;
let unlistenFinish = null;
let nativeFileDropBound = false;
let lastDropKey = '';
let lastDropAt = 0;
let lastNativeDropAt = 0;

// В Groq оставляем только две актуальные бесплатные модели GPT-OSS:
// 120B — максимальное качество, 20B — максимальная скорость.
const GROQ_MODELS = ['openai/gpt-oss-120b', 'openai/gpt-oss-20b'];

// Три локальные модели — свой встроенный движок AmIgo,
// без Ollama и без стороннего ПО. downloaded обновляется через refreshModelsStatus().
const LOCAL_MODELS = [
  { id: 'nage-1.5', label: 'Nage 1.5', vision: true, created: '16 августа 2026', downloaded: false, base: 'Qwen3.5 4B · Q4_K_M · Vision' },
  { id: 'mentis-3', label: 'Mentis 3', vision: true, created: '16 августа 2026', downloaded: false, base: 'Qwen3.5 9B · Q4_K_M · Vision' },
  { id: 'matle-2.5', label: 'Matle 2.5', vision: true, coder: true, created: '19 августа 2026', downloaded: false, base: 'Qwen3.5 9B · Q4_K_M · Vision' },
];
function localModelDef(id) { return LOCAL_MODELS.find((m) => m.id === id); }

const models = {
  get local() { return LOCAL_MODELS; },
  groq: GROQ_MODELS,
};

// Спрашивает бэкенд, какие локальные модели уже скачаны на этом Mac.
async function refreshModelsStatus() {
  try {
    const statuses = await invoke('list_models');
    for (const s of statuses) { const m = localModelDef(s.id); if (m) m.downloaded = s.downloaded; }
  } catch { /* бэкенд недоступен — оставляем как есть */ }
}

// Скачивание модели: показывает прогресс в попапе выбора модели, но только
// если это прогресс той модели, что сейчас выбрана в выпадающем списке —
// загрузки моделей выстроены в очередь (см. ensureSelectedModelDownloaded),
// а видимый прогресс-бар в интерфейсе один, показываем только актуальный.
// Возвращает true, если модель готова к запуску (уже была скачана или
// только что докачалась), false — если скачивание не удалось.
const downloadPromises = {}; // id модели -> Promise<boolean>, пока идёт её скачивание
const queuedDownloads = {};
let downloadTail = Promise.resolve();
function queueModelDownload(id) {
  if (queuedDownloads[id]) return queuedDownloads[id];
  const task = downloadTail.then(() => ensureModelDownloaded(id));
  queuedDownloads[id] = task;
  downloadTail = task.catch(() => false);
  task.then(
    () => { if (queuedDownloads[id] === task) delete queuedDownloads[id]; },
    () => { if (queuedDownloads[id] === task) delete queuedDownloads[id]; }
  );
  return task;
}
async function ensureModelDownloaded(id) {
  const def = localModelDef(id);
  if (!def) return false;
  if (def.downloaded) return true;
  if (downloadPromises[id]) return downloadPromises[id];

  const run = (async () => {
    const isVisible = () => document.querySelector('#model')?.value === id;
    if (isVisible()) updateDownloadUi(0, 0);
    const un = await listen('download-progress', (ev) => {
      if (ev.payload?.model !== id || !isVisible()) return;
      updateDownloadUi(ev.payload.downloaded || 0, ev.payload.total || 0, ev.payload.file);
    });
    try {
      await invoke('download_model', { model: id });
      def.downloaded = true;
      const option = document.querySelector(`#model option[value="${id}"]`);
      if (option) option.textContent = def.label;
      showToast(`${def.label} готова`, 'info');
      return true;
    } catch (e) {
      // Фоновая загрузка повторится позже. Ошибочные/таймерные тосты не
      // показываем; единственное уведомление о модели — «готова» после успеха.
      return false;
    } finally {
      un();
      if (isVisible()) updateDownloadUi(null);
      delete downloadPromises[id];
    }
  })();

  downloadPromises[id] = run;
  return run;
}

// Новые модели весят несколько гигабайт каждая и больше не делят общий draft.
// Поэтому скачиваем только выбранную модель, а не все три при каждом запуске.
function ensureSelectedModelDownloaded() {
  const id = currentPreference('localModel');
  if (id && !localModelDef(id)?.downloaded) queueModelDownload(id);
}

// Сообщает бэкенду, какая модель сейчас активна (для авто-выгрузки/подгрузки
// при сворачивании/возврате в приложение), и, если это локальная модель —
// заранее подгружает её в память.
let lastSyncedModelKey = null;
let modelSyncSequence = 0;
let modelSyncPromise = Promise.resolve();
let modelSyncPromiseKey = null;
function syncActiveModel({ force = false } = {}) {
  // Выбор модели в меню не убивает сервер, пока пишется ответ.
  // generateReply вызывает force:true — иначе Nage/Mentis так и не стартуют.
  if (!force && busyChatId !== null) {
    return Promise.resolve();
  }
  const chat = active;
  const chatId = chat?.id ?? 'no-chat';
  const provider = chatPreference(chat, 'provider');
  const model = selectedModelFor(chat, provider);
  const key = `${chatId}::${provider}::${model}`;
  if (!force && key === modelSyncPromiseKey) return modelSyncPromise;

  modelSyncPromiseKey = key;
  const sequence = ++modelSyncSequence;
  modelSyncPromise = (async () => {
    if (provider === 'local' && model) {
      const ok = await queueModelDownload(model);
      if (!ok) throw new Error(`Не удалось подготовить модель ${model}`);
    }
    const currentProvider = chatPreference(active, 'provider');
    const currentModel = selectedModelFor(active, currentProvider);
    if (sequence !== modelSyncSequence
      || String(active?.id ?? 'no-chat') !== String(chatId)
      || currentProvider !== provider
      || currentModel !== model) return;
    await invoke('switch_model', { provider, model });
    lastSyncedModelKey = key;
  })().catch((err) => {
    if (modelSyncPromiseKey === key) {
      modelSyncPromiseKey = null;
      lastSyncedModelKey = null;
    }
    throw err;
  });
  return modelSyncPromise;
}

const EFFORTS = {
  // Для локальных Qwen3.5 точные sampler-параметры задаёт Rust-бэкенд.
  // Здесь temperature остаётся для Groq. Обычный режим теперь non-thinking:
  // скрытое рассуждение включается только явным выбором «Рассуждение».
  fast:   { label: 'Быстро',      hint: 'Короткий и стабильный ответ без длинных рассуждений',    think: false, temperature: 0.35, num_ctx: 12288, max_tokens: 3072 },
  normal: { label: 'Обычно',      hint: 'Прямой содержательный ответ без скрытого длинного цикла', think: false, temperature: 0.55, num_ctx: 24576, max_tokens: 8192 },
  think:  { label: 'Рассуждение', hint: 'Проверка сложной задачи с ограниченным рассуждением',     think: true,  temperature: 0.7,  num_ctx: 32768, max_tokens: 8192 },
};

// Полупрозрачные красные уведомления в правом верхнем углу — живут вне
// #app (который render() полностью перерисовывает), чтобы не исчезать
// раньше времени при следующей перерисовке интерфейса.
const toastStack = document.createElement('div');
toastStack.className = 'toast-stack';
document.body.appendChild(toastStack);
function showToast(message, type = 'error') {
  // Не дублируем одинаковые уведомления и не превращаем интерфейс в лог.
  if (Array.from(toastStack.querySelectorAll('.toast-msg')).some((el) => el.textContent === message)) return;
  const t = document.createElement('div');
  t.className = `toast${type === 'info' ? ' toast--info' : ''}`;
  t.innerHTML = `<span class="toast-msg"></span><button type="button" class="toast-close" title="Закрыть">${icon('close', 12)}</button>`;
  t.querySelector('.toast-msg').textContent = message;
  toastStack.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  const dismiss = () => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 250);
  };
  const timer = setTimeout(dismiss, type === 'info' ? 3200 : 6500);
  t.querySelector('.toast-close').onclick = () => { clearTimeout(timer); dismiss(); };
}

// ============================================================
// Шторка с источниками поиска — выезжает снизу на половину поверх
// всего интерфейса (живёт вне #app по той же причине, что и toastStack).
// Клик по верхней (затемнённой) половине закрывает её, клик по источнику
// открывает ссылку в системном браузере.
// ============================================================
const searchSheet = document.createElement('div');
searchSheet.className = 'search-sheet';
searchSheet.innerHTML = `
  <div class="search-sheet-scrim"></div>
  <div class="search-sheet-panel">
    <div class="search-sheet-handle"></div>
    <div class="search-sheet-query"></div>
    <div class="search-sheet-sources"></div>
  </div>`;
document.body.appendChild(searchSheet);
searchSheet.querySelector('.search-sheet-scrim').onclick = closeSearchSheet;
searchSheet.querySelector('.search-sheet-sources').onclick = (e) => {
  const src = e.target.closest('.search-source');
  if (src?.dataset.url) openUrl(src.dataset.url).catch(() => {});
};
function openSearchSheet(search) {
  searchSheet.querySelector('.search-sheet-query').textContent = `«${search.query}»`;
  const sources = search.sources || [];
  searchSheet.querySelector('.search-sheet-sources').innerHTML =
    sources
      .map(
        (s) => `<div class="search-source" data-url="${escapeHtml(s.url)}">
          <span class="search-source-title">${escapeHtml(s.title || s.url)}</span>
          <span class="search-source-url">${escapeHtml(hostFromUrl(s.url))}</span>
        </div>`
      )
      .join('') || '<p class="hint">Источники не найдены</p>';
  searchSheet.classList.add('open');
}
function closeSearchSheet() {
  searchSheet.classList.remove('open');
}

// ============================================================
// Иконки — плоские line-icons (SVG, currentColor), без эмодзи.
// ============================================================
const ICONS = {
  close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
  edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>',
  arrowUp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>',
  square: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="7" y="7" width="10" height="10" rx="1.5"/></svg>',
  loader: '<svg class="spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 12a9 9 0 1 1-6.2-8.56"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><polyline points="23 20 23 14 17 14"/><path d="M20.49 9A9 9 0 0 0 5.6 5.6L1 10m22 4-4.6 4.4A9 9 0 0 1 3.51 15"/></svg>',
  chevronDown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  panel: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="9" y1="4" x2="9" y2="20"/></svg>',
  cloud: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 19H9a5 5 0 1 1 1.3-9.8A6 6 0 0 1 22 12.5 4.5 4.5 0 0 1 17.5 19Z"/></svg>',
  dot: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="5"/></svg>',
  calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><line x1="16" y1="3" x2="16" y2="7"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="3" y1="11" x2="21" y2="11"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16"/><circle cx="12" cy="7.6" r=".6" fill="currentColor" stroke="none"/></svg>',
  helpCircle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.5 2.5 0 1 1 4.4 1.65c-.85.8-2.1 1.15-2.1 2.6"/><circle cx="12" cy="17" r=".7" fill="currentColor" stroke="none"/></svg>',
  file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><polyline points="14 2 14 8 20 8"/></svg>',
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18Z"/></svg>',
  chevronRight: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 6 15 12 9 18"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>',
  code: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="8 9 4 12 8 15"/><polyline points="16 9 20 12 16 15"/><line x1="14" y1="5" x2="10" y2="19"/></svg>',
  spark: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2c.6 3.6 2.4 5.4 6 6-3.6.6-5.4 2.4-6 6-.6-3.6-2.4-5.4-6-6 3.6-.6 5.4-2.4 6-6Z"/><path d="M19 15c.3 1.7 1.1 2.5 2.8 2.8-1.7.3-2.5 1.1-2.8 2.8-.3-1.7-1.1-2.5-2.8-2.8 1.7-.3 2.5-1.1 2.8-2.8Z"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  starFilled: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 0 1-14 0"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>',
  brain: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/><path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/><path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/><path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/><path d="M3.477 10.896a4 4 0 0 1 .585-.396"/><path d="M19.938 10.5a4 4 0 0 1 .585.396"/><path d="M6 18a4 4 0 0 1-1.967-.516"/><path d="M19.967 17.484A4 4 0 0 1 18 18"/></svg>',
};
function icon(name, size = 16) {
  return `<span class="icon" style="width:${size}px;height:${size}px">${ICONS[name] || ''}</span>`;
}

const LANG_EXT = {
  js: 'js', javascript: 'js', jsx: 'jsx', ts: 'ts', typescript: 'ts', tsx: 'tsx',
  py: 'py', python: 'py', rb: 'rb', ruby: 'rb', rs: 'rs', rust: 'rs',
  go: 'go', java: 'java', kt: 'kt', kotlin: 'kt', swift: 'swift', c: 'c', cpp: 'cpp', 'c++': 'cpp',
  cs: 'cs', 'c#': 'cs', php: 'php', html: 'html', css: 'css', scss: 'scss',
  json: 'json', yaml: 'yaml', yml: 'yml', xml: 'xml', sql: 'sql',
  sh: 'sh', bash: 'sh', zsh: 'sh', md: 'md', markdown: 'md', txt: 'txt',
  // Не-текстовые форматы документов — модель пишет лёгкую markdown-разметку
  // в теле блока, а fileGenerators.js собирает из неё настоящий бинарный
  // файл (см. BINARY_FORMATS ниже и обработчик .download-code).
  pdf: 'pdf', pptx: 'pptx', ppt: 'pptx', docx: 'docx', doc: 'docx', xlsx: 'xlsx', xls: 'xlsx',
};
function extensionForLang(lang) {
  const key = (lang || '').trim().toLowerCase();
  return LANG_EXT[key] || 'txt';
}
function isNearBottom(el, threshold = 80) {
  return el.scrollHeight - el.scrollTop - el.clientHeight <= threshold;
}
function scrollStateFor(chat = active) {
  if (!chat) return { top: 0, follow: true };
  if (!chatScrollState.has(chat.id)) chatScrollState.set(chat.id, { top: 0, follow: true, manualUntil: 0 });
  return chatScrollState.get(chat.id);
}
function pinMessagesToBottom(el) {
  if (!el) return;
  el.scrollTop = Math.max(0, el.scrollHeight - el.clientHeight);
  const state = scrollStateFor();
  state.top = el.scrollTop;
  state.follow = true;
  state.manualUntil = 0;
}
function cancelScrollAnimation() {
  if (scrollAnimationFrame !== null) cancelAnimationFrame(scrollAnimationFrame);
  scrollAnimationFrame = null;
}
// Собственная короткая анимация надёжно перебивает инерцию WKWebView, но не
// отключает overflow и не прячет полосу прокрутки. Любой новый жест отменяет её.
function animateMessagesToBottom(el) {
  cancelScrollAnimation();
  const started = performance.now();
  const from = el.scrollTop;
  const duration = 240;
  const step = (now) => {
    const t = Math.min(1, (now - started) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    const target = Math.max(0, el.scrollHeight - el.clientHeight);
    el.scrollTop = from + (target - from) * eased;
    if (t < 1) scrollAnimationFrame = requestAnimationFrame(step);
    else { scrollAnimationFrame = null; pinMessagesToBottom(el); }
  };
  scrollAnimationFrame = requestAnimationFrame(step);
}

// Изменение размера окна (в т.ч. функцией уменьшения окна на Mac) само по
// себе не создаёт событие scroll, поэтому без этого обработчика видимость
// кнопки "вниз" могла бы остаться устаревшей после ресайза — например,
// пользователь был у самого низа, окно стало ниже (то же место экрана
// теперь дальше от низа в пикселях), а кнопка "вниз" ещё не показалась бы
// до следующей прокрутки. Пересчитываем сразу, с небольшим троттлингом,
// чтобы не дёргать это на каждый промежуточный кадр во время драга ресайза.
let resizeThrottle = null;
window.addEventListener('resize', () => {
  if (resizeThrottle) return;
  resizeThrottle = setTimeout(() => {
    resizeThrottle = null;
    const messagesArea = document.querySelector('#messages');
    const scrollBtn = document.querySelector('#scrollBottom');
    if (!messagesArea || !scrollBtn) return;
    const state = scrollStateFor();
    if (state.follow) pinMessagesToBottom(messagesArea);
    else {
      state.top = messagesArea.scrollTop;
      if (isNearBottom(messagesArea)) state.follow = true;
    }
    scrollBtn.hidden = state.follow;
  }, 120);
});

// Приветствия по времени суток — показываются СТРОГО в своё окно, никогда
// невпопад (например, "Доброе утро" вечером). Окна не пересекаются и
// покрывают все 24 часа; ночное оборачивается через полночь (23:00–04:59).
const TIME_GREETINGS = [
  { id: 'night', text: 'Доброй ночи', withName: (n) => `Доброй ночи, ${n}`, from: 23, to: 5 },
  { id: 'morning', text: 'Доброе утро', withName: (n) => `Доброе утро, ${n}`, from: 5, to: 12 },
  { id: 'day', text: 'Добрый день', withName: (n) => `Добрый день, ${n}`, from: 12, to: 18 },
  { id: 'evening', text: 'Добрый вечер', withName: (n) => `Добрый вечер, ${n}`, from: 18, to: 23 },
];
function timeGreetingEntry() {
  const h = new Date().getHours();
  return TIME_GREETINGS.find((g) => (g.from < g.to ? h >= g.from && h < g.to : h >= g.from || h < g.to)) || TIME_GREETINGS[2];
}

// 16 нейтральных приветствий, не привязанных ко времени суток — могут
// выпасть в любой час, вперемешку с тем единственным приветствием по
// времени, которое сейчас актуально (итого пул из 20 вариантов на выбор).
// У каждого — свой ответ на вопрос "куда вставлять имя": withName задаёт
// ПОЛНУЮ фразу с именем на естественном месте (не обязательно в конце и не
// через запятую вслепую), а если withName не задан — это осознанно "чисто
// нейтральная" фраза, которая с именем звучала бы неестественно, и имя к
// ней вообще не подставляется, каким бы ни было store.userName.
const NEUTRAL_GREETINGS = [
  { id: 'n1', text: 'С чем сегодня поработаем?', withName: (n) => `С чем сегодня поработаем, ${n}?` },
  { id: 'n2', text: 'Привет! Готов помочь.', withName: (n) => `Привет, ${n}! Готов помочь.` },
  { id: 'n3', text: 'Чем займёмся?', withName: (n) => `Чем займёмся, ${n}?` },
  { id: 'n4', text: 'Слушаю — что нужно сделать?' },
  { id: 'n5', text: 'Есть задача? Давай разберёмся.' },
  { id: 'n6', text: 'Рад видеть. С чего начнём?', withName: (n) => `Рад видеть, ${n}. С чего начнём?` },
  { id: 'n7', text: 'Готов к работе — что в планах?' },
  { id: 'n8', text: 'На связи. Что обсудим?', withName: (n) => `На связи, ${n}. Что обсудим?` },
  { id: 'n9', text: 'Какой вопрос сегодня?' },
  { id: 'n10', text: 'Помогу разобраться — рассказывай.' },
  { id: 'n11', text: 'Что интересует?' },
  { id: 'n12', text: 'Давай к делу — с чем помочь?' },
  { id: 'n13', text: 'Здесь и готов помочь.' },
  { id: 'n14', text: 'Спрашивай — постараюсь разобраться.' },
  { id: 'n15', text: 'Чем могу быть полезен?', withName: (n) => `Чем могу быть полезен, ${n}?` },
  { id: 'n16', text: 'Готов слушать.' },
];

function findGreetingById(id) {
  if (id === 'time') return timeGreetingEntry();
  return NEUTRAL_GREETINGS.find((g) => g.id === id) || NEUTRAL_GREETINGS[0];
}
// Храним не готовую строку и не весь объект (с функцией withName внутри
// не переживёт JSON.stringify при сохранении в localStorage), а лёгкий
// id — по нему всегда можно заново найти живой объект с его withName.
function pickGreetingId() {
  const ids = ['time', ...NEUTRAL_GREETINGS.map((g) => g.id)];
  return ids[Math.floor(Math.random() * ids.length)];
}
function formatGreeting(entry, name) {
  return name && entry.withName ? entry.withName(name) : entry.text;
}

// Приветствие на главном экране (пустой диалог). id выбирается один раз —
// при создании диалога, если он есть (active.greetingId), либо один раз на
// текущий сеанс, если диалогов ещё вообще нет (sessionGreetingId, active
// === null — например сразу после первого запуска). Без этой развилки
// приветствие раньше молча пропадало, когда открывать было ещё нечего.
let sessionGreetingId = null;
function greetingPhrase() {
  const name = (store.userName || '').trim();
  if (active) {
    if (!active.greetingId) active.greetingId = pickGreetingId();
    return formatGreeting(findGreetingById(active.greetingId), name);
  }
  if (!sessionGreetingId) sessionGreetingId = pickGreetingId();
  return formatGreeting(findGreetingById(sessionGreetingId), name);
}

function focusActiveComposer() {
  requestAnimationFrame(() => document.querySelector('#prompt')?.focus({ preventScroll: true }));
}

function newChat() {
  // Повторный клик в уже открытом пустом диалоге ничего не создаёт.
  if (isUnusedChat(active)) {
    searchQuery = '';
    editingIndex = null;
    render();
    focusActiveComposer();
    return active;
  }

  // Если пустой «Новый диалог» уже был создан, но пользователь находится в
  // другом чате, открываем существующий — не размножаем пустые записи.
  const existing = store.chats.find(isUnusedChat);
  if (existing) {
    active = existing;
    searchQuery = '';
    editingIndex = null;
    save();
    render();
    focusActiveComposer();
    return active;
  }

  active = {
    id: nextChatId(store.chats), title: 'Новый диалог', messages: [], pendingAttachments: [], activeTopicId: 0,
    provider: store.provider, localModel: store.localModel, groqModel: store.groqModel,
    customGroqModel: store.customGroqModel, effort: store.effort,
  };
  store.chats.unshift(active);
  searchQuery = '';
  editingIndex = null;
  save();
  render();
  focusActiveComposer();
  return active;
}

function chatMatches(chat, query) {
  if (!query) return true;
  const text = [chat.title, ...(chat.messages || []).map((m) => m.content || '')].join(' ').toLocaleLowerCase('ru');
  return text.includes(query.toLocaleLowerCase('ru'));
}

function groupChats(chats) {
  const startOfDay = (t) => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const now = new Date();
  const today = startOfDay(now.getTime());
  const yesterday = today - 86400000;
  const daysFromMonday = (now.getDay() + 6) % 7;
  const weekStart = today - daysFromMonday * 86400000;
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).setHours(0, 0, 0, 0);
  const groups = { 'Сегодня': [], 'Вчера': [], 'На этой неделе': [], 'В этом месяце': [], 'Позже': [] };
  for (const c of chats) {
    // updatedAt обновляется при каждой отправке — старый диалог, к которому
    // вернулись сегодня, окажется в «Сегодня», а не в своей исходной группе.
    const day = startOfDay(c.updatedAt || c.id);
    if (day === today) groups['Сегодня'].push(c);
    else if (day === yesterday) groups['Вчера'].push(c);
    else if (day >= weekStart) groups['На этой неделе'].push(c);
    else if (day >= monthStart) groups['В этом месяце'].push(c);
    else groups['Позже'].push(c);
  }
  return groups;
}

function openModal(html, className = '') {
  const d = document.querySelector('#modal');
  d.className = className;
  d.innerHTML = html;
  d.showModal();
  return d;
}

// Разбивает код на пронумерованные строки (таблица: номер + содержимое) —
// нужно, чтобы номера строк были видны и не переносились вместе с текстом,
// а горизонтальная прокрутка была только у содержимого длинных строк.
function renderCodeLines(text) {
  const lines = String(text || '').replace(/\r\n/g, '\n').split('\n');
  const gutter = String(Math.max(lines.length, 1)).length;
  return `<div class="preview-code-lines">${lines
    .map((line, i) => `<div class="code-line"><span class="code-ln" style="min-width:${gutter + 1}ch">${i + 1}</span><span class="code-lc">${escapeHtml(line) || ' '}</span></div>`)
    .join('')}</div>`;
}

function parsePreviewTable(text) {
  const rows = [];
  for (const raw of String(text || '').replace(/\r\n/g, '\n').split('\n')) {
    const line = raw.trim();
    if (!line.startsWith('|') || !line.includes('|', 1)) continue;
    if (/^\|?\s*:?-{3,}/.test(line.replace(/\|/g, '').trim()) || /^(\|\s*:?-+:?\s*)+\|$/.test(line)) continue;
    const cells = line.replace(/^\||\|$/g, '').split('|').map((cell) => cell.trim());
    if (cells.length) rows.push(cells);
  }
  if (rows.length >= 1) return rows;
  const tsv = String(text || '').replace(/\r\n/g, '\n').split('\n')
    .map((line) => line.split('\t'))
    .filter((row) => row.some((cell) => String(cell || '').trim()));
  return tsv.some((row) => row.length > 1) ? tsv : [];
}

function renderSheetPreview(text) {
  const tables = [];
  const chunks = String(text || '').split(/\n{2,}/);
  for (const chunk of chunks) {
    const rows = parsePreviewTable(chunk);
    if (rows.length) tables.push(rows);
  }
  if (!tables.length) {
    const rows = parsePreviewTable(text);
    if (rows.length) tables.push(rows);
  }
  if (!tables.length) {
    return `<pre class="preview-text">${escapeHtml(text || '')}</pre>`;
  }
  return tables.map((rows) => {
    const width = Math.max(...rows.map((row) => row.length), 1);
    const normalized = rows.map((row) => {
      const next = row.slice();
      while (next.length < width) next.push('');
      return next;
    });
    const head = normalized[0];
    const body = normalized.slice(1);
    return `<div class="preview-sheet-wrap"><table class="preview-sheet">
      <thead><tr>${head.map((cell) => `<th>${escapeHtml(cell)}</th>`).join('')}</tr></thead>
      <tbody>${(body.length ? body : [['']]).map((row) => `<tr>${row.map((cell) => `<td>${escapeHtml(cell)}</td>`).join('')}</tr>`).join('')}</tbody>
    </table></div>`;
  }).join('');
}

// Предпросмотр по клику на карточку файла (не на кнопку "Скачать"). Для
// готовых документов показывает визуальное представление; для кода — код
// с номерами строк. Модалка шире обычной (см. .modal-preview в style.css).
const CODE_PREVIEW_EXTS = new Set([
  'js','jsx','mjs','cjs','ts','tsx','py','rb','rs','go','java','kt','kts','swift','c','h','cpp','hpp','cc','cs',
  'php','sh','bash','zsh','sql','css','scss','less','vue','svelte','json','jsonc','xml','yml','yaml','toml',
  'ini','env','conf','cfg','lua','r','pl','pm','ex','exs','erl','hs','clj','scala','gradle','dart','kt',
]);

function parsePptxPreviewSlides(sourceText, extractedSlides = null) {
  const fromExtracted = Array.isArray(extractedSlides)
    ? extractedSlides.map((text) => String(text || '').trim()).filter(Boolean)
    : [];
  const source = String(sourceText || '').replace(/\r\n/g, '\n');
  const chunks = fromExtracted.length
    ? fromExtracted
    : source.split(/\n\s*---\s*\n/).map((item) => item.trim()).filter(Boolean);
  if (!chunks.length && source.trim()) chunks.push(source.trim());
  return chunks.map((raw, index) => {
    const images = [];
    const clean = raw.replace(/!\[img:([^\]\n]+)\]/g, (_, name) => { images.push(name.trim()); return ''; });
    const lines = clean.split('\n').map((line) => line.trim()).filter(Boolean);
    let title = '';
    const bullets = [];
    const body = [];
    for (const line of lines) {
      if (!title && /^#{1,3}\s+/.test(line)) title = line.replace(/^#{1,3}\s+/, '');
      else if (/^[-*]\s+/.test(line)) bullets.push(line.replace(/^[-*]\s+/, ''));
      else if (!title) title = line.replace(/^#+\s*/, '');
      else body.push(line);
    }
    return { title: title || `Слайд ${index + 1}`, body, bullets, images };
  });
}

async function buildPptxPreview(sourceText, chatId, extractedSlides = null) {
  const slides = parsePptxPreviewSlides(sourceText, extractedSlides);
  if (!slides.length) return '<div class="preview-loading">В презентации нет слайдов</div>';
  for (const slide of slides) {
    slide.imageUrls = [];
    for (const name of slide.images.slice(0, 4)) {
      const url = await readSandboxImageForPptx(chatId, name);
      if (url && !slide.imageUrls.includes(url)) slide.imageUrls.push(url);
    }
  }
  const slideHtml = slides.map((slide, index) => {
    const images = slide.imageUrls.length
      ? `<div class="pptx-preview-images count-${slide.imageUrls.length}">${slide.imageUrls.map((url) => `<img src="${url}" alt="">`).join('')}</div>`
      : '';
    return `<section class="pptx-preview-slide" data-pptx-slide="${index}" ${index ? 'hidden' : ''}>
      <div class="pptx-preview-copy">
        <h1>${escapeHtml(slide.title)}</h1>
        ${slide.body.length ? `<div class="pptx-preview-body">${slide.body.map((line) => `<p>${escapeHtml(line)}</p>`).join('')}</div>` : ''}
        ${slide.bullets.length ? `<ul>${slide.bullets.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>` : ''}
      </div>${images}
    </section>`;
  }).join('');
  const thumbs = slides.map((slide, index) => `<button type="button" class="pptx-preview-thumb${index ? '' : ' active'}" data-pptx-target="${index}"><b>${index + 1}</b><span>${escapeHtml(slide.title)}</span></button>`).join('');
  return `<div class="pptx-preview">
    <div class="pptx-preview-stage">${slideHtml}</div>
    <div class="pptx-preview-controls">
      <button type="button" data-pptx-prev>←</button>
      <span data-pptx-counter>1 / ${slides.length}</span>
      <button type="button" data-pptx-next>→</button>
    </div>
    <div class="pptx-preview-thumbs">${thumbs}</div>
  </div>`;
}

function bindPptxPreview(root) {
  const slides = [...root.querySelectorAll('[data-pptx-slide]')];
  const thumbs = [...root.querySelectorAll('[data-pptx-target]')];
  if (!slides.length) return;
  let current = 0;
  const show = (index) => {
    current = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => { slide.hidden = i !== current; });
    thumbs.forEach((thumb, i) => thumb.classList.toggle('active', i === current));
    const counter = root.querySelector('[data-pptx-counter]');
    if (counter) counter.textContent = `${current + 1} / ${slides.length}`;
    thumbs[current]?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  };
  root.querySelector('[data-pptx-prev]')?.addEventListener('click', () => show(current - 1));
  root.querySelector('[data-pptx-next]')?.addEventListener('click', () => show(current + 1));
  thumbs.forEach((thumb, index) => thumb.addEventListener('click', () => show(index)));
}

async function openFilePreview(name, ext, isDoc, sourceText, extractedSlides = null) {
  const d = document.querySelector('#modal');
  d.className = 'modal-preview';
  const normalizedExt = (ext || '').toLowerCase();
  let bodyHtml;
  if (normalizedExt === 'html' || normalizedExt === 'htm') {
    bodyHtml = '<iframe class="preview-frame preview-html" sandbox="allow-scripts allow-forms allow-modals allow-popups allow-downloads"></iframe>';
  } else if (normalizedExt === 'pdf') {
    bodyHtml = '<iframe class="preview-frame preview-pdf"></iframe>';
  } else if (normalizedExt === 'pptx' || normalizedExt === 'ppt') {
    bodyHtml = '<div class="preview-loading">Собираю предпросмотр слайдов…</div>';
  } else if (normalizedExt === 'xlsx' || normalizedExt === 'xls' || normalizedExt === 'csv') {
    bodyHtml = renderSheetPreview(sourceText || '');
  } else if (isDoc || ['md','markdown'].includes(normalizedExt)) {
    bodyHtml = `<div class="preview-doc">${renderMarkdown(sourceText || '')}</div>`;
  } else if (CODE_PREVIEW_EXTS.has(normalizedExt) || normalizedExt === 'json') {
    let formatted = sourceText || '';
    if (normalizedExt === 'json') {
      try { formatted = JSON.stringify(JSON.parse(formatted), null, 2); } catch {}
    }
    bodyHtml = `<div class="preview-code">${renderCodeLines(formatted)}</div>`;
  } else {
    bodyHtml = `<div class="preview-code">${renderCodeLines(sourceText || '')}</div>`;
  }
  d.innerHTML = `
    <div class="preview-head">
      <h2>${escapeHtml(name)}${ext ? `<span class="codeblock-dot">·</span><span class="codeblock-ext">${escapeHtml(ext.toUpperCase())}</span>` : ''}</h2>
      <div class="preview-corner-actions">
        <button type="button" id="copyPreview" class="icon-btn preview-corner-btn" title="Копировать содержимое">${icon('copy', 15)}</button>
        <button type="button" id="closePreview" class="icon-btn preview-corner-btn" title="Закрыть">${icon('close', 16)}</button>
      </div>
    </div>
    <div class="preview-body">${bodyHtml}</div>`;
  d.showModal();
  document.activeElement?.blur();
  d.querySelector('#closePreview').onclick = () => d.close();
  d.querySelector('#copyPreview').onclick = () => {
    navigator.clipboard.writeText(sourceText || '').then(() => {
      const btn = d.querySelector('#copyPreview');
      const orig = btn.innerHTML;
      btn.innerHTML = icon('check', 15);
      setTimeout(() => { btn.innerHTML = orig; }, 1500);
    }).catch(() => showToast('Не удалось скопировать'));
  };
  if (normalizedExt === 'html' || normalizedExt === 'htm') {
    d.querySelector('.preview-html').srcdoc = sourceText || '';
  } else if (normalizedExt === 'pptx' || normalizedExt === 'ppt') {
    const body = d.querySelector('.preview-body');
    if (body) {
      body.innerHTML = await buildPptxPreview(sourceText, active?.id, extractedSlides);
      bindPptxPreview(body);
    }
  } else if (normalizedExt === 'pdf') {
    try {
      const base64 = await generateBinaryFileBase64('pdf', sourceText || '', active?.id);
      const frame = d.querySelector('.preview-pdf');
      if (frame) frame.src = `data:application/pdf;base64,${base64}`;
    } catch {
      const body = d.querySelector('.preview-body');
      if (body) body.innerHTML = '<div class="preview-loading">Не удалось собрать предпросмотр PDF</div>';
    }
  }
  d.addEventListener('close', () => d.classList.remove('modal-preview'), { once: true });
}

async function openSandboxFilePreview(filename) {
  let preview;
  try {
    preview = await invoke('sandbox_preview_file', { chatId: String(active.id), filename });
  } catch (err) {
    showToast(`Не удалось загрузить предпросмотр: ${String(err || '')}`);
    return;
  }
  const ext = (preview.ext || filename.split('.').pop() || '').toLowerCase();
  if (preview.kind === 'text' || preview.kind === 'document') {
    await openFilePreview(filename, ext, preview.kind === 'document', preview.content || '', preview.slides || null);
    return;
  }

  const d = document.querySelector('#modal');
  d.className = 'modal-preview';
  const body = preview.kind === 'image'
    ? `<div class="sandbox-preview-image-wrap"><img class="sandbox-preview-image" src="${preview.content}" alt="${escapeHtml(filename)}"></div>`
    : `<iframe class="preview-frame preview-pdf" src="${preview.content}"></iframe>`;
  d.innerHTML = `
    <div class="preview-head">
      <h2>${escapeHtml(filename)}<span class="codeblock-dot">·</span><span class="codeblock-ext">${escapeHtml(ext.toUpperCase())}</span></h2>
      <button type="button" id="closePreview" class="icon-btn preview-corner-btn" title="Закрыть">${icon('close', 16)}</button>
    </div>
    <div class="preview-body">${body}</div>`;
  d.showModal();
  d.querySelector('#closePreview').onclick = () => d.close();
  d.addEventListener('close', () => d.classList.remove('modal-preview'), { once: true });
}

function confirmDialog(title, body, confirmLabel) {
  return new Promise((resolve) => {
    const d = openModal(`
      <h2>${escapeHtml(title)}</h2>
      <p class="modal-body">${escapeHtml(body)}</p>
      <div class="actions">
        <button type="button" id="mCancel">Отмена</button>
        <button type="button" id="mConfirm" class="danger">${escapeHtml(confirmLabel)}</button>
      </div>`);
    d.querySelector('#mCancel').onclick = () => { d.close(); resolve(false); };
    d.querySelector('#mConfirm').onclick = () => { d.close(); resolve(true); };
  });
}

function renamePrompt(current) {
  return new Promise((resolve) => {
    const d = openModal(`
      <h2>Переименовать диалог</h2>
      <input id="mRename" value="${escapeHtml(current)}" maxlength="60">
      <div class="actions">
        <button type="button" id="mCancel">Отмена</button>
        <button type="button" id="mSave" class="primary">Сохранить</button>
      </div>`);
    const input = d.querySelector('#mRename');
    input.focus();
    input.select();
    const submit = () => { const v = input.value.trim(); d.close(); resolve(v || null); };
    input.onkeydown = (e) => { if (e.key === 'Enter') submit(); };
    d.querySelector('#mCancel').onclick = () => { d.close(); resolve(null); };
    d.querySelector('#mSave').onclick = submit;
  });
}

function pinChat(id) {
  const chat = store.chats.find((c) => c.id === id);
  if (!chat) return;
  chat.pinned = !chat.pinned;
  save();
  const chatsEl = document.querySelector('.chats');
  if (chatsEl) { chatsEl.innerHTML = buildChatListHtml(); bindChatRowHandlers(chatsEl); }
}

async function deleteChat(id) {
  const chat = store.chats.find((c) => c.id === id);
  if (!chat) return;
  const ok = await confirmDialog('Удалить диалог?', `«${chat.title}» будет удалён без возможности восстановления.`, 'Удалить');
  if (!ok) return;
  const index = store.chats.findIndex((c) => c.id === id);
  store.chats.splice(index, 1);
  if (active?.id === id) active = store.chats[0] || null;
  invoke('sandbox_delete_all', { chatId: String(id) }).catch(() => {});
  save();
  render();
}

async function renameChat(id) {
  const chat = store.chats.find((c) => c.id === id);
  if (!chat) return;
  const next = await renamePrompt(chat.title);
  if (!next) return;
  chat.title = next.slice(0, 60);
  save();
  render();
}

function formatTime(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

const LONG_MSG_LIMIT = 600; // символов — после этого сообщение пользователя сворачивается
function hostFromUrl(u) {
  try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; }
}

// Строка статусов над ответом ассистента — может показывать сразу несколько
// этапы ответа. После завершения они остаются в истории как компактный
// отчёт о выполненной работе; мерцание отключается, но сам статус не исчезает.
function statusRowHtml(m, i) {
  if (m.role !== 'assistant') return `<div class="status-row-slot" data-status-index="${i}"></div>`;
  const chips = [];
  if (m.retryStatus && !m.retryStatus.done) {
    const chip = `<div class="status-chip pending">${icon('loader', 13)}<span class="status-chip-label">Перезапуск ответа</span></div>`;
    return `<div class="status-row-slot" data-status-index="${i}"><div class="status-row">${chip}</div></div>`;
  }
  if (m.filesStatus && !m.filesStatus.done) {
    const chip = `<div class="status-chip pending">${icon('file', 13)}<span class="status-chip-label">Работа с документами</span></div>`;
    return `<div class="status-row-slot" data-status-index="${i}"><div class="status-row">${chip}</div></div>`;
  }
  if (m.questionStatus && !m.questionStatus.done) {
    const chip = `<div class="status-chip pending">${icon('helpCircle', 13)}<span class="status-chip-label">Генерация вопросов</span></div>`;
    return `<div class="status-row-slot" data-status-index="${i}"><div class="status-row">${chip}</div></div>`;
  }
  if (m.imagePreparationStatus) {
    const count = Math.max(1, Number(m.imagePreparationStatus.count) || (m.sandboxImages || []).length || 1);
    const label = m.imagePreparationStatus.done
      ? (count === 1 ? 'Изображение готово' : 'Изображения готовы')
      : (count === 1 ? 'Подготовка изображения' : 'Подготовка изображений');
    chips.push(`<div class="status-chip${m.imagePreparationStatus.done ? '' : ' pending'}">${icon('image', 13)}<span class="status-chip-label">${label}</span></div>`);
  }
  if (m.imageStatus) {
    chips.push(`<div class="status-chip${m.imageStatus.done ? '' : ' pending'}">${icon('image', 13)}<span class="status-chip-label">Анализ изображения</span></div>`);
  }
  if (m.audioStatus) {
    chips.push(`<div class="status-chip${m.audioStatus.done ? '' : ' pending'}">${icon('mic', 13)}<span class="status-chip-label">${m.audioStatus.done ? 'Аудио распознано' : 'Распознаю аудио'}</span></div>`);
  }
  if (m.thinkStatus) {
    chips.push(`<div class="status-chip${m.thinkStatus.done ? '' : ' pending'}">${icon('spark', 13)}<span class="status-chip-label">${m.thinkStatus.done ? 'Думал' : 'Думаю'}</span></div>`);
  }
  if (m.codeStatus) {
    chips.push(`<div class="status-chip${m.codeStatus.done ? '' : ' pending'}">${icon('code', 13)}<span class="status-chip-label">Работа с кодом</span></div>`);
  }
  if (m.filesStatus) {
    chips.push(`<div class="status-chip">${icon('file', 13)}<span class="status-chip-label">Документы готовы</span></div>`);
  }
  if (m.stopped) {
    chips.push(`<div class="status-chip status-chip--stopped">${icon('square', 11)}<span class="status-chip-label">Остановлено</span></div>`);
  }
  if (m.search) {
    const search = m.search;
    const hasSources = (search.sources || []).length > 0;
    chips.push(`<div class="status-chip status-chip--search${search.done ? '' : ' pending'}">
      ${icon('globe', 13)}
      <span class="status-chip-label">Поиск в интернете</span>
      <button type="button" class="search-indicator-toggle" data-search-toggle="${i}" title="Показать источники" ${hasSources ? '' : 'disabled'}>${icon('chevronRight', 13)}</button>
    </div>`);
  }
  if (!chips.length) return `<div class="status-row-slot" data-status-index="${i}"></div>`;
  return `<div class="status-row-slot" data-status-index="${i}"><div class="status-row">${chips.join('')}</div></div>`;
}

const GALLERY_MARKER_RE = /\uE000AMIGO_GALLERY:([a-zA-Z0-9_-]+)\uE001/g;
function galleryMarker(id) { return `\uE000AMIGO_GALLERY:${id}\uE001`; }
function stripGalleryMarkers(text) { return String(text || '').replace(GALLERY_MARKER_RE, ''); }
function longestSuffixPrefix(text, pattern) {
  if (!text || !pattern) return 0;
  const prefix = new Array(pattern.length).fill(0);
  for (let i = 1, j = 0; i < pattern.length; i++) {
    while (j > 0 && pattern[i] !== pattern[j]) j = prefix[j - 1];
    if (pattern[i] === pattern[j]) j += 1;
    prefix[i] = j;
  }
  let matched = 0;
  for (let i = 0; i < text.length; i++) {
    while (matched > 0 && text[i] !== pattern[matched]) matched = prefix[matched - 1];
    if (text[i] === pattern[matched]) matched += 1;
    if (matched === pattern.length && i < text.length - 1) matched = prefix[matched - 1];
  }
  return matched;
}

function knownSandboxFilenames(chat = active) {
  const names = new Set();
  for (const message of chat?.messages || []) {
    for (const name of message.sandboxFiles || []) if (name) names.add(name);
    for (const name of message.generatedFiles || []) if (name) names.add(name);
    for (const image of message.sandboxImages || []) if (image?.name) names.add(image.name);
    for (const attachment of message.attachments || []) if (attachment?.sandboxPath) names.add(attachment.sandboxPath);
  }
  for (const attachment of chat?.pendingAttachments || []) {
    if (attachment?.sandboxPath) names.add(attachment.sandboxPath);
  }
  return [...names];
}

function renderAssistantContent(message, msgIndex, streaming = false) {
  const source = assistantDisplayContent(message, !streaming);
  const groups = message.galleryGroups || {};
  const sandboxFiles = knownSandboxFilenames();
  const rendered = [];
  let cursor = 0;
  let match;
  GALLERY_MARKER_RE.lastIndex = 0;
  while ((match = GALLERY_MARKER_RE.exec(source)) !== null) {
    const before = source.slice(cursor, match.index);
    if (before.trim()) {
      const text = streaming ? stabilizeStreamingMarkdown(stripPendingBlocks(before)) : before;
      rendered.push(renderMarkdown(text, {
        msgIndex, answers: message.questionAnswers || {}, hideQuestions: !!message.questionDismissed, hideCodeBlocks: !!message.codeOnlyFiles, sandboxFiles, scope: `segment-${rendered.length}`,
      }));
    }
    rendered.push(sandboxImagesRowHtml(message, msgIndex, groups[match[1]] || [], match[1]));
    cursor = match.index + match[0].length;
  }
  const tail = source.slice(cursor);
  if (tail.trim()) {
    const text = streaming ? stabilizeStreamingMarkdown(stripPendingBlocks(tail)) : tail;
    rendered.push(renderMarkdown(text, {
      msgIndex, answers: message.questionAnswers || {}, hideQuestions: !!message.questionDismissed, hideCodeBlocks: !!message.codeOnlyFiles, sandboxFiles, scope: `segment-${rendered.length}`,
    }));
  }

  // Старые сообщения не содержат marker: сохраняем прежнее расположение
  // галереи сверху. Непривязанные новые изображения тоже не теряются.
  const groupedNames = new Set(Object.values(groups).flat());
  const ungrouped = (message.sandboxImages || [])
    .map((image) => image.name)
    .filter((name) => name && !groupedNames.has(name));
  if (ungrouped.length) rendered.unshift(sandboxImagesRowHtml(message, msgIndex, ungrouped, 'legacy'));
  const result = rendered.join('');
  if (result) return result;
  if ((message.sandboxFiles || []).length || (message.generatedFiles || []).length) return '';
  const questions = parseQuestionBlocks(message.content || '');
  if (questions.length && message.questionAnswers) {
    const resolved = questions.every((question) => message.questionAnswers[question.qid] !== undefined);
    if (resolved) return questionReceiptHtml(message.questionAnswers, questions);
    if (message.questionDismissed) return '';
  }
  // Индикатор печати только у ответа, который сейчас реально пишется.
  // Иначе квитанция «Ответ получен» оставляла вечные три точки.
  const live = streaming
    || (isChatBusy() && active?.messages[active.messages.length - 1] === message);
  if (!live || message.suppressEmptyThinking) return '';
  return '<span class="thinking"><span></span><span></span><span></span></span>';
}

function messageHtml(m, i) {
  if (m.role === 'user') {
    const html = escapeHtml(m.content).replace(/\n/g, '<br>');
    if (m.content.length <= LONG_MSG_LIMIT) return html;
    return `<div class="msg-clamp" id="clamp-${i}">${html}</div><button type="button" class="msg-expand" data-expand="${i}">Показать больше</button>`;
  }
  return renderAssistantContent(m, i, false);
}

// Ряд миниатюр картинок, которые модель нашла в интернете и скачала в
// песочницу (download_image) — несколько штук показываются друг за другом
// в прокручиваемом ряду, тем же классом .attach-row, что и обычные
// вложения (nowrap + overflow-x:auto, см. style.css), чтобы пользователь
// мог промотать вправо, если вариантов несколько. dataUrl === null, пока
// миниатюра ещё подгружается с диска; 'error' — не удалось прочитать.
function sandboxImagesRowHtml(m, msgIndex, requestedNames = null, galleryKey = 'main') {
  const seenImages = new Set();
  const requested = requestedNames?.length ? new Set(requestedNames) : null;
  const sourceImages = requested
    ? requestedNames.map((name) => (m.sandboxImages || []).find((image) => image.name === name)).filter(Boolean)
    : (m.sandboxImages || []);
  const images = sourceImages.filter((im) => {
    // Галерея появляется только после успешного чтения реального изображения.
    // Пока dataUrl нет, отдельный статус уже показывает подготовку — серый
    // пустой кадр здесь не нужен.
    if (!im.dataUrl || im.dataUrl === 'expired' || im.dataUrl === 'error') return false;
    const key = im.dataUrl;
    if (seenImages.has(key)) return false;
    seenImages.add(key);
    return true;
  });
  const galleryId = `${msgIndex}-${galleryKey}`;
  if (!images.length) return '';
  const ready = images.filter((im) => im.dataUrl && im.dataUrl !== 'error');
  const main = ready[0];
  const caption = main?.name || 'Изображение';
  const mainHtml = main
    ? `<img class="sandbox-gallery-main sandbox-image-chip" data-gallery-main="${escapeHtml(galleryId)}" data-gallery-index="1" src="${main.dataUrl}" alt="${escapeHtml(main.name)}" title="Открыть изображение" loading="lazy">`
    : `<div class="sandbox-gallery-main sandbox-image-chip sandbox-image-chip--loading"></div>`;
  const stage = `<div class="sandbox-gallery-stage">
    ${mainHtml}
    <div class="sandbox-gallery-meta">
      <span class="sandbox-gallery-caption" data-gallery-caption="${escapeHtml(galleryId)}">${escapeHtml(caption)}</span>
      <span class="sandbox-gallery-count" data-gallery-count="${escapeHtml(galleryId)}">${main ? 1 : 0}/${images.length}</span>
    </div>
  </div>`;
  if (images.length === 1) return `<div class="sandbox-gallery sandbox-gallery--single">${stage}</div>`;
  const strip = images.slice(1).map((im, index) => {
    const galleryIndex = index + 2;
    if (!im.dataUrl || im.dataUrl === 'error') return `<div class="sandbox-gallery-thumb sandbox-image-chip sandbox-image-chip--loading" title="${escapeHtml(im.name)}"></div>`;
    return `<img class="sandbox-gallery-thumb sandbox-image-chip" data-gallery-target="${escapeHtml(galleryId)}" data-gallery-index="${galleryIndex}" src="${im.dataUrl}" alt="${escapeHtml(im.name)}" title="${escapeHtml(im.name)}" loading="lazy">`;
  }).join('');
  return `<div class="sandbox-gallery">${stage}<div class="sandbox-gallery-strip">${strip}</div></div>`;
}

function sandboxFileCardsHtml(m) {
  if (m.role !== 'assistant' || !m.sandboxFiles?.length) return '';
  const namedInAnswer = new Set(generatedFileBlocks(m.content || '').map((f) => f.filename));
  const files = [...new Set(m.sandboxFiles)].filter((name) => !namedInAnswer.has(name));
  if (!files.length) return '';
  return `<div class="file-cards sandbox-file-cards">${files.map((name) => {
    const ext = (name.split('.').pop() || 'file').toUpperCase();
    const base = name.replace(/\.[^./]+$/, '');
    return `<div class="file-card sandbox-file-card" data-sandbox-open="${escapeHtml(name)}" title="Открыть предпросмотр">
      <span class="file-card-icon">${icon('file', 16)}</span>
      <div class="file-card-info"><div class="file-card-name">${escapeHtml(base)}</div><div class="file-card-ext">${escapeHtml(ext)}</div></div>
      <div class="file-card-actions">
        <button type="button" class="file-card-preview" data-sandbox-open="${escapeHtml(name)}">Предпросмотр</button>
        <button type="button" class="file-card-download sandbox-file-download" data-sandbox-download="${escapeHtml(name)}">Скачать</button>
      </div>
    </div>`;
  }).join('')}</div>`;
}

function attachChipHtml(d, i, removable = true) {
  const removeBtn = removable ? `<button type="button" class="attach-remove" data-remove="${i}" title="Убрать">${icon('close', 12)}</button>` : '';
  if (d.kind === 'image') {
    return `
      <div class="attach-chip attach-chip--image${removable ? ' attach-chip--removable' : ''}" title="${escapeHtml(d.name)}">
        ${removeBtn}
        <img class="attach-thumb" src="${d.imageDataUrl}" alt="${escapeHtml(d.name)}">
        <span class="attach-badge">${escapeHtml(formatBadge(d))}</span>
      </div>`;
  }
  const previewLine = escapeHtml(d.name);
  return `
    <div class="attach-chip${removable ? ' attach-chip--removable' : ''}">
      ${removeBtn}
      <div class="attach-preview">${icon('file', 14)}<span>${previewLine}</span></div>
      <span class="attach-badge">${escapeHtml(formatBadge(d))}</span>
    </div>`;
}

function chatRowHtml(c) {
  const pinned = !!c.pinned;
  return `
    <div class="chatrow ${active?.id === c.id ? 'selected' : ''}">
      <button class="chat" data-id="${c.id}" title="Открыть диалог">${escapeHtml(c.title)}</button>
      <button class="pin-chat ${pinned ? 'pinned' : ''}" data-pin="${c.id}" title="${pinned ? 'Открепить' : 'Закрепить'}">${icon(pinned ? 'starFilled' : 'star', 13)}</button>
      <button class="rename-chat" data-rename="${c.id}" title="Переименовать">${icon('edit', 13)}</button>
      <button class="delete-chat" data-delete="${c.id}" title="Удалить диалог" aria-label="Удалить диалог">${icon('trash', 13)}</button>
    </div>`;
}

// Закрывает всплывающие панели при клике вне них.
document.addEventListener('click', (e) => {
  if (!e.target.closest('#modePopover') && !e.target.closest('#modeBtn')) {
    const p = document.querySelector('#modePopover');
    if (p) p.hidden = true;
  }
  if (!e.target.closest('.split-toggle') && !e.target.closest('.code-menu')) {
    document.querySelectorAll('.code-menu').forEach((m) => (m.hidden = true));
  }
});

function updateModeLabel() {
  const label = document.querySelector('#modelLabel');
  if (!label) return;
  const provider = currentPreference('provider');
  const rawModel = provider === 'local' ? currentPreference('localModel') : currentPreference('groqModel');
  const modelName = provider === 'local'
    ? (localModelDef(rawModel)?.label || rawModel)
    : (currentPreference('customGroqModel') || rawModel);
  const effort = EFFORTS[currentPreference('effort')] || EFFORTS.normal;
  label.innerHTML = `${effort.label} · ${modelName} ${icon('chevronDown', 12)}`;
}

// Прогресс скачивания модели прямо в попапе выбора модели. Вызывается с
// (downloaded, total) во время скачивания, с null — чтобы скрыть блок.
function updateDownloadUi(downloaded, total, file) {
  const el = document.querySelector('#downloadStatus');
  if (!el) return;
  if (downloaded === null) { el.hidden = true; return; }
  el.hidden = false;
  const pct = total ? Math.min(100, Math.round((downloaded / total) * 100)) : 0;
  el.querySelector('.download-fill').style.width = `${pct}%`;
  // Один общий прогресс для основной модели и всех её дополнительных файлов.
  // Технические имена и «сколько из скольки» пользователю не показываем.
  el.querySelector('.download-text').textContent = total
    ? `Загрузка модели… ${pct}%`
    : 'Подготовка загрузки модели…';
}

function buildChatListHtml() {
  const visibleChats = store.chats.filter((c) => chatMatches(c, searchQuery));
  const pinned = visibleChats.filter((c) => c.pinned);
  const unpinned = visibleChats.filter((c) => !c.pinned);
  const groups = groupChats(unpinned);

  const pinnedSection = pinned.length
    ? `<div class="chat-group-label">Закреплённые</div>${pinned.map(chatRowHtml).join('')}`
    : '';

  const groupedSection = Object.entries(groups)
    .filter(([, arr]) => arr.length)
    .map(([label, arr]) => `<div class="chat-group-label">${label}</div>${arr.map(chatRowHtml).join('')}`)
    .join('');

  return pinnedSection + groupedSection || (store.chats.length ? '<p class="hint">Ничего не найдено</p>' : '<p class="hint">История появится здесь</p>');
}

// Навешивает обработчики на строки диалогов внутри переданного контейнера —
// вынесено из render(), чтобы можно было перепривязывать их и после точечного
// обновления списка (поиск), не перерисовывая всё приложение целиком.
function bindChatRowHandlers(container) {
  container.querySelectorAll('.chat').forEach((b) => (b.onclick = () => { active = store.chats.find((x) => x.id == b.dataset.id); editingIndex = null; render(); }));
  container.querySelectorAll('.pin-chat').forEach((b) => (b.onclick = () => pinChat(Number(b.dataset.pin))));
  container.querySelectorAll('.rename-chat').forEach((b) => (b.onclick = () => renameChat(Number(b.dataset.rename))));
  container.querySelectorAll('.delete-chat').forEach((b) => (b.onclick = () => deleteChat(Number(b.dataset.delete))));
}

async function hydrateSandboxImages() {
  if (!active) return;
  const pending = [];
  for (const m of active.messages || []) {
    for (const im of m.sandboxImages || []) {
      if (im.dataUrl || im.loading) continue;
      im.loading = true;
      pending.push(
        invoke('sandbox_read_image', { chatId: String(active.id), filename: im.name })
          .then((url) => { im.dataUrl = url; })
          .catch(() => { im.dataUrl = 'error'; })
          .finally(() => { im.loading = false; })
      );
    }
  }
  const attachmentGroups = [active.pendingAttachments || [], ...(active.messages || []).map((m) => m.attachments || [])];
  for (const group of attachmentGroups) {
    for (const item of group) {
      if (item.kind !== 'image' || item.imageDataUrl || !item.sandboxPath || item.imageLoading) continue;
      item.imageLoading = true;
      pending.push(
        invoke('sandbox_read_image', { chatId: String(active.id), filename: item.sandboxPath })
          .then((url) => { item.imageDataUrl = url; item.imageBase64 = url.split(',')[1] || ''; })
          .catch(() => {})
          .finally(() => { item.imageLoading = false; })
      );
    }
  }
  if (!pending.length) return;
  const chatId = active.id;
  await Promise.all(pending);
  if (active?.id === chatId) render();
}

function render() {
  // render() полностью пересобирает #app, а значит и #messages — свежий DOM-
  // узел не помнит, где пользователь только что прокручивал. Раньше это
  // означало жёсткий прыжок вниз при КАЖДОМ render() (в том числе сразу по
  // окончании генерации ответа), даже если человек в этот момент читал
  // историю выше. Запоминаем позицию до пересборки и либо остаёмся на ней,
  // либо, если пользователь и так был у самого низа, продолжаем следовать
  // за низом — ровно то же поведение, что уже есть в потоковой печати.
  const prevMessagesArea = document.querySelector('#messages');
  // Позицию прокрутки переносим только если это тот же диалог, что и был —
  // при переключении на другой чат (или первом открытии) старая позиция
  // никак не относится к новому содержимому, там всегда открываем снизу.
  const sameChat = prevMessagesArea && active && lastRenderedChatId === active.id;
  const hadSavedScroll = !!active && chatScrollState.has(active.id);
  const savedScroll = active ? scrollStateFor(active) : { top: 0, follow: true };
  const prevScrollTop = sameChat ? prevMessagesArea.scrollTop : (hadSavedScroll ? savedScroll.top : null);
  const prevWasNearBottom = sameChat ? savedScroll.follow : (hadSavedScroll ? savedScroll.follow : true);
  // Якорь первого видимого сообщения сохраняет именно то место чтения даже
  // если выше загрузилась картинка и высота контента заметно изменилась.
  let prevVisibleAnchor = null;
  if (sameChat && !savedScroll.follow) {
    const viewportTop = prevMessagesArea.getBoundingClientRect().top;
    const visible = Array.from(prevMessagesArea.querySelectorAll('article[data-message-index]'))
      .find((el) => el.getBoundingClientRect().bottom > viewportTop);
    if (visible) prevVisibleAnchor = {
      index: visible.dataset.messageIndex,
      offset: visible.getBoundingClientRect().top - viewportTop,
    };
  }
  if (sameChat) savedScroll.top = prevMessagesArea.scrollTop;

  const chatListHtml = buildChatListHtml();
  const chatBusy = isChatBusy(active);

  document.querySelector('#app').innerHTML = `
    <div class="shell ${store.sidebarCollapsed ? 'collapsed' : ''}">
      <button id="expandBtn" class="icon-btn expand-btn" title="Показать боковую панель">${icon('panel', 15)}</button>
      <aside>
        <div class="brand-row">
          <b><span title="AI спрятано в Am-I-go">A</span>m<span title="AI спрятано в Am-I-go">I</span>go</b>
          <button id="collapseBtn" class="icon-btn" title="Свернуть боковую панель">${icon('panel', 15)}</button>
        </div>
        <button id="new" class="nav-item">${icon('plus', 15)}Новый диалог</button>
        <div class="nav-item search-row">
          ${icon('search', 14)}<input id="chatSearch" value="${escapeHtml(searchQuery)}" placeholder="Поиск">
        </div>
        <div class="chats">${chatListHtml}</div>
        <div class="foot">
          <button id="settings" class="nav-item">${icon('settings', 15)}Настройки</button>
        </div>
      </aside>
      <main>
        <div class="messages-wrap">
        ${active ? `<div class="chat-header-bar"><button id="chatSettingsBtn" class="icon-btn" title="Память диалога">${icon('brain', 15)}</button></div>` : ''}
        <section id="messages"><div class="messages-inner">${
          active?.messages.length
            ? active.messages
                .map((m, i) => {
                  const isLast = i === active.messages.length - 1;
                  const label = m.role === 'user' ? 'Вы' : chatBusy && isLast ? 'AmIgo · в работе' : 'AmIgo';
                  if (m.role === 'user' && i === editingIndex) {
                    return `
          <article class="${m.role} editing" data-message-index="${i}">
            <label>${label}</label>
            <div class="msg-edit-form">
              <textarea class="msg-edit-input" rows="1">${escapeHtml(m.content || '')}</textarea>
              <div class="msg-actions">
                <button type="button" class="msg-edit-cancel" data-index="${i}">Отмена</button>
                <button type="button" class="msg-edit-save primary" data-index="${i}">${icon('check', 13)}Сохранить</button>
              </div>
            </div>
          </article>`;
                  }
                  return `
          <article class="${m.role}" data-message-index="${i}">
            <label>${label}</label>
            ${statusRowHtml(m, i)}
            ${m.role === 'user' && m.attachments?.length ? `<div class="attach-row attach-row--sent">${m.attachments.map((d) => attachChipHtml(d, null, false)).join('')}</div>` : ''}
            ${m.role === 'assistant' || m.content ? `<div class="msg-content">${messageHtml(m, i)}</div>` : ''}
            ${sandboxFileCardsHtml(m)}
            <div class="msg-actions">
              <span class="msg-time">${formatTime(m.time)}</span>
              ${m.role === 'user' && !chatBusy ? `<button class="msg-edit" data-index="${i}" title="Редактировать">${icon('edit', 13)}</button>` : ''}
              <button class="msg-copy" data-index="${i}" title="Скопировать">${icon('copy', 13)}</button>
              ${m.role === 'assistant' && isLast && !chatBusy && m.content ? `<button class="msg-regenerate" data-index="${i}" title="Переделать">${icon('refresh', 13)}</button>` : ''}
            </div>
          </article>`;
                })
                .join('')
            : `<div class="welcome">
                 <h1>${greetingPhrase()}</h1>
                 <div class="tips">
                   <button>${icon('calendar', 14)}Помоги составить план на день</button>
                   <button>${icon('info', 14)}Расскажи, что умеешь</button>
                   <button>${icon('file', 14)}Проанализируй мой документ</button>
                 </div>
               </div>`
        }</div></section>
        <button id="scrollBottom" class="scroll-bottom" type="button" hidden>${icon('chevronDown', 13)}Вниз</button>
        </div>
        <div class="composer">
        <form id="send">
          ${active?.pendingAttachments?.length ? `<div class="attach-row">${active.pendingAttachments.map((d, i) => attachChipHtml(d, i, true)).join('')}</div>` : ''}
          <textarea id="prompt" placeholder="Напиши сообщение…" rows="1">${escapeHtml(active?.draft || '')}</textarea>
          <div class="composer-toolbar">
            <button type="button" id="attachBtn" class="icon-btn" title="Прикрепить документ">${icon('plus', 16)}</button>
            <div class="toolbar-spacer"></div>
            <button type="button" id="modelLabel" class="model-label"></button>
            <button id="sendBtn" type="submit"></button>
          </div>
          <div id="modePopover" class="mode-popover" hidden>
            <div class="segmented" id="providerSeg">
              <button type="button" data-value="local" class="${currentPreference('provider') === 'local' ? 'active' : ''}">${icon('dot', 12)}Локально</button>
              <button type="button" data-value="groq" class="${currentPreference('provider') === 'groq' ? 'active' : ''}">${icon('cloud', 13)}Groq</button>
            </div>
            <div class="popover-row">
              <select id="model"></select>
              <input id="customModel" placeholder="своя модель…" title="Точное имя модели, если её нет в списке">
            </div>
            <div id="downloadStatus" class="download-status" hidden>
              <div class="download-track"><div class="download-fill"></div></div>
              <span class="download-text"></span>
            </div>
            <label class="popover-toggle-row" for="webSearchToggle">
              ${icon('search', 14)}
              <span>Поиск</span>
              <span class="switch">
                <input type="checkbox" id="webSearchToggle" ${store.webSearchEnabled ? 'checked' : ''}>
                <span class="switch-track"></span>
              </span>
            </label>
            <div class="popover-label">Глубина рассуждения</div>
            ${Object.entries(EFFORTS)
              .map(
                ([key, e]) => `
              <button type="button" class="effort-item" data-effort="${key}">
                <span class="effort-text"><b>${e.label}</b><small>${e.hint}</small></span>
                <span class="check">${currentPreference('effort') === key ? icon('check', 13) : ''}</span>
              </button>`
              )
              .join('')}
          </div>
        </form>
        <p class="composer-disclaimer">AmIgo - ИИ и может ошибаться, пожалуйста, перепроверяйте ответы</p>
        </div>
      </main>
    </div>
    <dialog id="modal"></dialog>`;

  document.querySelector('#new').onclick = newChat;
  const setSidebarCollapsed = (collapsed) => {
    store.sidebarCollapsed = collapsed;
    document.querySelector('.shell')?.classList.toggle('collapsed', collapsed);
    save();
  };
  document.querySelector('#collapseBtn').onclick = () => setSidebarCollapsed(true);
  document.querySelector('#expandBtn').onclick = () => setSidebarCollapsed(false);

  const search = document.querySelector('#chatSearch');
  search.oninput = () => {
    searchQuery = search.value;
    const chatsEl = document.querySelector('.chats');
    chatsEl.innerHTML = buildChatListHtml();
    bindChatRowHandlers(chatsEl);
  };

  bindChatRowHandlers(document.querySelector('.chats'));

  const model = document.querySelector('#model');
  function updateModels() {
    const customEl = document.querySelector('#customModel');
    const provider = currentPreference('provider');
    if (provider === 'local') {
      // Фиксированный список локальных моделей, без свободного ввода имени.
      model.innerHTML = models.local
        .map((m) => `<option value="${m.id}">${m.label}${m.downloaded ? '' : (downloadPromises[m.id] || queuedDownloads[m.id]) ? ' (скачивается…)'  : ' (скачается при выборе)'}</option>`)
        .join('');
      if (customEl) { customEl.hidden = true; customEl.value = ''; }
    } else {
      model.innerHTML = models.groq.map((x) => `<option>${x}</option>`).join('');
      if (customEl) customEl.hidden = false;
    }
    const wanted = provider === 'local' ? currentPreference('localModel') : currentPreference('groqModel');
    if (Array.from(model.options).some((o) => o.value === wanted)) model.value = wanted;
    else {
      setCurrentPreference(provider === 'local' ? 'localModel' : 'groqModel', model.value);
      save();
    }
    if (customEl && provider !== 'local') customEl.value = currentPreference('customGroqModel');
    updateModeLabel();
    void syncActiveModel().catch(() => {});
  }
  updateModels();
  model.onchange = () => {
    const provider = currentPreference('provider');
    setCurrentPreference(provider === 'local' ? 'localModel' : 'groqModel', model.value);
    save(); updateModeLabel(); void syncActiveModel().catch(() => {});
  };
  document.querySelector('#customModel').oninput = (e) => {
    setCurrentPreference('customGroqModel', e.target.value.trim());
    save(); updateModeLabel(); void syncActiveModel().catch(() => {});
  };

  document.querySelector('#webSearchToggle').onchange = (e) => {
    store.webSearchEnabled = e.target.checked;
    save();
  };

  document.querySelectorAll('#providerSeg button').forEach((b) => {
    b.onclick = () => {
      setCurrentPreference('provider', b.dataset.value);
      save();
      document.querySelectorAll('#providerSeg button').forEach((x) => x.classList.toggle('active', x === b));
      if (currentPreference('provider') === 'local') refreshModelsStatus().then(updateModels);
      else updateModels();
    };
  });

  document.querySelectorAll('.effort-item').forEach((item) => {
    item.onclick = () => {
      setCurrentPreference('effort', item.dataset.effort);
      save();
      document.querySelectorAll('.effort-item .check').forEach((c) => (c.innerHTML = ''));
      item.querySelector('.check').innerHTML = icon('check', 13);
      updateModeLabel();
    };
  });

  const modeBtn = document.querySelector('#modelLabel');
  const modePopover = document.querySelector('#modePopover');
  modeBtn.onclick = (e) => {
    e.stopPropagation();
    modePopover.hidden = !modePopover.hidden;
  };
  document.querySelector('#attachBtn').onclick = docs;

  document.querySelectorAll('.attach-remove').forEach((b) => (b.onclick = () => removeDoc(Number(b.dataset.remove))));

  const promptEl = document.querySelector('#prompt');
  promptEl.oninput = () => {
    if (active) active.draft = promptEl.value;
    promptEl.style.height = 'auto';
    promptEl.style.height = Math.min(promptEl.scrollHeight, 200) + 'px';
  };
  if (promptEl.value) {
    promptEl.style.height = 'auto';
    promptEl.style.height = Math.min(promptEl.scrollHeight, 200) + 'px';
  }
  promptEl.onkeydown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  // Вставка работает из любой части чата: предварительно кликать в поле
  // ввода не нужно. Поля настроек/поиска и модальные окна не перехватываем.
  const handleComposerPaste = async (e, forceToPrompt = false) => {
    if ((active?.pendingAttachments || []).length >= MAX_ATTACHMENTS) {
      showToast(`Можно прикрепить не больше ${MAX_ATTACHMENTS} файлов за одно сообщение`);
      return;
    }
    const items = e.clipboardData?.items || [];
    const imageItem = Array.from(items).find((it) => it.type && it.type.startsWith('image/'));
    if (imageItem) {
      const file = imageItem.getAsFile();
      if (!file) return;
      e.preventDefault();
      if (active) active.draft = promptEl.value;
      const reader = new FileReader();
      reader.onload = async () => {
        if (!active) newChat();
        const dataUrl = reader.result;
        const ext = (file.type.split('/')[1] || 'png').toLowerCase();
        const name = `Вставленное_изображение_${Date.now()}.${ext}`;
        try {
          const prepared = await invoke('prepare_image_data_url', {
            chatId: String(active.id), dataUrl, suggestedName: name,
          });
          addAttachment({
            id: Date.now() + Math.random(), name: prepared.filename, ext: 'png', kind: 'image',
            imageDataUrl: prepared.data_url, imageBase64: (prepared.data_url.split(',')[1] || ''),
            sandboxPath: prepared.filename,
          });
        } catch (err) {
          showToast(`Не удалось подготовить изображение: ${String(err || '').slice(0, 180)}`);
          return;
        }
        save(); render();
      };
      reader.onerror = () => showToast('Не удалось вставить изображение');
      reader.readAsDataURL(file);
      return;
    }
    const text = e.clipboardData?.getData('text/plain') || '';
    if (text.length > PASTE_THRESHOLD) {
      e.preventDefault();
      if (!active) newChat();
      active.draft = promptEl.value;
      const name = `Вставленный_текст_${Date.now()}.txt`;
      let sandboxPath = null;
      try {
        await invoke('sandbox_save_generated_text', { chatId: String(active.id), path: name, content: text });
        sandboxPath = name;
      } catch (err) {
        showToast(`Не удалось сохранить текст в песочнице: ${String(err || '').slice(0, 180)}`);
      }
      addAttachment({ id: Date.now() + Math.random(), name, ext: 'txt', kind: 'paste', text, preview: shortPreview(text), sandboxPath });
      save(); render();
      return;
    }
    if (forceToPrompt && text) {
      e.preventDefault();
      promptEl.focus();
      promptEl.setRangeText(text, promptEl.selectionStart, promptEl.selectionEnd, 'end');
      promptEl.dispatchEvent(new Event('input', { bubbles: true }));
    }
  };
  promptEl.onpaste = (e) => handleComposerPaste(e, false);
  document.onpaste = (e) => {
    const target = e.target;
    if (target === promptEl || target?.matches?.('input,textarea,[contenteditable="true"]')) return;
    if (document.querySelector('dialog[open]')) return;
    handleComposerPaste(e, true);
  };

  const composer = document.querySelector('.composer');
  const markComposerDrop = (on) => composer?.classList.toggle('drop-hover', !!on);
  const hasFileDrag = (e) => Array.from(e.dataTransfer?.types || []).includes('Files');
  composer?.addEventListener('dragenter', (e) => {
    if (!hasFileDrag(e)) return;
    e.preventDefault();
    markComposerDrop(true);
  });
  composer?.addEventListener('dragover', (e) => {
    if (!hasFileDrag(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    markComposerDrop(true);
  });
  composer?.addEventListener('dragleave', (e) => {
    if (!composer.contains(e.relatedTarget)) markComposerDrop(false);
  });
  composer?.addEventListener('drop', (e) => {
    if (!hasFileDrag(e)) return;
    e.preventDefault();
    markComposerDrop(false);
    void handleHtmlFileDrop(e.dataTransfer);
  });

  // Печатать можно сразу после открытия/переключения чата. Первый символ
  // не теряется: вставляем его в позицию курсора и переводим фокус.
  document.onkeydown = (e) => {
    if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || e.key.length !== 1) return;
    const target = e.target;
    if (target?.matches?.('input,textarea,select,button,a,[contenteditable="true"]') || document.querySelector('dialog[open]')) return;
    e.preventDefault();
    promptEl.focus();
    promptEl.setRangeText(e.key, promptEl.selectionStart, promptEl.selectionEnd, 'end');
    promptEl.dispatchEvent(new Event('input', { bubbles: true }));
  };

  document.querySelector('#send').onsubmit = (e) => { e.preventDefault(); sendMessage(); };
  document.querySelector('#settings').onclick = settings;
  document.querySelector('#chatSettingsBtn')?.addEventListener('click', chatSettings);
  document.querySelectorAll('.tips button').forEach((b) => (b.onclick = () => { promptEl.value = b.textContent.trim(); sendMessage(); }));

  const messagesArea = document.querySelector('#messages');
  const scrollBtn = document.querySelector('#scrollBottom');
  const scrollState = scrollStateFor();
  if (prevWasNearBottom || prevScrollTop === null) pinMessagesToBottom(messagesArea);
  else {
    messagesArea.scrollTop = Math.min(prevScrollTop, Math.max(0, messagesArea.scrollHeight - messagesArea.clientHeight));
    if (prevVisibleAnchor) {
      const anchor = messagesArea.querySelector(`article[data-message-index="${prevVisibleAnchor.index}"]`);
      if (anchor) {
        const viewportTop = messagesArea.getBoundingClientRect().top;
        const newOffset = anchor.getBoundingClientRect().top - viewportTop;
        messagesArea.scrollTop += newOffset - prevVisibleAnchor.offset;
      }
    }
    scrollState.top = messagesArea.scrollTop;
    scrollState.follow = performance.now() >= (scrollState.manualUntil || 0) && isNearBottom(messagesArea);
  }
  scrollBtn.hidden = scrollState.follow;
  lastRenderedChatId = active ? active.id : null;
  messagesArea.onscroll = () => {
    scrollState.top = messagesArea.scrollTop;
    const manualScroll = performance.now() < (scrollState.manualUntil || 0);
    scrollState.follow = !manualScroll && isNearBottom(messagesArea);
    scrollBtn.hidden = scrollState.follow;
  };
  // Trackpad/touch-жест мгновенно отключает автоприлипание ещё до первого
  // scroll-события. Блокировка продлевается колесом и не спорит с инерцией.
  const suspendAutoFollow = () => {
    cancelScrollAnimation();
    scrollState.follow = false;
    scrollState.manualUntil = performance.now() + 900;
    scrollBtn.hidden = false;
  };
  for (const eventName of ['wheel', 'touchstart', 'pointerdown']) {
    messagesArea.addEventListener(eventName, suspendAutoFollow, { passive: true });
  }
  scrollBtn.onclick = () => {
    scrollState.manualUntil = 0;
    scrollState.follow = true;
    scrollBtn.hidden = true;
    animateMessagesToBottom(messagesArea);
  };

  const editInput = messagesArea.querySelector('.msg-edit-input');
  if (editInput) {
    editInput.style.height = editInput.scrollHeight + 'px';
    editInput.oninput = () => { editInput.style.height = 'auto'; editInput.style.height = editInput.scrollHeight + 'px'; };
    editInput.focus();
    editInput.setSelectionRange(editInput.value.length, editInput.value.length);
    editInput.onkeydown = (e) => {
      if (e.key === 'Escape') { editingIndex = null; render(); }
      else if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); messagesArea.querySelector('.msg-edit-save')?.click(); }
    };
  }

  messagesArea.onclick = (e) => {
    const toggle = e.target.closest('.split-toggle');
    // Клик где угодно закрывает все открытые меню; если это был клик именно
    // по шеврону — открывает/закрывает конкретно его меню.
    document.querySelectorAll('.code-menu').forEach((m) => {
      if (!toggle || m.dataset.menuFor !== toggle.dataset.menu) m.hidden = true;
    });
    if (toggle) {
      const menu = messagesArea.querySelector(`.code-menu[data-menu-for="${toggle.dataset.menu}"]`);
      if (menu) menu.hidden = !menu.hidden;
      return;
    }
    const expandBtn = e.target.closest('.msg-expand');
    if (expandBtn) {
      const clamp = document.getElementById(`clamp-${expandBtn.dataset.expand}`);
      if (clamp) {
        const expanded = clamp.classList.toggle('expanded');
        expandBtn.textContent = expanded ? 'Свернуть' : 'Показать больше';
      }
      return;
    }
    const copyCode = e.target.closest('.copy-code');
    if (copyCode) {
      const codeEl = document.getElementById(copyCode.dataset.target);
      if (!codeEl) return;
      navigator.clipboard
        .writeText(codeEl.textContent)
        .then(() => { const old = copyCode.innerHTML; copyCode.innerHTML = icon('check', 13) + 'Скопировано'; setTimeout(() => (copyCode.innerHTML = old), 1500); })
        .catch(() => alert('Не удалось скопировать. Выделите код вручную.'));
      return;
    }
    const downloadCode = e.target.closest('.download-code');
    if (downloadCode) {
      const codeEl = document.getElementById(downloadCode.dataset.target);
      if (!codeEl) return;
      const ext = extensionForLang(downloadCode.dataset.lang);
      const defaultPath = downloadCode.dataset.filename || `amigo-code.${ext}`;
      saveFileDialog({ defaultPath })
        .then(async (path) => {
          if (!path) return; // пользователь отменил диалог
          const old = downloadCode.innerHTML;
          if (BINARY_FORMATS.has(ext)) {
            // PDF/PPTX/DOCX/XLSX — текст блока это не готовый файл, а лёгкая
            // разметка модели; здесь она превращается в настоящий бинарный
            // документ и уходит в save_binary_file как base64.
            downloadCode.innerHTML = icon('refresh', 13) + 'Собираю файл…';
            try {
              const base64 = await generateBinaryFileBase64(ext, codeEl.textContent, active?.id);
              await invoke('save_binary_file', { path, contentBase64: base64 });
              downloadCode.innerHTML = icon('check', 13) + 'Сохранено';
            } catch (err) {
              downloadCode.innerHTML = old;
              showToast('Не удалось собрать файл, попробуйте снова');
              return;
            }
          } else {
            await invoke('save_file', { path, content: codeEl.textContent });
            downloadCode.innerHTML = icon('check', 13) + 'Сохранено';
          }
          setTimeout(() => (downloadCode.innerHTML = old), 1500);
        })
        .catch(() => showToast('Ошибка загрузки, попробуйте снова'));
      return;
    }
    const sandboxDownload = e.target.closest('.sandbox-file-download');
    if (sandboxDownload) {
      const filename = sandboxDownload.dataset.sandboxDownload;
      saveFileDialog({ defaultPath: filename })
        .then(async (destination) => {
          if (!destination) return;
          const old = sandboxDownload.innerHTML;
          sandboxDownload.innerHTML = icon('refresh', 13) + 'Сохраняю…';
          try {
            await invoke('sandbox_export_file', {
              chatId: String(active.id), filename, destination,
            });
            sandboxDownload.innerHTML = icon('check', 13) + 'Сохранено';
            setTimeout(() => { sandboxDownload.innerHTML = old; }, 1500);
          } catch (err) {
            sandboxDownload.innerHTML = old;
            showToast(`Не удалось скачать файл: ${String(err || '').slice(0, 180)}`);
          }
        })
        .catch(() => showToast('Не удалось открыть диалог сохранения'));
      return;
    }
    const sandboxFile = e.target.closest('[data-sandbox-open]');
    if (sandboxFile) {
      const filename = sandboxFile.dataset.sandboxOpen;
      openSandboxFilePreview(filename);
      return;
    }
    const fileCard = e.target.closest('.file-card');
    if (fileCard) {
      const srcEl = document.getElementById(fileCard.dataset.block);
      const ext = fileCard.dataset.ext || '';
      const fullName = fileCard.dataset.fullname || `${fileCard.dataset.filename || 'Файл'}${ext ? `.${ext.toLowerCase()}` : ''}`;
      openFilePreview(fullName, ext, fileCard.dataset.doc === '1', srcEl ? srcEl.textContent : '');
      return;
    }
    const editBtn = e.target.closest('.msg-edit');
    if (editBtn) { editingIndex = Number(editBtn.dataset.index); render(); return; }
    const editCancel = e.target.closest('.msg-edit-cancel');
    if (editCancel) { editingIndex = null; render(); return; }
    const editSave = e.target.closest('.msg-edit-save');
    if (editSave) {
      const idx = Number(editSave.dataset.index);
      const textarea = messagesArea.querySelector('.msg-edit-input');
      const newText = textarea?.value.trim();
      if (!newText) return;
      active.messages[idx].content = newText;
      active.messages.splice(idx + 1); // обрезаем всё, что шло после — ответ будет пересобран заново
      editingIndex = null;
      save();
      generateReply();
      return;
    }
    const copyMsg = e.target.closest('.msg-copy');
    if (copyMsg) {
      const m = active.messages[Number(copyMsg.dataset.index)];
      if (!m) return;
      navigator.clipboard
        .writeText(stripGalleryMarkers(m.content))
        .then(() => { const old = copyMsg.innerHTML; copyMsg.innerHTML = icon('check', 13); copyMsg.title = 'Скопировано'; setTimeout(() => { copyMsg.innerHTML = old; copyMsg.title = 'Скопировать'; }, 1300); })
        .catch(() => {});
      return;
    }
    const regen = e.target.closest('.msg-regenerate');
    if (regen) { regenerate(Number(regen.dataset.index)); return; }
    const searchToggle = e.target.closest('.status-chip--search');
    if (searchToggle && !searchToggle.classList.contains('pending')) {
      const slot = searchToggle.closest('.status-row-slot');
      const m = active.messages[Number(slot?.dataset.statusIndex)];
      if (m?.search?.sources?.length) openSearchSheet(m.search);
      return;
    }
    const imgChip = e.target.closest('.sandbox-image-chip');
    if (imgChip?.hasAttribute('data-gallery-target')) {
      const galleryId = imgChip.dataset.galleryTarget;
      const gallery = imgChip.closest('.sandbox-gallery');
      const main = gallery?.querySelector(`[data-gallery-main="${galleryId}"]`);
      if (!main) return;
      // Меняем главное изображение и миниатюру местами: один и тот же кадр
      // никогда не показывается одновременно дважды.
      const previous = { src: main.src, alt: main.alt, index: main.dataset.galleryIndex || '1' };
      main.src = imgChip.src;
      main.alt = imgChip.alt;
      main.dataset.galleryIndex = imgChip.dataset.galleryIndex || '1';
      imgChip.src = previous.src;
      imgChip.alt = previous.alt;
      imgChip.title = previous.alt;
      imgChip.dataset.galleryIndex = previous.index;
      const caption = gallery?.querySelector(`[data-gallery-caption="${galleryId}"]`);
      if (caption) caption.textContent = main.alt || 'Изображение';
      const count = gallery?.querySelector(`[data-gallery-count="${galleryId}"]`);
      const total = gallery.querySelectorAll('.sandbox-gallery-thumb').length + 1;
      if (count) count.textContent = `${main.dataset.galleryIndex}/${total}`;
      return;
    }
    if (imgChip && imgChip.tagName === 'IMG') {
      const d = openModal(`
        <button type="button" id="closePreview" class="image-preview-close" title="Закрыть" aria-label="Закрыть">${icon('close', 18)}</button>
        <img class="image-preview-full" src="${imgChip.src}" alt="${escapeHtml(imgChip.alt)}">
      `, 'image-preview-modal');
      document.activeElement?.blur();
      d.querySelector('#closePreview').onclick = () => d.close();
      return;
    }

    // Крестик закрывает карточку без отправки модели и оставляет квитанцию
    // «Вопрос пропущен», как кнопка «Пропустить» на последнем шаге.
    const qDismiss = e.target.closest('.question-dismiss');
    if (qDismiss) {
      const card = qDismiss.closest('.question-card');
      const message = active.messages[Number(card?.dataset.msgIndex)];
      if (message) {
        const questions = parseQuestionBlocks(message.content || '');
        message.questionAnswers = message.questionAnswers || {};
        for (const question of questions) {
          if (message.questionAnswers[question.qid] === undefined) {
            message.questionAnswers[question.qid] = { status: 'skipped' };
          }
        }
        delete message.questionDismissed;
        save();
        render();
      }
      return;
    }

    // Карточка опроса от модели: клик по варианту — только выделяет его
    // (единственный способ отправить шаг — кнопка «Ответить» в футере).
    const qOption = e.target.closest('.question-option');
    if (qOption) {
      const card = qOption.closest('.question-card');
      if (!card) return;
      const multiple = card.dataset.multiple === '1';
      const customInput = card.querySelector('.question-custom-input');
      if (customInput) customInput.value = '';
      if (multiple) {
        qOption.classList.toggle('selected');
      } else {
        card.querySelectorAll('.question-option').forEach((el) => el.classList.toggle('selected', el === qOption));
      }
      updateQuestionSubmitState(card);
      return;
    }
    const qSkip = e.target.closest('.question-skip');
    if (qSkip) {
      advanceQuestion(qSkip.closest('.question-card'), { status: 'skipped' });
      return;
    }
    const qSubmit = e.target.closest('.question-submit');
    if (qSubmit && !qSubmit.disabled) {
      const card = qSubmit.closest('.question-card');
      const text = questionCardAnswerText(card);
      if (!text) return;
      advanceQuestion(card, { status: 'answered', text });
      return;
    }
  };
  messagesArea.oninput = (e) => {
    if (e.target.classList?.contains('question-custom-input')) {
      updateQuestionSubmitState(e.target.closest('.question-card'));
    }
  };
  messagesArea.onkeydown = (e) => {
    if (e.key === 'Enter' && e.target.classList?.contains('question-custom-input')) {
      e.preventDefault();
      const card = e.target.closest('.question-card');
      const text = e.target.value.trim();
      if (!text || !card) return;
      advanceQuestion(card, { status: 'answered', text });
    }
  };

  updateModeLabel();
  updateSendUI();
  if (!editInput && !document.querySelector('dialog[open]')) {
    requestAnimationFrame(() => {
      const p = document.querySelector('#prompt');
      if (p && !document.querySelector('dialog[open]')) {
        p.focus({ preventScroll: true });
        p.setSelectionRange(p.value.length, p.value.length);
      }
    });
  }
  // После перезапуска восстанавливаем миниатюры с диска, не храня тяжёлый
  // base64 в localStorage. Флаг loading исключает повторные чтения.
  void hydrateSandboxImages();
}

function forceUnstickGeneration(chatId) {
  if (String(busyChatId) !== String(chatId) && String(stopRequestedChatId) !== String(chatId)) return;
  generationSeq += 1;
  invoke('stop_generation').catch(() => {});
  invoke('end_generation').catch(() => {});
  const chat = store.chats.find((item) => String(item.id) === String(chatId));
  if (chat) {
    const last = chat.messages[chat.messages.length - 1];
    if (last?.role === 'assistant' && !(last.content || '').trim() && !last.continuationDraft) {
      chat.messages.pop();
    } else if (last?.role === 'assistant') {
      last.stopped = true;
    }
    save();
  }
  if (String(busyChatId) === String(chatId)) busyChatId = null;
  // stopRequestedChatId не сбрасываем здесь: иначе generateReply решит,
  // что остановки не было, и запустит повторный chat_stream.
  if (active && String(active.id) === String(chatId)) render();
  else updateSendUI();
  void syncActiveModel().catch(() => {});
}

function updateSendUI() {
  const btn = document.querySelector('#sendBtn');
  if (!btn) return;
  const here = isChatBusy(active);
  if (here) {
    const stopping = isChatStopping(active);
    btn.disabled = false;
    btn.innerHTML = stopping ? icon('loader', 14) : icon('square', 13);
    btn.classList.toggle('stopping', stopping);
    btn.title = stopping ? 'Останавливаю…' : 'Стоп';
    btn.type = 'button';
    btn.onclick = () => {
      const chatId = String(active.id);
      stopRequestedChatId = chatId;
      updateSendUI();
      invoke('stop_generation').catch(() => {});
      // Если поток уже мёртв, а JS ещё ждёт download/switch/health —
      // через 1.6 с принудительно отпускаем интерфейс.
      setTimeout(() => forceUnstickGeneration(chatId), 1600);
    };
  } else {
    btn.classList.remove('stopping');
    btn.innerHTML = icon('arrowUp', 16);
    btn.type = 'submit';
    btn.onclick = null;
    btn.disabled = anyGenerationBusy();
    btn.title = btn.disabled ? 'Ответ формируется в другом диалоге' : 'Отправить';
  }
}

function sanitizeStoppedContent(text, initialLength = 0) {
  const source = withoutThinkingMarkup(text);
  const prefix = source.slice(0, initialLength);
  const newTail = source.slice(initialLength);
  // Незаконченный опрос/файл не является результатом и не должен появляться
  // сырым JSON после нажатия «Стоп». Ранее готовая часть ответа сохраняется.
  return `${prefix}${stripPendingBlocks(newTail)}`.trimEnd();
}

// Явно именованные файловые блоки модели сохраняются в песочницу.
// Неименованный текст больше никогда не превращается в автоматический файл.
const LANG_FILE_EXT = {
  py:'py', python:'py', js:'js', javascript:'js', jsx:'jsx', mjs:'mjs', cjs:'cjs', ts:'ts', typescript:'ts', tsx:'tsx',
  html:'html', css:'css', json:'json', yaml:'yaml', yml:'yml', xml:'xml',
  md:'md', markdown:'md', txt:'txt', text:'txt', csv:'csv', sql:'sql',
  sh:'sh', bash:'sh', zsh:'zsh', rust:'rs', rs:'rs', go:'go', java:'java', c:'c', cpp:'cpp', h:'h', hpp:'hpp', swift:'swift', kotlin:'kt', kt:'kt',
  pdf:'pdf', pptx:'pptx', docx:'docx', xlsx:'xlsx',
};
function cleanGeneratedFilename(name, fallbackExt = 'txt') {
  const base = String(name || '').split(/[\\/]/).pop().replace(/[^\p{L}\p{N}._ -]/gu, '_').trim();
  if (!base) return `generated_file.${fallbackExt}`;
  const safe = /\.[a-z0-9]{1,8}$/i.test(base) ? base : `${base}.${fallbackExt}`;
  return safe.slice(0, 90);
}

function generatedFileBlocks(text) {
  const out = [];
  const re = /(```|~~~)([\w+-]+):([^\n`]+)\n([\s\S]*?)\1/g;
  let m;
  while ((m = re.exec(text || ''))) {
    const filename = cleanGeneratedFilename(m[3].trim(), LANG_FILE_EXT[(m[2] || '').toLowerCase()] || 'txt');
    out.push({ lang: (m[2] || '').toLowerCase(), filename, content: m[4] });
  }
  return out;
}
function inferCodeLanguage(lang, content) {
  const explicit = String(lang || '').toLowerCase();
  if (explicit) return explicit;
  const source = String(content || '').trim();
  if (/^<!doctype html|^<html[\s>]/i.test(source)) return 'html';
  if (/^(?:from\s+\S+\s+import|import\s+\S+|def\s+\w+|class\s+\w+):?/m.test(source)) return 'python';
  if (/^(?:import|export)\s|\b(?:const|let|function|class)\s+\w+/m.test(source)) return 'javascript';
  if (/^\s*[.#]?[\w-]+\s*\{[\s\S]*:[^;]+;/m.test(source)) return 'css';
  try { JSON.parse(source); return 'json'; } catch { return 'txt'; }
}

function isDocumentLang(lang) {
  return BINARY_FORMATS.has(lang) || ['ppt', 'doc', 'xls'].includes(lang);
}

function isFileWorthyUnnamedBlock(lang, content, strict) {
  if (isDocumentLang(lang)) return true;
  if (['text', 'txt', 'md', 'markdown', 'question'].includes(lang)) return false;
  if (!LANG_FILE_EXT[lang] && !['javascript', 'typescript', 'python'].includes(lang)) return false;
  if (!strict) return true;
  const body = String(content || '');
  const lines = body.split('\n').filter((line) => line.trim());
  return lines.length >= 3
    || body.trim().length >= 80
    || /(?:function|class|def |import |export |#include|package |fn |public |<!doctype|<html)/i.test(body);
}

function unnamedFileWorthyBlocks(text, { strict = false } = {}) {
  const out = [];
  const re = /(```|~~~)([\w+-]*)(?::([^\n`]+))?\s*\n([\s\S]*?)\1/g;
  let match;
  while ((match = re.exec(text || ''))) {
    const full = match[0];
    const lang = inferCodeLanguage(match[2], match[4]);
    const filename = (match[3] || '').trim();
    if (filename || parseQuestionBlocks(full).length) continue;
    if (looksLikeToolCallPayload(match[4])) continue;
    if (!isFileWorthyUnnamedBlock(lang, match[4], strict)) continue;
    out.push({ start: match.index, end: match.index + full.length, lang, content: match[4] });
  }
  return out;
}

function fallbackGeneratedFilename(block, index, used) {
  const ext = LANG_FILE_EXT[block.lang] || block.lang.replace(/[^a-z0-9]/gi, '').slice(0, 8) || 'txt';
  const identifier = String(block.content || '').match(/(?:export\s+(?:default\s+)?)?(?:async\s+)?(?:function|class|interface|type|const)\s+([A-Za-z_$][\w$]*)/)?.[1];
  const defaults = {
    html:'index', css:'styles', js:'app', javascript:'app', jsx:'App',
    ts:'app', typescript:'app', tsx:'App', python:'solution', py:'solution',
    rust:'main', rs:'main', go:'main', java:'Main', json:'data', sql:'query',
    sh:'script', bash:'script', zsh:'script', cpp:'main', c:'main',
    pdf:'dokument', pptx:'prezentaciya', ppt:'prezentaciya',
    docx:'dokument', doc:'dokument', xlsx:'tablica', xls:'tablica',
  };
  const base = (identifier || defaults[block.lang] || `file_${index + 1}`)
    .replace(/[^A-Za-z0-9_$-]/g, '_');
  let candidate = cleanGeneratedFilename(`${base}.${ext}`, ext);
  let suffix = 2;
  while (used.has(candidate.toLocaleLowerCase('ru'))) {
    candidate = cleanGeneratedFilename(`${base}_${suffix++}.${ext}`, ext);
  }
  used.add(candidate.toLocaleLowerCase('ru'));
  return candidate;
}

async function persistGeneratedFiles(message, chat) {
  const stripped = stripLeakedToolCalls(message.content);
  if (stripped !== message.content) message.content = stripped;
  const blocks = generatedFileBlocks(message.content);
  message.generatedFiles = message.generatedFiles || [];
  message.sandboxFiles = message.sandboxFiles || [];
  for (const file of blocks) {
    if (message.generatedFiles.includes(file.filename)) continue;
    if (looksLikeToolCallPayload(file.content)) continue;
    try {
      const ext = file.filename.split('.').pop().toLowerCase();
      if (BINARY_FORMATS.has(ext)) {
        const contentBase64 = await generateBinaryFileBase64(ext, file.content, chat.id);
        await invoke('sandbox_save_generated_binary', { chatId: String(chat.id), path: file.filename, contentBase64 });
      } else {
        await invoke('sandbox_save_generated_text', { chatId: String(chat.id), path: file.filename, content: file.content });
      }
      message.generatedFiles.push(file.filename);
    } catch (e) {
      console.warn('Could not persist generated file:', file.filename, e);
    }
  }

  if (!message.codeOnlyFiles && !message.preferFiles) return;
  const unnamed = unnamedFileWorthyBlocks(message.content, { strict: !!message.preferFiles && !message.codeOnlyFiles });
  if (!unnamed.length) return;
  const existing = await invoke('sandbox_list', { chatId: String(chat.id) }).catch(() => []);
  const used = new Set([...existing, ...message.generatedFiles, ...message.sandboxFiles]
    .map((name) => String(name).toLocaleLowerCase('ru')));
  const saved = [];
  for (let index = 0; index < unnamed.length; index++) {
    const block = unnamed[index];
    const filename = fallbackGeneratedFilename(block, index, used);
    try {
      const ext = filename.split('.').pop().toLowerCase();
      if (BINARY_FORMATS.has(ext) || isDocumentLang(block.lang)) {
        const binaryExt = BINARY_FORMATS.has(ext) ? ext : (LANG_FILE_EXT[block.lang] || ext);
        const contentBase64 = await generateBinaryFileBase64(binaryExt, block.content, chat.id);
        await invoke('sandbox_save_generated_binary', { chatId: String(chat.id), path: filename, contentBase64 });
      } else {
        await invoke('sandbox_save_generated_text', {
          chatId: String(chat.id), path: filename, content: block.content,
        });
      }
      message.generatedFiles.push(filename);
      if (!message.sandboxFiles.includes(filename)) message.sandboxFiles.push(filename);
      saved.push({ ...block, filename });
    } catch (error) {
      console.warn('Could not convert code block to file:', filename, error);
      showToast(`Не удалось сохранить файл «${filename}»`);
    }
  }
  if (saved.length) {
    let rewritten = '';
    let cursor = 0;
    for (const block of saved) {
      rewritten += message.content.slice(cursor, block.start);
      if (message.preferFiles && !message.codeOnlyFiles) {
        rewritten += '```' + block.lang + ':' + block.filename + '\n' + block.content + '```';
      }
      cursor = block.end;
    }
    rewritten += message.content.slice(cursor);
    message.content = rewritten.replace(/\n{3,}/g, '\n\n').trim();
  }
}

function withoutThinkingMarkup(text) {
  let clean = String(text || '').replace(/<think>[\s\S]*?<\/think>/gi, '');
  const open = clean.toLowerCase().lastIndexOf('<think>');
  if (open !== -1) clean = clean.slice(0, open);
  return clean.trimStart();
}

function cleanImageDeliveryText(message) {
  const images = message?.sandboxImages || [];
  let text = String(message?.content || '');
  if (!images.length) return text;
  const names = images.map((image) => image.name).filter(Boolean);
  text = text
    .split(/\n{2,}/)
    .filter((paragraph) => {
      return !(/не могу[^\n]*(?:встав|показ)[^\n]*(?:изображ|картин)/i.test(paragraph)
        || /(?:изображения|картинки|они)[^\n]*доступн[^\n]*песочниц/i.test(paragraph));
    })
    .join('\n\n');
  text = text
    .split('\n')
    .filter((line) => !names.some((name) => line.includes(name)))
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return text || 'Изображения показаны в галерее.';
}

function lastUserPlainText(chat = active) {
  const raw = [...(chat?.messages || [])].reverse().find((message) => message.role === 'user')?.content || '';
  return String(raw).replace(/^\[ТЕКУЩИЙ ЗАПРОС[^\n]*\]\s*/i, '').trim();
}

function assistantDisplayContent(message, final = true) {
  let text = withoutThinkingMarkup(message?.content || '');
  text = stripEchoedUserPrompt(text, lastUserPlainText());
  if (final) text = removeRepeatedProse(collapseRepeatedWholeResponse(text));
  // download_image уже создаёт красивую галерею. Убираем только внешнюю
  // Markdown-картинку из текста, чтобы тот же визуал не показывался второй раз.
  // Специальные строки ![img:filename] внутри документов не затрагиваются.
  if ((message?.sandboxImages || []).length) {
    text = cleanImageDeliveryText({ ...message, content: text });
    text = text.replace(/!\[[^\]]*\]\((?:https?:\/\/|data:image\/)[^)]+\)\s*/gi, '');
  }
  return text;
}

function normalizeSurveyContent(content, overrideQuestions = null) {
  const parsedQuestions = parseQuestionBlocks(content);
  if (!parsedQuestions.length) return content;
  const questions = overrideQuestions ?? parsedQuestions;
  const fenceRe = /(```|~~~)([\w+-]*)(?::([^\n`]+))?\s*\n([\s\S]*?)\1/gi;
  let foundSurvey = false;
  let prefix = String(content || '').replace(fenceRe, (block) => {
    if (!parseQuestionBlocks(block).length) return block;
    foundSurvey = true;
    return '';
  }).replace(/\n{3,}/g, '\n\n').trim();
  if (!foundSurvey) return content;
  const normalizeQuestionText = (value) => String(value || '')
    .toLocaleLowerCase('ru')
    .replace(/^\s*(?:#{1,6}|[-*•]|\d+[.)]|>)\s*/, '')
    .replace(/[*_`~]/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const questionKeys = parsedQuestions.map((item) => normalizeQuestionText(item.question));
  prefix = prefix.split('\n').filter((line) => {
    if (!line.includes('?')) return true;
    const lineKey = normalizeQuestionText(line);
    return !questionKeys.some((key) => key && (lineKey === key || lineKey.endsWith(key) || key.endsWith(lineKey)));
  }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  const payload = questions.map(({ question, multiple, options }) => ({
    question,
    multiple: !!multiple,
    options: options || [],
  }));
  if (!payload.length) return prefix;
  const block = `\`\`\`question\n${JSON.stringify(payload, null, 2)}\n\`\`\``;
  return prefix ? `${prefix}\n\n${block}` : block;
}



function resolvedQuestionHistory(messages, topicId = null, excludeMessage = null) {
  const out = [];
  for (const message of messages || []) {
    if (message === excludeMessage || message.role !== 'assistant') continue;
    if (topicId !== null && (Number.isInteger(message.topicId) ? message.topicId : 0) !== topicId) continue;
    const questions = parseQuestionBlocks(message.content || '');
    for (const question of questions) {
      const result = message.questionAnswers?.[question.qid];
      if (!result || !['answered', 'skipped'].includes(result.status)) continue;
      out.push({
        question: question.question,
        status: result.status,
        answer: result.status === 'answered' ? String(result.text || '').trim() : 'Пропущено',
      });
    }
  }
  return out;
}

function filterResolvedSurvey(content, resolved) {
  const questions = parseQuestionBlocks(content);
  if (!questions.length || !resolved.length) {
    return { content, repeated: [], remaining: questions };
  }
  const repeated = [];
  const remaining = questions.filter((question) => {
    const previous = resolved.find((item) => areUserQuestionsEquivalent(item.question, question.question));
    if (!previous) return true;
    repeated.push({ current: question, previous });
    return false;
  });
  return {
    content: repeated.length ? normalizeSurveyContent(content, remaining) : content,
    repeated,
    remaining,
  };
}

async function enrichSurveyOptions(content, provider, model) {
  const questions = parseQuestionBlocks(content);
  if (!questions.length || !questions.some((question) => !(question.options || []).length)) return content;
  const explicitFence = /(```|~~~)\s*question[^\n]*\n[\s\S]*?\1/i;
  if (!explicitFence.test(content)) return content;

  const input = questions.map((question) => ({
    question: question.question,
    multiple: !!question.multiple,
    options: question.options || [],
  }));
  try {
    const req = {
      provider,
      model,
      web_search: false,
      temperature: 0.3,
      num_ctx: 4096,
      max_tokens: 1200,
      messages: [
        {
          role: 'system',
          content: 'Ты дорабатываешь JSON-опрос. Для каждого вопроса предложи 2–6 коротких вероятных вариантов, если набор разумно предсказать. Оставляй options пустым только для имени, пути, произвольного текста или действительно открытого ответа. Ставь multiple=true только если одновременно можно выбрать несколько вариантов. Не добавляй вариант «Другое»: интерфейс уже даёт свободный ввод. question и options пиши только простым текстом без Markdown, ссылок, HTML и обратных кавычек. Не меняй порядок и смысл вопросов. Верни только JSON-массив.',
        },
        { role: 'user', content: JSON.stringify(input) },
      ],
    };
    if (provider === 'local') req.think = false;
    const raw = withoutThinkingMarkup(await invoke('chat_complete_silent', { req }));
    const start = raw.indexOf('[');
    const end = raw.lastIndexOf(']');
    if (start === -1 || end <= start) return content;
    const parsed = JSON.parse(raw.slice(start, end + 1));
    if (!Array.isArray(parsed) || !parsed.length) return content;

    const enriched = questions.map((question, index) => {
      const candidate = parsed[index] || {};
      const proposed = Array.isArray(candidate.options)
        ? [...new Set(candidate.options.map((option) => String(option).trim()).filter(Boolean))].slice(0, 8)
        : [];
      const options = proposed.length ? proposed : (question.options || []);
      return {
        question: question.question,
        multiple: options.length > 1 && !!candidate.multiple,
        options,
      };
    });
    const block = `\`\`\`question\n${JSON.stringify(enriched, null, 2)}\n\`\`\``;
    const prefix = content.replace(/(```|~~~)\s*question[^\n]*\n[\s\S]*?\1/gi, '').trim();
    return prefix ? `${prefix}\n\n${block}` : block;
  } catch {
    return content;
  }
}

// Логика смены темы и продолжения вынесена в chatLogic.js и покрыта тестами.

// Блоки кода из истории можно скопировать в песочницу напрямую через
// copy_code_to_file: модель передаёт только id и путь, не генерируя тот же
// большой текст второй раз.
function collectConversationCodeBlocks(messages, maxBlocks = 24) {
  const blocks = [];
  for (let messageIndex = 0; messageIndex < (messages || []).length; messageIndex++) {
    const content = stripGalleryMarkers(messages[messageIndex]?.content || '');
    const re = /(```|~~~)([\w+-]*)(?::([^\n`]+))?\s*\n([\s\S]*?)(?:\1|$)/g;
    let match;
    let blockIndex = 0;
    while ((match = re.exec(content))) {
      const lang = (match[2] || 'text').toLowerCase();
      if (lang === 'question' || BINARY_FORMATS.has(lang)) continue;
      const code = match[4] || '';
      if (!code.trim()) continue;
      blocks.push({
        id: `m${messageIndex}-b${blockIndex++}`,
        label: (match[3] || `${lang}-блок из сообщения ${messageIndex + 1}`).trim().slice(0, 100),
        language: lang,
        content: code.slice(0, 1_000_000),
      });
    }
  }
  return blocks.slice(-maxBlocks);
}

async function generateReply(continueMsg = null) {
  const chat = active;
  if (!chat) return;
  const seq = ++generationSeq;
  // Сбрасываем старый stop-флаг ровно один раз до появления кнопки «Стоп».
  // chat_stream больше не сбрасывает его повторно, поэтому поздний клик не
  // теряется даже во время подготовки модели или поиска.
  try { await invoke('begin_generation'); }
  catch {
    showToast('Не удалось подготовить генерацию');
    invoke('end_generation').catch(() => {});
    return;
  }
  const generationProvider = chatPreference(chat, 'provider');
  const generationModel = selectedModelFor(chat, generationProvider);
  const generationEffort = EFFORTS[chatPreference(chat, 'effort')] || EFFORTS.normal;
  // Файлы и изображения песочницы постоянные: они удаляются только явным
  // действием пользователя/модели или вместе с диалогом.
  const latestUserTopic = [...(chat.messages || [])].reverse().find((m) => m.role === 'user')?.topicId;
  const requestTopicId = Number.isInteger(continueMsg?.topicId)
    ? continueMsg.topicId
    : (Number.isInteger(latestUserTopic) ? latestUserTopic : (chat.activeTopicId || 0));
  chat.activeTopicId = requestTopicId;
  const assistantMsg = continueMsg || { role: 'assistant', content: '', time: Date.now(), topicId: requestTopicId };
  assistantMsg.topicId = requestTopicId;
  // Matle прячет сырой код и оставляет только файлы. Nage/Mentis по умолчанию
  // тоже превращают код и документы в карточки с предпросмотром.
  assistantMsg.codeOnlyFiles = !!assistantMsg.codeOnlyFiles
    || (generationProvider === 'local' && generationModel === 'matle-2.5');
  assistantMsg.preferFiles = !!assistantMsg.preferFiles
    || (generationProvider === 'local' && ['nage-1.5', 'mentis-3'].includes(generationModel));
  const resumingHiddenDraft = !!continueMsg?.continuationDraft;
  if (resumingHiddenDraft) assistantMsg.content = continueMsg.continuationDraft;
  // Если продолжается скрытый недописанный файл, повторный Stop снова должен
  // скрыть весь незакрытый блок, а не считать его уже готовым префиксом.
  const initialContentLength = resumingHiddenDraft ? 0 : assistantMsg.content.length;
  // Статус «Работа с кодом» не создаём заранее: чип появится только после
  // события chat-status kind=code от Rust, когда Matle реально берётся за код.
  assistantMsg.stopped = false;
  if (!continueMsg) {
    const previousSurvey = [...chat.messages].reverse().find((message) => (
      message.role === 'assistant' && parseQuestionBlocks(message.content || '').length
    ));
    if (previousSurvey && previousSurvey.questionAnswers && Object.keys(previousSurvey.questionAnswers).length) {
      assistantMsg.suppressEmptyThinking = true;
    }
    chat.messages.push(assistantMsg);
  }
  if (String(stopRequestedChatId) === String(chat.id)) stopRequestedChatId = null;
  busyChatId = chat.id;
  save();
  render();

  const replyScrollState = scrollStateFor(chat);
  const visibleReplyDom = () => {
    if (active?.id !== chat.id) return {};
    const messagesArea = document.querySelector('#messages');
    return {
      messagesArea,
      scrollBtn: document.querySelector('#scrollBottom'),
      contentEl: messagesArea?.querySelector('article:last-child > .msg-content'),
      articleEl: messagesArea?.querySelector('article:last-child'),
    };
  };

  updateSendUI();

  let lastFinishReason = null;
  let finishDocumentWork = async () => {};
  let finishQuestionGeneration = async () => {};
  let firstTokenWatchdog = null;
  const clearReplyWatchdog = () => {
    if (firstTokenWatchdog !== null) {
      clearTimeout(firstTokenWatchdog);
      firstTokenWatchdog = null;
    }
  };
  const replyCancelled = () => seq !== generationSeq || String(stopRequestedChatId) === String(chat.id);
  firstTokenWatchdog = setTimeout(() => {
    if (seq !== generationSeq) return;
    if ((assistantMsg.content || '').trim()) return;
    stopRequestedChatId = String(chat.id);
    invoke('stop_generation').catch(() => {});
    assistantMsg.content = 'Модель слишком долго не отвечает. Попробуйте ещё раз.';
    showToast(assistantMsg.content);
    forceUnstickGeneration(chat.id);
  }, 40000);

  try {
  if (unlistenChunk) { unlistenChunk(); unlistenChunk = null; }
  let lastAutosave = 0;
  let continuationMode = !!continueMsg;
  let continuationPending = '';
  let continuationCommitted = !continuationMode;
  let streamedChars = 0;
  let streamedPayloadText = '';
  let openGalleryGroupId = null;
  let gallerySequence = Object.keys(assistantMsg.galleryGroups || {}).length;
  const appendStreamText = (chunk, force = false) => {
    const incoming = String(chunk || '');
    streamedChars += incoming.length;
    streamedPayloadText += incoming;
    if (!continuationMode || continuationCommitted) {
      assistantMsg.content += incoming;
      return !!incoming;
    }
    continuationPending += incoming;
    // Если модель начала ответ с самого начала, ничего из перезапуска не
    // показываем по частям. После завершения потока вырезаем весь уже
    // существующий префикс по его хвосту и последовательности слов.
    const restarted = continuationLooksRestarted(assistantMsg.content, continuationPending);
    if (!force && restarted) return false;
    if (!force && continuationPending.length < 320 && !continuationPending.includes('\n\n')) return false;
    const cleaned = cleanContinuationStart(assistantMsg.content, continuationPending);
    continuationPending = '';
    continuationCommitted = true;
    assistantMsg.content += cleaned;
    return !!cleaned;
  };

  unlistenChunk = await listen('chat-chunk', (event) => {
    const keepFollowing = replyScrollState.follow
      && performance.now() >= (replyScrollState.manualUntil || 0);
    if (openGalleryGroupId && event.payload.content) openGalleryGroupId = null;
    let statusChanged = false;
    if (assistantMsg.imageStatus && !assistantMsg.imageStatus.done) { assistantMsg.imageStatus.done = true; statusChanged = true; }
    if (assistantMsg.audioStatus && !assistantMsg.audioStatus.done) { assistantMsg.audioStatus.done = true; statusChanged = true; }
    if (assistantMsg.thinkStatus && !assistantMsg.thinkStatus.done) { assistantMsg.thinkStatus.done = true; statusChanged = true; }
    if (statusChanged) refreshStatusRow();
    const appended = appendStreamText(event.payload.content);
    if (appended) clearReplyWatchdog();
    if (appended && assistantMsg.suppressEmptyThinking) delete assistantMsg.suppressEmptyThinking;
    const questionProbe = `${assistantMsg.content}${continuationPending}`;
    if (isStreamingFileDraft(questionProbe)) {
      if (!assistantMsg.filesStatus || assistantMsg.filesStatus.done) beginDocumentWork();
    } else {
      // Во время стрима доверяем только явному question-fence. Обычная фраза,
      // временно закончившаяся знаком «?», не должна включать ложный статус.
      if (/(```|~~~)\s*question/i.test(questionProbe)) {
        beginQuestionGeneration();
      }
    }
    if (!appended) return;
    // Сохраняем прогресс печати не реже раза в секунду (не на каждый токен —
    // localStorage не бесплатен при частых записях). Если приложение закроют
    // принудительно (⌘Q) посреди ответа, недописанный текст останется в
    // истории, и "продолжай" при следующем запуске будет с чем работать —
    // без этого недописанный текст existовал бы только в памяти и терялся.
    const now = Date.now();
    if (now - lastAutosave > 1000) { lastAutosave = now; save(); }
    const { contentEl, messagesArea, scrollBtn } = visibleReplyDom();
    if (contentEl && messagesArea) {
      const preservedTop = messagesArea.scrollTop;
      // Внутреннее рассуждение никогда не выводим как текст ответа — даже в
      // режиме «Рассуждение» показывается только статус, затем финальный ответ.
      let visibleContent = hideStreamingQuestionDraft(assistantDisplayContent(assistantMsg, false));
      if (assistantMsg.questionStatus && !assistantMsg.questionStatus.done) {
        const converted = convertPlainQuestionsToSurvey(visibleContent);
        if (converted !== visibleContent) visibleContent = converted.split(/```question/i)[0].trim();
      }
      const renderMessage = visibleContent === assistantMsg.content
        ? assistantMsg
        : { ...assistantMsg, content: visibleContent };
      contentEl.innerHTML = renderAssistantContent(renderMessage, chat.messages.indexOf(assistantMsg), true);
      if (keepFollowing) {
        pinMessagesToBottom(messagesArea);
        if (scrollBtn) scrollBtn.hidden = true;
      } else {
        // Перерисовка markdown не должна бороться с инерцией trackpad.
        messagesArea.scrollTop = preservedTop;
        replyScrollState.top = preservedTop;
        if (scrollBtn) scrollBtn.hidden = false;
      }
    }
  });

  // Обновляет строку статусов (изображение/думаю/поиск) над уже отрисованным
  // ответом, не перерисовывая весь чат — как и chat-chunk выше, работает
  // напрямую с DOM, чтобы не терять то, что уже успело напечататься.
  function refreshStatusRow() {
    const keepFollowing = replyScrollState.follow
      && performance.now() >= (replyScrollState.manualUntil || 0);
    const { articleEl, messagesArea, scrollBtn } = visibleReplyDom();
    const preservedTop = messagesArea?.scrollTop || 0;
    const slot = articleEl?.querySelector('.status-row-slot');
    const idx = chat.messages.indexOf(assistantMsg);
    if (slot) slot.outerHTML = statusRowHtml(assistantMsg, idx);
    if (keepFollowing && messagesArea) pinMessagesToBottom(messagesArea);
    else if (messagesArea) messagesArea.scrollTop = preservedTop;
    if (scrollBtn) scrollBtn.hidden = keepFollowing;
  }

  // Быстрые list/read/write могут завершиться между двумя кадрами WebView.
  // Минимальное время гарантирует, что пользователь реально увидит статус.
  const DOCUMENT_STATUS_MIN_MS = 700;
  let documentStatusGeneration = 0;
  const beginDocumentWork = () => {
    documentStatusGeneration += 1;
    assistantMsg.filesStatus = { done: false, startedAt: performance.now() };
    refreshStatusRow();
  };
  finishDocumentWork = async () => {
    if (!assistantMsg.filesStatus || assistantMsg.filesStatus.done) return;
    const generation = documentStatusGeneration;
    const elapsed = performance.now() - (assistantMsg.filesStatus.startedAt || 0);
    const wait = Math.max(0, DOCUMENT_STATUS_MIN_MS - elapsed);
    if (wait) await new Promise((resolve) => setTimeout(resolve, wait));
    if (generation !== documentStatusGeneration || !assistantMsg.filesStatus) return;
    assistantMsg.filesStatus.done = true;
    refreshStatusRow();
  };

  const QUESTION_STATUS_MIN_MS = 650;
  let questionStatusGeneration = 0;
  const beginQuestionGeneration = () => {
    if (assistantMsg.questionStatus && !assistantMsg.questionStatus.done) return;
    questionStatusGeneration += 1;
    assistantMsg.questionStatus = { done: false, startedAt: performance.now() };
    refreshStatusRow();
  };
  finishQuestionGeneration = async () => {
    if (!assistantMsg.questionStatus || assistantMsg.questionStatus.done) return;
    const generation = questionStatusGeneration;
    const elapsed = performance.now() - (assistantMsg.questionStatus.startedAt || 0);
    const wait = Math.max(0, QUESTION_STATUS_MIN_MS - elapsed);
    if (wait) await new Promise((resolve) => setTimeout(resolve, wait));
    if (generation !== questionStatusGeneration || !assistantMsg.questionStatus) return;
    assistantMsg.questionStatus.done = true;
    refreshStatusRow();
  };

  const refreshAssistantBody = () => {
    const { contentEl, messagesArea, scrollBtn } = visibleReplyDom();
    if (!contentEl || !messagesArea) return;
    const keepFollowing = replyScrollState.follow
      && performance.now() >= (replyScrollState.manualUntil || 0);
    const preservedTop = messagesArea.scrollTop;
    contentEl.innerHTML = renderAssistantContent(
      assistantMsg,
      chat.messages.indexOf(assistantMsg),
      true,
    );
    if (keepFollowing) {
      pinMessagesToBottom(messagesArea);
      if (scrollBtn) scrollBtn.hidden = true;
    } else {
      messagesArea.scrollTop = preservedTop;
      replyScrollState.top = preservedTop;
      if (scrollBtn) scrollBtn.hidden = false;
    }
  };

  // Пока модель ищет в интернете, бэкенд шлёт события "chat-search":
  // сперва с done:false (сам факт поиска и запрос — мерцающая подпись),
  // затем с done:true и списком источников (подпись гаснет, стрелка активна).
  if (unlistenSearch) { unlistenSearch(); unlistenSearch = null; }
  unlistenSearch = await listen('chat-search', (event) => {
    const incoming = event.payload || {};
    const previous = assistantMsg.search || { queries: [], sources: [], done: false };
    const queries = Array.isArray(previous.queries) ? [...previous.queries] : (previous.query ? [previous.query] : []);
    if (incoming.query && !queries.includes(incoming.query)) queries.push(incoming.query);
    const byUrl = new Map((previous.sources || []).map((src) => [src.url, src]));
    for (const src of incoming.sources || []) if (src?.url) byUrl.set(src.url, src);
    assistantMsg.search = {
      queries,
      query: queries.join(' · '),
      sources: [...byUrl.values()].slice(0, 5),
      done: !!incoming.done,
    };
    refreshStatusRow();
  });
  if (unlistenSearchError) { unlistenSearchError(); unlistenSearchError = null; }
  unlistenSearchError = await listen('chat-search-error', (event) => {
    const message = event.payload?.message
      || 'Не удалось выполнить поиск Tavily. Ответ будет дан без интернет-поиска.';
    showToast(message);
    if (assistantMsg.search) assistantMsg.search.done = true;
    refreshStatusRow();
  });

  // "Думаю" — пока локальный движок AmIgo/Groq присылают отдельное поле рассуждений (не
  // основной текст ответа), бэкенд шлёт события "chat-status": active:true,
  // когда рассуждение началось, active:false — когда модель перешла
  // к печати финального текста (см. chat-chunk выше — там тоже есть подстраховка).
  if (unlistenStatus) { unlistenStatus(); unlistenStatus = null; }
  unlistenStatus = await listen('chat-status', (event) => {
    const { kind, active: on } = event.payload;
    if (kind === 'thinking') {
      assistantMsg.thinkStatus = { done: !on };
      // Если параллельно шёл анализ изображения — гасим его при старте мышления
      if (on && assistantMsg.imageStatus && !assistantMsg.imageStatus.done) assistantMsg.imageStatus.done = true;
    } else if (kind === 'vision') {
      if (on) { assistantMsg.imageStatus = assistantMsg.imageStatus || { done: false }; }
      else if (assistantMsg.imageStatus) { assistantMsg.imageStatus.done = true; }
    } else if (kind === 'audio') {
      if (on) { assistantMsg.audioStatus = assistantMsg.audioStatus || { done: false }; }
      else if (assistantMsg.audioStatus) { assistantMsg.audioStatus.done = true; }
    } else if (kind === 'images') {
      if (!on && event.payload?.failed) {
        delete assistantMsg.imagePreparationStatus;
      } else {
        assistantMsg.imagePreparationStatus = {
          done: !on,
          count: Math.max(1, Number(event.payload?.count) || assistantMsg.imagePreparationStatus?.count || 1),
        };
      }
    } else if (kind === 'code') {
      if (on) assistantMsg.codeStatus = { done: false };
      else if (assistantMsg.codeStatus) assistantMsg.codeStatus.done = true;
    } else if (kind === 'files') {
      if (on) beginDocumentWork();
      else void finishDocumentWork();
      return;
    }
    refreshStatusRow();
  });

  // Модель сохранила/доработала файл в песочнице этого диалога (см.
  // sandbox_write_file на бэкенде) — добавляем к текущему ответу карточку
  // файла, чтобы результат сразу был виден и доступен, без ручного поиска
  // в Finder. Один и тот же файл может обновляться несколько раз за один
  // ответ (модель дорабатывает) — карточка на файл только одна. Если файл
  // тут же был удалён (delete_file, модель убирает за собой) — карточку не
  // показываем вовсе, а не оставляем ссылку на то, чего уже нет на диске.
  // Картинки (kind:"image", скачаны через download_image) идут отдельным
  // рядом миниатюр, а не карточкой с именем файла — их может быть сразу
  // несколько, ряд прокручивается по горизонтали, как и вложения.
  if (unlistenSandbox) { unlistenSandbox(); unlistenSandbox = null; }
  unlistenSandbox = await listen('sandbox-file', (event) => {
    if (String(event.payload?.chat_id) !== String(chat.id)) return;
    const path = event.payload?.path;
    if (!path) return;
    if (event.payload?.kind === 'image') {
      assistantMsg.sandboxImages = assistantMsg.sandboxImages || [];
      if (assistantMsg.sandboxImages.some((im) => im.name === path)) return;
      if (!openGalleryGroupId) {
        openGalleryGroupId = `g${gallerySequence++}`;
        assistantMsg.galleryGroups = assistantMsg.galleryGroups || {};
        assistantMsg.galleryGroups[openGalleryGroupId] = [];
        const separator = assistantMsg.content && !assistantMsg.content.endsWith('\n') ? '\n\n' : '';
        assistantMsg.content += `${separator}${galleryMarker(openGalleryGroupId)}\n\n`;
      }
      assistantMsg.galleryGroups[openGalleryGroupId].push(path);
      const entry = { name: path, dataUrl: null };
      assistantMsg.sandboxImages.push(entry);
      save();
      refreshAssistantBody();
      invoke('sandbox_read_image', { chatId: String(chat.id), filename: path })
        .then((dataUrl) => {
          if (!dataUrl || dataUrl.length < 64) throw new Error('empty_image');
          entry.dataUrl = dataUrl;
          if (assistantMsg.imagePreparationStatus) {
            assistantMsg.imagePreparationStatus.count = (assistantMsg.sandboxImages || []).filter((image) => image.dataUrl && image.dataUrl !== 'error').length || 1;
          }
          save(); refreshAssistantBody(); refreshStatusRow();
        })
        .catch(() => {
          // Пустой/повреждённый файл вообще не рисуем: ни серой карточки,
          // ни значка вопроса браузера.
          assistantMsg.sandboxImages = (assistantMsg.sandboxImages || []).filter((image) => image !== entry);
          for (const names of Object.values(assistantMsg.galleryGroups || {})) {
            const index = names.indexOf(path);
            if (index !== -1) names.splice(index, 1);
          }
          refreshAssistantBody();
        });
      return;
    }
    assistantMsg.sandboxFiles = assistantMsg.sandboxFiles || [];
    if (event.payload?.removed) {
      assistantMsg.sandboxFiles = assistantMsg.sandboxFiles.filter((p) => p !== path);
    } else if (!assistantMsg.sandboxFiles.includes(path)) {
      assistantMsg.sandboxFiles.push(path);
    }
    refreshStatusRow();
  });

  if (unlistenFinish) { unlistenFinish(); unlistenFinish = null; }
  unlistenFinish = await listen('chat-finish', (event) => {
    lastFinishReason = event.payload?.reason || null;
  });

    const provider = generationProvider;
    const model = generationModel;
    const effort = generationEffort;
    // После первой загрузки обязательно ждём завершения switch_model.
    // Раньше первый запрос мог одновременно со стартом сервера запустить
    // второй экземпляр и завершиться connection_error.
    if (provider === 'local') {
      await invoke('sandbox_health', { chatId: String(chat.id) })
        .catch((err) => { throw new Error(`connection_error: Песочница недоступна: ${String(err || '')}`); });
      try {
        await syncActiveModel({ force: true });
      } catch (firstStartError) {
        if (replyCancelled()) return;
        // Холодный первый запуск иногда не успевает завершить инициализацию.
        // Повторяем подготовку один раз внутри того же пользовательского запроса.
        assistantMsg.retryStatus = { done: false };
        refreshStatusRow();
        await new Promise((resolve) => setTimeout(resolve, 500));
        await syncActiveModel({ force: true });
        delete assistantMsg.retryStatus;
        refreshStatusRow();
      }
    }
    if (replyCancelled()) return;
    // Интернет-поиск снова работает только через Tavily. Не обещаем модели
    // доступ к сети, если ключа в Keychain нет.
    const tavilyAvailable = await invoke('has_tavily_key').catch(() => false);
    const searchAvailable = !!store.webSearchEnabled && tavilyAvailable && !continueMsg;
    const effortNote = effort === EFFORTS.fast
      ? 'Отвечай кратко и по существу, без долгих рассуждений.'
      : effort.think === true
      ? 'Перед финальным ответом тщательно проверь задачу, но не выводи внутренний ход рассуждений и не повторяй промежуточные выводы.'
      : 'Дай прямой содержательный ответ без вывода внутреннего хода рассуждений.';

    // Память: общий профиль + память конкретного диалога.
    // Другие чаты в контекст не попадают.
    let memoryBlock = '';
    if (store.memory) memoryBlock += `[Профиль пользователя]\n${store.memory}\n\n`;
    if (chat.memory) memoryBlock += `[Память этого диалога]\n${chat.memory}\n\n`;
    const noticedFacts = extractDurableFacts(chat.messages || []);
    if (noticedFacts.length) memoryBlock += `[Замеченные факты диалога]\n${noticedFacts.join('\n')}\n\n`;

    // Личность модели: имя и дата создания берутся из фиксированного списка
    // локальных моделей; для Groq — общее имя AmIgo.
    // Дата и время — реальные, с компьютера пользователя (Intl, не догадки
    // модели), чтобы на вопрос "какое сегодня число" не давать случайный ответ.
    const localDef = provider === 'local' ? localModelDef(model) : null;
    const nowStr = new Date().toLocaleString('ru-RU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    const lastUserMsg = [...chat.messages].reverse().find((m) => m.role === 'user');
    const sandboxFilesNow = provider === 'local'
      ? ((await invoke('sandbox_list', { chatId: String(chat.id) }).catch(() => [])) || [])
      : [];
    const identityBlock = localDef
      ? `Тебя зовут ${localDef.label}. Дата твоего создания: ${localDef.created}. Ты работаешь локально на устройстве пользователя.`
      : 'Тебя зовут AmIgo.';
    const prefersTy = /(?:\bна\s+[«"']?ты[»"']?\b|обращ(?:айся|аться|ение)[^\n]{0,30}\bты\b|не\s+обращайся[^\n]{0,20}\bвы\b)/iu.test(`${store.memory || ''}\n${chat.memory || ''}`);

    const allMsgs = chat.messages.filter((m) => m !== assistantMsg);
    const topicMsgs = allMsgs.filter((m) => (Number.isInteger(m.topicId) ? m.topicId : 0) === requestTopicId);
    const turn = classifyTurn({
      text: lastUserMsg?.content || '',
      attachments: lastUserMsg?.attachments || [],
      sandboxFiles: sandboxFilesNow,
      searchAvailable,
      continueMsg: !!continueMsg,
    });
    const heavyInput = turn.hasTextFiles || turn.hasImages || sandboxFilesNow.length > 0;
    const CONTEXT_WINDOW = heavyInput ? 16 : 28;
    const oldMsgs = topicMsgs.length > CONTEXT_WINDOW ? topicMsgs.slice(0, -CONTEXT_WINDOW) : [];
    const recentMsgs = topicMsgs.length > CONTEXT_WINDOW ? topicMsgs.slice(-CONTEXT_WINDOW) : topicMsgs;
    const resolvedQuestionsForRequest = resolvedQuestionHistory(recentMsgs, requestTopicId, assistantMsg);
    const reusableCodeBlocks = collectConversationCodeBlocks(recentMsgs);
    const droppedDigest = compactDroppedMessages(oldMsgs);

    let evidenceHits = [];
    if (shouldGatherEvidence({
      intent: turn.intent,
      continueMsg: !!continueMsg,
      attachments: lastUserMsg?.attachments || [],
      sandboxFiles: sandboxFilesNow,
    })) {
      const documents = collectAttachmentDocuments(topicMsgs);
      const retrieveQuery = expandSearchQuery(lastUserMsg?.content || '') || (lastUserMsg?.content || '');
      const named = mentionedFilenames(lastUserMsg?.content || '', sandboxFilesNow);
      const focused = named.length
        ? documents.filter((doc) => named.includes(doc.name)).concat(documents.filter((doc) => !named.includes(doc.name)))
        : documents;
      evidenceHits = retrieveFromDocuments(focused, retrieveQuery, { maxHits: 8, maxChars: 7200 });
      const covered = new Set(evidenceHits.map((hit) => hit.path));
      const missing = sandboxFilesNow.filter((name) => !covered.has(name) && !isImageFilename(name));
      if (missing.length) {
        beginDocumentWork();
        try {
          const remote = await invoke('sandbox_retrieve', {
            chatId: String(chat.id),
            query: String(lastUserMsg?.content || '').slice(0, 400),
            maxHits: 8,
          });
          if (Array.isArray(remote?.hits) && remote.hits.length) {
            evidenceHits = mergeHits(evidenceHits, remote.hits.map((hit) => ({
              path: hit.path,
              offset: hit.offset,
              snippet: hit.snippet,
              score: hit.score,
              total: hit.total,
            })));
          }
        } catch {
          for (const name of missing.slice(0, 3)) {
            try {
              const preview = await invoke('sandbox_preview_file', { chatId: String(chat.id), filename: name });
              if (preview?.kind === 'text' || preview?.kind === 'document') {
                const extra = retrieveFromDocuments(
                  [{ name, text: String(preview.content || '').slice(0, 80_000) }],
                  retrieveQuery,
                  { maxHits: 3, maxChars: 2500 },
                );
                evidenceHits = mergeHits(evidenceHits, extra);
              }
            } catch { /* файл недоступен как текст */ }
          }
        }
      }
    }
    const evidence = formatEvidence(evidenceHits);

    let system = buildSystemPrompt({
      identityBlock,
      nowStr,
      intent: turn.intent,
      searchAvailable,
      continueMsg: !!continueMsg,
      provider,
      isCoder: !!localDef?.coder,
      prefersTy,
      memoryBlock,
      effortNote,
      sandboxFiles: sandboxFilesNow,
      evidencePresent: !!evidence,
      reusableCodeBlocks,
      resolvedAnswers: resolvedQuestionsForRequest,
      chatSummary: requestTopicId === 0 ? (chat.summary || '') : '',
      droppedDigest,
      requestTopicId,
      conciseCapability: !continueMsg && isConciseCapabilityQuestion(lastUserMsg?.content || ''),
      preferFiles: provider === 'local' && ['nage-1.5', 'mentis-3'].includes(model),
    });

    const attachmentNames = (m) => (m.attachments || []).map((d) => d.sandboxPath || d.name).filter(Boolean);
    const historicalUserContent = (m) => {
      const names = attachmentNames(m);
      const note = names.length ? `\n\n[Вложения того сообщения: ${names.join(', ')}]` : '';
      return (m.content || '') + note;
    };
    const buildContent = (m) => {
      const textAtts = (m.attachments || []).filter((d) => d.kind === 'text' || d.kind === 'paste' || d.kind === 'audio');
      const fileAtts = (m.attachments || []).filter((d) => d.kind === 'file');
      const imageAtts = (m.attachments || []).filter((d) => d.kind === 'image');
      let extra = '';
      for (const d of textAtts) {
        const source = String(d.text || '');
        const label = d.kind === 'audio' ? 'Локально распознанная аудиозапись' : 'Прикреплённый файл';
        if (d.kind === 'audio') {
          const body = source.slice(0, 4000);
          extra += `\n\n[${label}: ${d.name}]\n${body}${body.length < source.length ? `\n[показано ${body.length} символов из ${source.length}]` : ''}`;
          continue;
        }
        extra += `\n\n[${label}: ${d.name}, ${source.length} символов. Полный текст в песочнице — релевантные фрагменты уже подобраны ниже, иначе читай read_file с offset/limit.]`;
      }
      if (fileAtts.length) extra += `\n\n[Также прикреплены файлы без читаемого содержимого: ${fileAtts.map((d) => d.name).join(', ')}]`;
      if (imageAtts.length) extra += `\n\n[К сообщению приложено фото: ${imageAtts.map((d) => d.sandboxPath || d.name).join(', ')}. Они переданы как изображения.]`;
      const sandboxRefs = attachmentNames(m);
      if (sandboxRefs.length) extra += `\n\n[Оригиналы вложений сохранены в песочнице: ${sandboxRefs.join(', ')}. Для больших файлов — search_file / read_file с offset/limit.]`;
      return (m.content || '') + extra;
    };

    const lastUserIdx = recentMsgs.map((m) => m.role).lastIndexOf('user');
    const hasImages = lastUserIdx >= 0 && recentMsgs[lastUserIdx].attachments?.some((d) => d.kind === 'image');
    let visionOk = false;
    if (hasImages && provider === 'local' && model) {
      visionOk = await invoke('model_supports_vision', { model }).catch(() => false);
      if (!visionOk) showToast('Фото не поддерживается');
    } else if (hasImages && provider !== 'local') {
      showToast('Фото не поддерживается');
    }

    if (visionOk) {
      assistantMsg.imageStatus = { done: false };
      refreshStatusRow();
    }
    const hasAudio = lastUserIdx >= 0 && recentMsgs[lastUserIdx].attachments?.some((d) => d.kind === 'audio');
    if (hasAudio) {
      assistantMsg.audioStatus = { done: false };
      refreshStatusRow();
    }

    let messagesForModel = recentMsgs.map((m, i) => {
      const savedImages = m.role === 'assistant' && m.sandboxImages?.length
        ? `\n\n[Сохранённые изображения этого ответа: ${m.sandboxImages.map((im) => im.name).join(', ')}]`
        : '';
      const userContent = m.role === 'user'
        ? (i === lastUserIdx ? buildContent(m) : historicalUserContent(m))
        : '';
      const currentPrefix = m.role === 'user' && i === lastUserIdx
        ? userTaskPrefix({ intent: turn.intent, isCoder: !!localDef?.coder })
        : '';
      const msg = {
        role: m.role,
        content: m.role === 'user'
          ? currentPrefix + userContent
          : stripGalleryMarkers(m.content || '') + savedImages,
      };
      if (visionOk && m.role === 'user' && i === lastUserIdx) {
        const imgs = (m.attachments || []).filter((d) => d.kind === 'image' && d.imageDataUrl);
        const MAX_VISION_IMAGES = 6;
        if (imgs.length) {
          msg.images = imgs.slice(0, MAX_VISION_IMAGES).map((d) => d.imageDataUrl);
          if (imgs.length > MAX_VISION_IMAGES) {
            msg.content += `\n\n[Модель видит первые ${MAX_VISION_IMAGES} фото. Остальные сохранены в песочнице: ${imgs.slice(MAX_VISION_IMAGES).map((d) => d.sandboxPath || d.name).join(', ')}. ]`;
          }
        }
      }
      return msg;
    });

    const packed = packTurn({
      system,
      evidence,
      messages: messagesForModel.map((m) => ({ role: m.role, content: m.content || '' })),
      budget: contextBudget({
        numCtx: provider === 'local' ? Math.min(Number(effort.num_ctx) || 12_288, 12_288) : (Number(effort.num_ctx) || 32_768),
        hasImages: visionOk,
        imageCount: (messagesForModel.find((m) => m.images?.length)?.images || []).length,
        reserveOutput: visionOk ? 2_048 : Math.min(Number(effort.max_tokens) || 4_096, 4_096),
        provider,
      }),
      lastUserMax: heavyInput ? 1_000 : 2_400,
      otherMax: heavyInput ? 480 : 900,
    });
    system = packed.system;
    const lastPackedUser = packed.messages.map((m) => m.role).lastIndexOf('user');
    const originalImages = messagesForModel.find((m) => m.images?.length)?.images;
    messagesForModel = packed.messages.map((m, i) => {
      const next = { role: m.role, content: m.content };
      if (i === lastPackedUser && originalImages) next.images = originalImages;
      if (i === lastPackedUser && packed.evidence) next.content = `${next.content}\n\n${packed.evidence}`;
      return next;
    });

    // Продолжение оборванного ответа (см. sendMessage): allMsgs выше уже
    // исключил assistantMsg целиком (обычная логика — не отправлять пустой
    // черновик как часть истории), а значит без этого блока модель вообще
    // не увидела бы, что и где она успела написать, и просто ответила бы
    // на исходный вопрос заново. Явно показываем ей оборванный текст и
    // просим продолжить именно с этого места, не повторяясь.
    if (continueMsg) {
      // Частичный текст передаётся правильной ролью assistant. Когда он был
      // вложен внутрь user-сообщения, модель часто начинала ответ заново.
      messagesForModel.push({
        role: 'assistant',
        content: stripGalleryMarkers(withoutThinkingMarkup(assistantMsg.content)).trimEnd(),
      });
      messagesForModel.push({
        role: 'user',
        content: `[ПРОДОЛЖЕНИЕ] Продолжи строго после последнего уже написанного фрагмента: «${stripGalleryMarkers(withoutThinkingMarkup(assistantMsg.content)).slice(-240)}». Первым символом ответа должен быть следующий новый символ или слово. Запрещено повторять ответ с начала, заголовок, вступление, предыдущий абзац, пункты или открывать новый markdown-fence. Не пиши «Продолжение» и не объясняй действие.`,
      });
    }

    const summaryInjection = [];
    const currentUserMessage = lastUserIdx >= 0 ? recentMsgs[lastUserIdx] : null;
    const conciseCapabilityRequest = !continueMsg && isConciseCapabilityQuestion(currentUserMessage?.content || '');
    if (conciseCapabilityRequest) {
      system += '\n\n[ФОРМАТ ТЕКУЩЕГО ОТВЕТА] Самостоятельно ответь на вопрос о своих возможностях естественно и конкретно для выбранной модели. Это не заготовленный текст. Максимум два коротких предложения, без заголовков, списков, саморекламы и приглашения «дай знать».';
    }
    const unlimitedOutput = continueMsg?.unlimitedOutput ?? isUnlimitedCreationTask(
      currentUserMessage?.content || '',
      currentUserMessage?.attachments || [],
    );
    assistantMsg.unlimitedOutput = !!unlimitedOutput;
    const sampler = samplerForIntent(turn.intent, effort);
    const req = { provider, model, messages: [{ role: 'system', content: system }, ...summaryInjection, ...messagesForModel], web_search: !!store.webSearchEnabled && !continueMsg, temperature: sampler.temperature, num_ctx: effort.num_ctx, max_tokens: conciseCapabilityRequest ? 384 : (unlimitedOutput ? 16384 : sampler.max_tokens), unlimited_output: !!unlimitedOutput, chat_id: String(chat.id), code_blocks: reusableCodeBlocks };
    if (model === 'matle-2.5') req.think = false;
    else if (effort.think !== undefined) req.think = effort.think;
    if (replyCancelled()) return;
    let automaticRetryUsed = false;
    let responseStreamStart = streamedPayloadText.length;
    let full;
    try {
      full = await invoke('chat_stream', { req });
    } catch (firstError) {
      if (replyCancelled()) return;
      const stalled = /generation_stalled|не отвечает|timed?\s*out|timeout|deadline/i.test(String(firstError || ''));
      const canRetry = (stalled || generationProvider === 'local')
        && !assistantMsg.content.trim()
        && String(stopRequestedChatId) !== String(chat.id);
      if (!canRetry) throw firstError;

      automaticRetryUsed = true;
      assistantMsg.retryStatus = { done: false };
      refreshStatusRow();
      await new Promise((resolve) => setTimeout(resolve, 400));
      if (replyCancelled()) return;
      try {
        lastFinishReason = null;
        responseStreamStart = streamedPayloadText.length;
        await syncActiveModel({ force: true }).catch(() => {});
        const retryReq = { ...req, think: false };
        full = await invoke('chat_stream', { req: retryReq });
      } finally {
        if (assistantMsg.retryStatus) delete assistantMsg.retryStatus;
        refreshStatusRow();
      }
    }
    if (replyCancelled()) return;
    if (continuationMode && continuationPending) appendStreamText('', true);
    // Сверяем события с полным текстом, возвращённым Rust. Если WebView был
    // приостановлен в фоне и потерял часть chat-chunk, дописываем хвост.
    if (full) {
      const received = streamedPayloadText.slice(responseStreamStart);
      const overlap = longestSuffixPrefix(received, full);
      const missing = full.slice(overlap);
      if (missing) {
        assistantMsg.content += continuationMode
          ? cleanContinuationStart(assistantMsg.content, missing)
          : missing;
      }
    }

    // finish_reason=length, незакрытый fence или оборванный код/файл —
    // дописываем. Для создания кода/файлов проходов столько, сколько нужно.
    let autoContinuationCount = 0;
    const visibleContent = () => stripGalleryMarkers(withoutThinkingMarkup(assistantMsg.content));
    const lastSandboxIncomplete = async () => {
      const names = assistantMsg.sandboxFiles || [];
      const last = names[names.length - 1];
      if (!last) return false;
      try {
        const preview = await invoke('sandbox_preview_file', { chatId: String(chat.id), filename: last });
        return preview?.kind === 'text' && sourceLooksIncomplete(preview.content || '');
      } catch {
        return false;
      }
    };
    const needsContinuation = async () => (
      shouldAutoContinueReply(visibleContent(), lastFinishReason)
      || await lastSandboxIncomplete()
    );
    const autoContinuationLimit = unlimitedOutput || looksLikeIncompleteCode(visibleContent()) ? 12 : 2;
    while (autoContinuationCount < autoContinuationLimit
      && !replyCancelled()
      && await needsContinuation()) {
      autoContinuationCount += 1;
      const contentLengthBeforeContinuation = assistantMsg.content.length;
      lastFinishReason = null;
      continuationMode = true;
      continuationCommitted = false;
      continuationPending = '';
      const continuationStart = streamedChars;
      const continuationPayloadStart = streamedPayloadText.length;
      const previousTail = visibleContent().slice(-6000);
      const lastUser = [...req.messages].reverse().find((message) => message.role === 'user');
      const openFence = hasUnclosedFence(visibleContent());
      const incompleteCode = looksLikeIncompleteCode(visibleContent());
      if (incompleteCode && (assistantMsg.codeOnlyFiles || assistantMsg.codeStatus)) {
        assistantMsg.codeStatus = { done: false };
        refreshStatusRow();
      } else if (incompleteCode || isStreamingFileDraft(visibleContent())) {
        beginDocumentWork();
      }
      const continueHint = openFence
        ? 'Сейчас открыт незакрытый fenced-блок: допиши только его тело и закрой теми же ```. Не открывай новый блок.'
        : incompleteCode
        ? 'Код или файл оборван: незакрытые скобки или незаконченная строка. Допиши до синтаксически завершённого состояния и закрой блок.'
        : 'Продолжи строго с места обрыва.';
      const continuationReq = {
        ...req,
        think: false,
        web_search: false,
        unlimited_output: true,
        max_tokens: 8192,
        messages: [
          {
            role: 'system',
            content: 'Продолжи незаконченный ответ строго с места обрыва. Не начинай заново, не пиши «Продолжение», не повторяй уже написанное, не открывай новый fence, если предыдущий ещё открыт. Если это код или файл — закончи его целиком: закрой скобки, функции и fence.',
          },
          ...(lastUser ? [{ role: 'user', content: String(lastUser.content || '').slice(-4000) }] : []),
          { role: 'assistant', content: previousTail },
          {
            role: 'user',
            content: `[АВТОПРОДОЛЖЕНИЕ] ${continueHint} Последний уже написанный фрагмент: «${previousTail.slice(-240)}». Выведи только новые символы после обрыва.`,
          },
        ],
      };
      const continuationFull = await invoke('chat_stream', { req: continuationReq });
      if (continuationPending) appendStreamText('', true);
      if (continuationFull) {
        const received = streamedPayloadText.slice(continuationPayloadStart);
        const overlap = longestSuffixPrefix(received, continuationFull);
        const missing = continuationFull.slice(overlap);
        if (missing) {
          assistantMsg.content += cleanContinuationStart(assistantMsg.content, missing);
        } else if (streamedChars === continuationStart) {
          assistantMsg.content += cleanContinuationStart(assistantMsg.content, continuationFull);
        }
      }
      if (assistantMsg.content.length <= contentLengthBeforeContinuation + 8) break;
    }
    continuationMode = false;
    assistantMsg.content = removeRepeatedProse(collapseRepeatedWholeResponse(withoutThinkingMarkup(assistantMsg.content)));

    // Даже если запрос формально завершился без ошибки, пустой результат не
    // считается ответом: выполняем один non-thinking повтор.
    let stoppedByUser = replyCancelled();
    if (!continueMsg
      && !assistantMsg.content.trim()
      && !automaticRetryUsed
      && !stoppedByUser) {
      automaticRetryUsed = true;
      if (assistantMsg.thinkStatus) assistantMsg.thinkStatus.done = true;
      assistantMsg.retryStatus = { done: false };
      refreshStatusRow();
      const retryStart = streamedChars;
      try {
        lastFinishReason = null;
        const retryReq = { ...req, think: false, web_search: false, max_tokens: EFFORTS.normal.max_tokens };
        const retryFull = await invoke('chat_stream', { req: retryReq });
        if (streamedChars === retryStart && retryFull) assistantMsg.content += retryFull;
      } finally {
        if (assistantMsg.retryStatus) delete assistantMsg.retryStatus;
        refreshStatusRow();
      }
      assistantMsg.content = withoutThinkingMarkup(assistantMsg.content);
      stoppedByUser = String(stopRequestedChatId) === String(chat.id);
    }

    if (!continueMsg
      && evidence
      && looksLikeGroundingFailure(assistantMsg.content)
      && String(stopRequestedChatId) !== String(chat.id)) {
      assistantMsg.retryStatus = { done: false };
      refreshStatusRow();
      const previousFail = assistantMsg.content;
      assistantMsg.content = '';
      const groundStart = streamedPayloadText.length;
      try {
        lastFinishReason = null;
        const groundReq = {
          ...req,
          think: false,
          web_search: false,
          temperature: 0.2,
          messages: [
            { role: 'system', content: 'Ответь строго по фрагментам файлов в сообщении пользователя. Запрещено говорить, что файла нет или нет доступа. Если во фрагментах нет ответа — напиши, чего не хватает, без отговорок.' },
            ...messagesForModel,
            { role: 'user', content: '[КОРРЕКЦИЯ] Фрагменты уже даны ниже в запросе. Ответь по ним.' },
          ],
        };
        const groundFull = await invoke('chat_stream', { req: groundReq });
        if (!assistantMsg.content.trim() && groundFull) assistantMsg.content = groundFull;
        else {
          const received = streamedPayloadText.slice(groundStart);
          const overlap = longestSuffixPrefix(received, groundFull || '');
          const missing = (groundFull || '').slice(overlap);
          if (missing) assistantMsg.content += missing;
        }
        if (!assistantMsg.content.trim()) assistantMsg.content = previousFail;
      } finally {
        if (assistantMsg.retryStatus) delete assistantMsg.retryStatus;
        refreshStatusRow();
      }
      assistantMsg.content = withoutThinkingMarkup(assistantMsg.content);
      stoppedByUser = String(stopRequestedChatId) === String(chat.id);
    }

    if (stoppedByUser) {
      assistantMsg.continuationDraft = withoutThinkingMarkup(assistantMsg.content);
      assistantMsg.content = sanitizeStoppedContent(assistantMsg.content, initialContentLength);
      if (!assistantMsg.content.trim() && assistantMsg.continuationDraft.trim()) {
        assistantMsg.content = '_Создание файла приостановлено. Команда «продолжай» допишет его с места остановки._';
      }
    }
    if (!stoppedByUser) {
      delete assistantMsg.continuationDraft;
      assistantMsg.content = stripEchoedUserPrompt(
        stripLeakedToolCalls(removeRepeatedProse(collapseRepeatedWholeResponse(assistantMsg.content))),
        currentUserMessage?.content || '',
      );
      assistantMsg.content = cleanImageDeliveryText(assistantMsg);
      assistantMsg.content = normalizeSurveyContent(convertPlainQuestionsToSurvey(assistantMsg.content));

      // Если модель снова задала уже закрытый вопрос, пользователь его даже не
      // увидит: AmIgo подставляет сохранённый ответ и просит модель продолжить
      // исходную задачу. До четырёх таких циклов выполняются автоматически.
      let repeatedQuestionRounds = 0;
      while (repeatedQuestionRounds < 4 && String(stopRequestedChatId) !== String(chat.id)) {
        const duplicateRaw = assistantMsg.content;
        const filtered = filterResolvedSurvey(duplicateRaw, resolvedQuestionsForRequest);
        assistantMsg.content = filtered.content;
        if (!filtered.repeated.length || filtered.remaining.length) break;

        repeatedQuestionRounds += 1;
        delete assistantMsg.questionStatus;
        assistantMsg.retryStatus = { done: false };
        refreshStatusRow();
        const known = filtered.repeated.map(({ current, previous }) =>
          `${current.question} — ${previous.answer}`
        ).join('\n');
        const retryStart = streamedChars;
        const retryPayloadStart = streamedPayloadText.length;
        const repeatReq = {
          ...req,
          think: false,
          web_search: false,
          messages: [
            ...req.messages,
            { role: 'assistant', content: stripGalleryMarkers(duplicateRaw) },
            {
              role: 'user',
              content: `[СИСТЕМНАЯ КОРРЕКЦИЯ ПОВТОРА] Ты повторно задал уже закрытый вопрос. Ответ уже получен:\n${known}\nНе задавай этот вопрос или его перефразирование снова. Немедленно продолжи и выполни исходную задачу, используя этот ответ.`,
            },
          ],
        };
        lastFinishReason = null;
        const repeatFull = await invoke('chat_stream', { req: repeatReq });
        if (repeatFull) {
          const received = streamedPayloadText.slice(retryPayloadStart);
          const overlap = longestSuffixPrefix(received, repeatFull);
          const missing = repeatFull.slice(overlap);
          if (missing) assistantMsg.content += missing;
        } else if (streamedChars === retryStart) {
          break;
        }
        assistantMsg.content = normalizeSurveyContent(convertPlainQuestionsToSurvey(
          removeRepeatedProse(collapseRepeatedWholeResponse(withoutThinkingMarkup(assistantMsg.content)))
        ));
        delete assistantMsg.retryStatus;
        refreshStatusRow();
      }
      if (assistantMsg.retryStatus) {
        delete assistantMsg.retryStatus;
        refreshStatusRow();
      }

      // Смешанный опрос может содержать и новый, и повторный вопрос: повторный
      // удаляем, пользователю показываем только действительно новое уточнение.
      assistantMsg.content = filterResolvedSurvey(
        assistantMsg.content,
        resolvedQuestionsForRequest,
      ).content;
      if (parseQuestionBlocks(assistantMsg.content).length) beginQuestionGeneration();
      assistantMsg.content = normalizeSurveyContent(await enrichSurveyOptions(assistantMsg.content, provider, model));
      assistantMsg.content = filterResolvedSurvey(
        assistantMsg.content,
        resolvedQuestionsForRequest,
      ).content;
      if (parseQuestionBlocks(assistantMsg.content).length) {
        await finishQuestionGeneration();
        delete assistantMsg.questionStatus;
      }
    }
    assistantMsg.stopped = stoppedByUser;
    if (!assistantMsg.content.trim() && !stoppedByUser) {
      const emptyFailure = assistantMsg.search
        ? 'Не удалось получить ответ с Tavily. Перезапустите ответ или проверьте ключ Tavily.'
        : provider === 'groq'
        ? 'Не удалось получить ответ Groq. Перезапустите ответ или проверьте ключ Groq.'
        : 'Модель не вернула ответ после повторной попытки. Перезапустите ответ.';
      assistantMsg.content = emptyFailure;
      showToast(emptyFailure);
    }
    // Не сохраняем недописанный именованный блок как готовый файл после Стоп.
    if (!stoppedByUser) {
      const hasGeneratedDocuments = generatedFileBlocks(assistantMsg.content).length > 0;
      if (hasGeneratedDocuments) beginDocumentWork();
      await persistGeneratedFiles(assistantMsg, chat);
      if (hasGeneratedDocuments) await finishDocumentWork();
    }
  } catch (err) {
    const stoppedByUser = String(stopRequestedChatId) === String(chat.id)
      || /generation_stopped/i.test(String(err || ''));
    if (stoppedByUser) {
      // Отмена запроса/потока — ожидаемый результат нажатия кнопки, не ошибка.
      assistantMsg.continuationDraft = withoutThinkingMarkup(assistantMsg.content);
      assistantMsg.content = sanitizeStoppedContent(assistantMsg.content, initialContentLength);
      if (!assistantMsg.content.trim() && assistantMsg.continuationDraft.trim()) {
        assistantMsg.content = '_Создание файла приостановлено. Команда «продолжай» допишет его с места остановки._';
      }
      assistantMsg.stopped = true;
    } else {
      console.warn('AmIgo generation failed:', err);
      const errorText = String(err || 'Неизвестная ошибка');
      const hadPartialAnswer = !!assistantMsg.content.trim();
      if (hadPartialAnswer) {
        // Ошибка после уже начавшегося ответа не перекрывает чтение тостом.
        assistantMsg.content = `${assistantMsg.content}\n\n_Ответ прерван. Попробуйте ещё раз._`;
      } else {
        const isDailyLimit = /дневной лимит/i.test(errorText);
        const isTavilyError = /tavily|поиск|источник/i.test(errorText);
        const isContextLimit = /context size|context length|n_ctx|n_tokens|превыш.*контекст|слишком много (фото|текста|содержимого|влож)/i.test(errorText);
        const friendly = isDailyLimit
          ? 'Дневной лимит Tavily исчерпан: 32 обращения. Поиск снова станет доступен завтра.'
          : isTavilyError
          ? 'Не удалось получить ответ с Tavily. Перезапустите ответ или проверьте ключ Tavily.'
          : isContextLimit
          ? 'Слишком много фото или текста файлов для контекста модели. Отправьте меньше вложений за один раз — они уже сохранены в песочнице.'
          : generationProvider === 'groq'
          ? 'Не удалось получить ответ Groq. Перезапустите ответ или проверьте ключ Groq.'
          : errorText.replace(/^connection_error:\s*/, '').split('\n').slice(-12).join('\n').slice(-1000);
        showToast(friendly);
        assistantMsg.content = friendly;
      }
    }
  } finally {
    clearReplyWatchdog();
    try {
      if (assistantMsg.imageStatus && !assistantMsg.imageStatus.done) assistantMsg.imageStatus.done = true;
      if (assistantMsg.audioStatus && !assistantMsg.audioStatus.done) assistantMsg.audioStatus.done = true;
      if (assistantMsg.thinkStatus && !assistantMsg.thinkStatus.done) assistantMsg.thinkStatus.done = true;
      if (assistantMsg.codeStatus && !assistantMsg.codeStatus.done) assistantMsg.codeStatus.done = true;
      if (assistantMsg.filesStatus && !assistantMsg.filesStatus.done) await finishDocumentWork();
      if (assistantMsg.questionStatus && !assistantMsg.questionStatus.done) await finishQuestionGeneration();
      if (assistantMsg.questionStatus) delete assistantMsg.questionStatus;
      if (assistantMsg.retryStatus) delete assistantMsg.retryStatus;
      if (assistantMsg.search && !assistantMsg.search.done) assistantMsg.search.done = true;
    } catch (cleanupErr) { console.warn('AmIgo generation cleanup:', cleanupErr); }
    if (unlistenChunk) { try { unlistenChunk(); } catch {} unlistenChunk = null; }
    if (unlistenSearch) { try { unlistenSearch(); } catch {} unlistenSearch = null; }
    if (unlistenSearchError) { try { unlistenSearchError(); } catch {} unlistenSearchError = null; }
    if (unlistenStatus) { try { unlistenStatus(); } catch {} unlistenStatus = null; }
    if (unlistenSandbox) { try { unlistenSandbox(); } catch {} unlistenSandbox = null; }
    const stoppedByUser = String(stopRequestedChatId) === String(chat.id);
    const stillMine = seq === generationSeq;
    try {
      if (stillMine && stoppedByUser && !continueMsg && !assistantMsg.continuationDraft && assistantMsg.content.length <= initialContentLength) {
        const index = chat.messages.indexOf(assistantMsg);
        if (index !== -1) chat.messages.splice(index, 1);
      }
      assistantMsg.continuable = !!(assistantMsg.stopped || assistantMsg.continuationDraft || lastFinishReason === 'length' || looksLikeIncompleteCode(assistantMsg.content || ''));
      if (!assistantMsg.continuable) delete assistantMsg.continuationDraft;
    } catch (finishErr) { console.warn('AmIgo generation finish:', finishErr); }
    if (String(stopRequestedChatId) === String(chat.id)) stopRequestedChatId = null;
    await invoke('end_generation').catch(() => {});
    if (stillMine && String(busyChatId) === String(chat.id)) busyChatId = null;
    save();
    render();
    if (stillMine && !stoppedByUser) {
      maybeGenerateSummary(chat, generationProvider, generationModel);
      maybeGenerateTitle(chat, generationProvider, generationModel);
    }
  }
}

// Генерирует краткую сводку начала диалога, чтобы не грузить всю историю в контекст.
// Не блокирует UI — запускается в фоне после ответа.
async function maybeGenerateSummary(chat = active, providerOverride = null, modelOverride = null) {
  if (!chat) return;
  const msgs = chat.messages;
  const THRESHOLD = 24;
  const REGEN_EVERY = 8;
  if (msgs.length < THRESHOLD) return;
  const lastSummaryAt = chat.summaryAt || 0;
  if (msgs.length - lastSummaryAt < REGEN_EVERY && chat.summary) return;

  const provider = providerOverride || chatPreference(chat, 'provider');
  const model = modelOverride || selectedModelFor(chat, provider);
  if (!model) return;

  // Суммируем только старые сообщения (до окна контекста), не грузя свежие.
  const CONTEXT_WINDOW = 28;
  const toSummarize = msgs.slice(0, -CONTEXT_WINDOW);
  if (toSummarize.length < 5) return;

  try {
    const summaryMessages = [
      { role: 'system', content: 'Ты — краткий конспектировщик. Напиши сжатое резюме приведённого разговора (3–7 предложений), сохранив ключевые факты, решения и контекст. Только резюме, без лишних слов.' },
      ...toSummarize.map((m) => ({
        role: m.role,
        content: m.role === 'assistant' ? stripGalleryMarkers(m.content || '') : (m.content || ''),
      })),
      { role: 'user', content: 'Сделай краткое резюме этого разговора для использования как контекст.' },
    ];
    const req = { provider, model, messages: summaryMessages, web_search: false, temperature: 0.3, num_ctx: 8192 };
    const summary = await invoke('chat_complete_silent', { req });
    if (summary && chat) {
      chat.summary = summary.trim();
      chat.summaryAt = msgs.length;
      save();
    }
  } catch { /* тихо игнорируем — сводка некритична */ }
}

// Придумывает короткое название диалога после первого обмена репликами —
// не трогает диалоги, которые пользователь уже переименовал сам (или
// которым название уже подобрали автоматически): active.title к этому
// моменту перестаёт быть значением по умолчанию "Новый диалог".
async function maybeGenerateTitle(chat = active, providerOverride = null, modelOverride = null) {
  if (!chat) return;
  if (chat.title !== 'Новый диалог') return;
  const firstUser = chat.messages.find((m) => m.role === 'user');
  const firstAssistant = chat.messages.find((m) => m.role === 'assistant');
  if (!firstUser || !firstAssistant || !(firstAssistant.content || '').trim()) return;

  const provider = providerOverride || chatPreference(chat, 'provider');
  const model = modelOverride || selectedModelFor(chat, provider);
  if (!model) return;

  try {
    const titleMessages = [
      { role: 'system', content: 'Придумай короткое название для этого диалога: 2–5 слов, без кавычек и без точки в конце, на том же языке, на котором пишет пользователь. Ответь только названием, больше ничего не пиши.' },
      { role: 'user', content: `Сообщение пользователя: ${firstUser.content.slice(0, 500)}\n\nОтвет ассистента: ${stripGalleryMarkers(firstAssistant.content || '').slice(0, 500)}` },
    ];
    const req = { provider, model, messages: titleMessages, web_search: false, temperature: 0.3, num_ctx: 4096 };
    const title = await invoke('chat_complete_silent', { req });
    const clean = (title || '').trim().replace(/^["'«]+|["'»]+$/g, '').replace(/[.!]+$/, '').trim();
    if (clean && chat && chat.title === 'Новый диалог') {
      chat.title = clean.slice(0, 60);
      save();
      render();
    }
  } catch { /* тихо игнорируем — заголовок некритичен, останется "Новый диалог" */ }
}

function dismissOpenQuestionCards(chat) {
  for (const message of chat?.messages || []) {
    if (message.role !== 'assistant' || message.questionDismissed) continue;
    const questions = parseQuestionBlocks(message.content || '');
    if (!questions.length) continue;
    const answered = message.questionAnswers || {};
    const unanswered = questions.filter((question) => answered[question.qid] === undefined);
    if (!unanswered.length) continue;
    // Если часть вопросов уже закрыта, оставшиеся считаем пропущенными —
    // квитанция «Ответ получен» / «Вопрос пропущен» остаётся у любой модели.
    if (Object.keys(answered).length) {
      message.questionAnswers = { ...answered };
      for (const question of unanswered) {
        message.questionAnswers[question.qid] = { status: 'skipped' };
      }
    } else {
      message.questionDismissed = true;
    }
  }
}

const DEVELOPER_CLAIM_RE = /^(?:я\s+)?(?:твой|ваш|главный|реальный|настоящий)?\s*(?:разработчик|создатель|автор|владелец)\s+(?:amigo|тебя|проекта)|^(?:я\s+)?(?:создал|разработал)\s+(?:тебя|amigo)/iu;
const DEVELOPER_ANSWER_HASH = 'c639fc16f74ee2df8efb429882a5bb9f6170d15bb43321051e19a1111ddf9382';
async function sha256Text(value) {
  const data = new TextEncoder().encode(String(value || '').trim());
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function animateContinueCommand(input, text) {
  const target = document.querySelector('#sendBtn');
  if (!input || !target || !text) return;
  const from = input.getBoundingClientRect();
  const to = target.getBoundingClientRect();
  const flight = document.createElement('div');
  flight.className = 'continue-flight';
  flight.textContent = text;
  flight.style.left = `${from.left + Math.min(from.width / 2, 90)}px`;
  flight.style.top = `${from.top + from.height / 2}px`;
  document.body.appendChild(flight);
  input.classList.add('continue-source-flying');
  const dx = to.left + to.width / 2 - (from.left + Math.min(from.width / 2, 90));
  const dy = to.top + to.height / 2 - (from.top + from.height / 2);
  try {
    await flight.animate([
      { transform: 'translate(-50%,-50%) scale(1)', borderRadius: '10px', opacity: 1 },
      { transform: `translate(calc(-50% + ${dx * .62}px),calc(-50% + ${dy * .55 - 16}px)) scale(.48)`, borderRadius: '50%', opacity: .92, offset: .68 },
      { transform: `translate(calc(-50% + ${dx}px),calc(-50% + ${dy}px)) scale(.08)`, borderRadius: '50%', opacity: 0 },
    ], { duration: 520, easing: 'cubic-bezier(.22,.8,.24,1)', fill: 'forwards' }).finished;
  } catch { /* reduced-motion / interrupted animation */ }
  flight.remove();
  input.classList.remove('continue-source-flying');
}

async function sendMessage() {
  if (anyGenerationBusy()) return;
  const text = document.querySelector('#prompt').value.trim();
  if (!active) newChat();
  const attachments = active.pendingAttachments || [];
  if (!text && !attachments.length) return;
  const input = document.querySelector('#prompt');

  // "продолжай"/"continue" сразу после ответа модели — не новый вопрос, а
  // просьба дописать тот же ответ с того места, где он оборвался: кнопкой
  // "Стоп", лимитом контекста модели, или закрытием приложения (⌘Q)
  // посреди генерации. Работает одинаково независимо от причины обрыва —
  // условие только одно: последнее сообщение в диалоге от ассистента и не пустое.
  const lastMsg = active.messages[active.messages.length - 1];
  const continuationCommand = !attachments.length && CONTINUE_RE.test(text);
  if (continuationCommand) {
    if (!lastMsg || lastMsg.role !== 'assistant' || !(lastMsg.content || '').trim()) {
      showToast('В этом диалоге пока нет ответа, который можно продолжить');
      return;
    }
    if (!(lastMsg.continuable || lastMsg.stopped || lastMsg.continuationDraft || hasUnclosedFence(lastMsg.content || ''))) {
      showToast('Последний ответ уже завершён');
      return;
    }
    scrollStateFor().follow = true;
    await animateContinueCommand(input, text);
    input.value = '';
    active.draft = '';
    input.style.height = 'auto';
    active.updatedAt = Date.now();
    await generateReply(lastMsg);
    return;
  }

  const pendingDeveloperChallenge = [...(active.messages || [])].reverse().find(
    (message) => message.role === 'assistant' && message.developerChallenge && !message.questionDismissed
  );
  if (pendingDeveloperChallenge && text && !attachments.length) {
    const accepted = await sha256Text(text) === DEVELOPER_ANSWER_HASH;
    pendingDeveloperChallenge.questionDismissed = true;
    pendingDeveloperChallenge.questionAnswers = { 0: { status: accepted ? 'verified' : 'rejected' } };
    active.developerVerified = accepted;
    active.messages.push({ role: 'user', content: 'Ответ на проверочный вопрос отправлен.', attachments: [], time: Date.now(), topicId: active.activeTopicId || 0 });
    active.messages.push({ role: 'assistant', content: accepted ? 'Проверка пройдена.' : 'Проверка не пройдена.', attachments: [], time: Date.now(), topicId: active.activeTopicId || 0 });
    input.value = '';
    active.draft = '';
    active.updatedAt = Date.now();
    save(); render();
    return;
  }

  scrollStateFor().follow = true;
  // Любое следующее обычное сообщение означает, что старый неотвеченный
  // опрос больше не актуален: карточка исчезает, но текст истории сохраняется.
  dismissOpenQuestionCards(active);
  const startsNewTopic = shouldStartNewTopic(active, text, attachments);
  const currentTopic = Number.isInteger(active.activeTopicId) ? active.activeTopicId : 0;
  active.activeTopicId = startsNewTopic ? currentTopic + 1 : currentTopic;
  active.messages.push({
    role: 'user', content: text, attachments: [...attachments], time: Date.now(), topicId: active.activeTopicId,
  });
  active.pendingAttachments = [];
  active.updatedAt = Date.now(); // переносит диалог в «Сегодня» при продолжении
  if (active.title === 'Новый диалог') active.title = (text || attachments[0]?.name || 'Вложение').slice(0, 38);
  input.value = '';
  active.draft = '';
  input.style.height = 'auto';



  // Заявление о полномочиях не меняет инструкции модели. Проверку проводит
  // интерфейс, поэтому ответ не попадает в системный промпт и не может быть
  // выведен моделью или сохранён в открытом виде.
  if (DEVELOPER_CLAIM_RE.test(text)) {
    active.messages.push({
      role: 'assistant',
      content: '```question\n[{"question":"В каком году был придуман проект AmIgo?","multiple":false,"options":[]}]\n```',
      attachments: [], time: Date.now(), topicId: active.activeTopicId, developerChallenge: true,
    });
    save(); render();
    return;
  }

  await generateReply();
}

async function regenerate(index) {
  if (anyGenerationBusy()) return;
  scrollStateFor().follow = true;
  active.messages.splice(index);
  save();
  await generateReply();
}

// Текущий "черновой" ответ на открытый шаг опроса: если в поле «свой вариант»
// что-то введено — оно в приоритете, иначе — выбранные варианты списка (один
// или несколько, через запятую). Пустая строка = пока нечего отправлять,
// кнопка «Ответить» должна быть выключена.
function questionCardAnswerText(card) {
  if (!card) return '';
  const customVal = card.querySelector('.question-custom-input')?.value.trim();
  if (customVal) return customVal;
  const chosen = Array.from(card.querySelectorAll('.question-option.selected')).map((el) => el.dataset.value);
  return chosen.join(', ');
}

function updateQuestionSubmitState(card) {
  const btn = card?.querySelector('.question-submit');
  if (btn) btn.disabled = !questionCardAnswerText(card);
}

// Ответ на шаг опроса модели (карточка ```question): выбор варианта(ов) или
// свой текст, подтверждённые кнопкой «Ответить», либо «Пропустить». Пока не
// пройдены все вопросы этого опроса — просто переходим к следующему шагу
// (перерисовка карточки достаточно). Когда отвечен/пропущен последний вопрос —
// собираем все ответы в одно сообщение пользователя и запускаем генерацию.
async function advanceQuestion(card, result) {
  if (anyGenerationBusy() || !card) return;
  const msgIndex = Number(card.dataset.msgIndex);
  const qid = Number(card.dataset.qid);
  const total = Number(card.dataset.total);
  const m = active.messages[msgIndex];
  if (!m) return;
  m.questionAnswers = m.questionAnswers || {};
  if (m.questionAnswers[qid] !== undefined) return; // уже отвечали на этот шаг — защита от повторного клика
  if (m.developerChallenge) {
    const accepted = result?.status === 'answered'
      && await sha256Text(result.text) === DEVELOPER_ANSWER_HASH;
    m.questionAnswers[qid] = { status: accepted ? 'verified' : 'rejected' };
    m.questionDismissed = true;
    active.developerVerified = accepted;
    active.messages.push({
      role: 'assistant',
      content: accepted ? 'Проверка пройдена.' : 'Проверка не пройдена.',
      attachments: [], time: Date.now(), topicId: active.activeTopicId || 0,
    });
    save(); render();
    return;
  }
  m.questionAnswers[qid] = result;

  const isLastStep = Object.keys(m.questionAnswers).length >= total;
  if (isLastStep) {
    const questions = parseQuestionBlocks(m.content);
    const lines = questions.map((q) => {
      const r = m.questionAnswers[q.qid];
      const answerText = r && r.status === 'answered' && r.text ? r.text : 'Пропущено';
      return `${q.question} — ${answerText}`;
    });
    const combined = lines.join('\n');
    active.messages.push({ role: 'user', content: combined, attachments: [], time: Date.now(), topicId: active.activeTopicId || 0 });
    if (active.title === 'Новый диалог') active.title = combined.slice(0, 38);
    save();
    await generateReply();
  } else {
    save();
    render();
  }
}

function settings() {
  const d = openModal(`
    <h2>Настройки AmIgo</h2>
    <label>Ваше имя</label>
    <input id="userName" placeholder="Необязательно" value="${escapeHtml(store.userName || '')}">
    <label>Общий профиль (попадает во все диалоги)</label>
    <textarea id="mem" rows="5" placeholder="Например: Я предпочитаю…">${escapeHtml(store.memory || '')}</textarea>
    <label>Groq API key</label>
    <input id="key" type="password" placeholder="gsk_…">
    <small class="key-status" id="groqKeyStatus">Проверяю Связку ключей…</small>
    <label>Tavily API key</label>
    <input id="tavilyKey" type="password" placeholder="tvly-…">
    <small class="key-status" id="tavilyKeyStatus">Проверяю Связку ключей…</small>
    <p class="key-hint">Секреты хранятся в Связке ключей macOS. AmIgo показывает только маску, но не извлекает полный ключ обратно в поле.</p>
    <div class="actions"><button type="button" id="close">Отмена</button><button type="button" class="primary" id="saveSet">Сохранить</button></div>`);

  const setKeyInlineError = (id, message) => {
    const element = d.querySelector(id);
    if (!element) return;
    element.textContent = message;
    element.classList.add('error');
  };

  invoke('api_keys_status').then((status) => {
    const groqStatus = d.querySelector('#groqKeyStatus');
    const tavilyStatus = d.querySelector('#tavilyKeyStatus');
    if (groqStatus) groqStatus.textContent = status.groq_saved
      ? `Сохранён: ${status.groq_masked}. Оставьте поле пустым, чтобы не менять.`
      : 'Ключ Groq не сохранён.';
    if (tavilyStatus) tavilyStatus.textContent = status.tavily_saved
      ? `Сохранён: ${status.tavily_masked}. Оставьте поле пустым, чтобы не менять.`
      : 'Ключ Tavily не сохранён.';
    const fillMasked = (input, masked) => {
      if (!input || !masked || input.value) return;
      input.value = masked;
      input.dataset.masked = '1';
      input.placeholder = 'Вставьте новый ключ только для замены';
      input.addEventListener('focus', () => {
        if (input.dataset.masked === '1') {
          input.value = '';
          input.dataset.masked = '0';
        }
      }, { once: true });
    };
    if (status.groq_saved) fillMasked(d.querySelector('#key'), status.groq_masked);
    if (status.tavily_saved) fillMasked(d.querySelector('#tavilyKey'), status.tavily_masked);
  }).catch(() => {
    d.querySelector('#groqKeyStatus').textContent = 'Не удалось проверить ключ.';
    d.querySelector('#tavilyKeyStatus').textContent = 'Не удалось проверить ключ.';
  });

  d.querySelector('#close').onclick = () => d.close();
  d.querySelector('#saveSet').onclick = async () => {
    const saveButton = d.querySelector('#saveSet');
    saveButton.disabled = true;
    saveButton.textContent = 'Сохраняю…';

    // Оба значения считываем ДО первого await. Иначе macOS/WebView могла
    // очистить второе password-поле, пока проверялся первый ключ.
    const groqInput = d.querySelector('#key');
    const tavilyInput = d.querySelector('#tavilyKey');
    const key = groqInput.dataset.masked === '1' ? '' : groqInput.value.trim();
    const tavilyKey = tavilyInput.dataset.masked === '1' ? '' : tavilyInput.value.trim();
    store.userName = d.querySelector('#userName').value.trim();
    store.memory = d.querySelector('#mem').value;
    save();

    const errors = [];
    const saves = [];
    if (key) {
      saves.push(invoke('save_groq_key', { key }).catch((error) => {
        errors.push(['#groqKeyStatus', `Ключ Groq не сохранён: ${String(error || 'проверьте значение')}`]);
      }));
    }
    if (tavilyKey) {
      saves.push(invoke('save_tavily_key', { key: tavilyKey }).catch((error) => {
        errors.push(['#tavilyKeyStatus', `Ключ Tavily не сохранён: ${String(error || 'проверьте значение')}`]);
      }));
    }
    await Promise.all(saves);

    if (errors.length) {
      for (const [selector, message] of errors) setKeyInlineError(selector, message);
      saveButton.disabled = false;
      saveButton.textContent = 'Сохранить';
      return;
    }

    // Сохранение не блокируем сетевой проверкой: оба секрета уже надёжно
    // записаны в Keychain, а окно сразу закрывается, как ожидает пользователь.
    d.close();
    render();
  };
}

// Настройки конкретного диалога: своя память, не глобальная.
// Эта память видна модели только в данном чате — другие диалоги её не видят.
function chatSettings() {
  if (!active) return;
  const d = openModal(`<h2>${escapeHtml(active.title)}</h2><label>Память этого диалога</label><textarea id="chatMem" rows="7" placeholder="Что AmIgo должен помнить только в этом диалоге…">${escapeHtml(active.memory || '')}</textarea>${active.summary ? `<details style="margin-top:12px"><summary style="font-size:12px;color:var(--muted);cursor:pointer">Краткое резюме (${active.messages.length} сообщ.)</summary><p style="font-size:12px;color:var(--text-2);margin-top:8px;line-height:1.5">${escapeHtml(active.summary)}</p></details>` : ''}<div class="actions"><button type="button" id="close">Отмена</button><button type="button" class="primary" id="saveChatSet">Сохранить</button></div>`);
  d.querySelector('#close').onclick = () => d.close();
  d.querySelector('#saveChatSet').onclick = () => {
    active.memory = d.querySelector('#chatMem').value;
    save();
    d.close();
    render();
  };
}

// Держим в паре с read_image_base64 на стороне Rust: локальный движок AmIgo
// (llama.cpp/mtmd) декодирует изображения через stb_image, который читает
// JPEG/PNG/BMP/GIF — и не умеет WebP, TIFF, HEIC/HEIF. Список сверен с
// официальной документацией llama.cpp (mtmd-helper: "formats supported by
// stb_image: jpg, png, bmp, gif").
const IMAGE_EXTS = ['png', 'jpg', 'jpeg', 'gif', 'bmp'];
// Эти форматы WebView/mtmd читает не всегда. macOS sips автоматически
// декодирует их в канонический PNG до отправки локальной модели.
const IMAGE_EXTS_CONVERTIBLE = ['webp', 'tif', 'tiff', 'heic', 'heif', 'avif'];
const AUDIO_EXTS = ['wav', 'mp3', 'm4a', 'aac', 'flac', 'ogg', 'opus', 'aiff', 'aif', 'caf'];
// Держим в паре с PLAIN_TEXT_EXTS/rtf/pdf/docx на стороне Rust (extract_document) —
// список тут только для того, чтобы решить, каким способом читать файл.
const TEXT_EXTS = [
  'txt', 'md', 'markdown', 'csv', 'tsv', 'json', 'jsonl', 'yaml', 'yml', 'toml', 'ini', 'cfg', 'conf', 'env',
  'xml', 'svg', 'html', 'htm', 'css', 'scss', 'less', 'log', 'rst', 'tex', 'rtf', 'pdf', 'docx',
  'js', 'jsx', 'ts', 'tsx', 'mjs', 'cjs', 'py', 'rb', 'rs', 'go', 'java', 'kt', 'kts', 'swift',
  'c', 'h', 'cpp', 'cc', 'hpp', 'cs', 'php', 'sql', 'sh', 'bash', 'zsh', 'ps1', 'lua', 'pl', 'r', 'scala', 'dart', 'vue', 'svelte',
];
const PASTE_THRESHOLD = 2500; // символов — с такой длины вставленный текст становится карточкой-вложением, а не текстом в поле

function shortPreview(text, max = 160) {
  const clean = text.replace(/\s+/g, ' ').trim();
  return clean.length > max ? clean.slice(0, max) + '…' : clean;
}

function formatBadge(d) {
  if (d.kind === 'paste') return 'ВСТАВЛЕНО';
  if (d.kind === 'audio') return 'АУДИО';
  return (d.ext || 'file').toUpperCase();
}

async function attachFromDisk(path) {
  const name = path.split('/').pop();
  const ext = (name.split('.').pop() || '').toLowerCase();
  let sandboxPath = null;
  let sandboxImportError = null;
  try {
    sandboxPath = await invoke('sandbox_import_file', { chatId: String(active.id), sourcePath: path, filename: name });
  } catch (e) {
    const reason = String(e || 'неизвестная ошибка');
    if (/слишком большой|лимит/i.test(reason)) {
      showToast('Файл слишком большой для песочницы (максимум 100 МБ)');
      return false;
    }
    sandboxImportError = reason;
  }
  if (IMAGE_EXTS.includes(ext) || IMAGE_EXTS_CONVERTIBLE.includes(ext)) {
    try {
      const prepared = await invoke('prepare_image_attachment', {
        chatId: String(active.id), sourcePath: path, suggestedName: name,
      });
      if (sandboxPath && sandboxPath !== prepared.filename) {
        await invoke('sandbox_delete_files', { chatId: String(active.id), filenames: [sandboxPath] }).catch(() => {});
      }
      sandboxPath = prepared.filename;
      const imageDataUrl = prepared.data_url;
      addAttachment({
        id: Date.now() + Math.random(), name, ext: 'png', kind: 'image',
        imageDataUrl, imageBase64: imageDataUrl.split(',')[1] || '', sandboxPath,
        convertedFrom: ext !== 'png' ? ext : null,
      });
    } catch (conversionError) {
      // Для уже совместимого JPEG/PNG оставляем безопасный fallback. HEIC,
      // TIFF, WebP и AVIF без успешной конвертации модели не отправляем.
      if (!IMAGE_EXTS.includes(ext)) throw conversionError;
      const imageDataUrl = await invoke('read_image_base64', { path });
      addAttachment({ id: Date.now() + Math.random(), name, ext, kind: 'image', imageDataUrl, imageBase64: imageDataUrl.split(',')[1] || '', sandboxPath });
    }
  } else if (AUDIO_EXTS.includes(ext)) {
    showToast('Подготавливаю локальное распознавание аудио…', 'info');
    const transcript = await invoke('transcribe_audio', { sourcePath: path });
    if (!String(transcript || '').trim()) throw new Error('Аудио не содержит распознаваемой речи');
    addAttachment({
      id: Date.now() + Math.random(), name, ext, kind: 'audio',
      text: String(transcript).trim(), preview: shortPreview(String(transcript)), sandboxPath,
    });
  } else if (TEXT_EXTS.includes(ext)) {
    const extracted = await invoke('extract_document', { path });
    const text = extracted.slice(0, 40000);
    addAttachment({ id: Date.now() + Math.random(), name, ext, kind: 'text', text, preview: shortPreview(text), sandboxPath });
  } else {
    addAttachment({ id: Date.now() + Math.random(), name, ext, kind: 'file', sandboxPath });
    showToast(`AmIgo не умеет читать .${ext || '?'} — файл прикреплён, но модель не увидит его содержимое`);
  }
  if (!sandboxPath && sandboxImportError) {
    showToast(`Файл прикреплён, но не сохранён в песочнице: ${sandboxImportError.slice(0, 180)}`);
  }
  return true;
}

async function attachDroppedPaths(paths) {
  const list = (Array.isArray(paths) ? paths : [paths])
    .map((path) => String(path || '').trim())
    .filter(Boolean);
  if (!list.length) return;
  const key = list.join('|');
  const now = Date.now();
  if (key === lastDropKey && now - lastDropAt < 800) return;
  lastDropKey = key;
  lastDropAt = now;
  if (!active) newChat();
  const savedPrompt = document.querySelector('#prompt')?.value || active.draft || '';
  try {
    for (const path of list) {
      if ((active.pendingAttachments || []).length >= MAX_ATTACHMENTS) {
        showToast(`Можно прикрепить не больше ${MAX_ATTACHMENTS} файлов за одно сообщение`);
        break;
      }
      await attachFromDisk(path);
    }
    save();
    render();
    if (savedPrompt) {
      const prompt = document.querySelector('#prompt');
      if (prompt) {
        prompt.value = savedPrompt;
        if (active) active.draft = savedPrompt;
        prompt.style.height = 'auto';
        prompt.style.height = `${Math.min(prompt.scrollHeight, 200)}px`;
      }
    }
  } catch (e) {
    const msg = String(e);
    if (msg.includes('unsupported_format')) showToast('Формат файла не поддерживается');
    else showToast('Ошибка загрузки, попробуйте снова');
  }
}

function fileDropPaths(dataTransfer) {
  if (!dataTransfer) return [];
  const fromFiles = Array.from(dataTransfer.files || [])
    .map((file) => file.path)
    .filter((path) => path && (path.startsWith('/') || /^[A-Za-z]:[\\/]/.test(path)));
  if (fromFiles.length) return fromFiles;
  return String(dataTransfer.getData('text/uri-list') || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.startsWith('file:'))
    .map((line) => {
      try { return decodeURIComponent(new URL(line).pathname); }
      catch { return ''; }
    })
    .filter(Boolean);
}

async function handleHtmlFileDrop(dataTransfer) {
  if (Date.now() - lastNativeDropAt < 1200) return;
  const paths = fileDropPaths(dataTransfer);
  if (paths.length) {
    await attachDroppedPaths(paths);
    return;
  }
  const files = Array.from(dataTransfer?.files || []);
  if (!files.length) return;
  if (!active) newChat();
  const savedPrompt = document.querySelector('#prompt')?.value || active.draft || '';
  try {
    for (const file of files) {
      if ((active.pendingAttachments || []).length >= MAX_ATTACHMENTS) {
        showToast(`Можно прикрепить не больше ${MAX_ATTACHMENTS} файлов за одно сообщение`);
        break;
      }
      const ext = (file.name.split('.').pop() || '').toLowerCase();
      if (file.type.startsWith('image/') || IMAGE_EXTS.includes(ext) || IMAGE_EXTS_CONVERTIBLE.includes(ext)) {
        const dataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = () => reject(new Error('read'));
          reader.readAsDataURL(file);
        });
        const prepared = await invoke('prepare_image_data_url', {
          chatId: String(active.id), dataUrl, suggestedName: file.name || `drop_${Date.now()}.png`,
        });
        addAttachment({
          id: Date.now() + Math.random(), name: prepared.filename, ext: 'png', kind: 'image',
          imageDataUrl: prepared.data_url, imageBase64: (prepared.data_url.split(',')[1] || ''),
          sandboxPath: prepared.filename,
        });
        continue;
      }
      if (TEXT_EXTS.includes(ext) || String(file.type || '').startsWith('text/')) {
        const text = String(await file.text()).slice(0, 40000);
        const name = file.name || `Вставленный_текст_${Date.now()}.txt`;
        let sandboxPath = null;
        try {
          await invoke('sandbox_save_generated_text', { chatId: String(active.id), path: name, content: text });
          sandboxPath = name;
        } catch { /* карточка всё равно появится */ }
        addAttachment({
          id: Date.now() + Math.random(), name, ext: ext || 'txt',
          kind: ext === 'txt' ? 'paste' : 'text', text, preview: shortPreview(text), sandboxPath,
        });
        continue;
      }
      showToast(`Перетащите «${file.name}» через Finder в окно AmIgo или кнопкой «+»`);
    }
    save();
    render();
    if (savedPrompt) {
      const prompt = document.querySelector('#prompt');
      if (prompt) {
        prompt.value = savedPrompt;
        if (active) active.draft = savedPrompt;
        prompt.style.height = 'auto';
        prompt.style.height = `${Math.min(prompt.scrollHeight, 200)}px`;
      }
    }
  } catch {
    showToast('Ошибка загрузки, попробуйте снова');
  }
}

async function bindNativeFileDrop() {
  if (nativeFileDropBound) return;
  nativeFileDropBound = true;
  await listen('amigo-file-drag', (event) => {
    document.querySelector('.composer')?.classList.toggle('drop-hover', !!event.payload);
  });
  await listen('amigo-file-drop', (event) => {
    lastNativeDropAt = Date.now();
    const paths = [].concat(event.payload || []).filter(Boolean);
    void attachDroppedPaths(paths);
  });
}

async function docs() {
  if (!active) newChat();
  if ((active.pendingAttachments || []).length >= MAX_ATTACHMENTS) {
    showToast(`Можно прикрепить не больше ${MAX_ATTACHMENTS} файлов за одно сообщение`);
    return;
  }
  const selected = await open({ multiple: true });
  if (!selected) return;
  const paths = Array.isArray(selected) ? selected : [selected];
  await attachDroppedPaths(paths);
}

const MAX_ATTACHMENTS = 10;
// Единая точка добавления вложения — вместо проверки лимита в каждом из
// шести мест, где что-то прикрепляется (файл, фото, вставленный текст,
// вставленное изображение), проверяем один раз здесь. Возвращает false и
// показывает тост, если лимит уже достигнут — вызывающий код тогда просто
// не добавляет вложение.
function addAttachment(attachment) {
  active.pendingAttachments = active.pendingAttachments || [];
  if (active.pendingAttachments.length >= MAX_ATTACHMENTS) {
    showToast(`Можно прикрепить не больше ${MAX_ATTACHMENTS} файлов за одно сообщение`);
    return false;
  }
  active.pendingAttachments.push(attachment);
  return true;
}

function removeDoc(index) {
  if (!active?.pendingAttachments) return;
  const [removed] = active.pendingAttachments.splice(index, 1);
  if (removed?.sandboxPath) {
    invoke('sandbox_delete_files', { chatId: String(active.id), filenames: [removed.sandboxPath] }).catch(() => {});
  }
  save();
  render();
}

// Текст политики конфиденциальности для окна согласия — тот же, что лежит
// в PRIVACY.md рядом с исходниками, встроен прямо в приложение, чтобы не
// требовать открывать отдельный файл при первом запуске.
const PRIVACY_POLICY_TEXT = `ПОЛИТИКА КОНФИДЕНЦИАЛЬНОСТИ AmIgo

Дата последнего обновления: 09.08.2026

AmIgo — приложение, поддерживающее локальные модели искусственного
интеллекта и опциональное подключение стороннего облачного сервиса Groq.

Настоящий документ описывает обработку информации официальной
неизменённой версией AmIgo.


1. ЛОКАЛЬНАЯ ОБРАБОТКА

При использовании локальной модели запросы Пользователя обрабатываются
на его устройстве и не передаются Правообладателю.

Правообладатель не получает содержание локальных запросов и ответов.


2. GROQ

Использование Groq является опциональным.

Для использования Groq Пользователь самостоятельно предоставляет
Приложению собственный API-ключ Groq.

При отправке запроса облачной модели текст запроса и информация,
технически необходимая для выполнения запроса, передаются
непосредственно с устройства Пользователя в Groq через сеть Интернет.

Запросы не передаются через сервер Правообладателя.

Groq является независимым сторонним сервисом. Обработка информации
инфраструктурой Groq регулируется актуальными условиями и политикой
конфиденциальности Groq.

Перед использованием Groq Пользователю следует ознакомиться с этими
документами.


3. API-КЛЮЧ GROQ

API-ключ предоставляется самим Пользователем.

Правообладатель не получает API-ключ Пользователя и не хранит его на
своих серверах.

Если AmIgo сохраняет API-ключ на устройстве Пользователя, такое хранение
осуществляется локально на устройстве.

Пользователь должен обеспечивать конфиденциальность своего API-ключа и
при необходимости отозвать или заменить его через средства,
предоставляемые Groq.


4. ДАННЫЕ, НЕ СОБИРАЕМЫЕ ПРАВООБЛАДАТЕЛЕМ

На дату последнего обновления настоящей Политики официальная версия
AmIgo не использует сервер Правообладателя для обработки ИИ-запросов.

Если это соответствует фактической реализации Приложения, AmIgo также:

— не требует создания учётной записи AmIgo;
— не передаёт Правообладателю историю разговоров;
— не использует собственную телеметрию или аналитику;
— не продаёт персональные данные Пользователя;
— не использует данные Пользователя для рекламного профилирования.

Эти утверждения относятся только к действиям Правообладателя и не
описывают обработку информации независимыми сторонними сервисами,
которые Пользователь решает использовать.


5. ПЕРСОНАЛЬНЫЕ И КОНФИДЕНЦИАЛЬНЫЕ ДАННЫЕ

Пользователю не рекомендуется отправлять облачным моделям персональные
данные третьих лиц, пароли, закрытые ключи, платёжные данные,
коммерческую тайну или другую конфиденциальную информацию без
необходимых прав и законных оснований.

Если Пользователь включает такие сведения в запрос Groq, соответствующие
сведения передаются Groq в составе запроса.


6. СТОРОННИЕ СЕРВИСЫ

Настоящая Политика описывает действия Правообладателя AmIgo.

Она не определяет правила обработки информации сервисом Groq или иными
третьими лицами.

Актуальную информацию о работе Groq следует получать непосредственно из
документации, условий использования и политики конфиденциальности Groq.


7. ИЗМЕНЕНИЯ

Если в будущей версии AmIgo появятся серверная обработка, телеметрия,
аналитика, учётные записи или иные способы передачи данных
Правообладателю, настоящая Политика должна быть обновлена до или
одновременно с введением соответствующей функциональности.


8. КОНТАКТЫ

Правообладатель: Est_efan0
Проект: AmIgo
E-mail: gap-spelling-icing@duck.com`;

// Текст лицензии (условий использования) — тот же, что лежит в LICENSE
// рядом с исходниками. Показывается в том же полноэкранном окне сразу
// после политики конфиденциальности.
const LICENSE_TEXT = `ЛИЦЕНЗИЯ НА ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ AmIgo

Copyright © 2026 Est_efan0.
Все права защищены.

Настоящая лицензия регулирует использование приложения AmIgo
(далее — «Приложение»), включая принадлежащие автору исходный код,
интерфейс, ресурсы, сборочные скрипты и сопутствующие материалы.

Настоящая лицензия не распространяется на сторонние компоненты,
библиотеки и модели, используемые Приложением. Они предоставляются
на условиях собственных лицензий.


1. ПРЕДОСТАВЛЕНИЕ ЛИЦЕНЗИИ

1.1. Любому лицу, законно получившему копию Приложения или его исходного
кода от Правообладателя либо из официального репозитория проекта,
предоставляется ограниченная, неисключительная, непередаваемая и
несублицензируемая лицензия на установку и использование Приложения
в личных некоммерческих целях.

1.2. Если исходный код предоставлен Правообладателем, Пользователь также
вправе скомпилировать его для собственного использования без изменения
логики Приложения.

1.3. Предоставление исходного кода не означает передачу исключительных
прав на Приложение.

1.4. Все права, прямо не предоставленные настоящей лицензией, сохраняются
за Правообладателем.


2. ОГРАНИЧЕНИЯ

Без отдельного письменного разрешения Правообладателя запрещается:

a) продавать, сдавать в аренду, сублицензировать или иным образом
коммерчески распространять Приложение;

b) распространять изменённые версии Приложения как официальные версии
AmIgo;

c) изменять исходный код или создавать на его основе производные
произведения, за исключением случаев, прямо разрешённых Правообладателем
или применимым законодательством;

d) осуществлять декомпиляцию, дизассемблирование или иную обратную
разработку собранного Приложения, за исключением случаев и в пределах,
прямо разрешённых применимым законодательством;

e) удалять или изменять уведомления об авторском праве, авторстве или
лицензировании;

f) использовать название AmIgo, логотип, иконку или иную айдентику таким
образом, который создаёт ложное впечатление, что сторонний или изменённый
продукт является официальной версией AmIgo;

g) использовать Приложение для заведомо противоправных целей.

Ничто в настоящем разделе не ограничивает права Пользователя, которые
в силу применимого законодательства не могут быть ограничены договором.


3. ФУНКЦИИ ИСКУССТВЕННОГО ИНТЕЛЛЕКТА

3.1. AmIgo является программным инструментом, предоставляющим интерфейс
для взаимодействия с локальными и, по выбору Пользователя, сторонними
моделями искусственного интеллекта.

3.2. Результаты, сформированные моделями искусственного интеллекта
(далее — «ИИ-контент»), создаются автоматически и могут содержать
ошибки, вымышленные сведения, устаревшую, неполную, неточную,
небезопасную или вводящую в заблуждение информацию.

3.3. Правообладатель не осуществляет предварительную проверку каждого
ИИ-ответа и не гарантирует точность, достоверность, полноту,
оригинальность, безопасность или пригодность ИИ-контента для какой-либо
конкретной цели.

3.4. ИИ-контент предоставляется исключительно в информационных целях.
Он сам по себе не является юридической, медицинской, финансовой,
инвестиционной, налоговой или иной профессиональной консультацией.

3.5. Пользователь самостоятельно принимает решение об использовании
ИИ-контента и должен проверять существенную информацию до принятия
решений или совершения действий на её основании.

3.6. Пользователь не должен полагаться исключительно на непроверенный
ИИ-контент при принятии решений, способных причинить существенный вред
жизни или здоровью людей, имуществу, информационной безопасности,
правам третьих лиц или иным охраняемым законом интересам.

3.7. Программный код, команды и инструкции, сформированные ИИ, могут
содержать ошибки или уязвимости. Пользователь должен проверять их перед
выполнением или использованием.


4. ЛОКАЛЬНЫЙ РЕЖИМ И GROQ

4.1. Приложение может использовать локальные модели искусственного
интеллекта, исполняемые непосредственно на устройстве Пользователя.

4.2. Приложение также позволяет Пользователю по собственному выбору
подключить сторонний облачный сервис Groq с использованием собственного
API-ключа Пользователя.

4.3. Правообладатель не предоставляет Пользователю API-ключ Groq и не
предоставляет от своего имени доступ к услугам Groq.

4.4. При выборе облачной модели Groq текст запроса Пользователя и
технически необходимая для его выполнения информация передаются
непосредственно с устройства Пользователя стороннему сервису Groq через
сеть Интернет.

4.5. Запросы Groq не передаются через серверы Правообладателя, при
условии использования официальной неизменённой версии Приложения.

4.6. Правообладатель не контролирует инфраструктуру Groq, используемые
Groq модели, способы обработки данных на стороне Groq, доступность
сервиса или содержание сформированных им ответов.

4.7. Использование Groq регулируется актуальными условиями,
документацией и политикой конфиденциальности Groq. Пользователь
самостоятельно получает API-ключ и принимает соответствующие условия
Groq.

4.8. Пользователь самостоятельно определяет содержание направляемых Groq
запросов и не должен передавать пароли, закрытые криптографические ключи,
данные платёжных карт, чужие персональные данные, коммерческую тайну или
иную конфиденциальную информацию, если у него отсутствуют необходимые
права или законные основания для такой передачи.

4.9. Правообладатель не гарантирует постоянную доступность, неизменность
API, условий или функциональности Groq.


5. СТОРОННИЕ КОМПОНЕНТЫ

5.1. Приложение использует или может использовать программное
обеспечение, библиотеки и модели третьих лиц.

5.2. Такие компоненты не перелицензируются настоящим документом и
используются на условиях собственных лицензий.

5.3. В зависимости от конкретной версии AmIgo к таким компонентам могут
относиться:

— llama.cpp / llama-server;
— Tauri;
— библиотеки Rust и npm;
— модели семейства Qwen;
— иные библиотеки, модели и программные компоненты.

5.4. Условия использования конкретной модели определяются лицензией
конкретной версии и конкретных файлов этой модели.

5.5. Если условия сторонней лицензии предоставляют Пользователю права,
которые шире настоящей лицензии, настоящий документ не ограничивает
такие права в отношении соответствующего стороннего компонента.

5.6. Применимые уведомления об авторских правах и лицензиях третьих лиц
могут содержаться в файле THIRD_PARTY_NOTICES, документации проекта или
самих сторонних компонентах.


6. ОТКАЗ ОТ ГАРАНТИЙ

6.1. В МАКСИМАЛЬНОЙ СТЕПЕНИ, ДОПУСКАЕМОЙ ПРИМЕНИМЫМ
ЗАКОНОДАТЕЛЬСТВОМ, ПРИЛОЖЕНИЕ ПРЕДОСТАВЛЯЕТСЯ «КАК ЕСТЬ» («AS IS»)
И «ПО МЕРЕ ДОСТУПНОСТИ» («AS AVAILABLE») БЕЗ КАКИХ-ЛИБО ЯВНЫХ ИЛИ
ПОДРАЗУМЕВАЕМЫХ ГАРАНТИЙ.

6.2. В частности, Правообладатель не гарантирует:

— бесперебойную или безошибочную работу Приложения;
— совместимость со всеми устройствами и версиями операционных систем;
— отсутствие программных ошибок или уязвимостей;
— сохранность данных Пользователя;
— постоянную доступность сторонних сервисов;
— точность или пригодность ИИ-контента;
— соответствие Приложения индивидуальным ожиданиям Пользователя.

6.3. Если применимое законодательство не допускает исключение
определённой гарантии, соответствующее исключение применяется только в
максимально допустимой законом степени.


7. ОГРАНИЧЕНИЕ ОТВЕТСТВЕННОСТИ

7.1. В максимальной степени, допускаемой применимым законодательством,
Правообладатель не несёт ответственности за косвенные, случайные,
специальные или последующие убытки, упущенную выгоду, потерю данных,
репутационный вред или перерыв в деятельности, связанные с использованием
или невозможностью использования Приложения.

7.2. В максимальной степени, допускаемой применимым законодательством,
Правообладатель не несёт ответственности за решения или действия
Пользователя, предпринятые исключительно на основании непроверенного
ИИ-контента.

7.3. Правообладатель не несёт ответственности за работу, доступность,
безопасность, действия, изменение условий или прекращение работы Groq
или иных независимых сторонних сервисов в той мере, в которой
соответствующие обстоятельства находятся вне разумного контроля
Правообладателя.

7.4. Пользователь самостоятельно отвечает за законность содержания,
которое он вводит или передаёт сторонним сервисам, в пределах,
установленных применимым законодательством.

7.5. НИЧТО В НАСТОЯЩЕЙ ЛИЦЕНЗИИ НЕ ИСКЛЮЧАЕТ И НЕ ОГРАНИЧИВАЕТ
ОТВЕТСТВЕННОСТЬ ПРАВООБЛАДАТЕЛЯ, ЕСЛИ И В ТОЙ МЕРЕ, В КОТОРОЙ ТАКАЯ
ОТВЕТСТВЕННОСТЬ НЕ МОЖЕТ БЫТЬ ИСКЛЮЧЕНА ИЛИ ОГРАНИЧЕНА СОГЛАШЕНИЕМ
В СИЛУ ПРИМЕНИМОГО ЗАКОНОДАТЕЛЬСТВА.


8. ПРЕКРАЩЕНИЕ ЛИЦЕНЗИИ

8.1. Пользователь вправе прекратить использование Приложения в любое
время.

8.2. Права, предоставленные настоящей лицензией, могут быть прекращены
при существенном нарушении Пользователем её условий в той мере, в
которой это допускается применимым законодательством.

8.3. Прекращение настоящей лицензии не прекращает и не изменяет права,
полученные Пользователем непосредственно на сторонние компоненты по их
собственным лицензиям.


9. ПРИМЕНИМОЕ ЗАКОНОДАТЕЛЬСТВО

9.1. Настоящая лицензия регулируется применимым законодательством.

9.2. Ничто в настоящей лицензии не ограничивает обязательные права
Пользователя, которые согласно применимому законодательству не могут
быть исключены или ограничены соглашением сторон.

9.3. Если какое-либо положение настоящей лицензии будет признано
недействительным или неисполнимым, остальные положения сохраняют силу.


10. ИЗМЕНЕНИЯ

10.1. Правообладатель вправе устанавливать новые или изменённые
лицензионные условия для будущих версий AmIgo.

10.2. Такие изменения сами по себе не изменяют условия лицензирования
ранее полученной версии, если иное не предусмотрено применимым
законодательством.


11. КОНТАКТЫ

Правообладатель: Est_efan0
Проект: AmIgo
E-mail: gap-spelling-icing@duck.com`;

// Окно согласия при первом запуске. Пока store.privacyAccepted не true —
// это единственное, что видит пользователь: ни чат, ни настройки, ни
// скачивание моделей не запускаются (initApp вызывается только после "Да").
// Показывается заново при каждом запуске приложения, пока не нажата "Да" —
// даже если пользователь закроет и откроет AmIgo снова.
function renderConsentGate() {
  document.querySelector('#app').innerHTML = `
    <div class="consent-overlay">
      <div class="consent-box">
        <p class="consent-text">Вы ознакомились с <button type="button" id="privacyLinkBtn" class="consent-link">политикой конфиденциальности</button>?</p>
        <button type="button" id="consentYes" class="consent-yes">Да</button>
      </div>
    </div>
    <div id="privacyFullscreen" class="privacy-fullscreen" hidden>
      <button type="button" id="privacyCloseBtn" class="icon-btn privacy-close" title="Закрыть">${icon('close', 18)}</button>
      <div class="privacy-fullscreen-content">
        <h2 class="privacy-doc-title">Политика конфиденциальности</h2>
        ${escapeHtml(PRIVACY_POLICY_TEXT)}
        <h2 class="privacy-doc-title privacy-doc-title--second">Условия использования</h2>
        ${escapeHtml(LICENSE_TEXT)}
      </div>
    </div>
  `;
  document.querySelector('#privacyLinkBtn').onclick = () => { document.querySelector('#privacyFullscreen').hidden = false; };
  document.querySelector('#privacyCloseBtn').onclick = () => { document.querySelector('#privacyFullscreen').hidden = true; };
  document.querySelector('#consentYes').onclick = () => {
    store.privacyAccepted = true;
    save();
    initApp();
  };
}

// Обычный запуск приложения — то, что раньше выполнялось безусловно внизу
// файла, теперь запускается только после согласия с политикой конфиденциальности.
function initApp() {
  render();
  void bindNativeFileDrop().catch(() => {});
  // При старте приложения сразу проверяем, какие из трёх локальных моделей
  // уже скачаны, и (если выбран локальный режим) заранее подгружаем активную
  // модель в память — это и есть «модель сама включается при открытии».
  refreshModelsStatus().then(() => { ensureSelectedModelDownloaded(); render(); });
}

if (store.privacyAccepted) initApp();
else renderConsentGate();

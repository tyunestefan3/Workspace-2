# Исправление повреждённых моделей Mentis

## Причина

`llama-server` сообщает:

```text
tensor 'blk.31.ffn_up.weight' data is not within the file bounds,
model is corrupted or incomplete
```

Это означает, что GGUF-файл загрузился не полностью. Предупреждение CORS перед этой строкой не является причиной остановки.

Старый код считал модель готовой, если файл был больше 1 МБ и начинался с `GGUF`. Оборванный многогигабайтный файл проходил такую проверку. Кроме того, интерфейс показывал только первые 500 символов лога и скрывал настоящую ошибку.

## Что исправлено

- Проверяется точный размер каждого закреплённого GGUF.
- Неполный финальный файл больше не считается установленной моделью.
- После загрузки размер проверяется до переименования `.part` в `.gguf`.
- Убран общий двухминутный тайм-аут многогигабайтной загрузки; оставлен тайм-аут подключения.
- В уведомлении показываются последние строки лога, где находится причина сбоя.
- На Mac с 16 ГБ исправлен расчёт ОЗУ: теперь выбирается контекст 12K, а не 24K.
- CORS ограничен localhost; не относящийся к сбою баннер больше не засоряет лог.

## Точные размеры файлов

- `Qwen3.5-4B-Q4_K_M.gguf` — `2740937888` байт.
- `mmproj-Qwen3.5-4B-F16.gguf` — `672423616` байт.
- `Qwen3.5-9B-Q4_K_M.gguf` — `5680522464` байт.
- `mmproj-Qwen3.5-9B-F16.gguf` — `918166080` байт.
- `Qwen3-4B-Q4_K_M.gguf` — устаревшая модель, больше не используется и должна быть удалена.

Проверка на macOS:

```bash
stat -f '%N: %z bytes' "$HOME/Library/Application Support/AmIgo/models/"*.gguf
```

## Как восстановить уже повреждённые Mentis

После сборки новой версии полностью закройте AmIgo и удалите только файлы Mentis:

```bash
MODEL_DIR="$HOME/Library/Application Support/AmIgo/models"
rm -f \
  "$MODEL_DIR/Qwen3-4B-Q4_K_M.gguf" \
  "$MODEL_DIR/Qwen3-4B-Q4_K_M.gguf.part" \
  "$MODEL_DIR/Qwen3.5-4B-Q4_K_M.gguf" \
  "$MODEL_DIR/Qwen3.5-4B-Q4_K_M.gguf.part" \
  "$MODEL_DIR/mmproj-Qwen3.5-4B-F16.gguf" \
  "$MODEL_DIR/mmproj-Qwen3.5-4B-F16.gguf.part" \
  "$MODEL_DIR/Qwen3.5-9B-Q4_K_M.gguf" \
  "$MODEL_DIR/Qwen3.5-9B-Q4_K_M.gguf.part" \
  "$MODEL_DIR/mmproj-Qwen3.5-9B-F16.gguf" \
  "$MODEL_DIR/mmproj-Qwen3.5-9B-F16.gguf.part"
```

`Qwen3-4B-Q4_K_M.gguf` и его `.part` теперь нужно удалить: Nage 1.5 использует `Qwen3.5-4B-Q4_K_M.gguf` и `mmproj-Qwen3.5-4B-F16.gguf`.

Затем запустите новую сборку и выберите Nage 1.5 или Mentis 3. Для загрузки Mentis 3 желательно иметь не менее 8 ГБ свободного места.

import assert from 'node:assert/strict';
import {
  CONTINUE_RE,
  cleanContinuationStart,
  convertPlainQuestionsToSurvey,
  isUnlimitedCreationTask,
  isUnusedChat,
  nextChatId,
  shouldStartNewTopic,
} from '../src/chatLogic.js';

const empty = { id: 1, title: 'Новый диалог', messages: [], pendingAttachments: [], draft: '' };
assert.equal(isUnusedChat(empty), true);
assert.equal(isUnusedChat({ ...empty, draft: 'черновик' }), false);
assert.equal(isUnusedChat({ ...empty, pendingAttachments: [{ name: 'a.txt' }] }), false);
assert.equal(isUnusedChat({ ...empty, messages: [{ role: 'user', content: 'Привет' }] }), false);
assert.equal(nextChatId([{ id: 20 }, { id: 30 }], 10), 31);
assert.equal(isUnlimitedCreationTask('Создай большой HTML-файл калькулятора', []), true);
assert.equal(isUnlimitedCreationTask('Напиши код на Python для анализа данных', []), true);
assert.equal(isUnlimitedCreationTask('Объясни, что такое Python', []), false);
assert.equal(isUnlimitedCreationTask('Исправь этот файл', [{ sandboxPath: 'app.js' }]), true);

const chat = {
  messages: [{
    role: 'user',
    content: 'Объясни устройство локальной модели и параметры генерации ответа подробно',
  }],
};
assert.equal(shouldStartNewTopic(chat, 'Теперь новая тема: расскажи о выращивании орхидей'), true);
assert.equal(shouldStartNewTopic(chat, 'А как это работает подробнее?'), false);
assert.equal(
  shouldStartNewTopic(chat, 'Подготовь подробный маршрут путешествия по северной Италии с музеями ресторанами поездами гостиницами бюджетом'),
  true
);

const singleSurvey = convertPlainQuestionsToSurvey('Какой формат документа вам нужен?');
assert.match(singleSurvey, /```question/);
assert.match(singleSurvey, /Какой формат документа вам нужен\?/);

const multiSurvey = convertPlainQuestionsToSurvey(`Чтобы подготовить результат, уточните:
1. Какой формат нужен?
- PDF
- DOCX
2. Для какой аудитории готовим документ?`);
assert.match(multiSurvey, /```question/);
assert.match(multiSurvey, /"PDF"/);
assert.match(multiSurvey, /Для какой аудитории/);

const explanatory = 'Почему это важно?\nПотому что это влияет на итоговый результат.';
assert.equal(convertPlainQuestionsToSurvey(explanatory), explanatory);
const codeQuestion = '```js\nconst value = ready ? 1 : 0;\n```';
assert.equal(convertPlainQuestionsToSurvey(codeQuestion), codeQuestion);

for (const command of ['продолжай', 'Продолжи, пожалуйста', 'continue', '/continue', 'go on please', 'дальше']) {
  assert.equal(CONTINUE_RE.test(command), true, command);
}

const existing = 'Первый абзац.\n\nВторой абзац уже начат и должен продолжаться отсюда.';
const repeated = 'Второй абзац уже начат и должен продолжаться отсюда.\nНовая часть ответа.';
assert.equal(cleanContinuationStart(existing, repeated), '\nНовая часть ответа.');
assert.equal(cleanContinuationStart(existing, 'Продолжение: Новая часть.'), 'Новая часть.');

console.log('Chat logic tests passed.');

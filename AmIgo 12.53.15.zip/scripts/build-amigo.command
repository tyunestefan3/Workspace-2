#!/bin/zsh
# Собирает AmIgo.app + AmIgo.dmg. Первый запуск может занять несколько минут.
set -e
cd "$(dirname "$0")/.."

if ! command -v cargo >/dev/null; then
  echo "Rust не найден. Выполните в Terminal: brew install rust"
  exit 1
fi

# Используем зафиксированную и проверенную сборку llama.cpp. Homebrew latest
# больше не влияет на совместимость speculative decoding после обновлений.
LLAMA_BUILD="b10441"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64)
    ASSET="llama-${LLAMA_BUILD}-bin-macos-arm64.tar.gz"
    EXPECTED_SHA="a1665593b241af9bd302ac33b0cc9d252a507038e174b6fbc2763e71dff1ddb5"
    WHISPER_WHEEL="whisper_cpp_cli-0.0.3-py3-none-macosx_11_0_arm64.whl"
    WHISPER_SHA="6c9cb1d10770da5b7f92c54c2ace29142694b5b392c274db1d95ce1d2f6223d2"
    WHISPER_URL="https://files.pythonhosted.org/packages/fd/eb/4d1a96d887b62fdddc58e3e0c9c94f673b54cd9fc025329340f9c4d052bc/whisper_cpp_cli-0.0.3-py3-none-macosx_11_0_arm64.whl"
    ;;
  x86_64)
    ASSET="llama-${LLAMA_BUILD}-bin-macos-x64.tar.gz"
    EXPECTED_SHA="540e66a464483ad7cdd53780cc48819d5be314d61d0aefae3514af2dddff0ee7"
    WHISPER_WHEEL="whisper_cpp_cli-0.0.3-py3-none-macosx_10_12_x86_64.whl"
    WHISPER_SHA="1d85c6ca3dbf907c07a59f8daa620b3d0e3b263356c5220357dd7e06b42bc523"
    WHISPER_URL="https://files.pythonhosted.org/packages/a5/11/359833bd72353eb0142defc26ac2d8bd957da5b72540bd546ce7f0caea83/whisper_cpp_cli-0.0.3-py3-none-macosx_10_12_x86_64.whl"
    ;;
  *)
    echo "Неподдерживаемая архитектура Mac: $ARCH"
    exit 1
    ;;
esac

CACHE_DIR="$HOME/Library/Caches/AmIgo"
ARCHIVE="$CACHE_DIR/$ASSET"
URL="https://github.com/ggml-org/llama.cpp/releases/download/$LLAMA_BUILD/$ASSET"
mkdir -p "$CACHE_DIR"

valid_archive() {
  [[ -f "$ARCHIVE" ]] || return 1
  [[ "$(shasum -a 256 "$ARCHIVE" | awk '{print $1}')" == "$EXPECTED_SHA" ]]
}
if ! valid_archive; then
  rm -f "$ARCHIVE"
  echo "Скачиваю проверенный движок AmIgo ($LLAMA_BUILD, $ARCH)…"
  curl -L --fail --retry 3 --connect-timeout 20 "$URL" -o "$ARCHIVE"
fi
if ! valid_archive; then
  echo "Контрольная сумма llama-server не совпала. Сборка остановлена."
  exit 1
fi

WHISPER_ARCHIVE="$CACHE_DIR/$WHISPER_WHEEL"
valid_whisper_archive() {
  [[ -f "$WHISPER_ARCHIVE" ]] || return 1
  [[ "$(shasum -a 256 "$WHISPER_ARCHIVE" | awk '{print $1}')" == "$WHISPER_SHA" ]]
}
if ! valid_whisper_archive; then
  rm -f "$WHISPER_ARCHIVE"
  echo "Скачиваю проверенный локальный модуль распознавания аудио ($ARCH)…"
  curl -L --fail --retry 3 --connect-timeout 20 "$WHISPER_URL" -o "$WHISPER_ARCHIVE"
fi
if ! valid_whisper_archive; then
  echo "Контрольная сумма модуля распознавания аудио не совпала."
  exit 1
fi

TMP_ENGINE="$(mktemp -d -t amigo-llama)"
trap 'rm -rf "$TMP_ENGINE"' EXIT
tar -xzf "$ARCHIVE" -C "$TMP_ENGINE"
ENGINE_DIR="$(find "$TMP_ENGINE" -type f -name llama-server -print -quit | xargs dirname)"

BIN_DIR="src-tauri/bin"
BIN_TARGET="$BIN_DIR/llama-server"
rm -rf "$BIN_DIR"
mkdir -p "$BIN_DIR"
/bin/cp -f "$ENGINE_DIR/llama-server" "$BIN_TARGET"
# whisper.cpp 1.5.5 — небольшой самодостаточный бинарник из закреплённого
# macOS wheel. Модель распознавания речи (~60 МБ) скачивается только при
# первом аудиофайле и не раздувает DMG.
unzip -p "$WHISPER_ARCHIVE" 'whisper_cpp_cli-0.0.3.data/scripts/whisper-cpp' > "$BIN_DIR/whisper-cpp"
chmod 755 "$BIN_DIR/whisper-cpp"
for dylib in "$ENGINE_DIR"/*.dylib(N); do
  /bin/cp -fL "$dylib" "$BIN_DIR/${dylib:t}"
done
chmod 755 "$BIN_TARGET" "$BIN_DIR/whisper-cpp" "$BIN_DIR"/*.dylib(N)
for macho in "$BIN_TARGET" "$BIN_DIR/whisper-cpp" "$BIN_DIR"/*.dylib(N); do
  codesign --force --sign - "$macho" >/dev/null 2>&1 || true
done

# Сборка не продолжается, если бинарник или нужные spec-флаги не работают.
HELP_OUTPUT="$(DYLD_LIBRARY_PATH="$BIN_DIR" "$BIN_TARGET" --help 2>&1)"
for required in "--metrics" "--jinja" "--flash-attn" "--reasoning-format" "--reasoning-budget" "--reasoning-budget-message"; do
  if ! printf '%s' "$HELP_OUTPUT" | grep -q -- "$required"; then
    echo "В проверенном llama-server отсутствует $required"
    exit 1
  fi
done

echo "Движок AmIgo подготовлен: llama.cpp $LLAMA_BUILD ($ARCH, со всеми dylib)"

npm install
# Создаём .icns из утверждённой иконки перед сборкой.
zsh scripts/make-macos-icon.command

# Tauri добавляет к DMG версию и архитектуру. Перед сборкой убираем старые
# образы, а свежий результат ниже переименовываем в понятный AmIgo.dmg.
DMG_DIR="src-tauri/target/release/bundle/dmg"
mkdir -p "$DMG_DIR"
rm -f "$DMG_DIR"/*.dmg(N)

npm run tauri build

DMG_FILES=("$DMG_DIR"/*.dmg(N))
if (( ${#DMG_FILES[@]} > 0 )); then
  mv -f "$DMG_FILES[1]" "$DMG_DIR/AmIgo.dmg"
fi

# Финальная проверка того, что отправляемый DMG самодостаточен.
APP_DIR="src-tauri/target/release/bundle/macos/AmIgo.app"
FINAL_DMG="$DMG_DIR/AmIgo.dmg"
[[ -d "$APP_DIR" ]] || { echo "AmIgo.app не найден после сборки"; exit 1; }
[[ -s "$FINAL_DMG" ]] || { echo "AmIgo.dmg не создан"; exit 1; }
[[ -x "$APP_DIR/Contents/Resources/bin/llama-server" ]] || {
  echo "В AmIgo.app отсутствует встроенный llama-server"
  exit 1
}
[[ -x "$APP_DIR/Contents/Resources/bin/whisper-cpp" ]] || {
  echo "В AmIgo.app отсутствует встроенный модуль распознавания аудио"
  exit 1
}
DYLIB_FILES=("$APP_DIR/Contents/Resources/bin"/*.dylib(N))
(( ${#DYLIB_FILES[@]} > 0 )) || { echo "В AmIgo.app отсутствуют dylib движка"; exit 1; }
ICON_FILES=("$APP_DIR/Contents/Resources"/*.icns(N))
(( ${#ICON_FILES[@]} > 0 )) || { echo "В AmIgo.app отсутствует иконка .icns"; exit 1; }
APP_EXECUTABLES=("$APP_DIR/Contents/MacOS"/*(N*))
(( ${#APP_EXECUTABLES[@]} > 0 )) || { echo "В AmIgo.app отсутствует исполняемый файл"; exit 1; }

echo "Проверка DMG пройдена: приложение, иконка, llama-server и dylib находятся внутри."
echo "Проверка аудио пройдена: whisper-cpp находится внутри приложения."
echo "Сборка завершена. Приложение: $APP_DIR"
echo "Образ для отправки: $FINAL_DMG"
open "$DMG_DIR" || true

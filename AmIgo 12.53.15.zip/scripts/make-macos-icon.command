#!/bin/zsh
# Генерирует весь набор иконок официальной командой Tauri.
# Важно: generate_context! требует src-tauri/icons/icon.png именно в RGBA.
# Простое переименование JPEG в PNG или конвертация через sips может оставить
# RGB без alpha-канала и привести к ошибке «icon.png is not RGBA».
set -e
cd "$(dirname "$0")/.."

SOURCE=""
for candidate in icons/amigo-source.png icons/amigo-source.jpeg icons/amigo-source.jpg; do
  if [[ -f "$candidate" ]]; then
    SOURCE="$candidate"
    break
  fi
done

if [[ -z "$SOURCE" ]]; then
  echo "Не найден исходник иконки. Положите amigo-source.png, .jpeg или .jpg в папку icons."
  exit 1
fi

# @tauri-apps/cli уже установлен предыдущей командой npm install в
# build-amigo.command. Генератор Tauri сам создаёт корректные RGBA icon.png,
# icon.icns и остальные платформенные размеры.
npm run tauri -- icon "$SOURCE"

PNG="src-tauri/icons/icon.png"
ICNS="src-tauri/icons/icon.icns"
if [[ ! -f "$PNG" || ! -f "$ICNS" ]]; then
  echo "Генератор Tauri не создал обязательные файлы icon.png/icon.icns."
  exit 1
fi

# Проверяем не только расширение, но и наличие alpha-канала.
FORMAT="$(sips -g format "$PNG" 2>/dev/null | tail -1 | awk '{print $2}')"
ALPHA="$(sips -g hasAlpha "$PNG" 2>/dev/null | tail -1 | awk '{print $2}')"
if [[ "$FORMAT" != "png" || "$ALPHA" != "yes" ]]; then
  echo "Некорректная иконка Tauri: $PNG (format=$FORMAT, hasAlpha=$ALPHA; требуется PNG RGBA)."
  exit 1
fi

echo "Готово: $ICNS и RGBA $PNG (исходник: $SOURCE)"

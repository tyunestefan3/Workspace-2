export const CONTINUE_RE = /^(?:\/)?(?:продолжай|продолжи|продолжение|continue|go\s+on|дальше)(?:\s*[,—-]?\s*(?:пожалуйста|please|с\s+места\s+остановки))?[.!…\s]*$/i;

const TOPIC_SWITCH_RE = /^(?:а\s+)?(?:теперь|другая\s+тема|новая\s+тема|новый\s+вопрос|сменим\s+тему|смени\s+тему|перейд[её]м\s+(?:к|на)|давай\s+(?:о|про|обсудим)|отдельный\s+вопрос)(?=\s|:|[,.!?—-]|$)/i;
const FOLLOWUP_START_RE = /^(?:а|и|но|также|ещ[её]|тогда|поэтому|почему|зачем|как|какие?|какая|какой|кто|что|где|когда|сколько|можешь|уточни|подробнее|это|этот|эта|он|она|они)(?=\s|:|[,.!?—-]|$)/i;
const TOPIC_STOP_WORDS = new Set(['который','которая','которые','чтобы','этого','этому','можно','нужно','будет','только','очень','пожалуйста','расскажи','сделай','помоги','такое','такой','такая']);

export function isUnusedChat(chat) {
  if (!chat) return false;
  const hasMessages = (chat.messages || []).some(
    (message) => (message.content || '').trim() || (message.attachments || []).length
  );
  return !hasMessages
    && !(chat.pendingAttachments || []).length
    && !(chat.draft || '').trim();
}

export function nextChatId(chats, now = Date.now()) {
  return Math.max(now, ...(chats || []).map((chat) => Number(chat.id) || 0)) + 1;
}

function topicWords(text) {
  return new Set(
    (String(text || '').toLocaleLowerCase('ru').match(/[a-zа-яё0-9]{4,}/giu) || [])
      .filter((word) => !TOPIC_STOP_WORDS.has(word))
  );
}

export function isUnlimitedCreationTask(text, attachments = []) {
  const source = String(text || '').toLocaleLowerCase('ru');
  if (/(?:создай|создать|напиши|сгенерируй|сделай|разработай|доработай|измени|исправь|перепиши|подготовь)[\s\S]{0,100}(?:код|файл|скрипт|программ|сайт|страниц|html|css|javascript|typescript|python|json|проект|презентац|pptx|pdf|docx|xlsx|документ|таблиц)/i.test(source)) return true;
  if (/(?:код|файл|скрипт|программа|сайт|презентация|документ)[\s\S]{0,60}(?:создай|напиши|сгенерируй|сделай|доработай|измени|исправь)/i.test(source)) return true;
  if (/\b[\w.-]+\.(?:html?|css|js|jsx|ts|tsx|py|rb|rs|go|java|kt|swift|c|cpp|h|hpp|cs|php|sql|sh|zsh|json|ya?ml|toml|md|pdf|pptx|docx|xlsx)\b/i.test(source)) return true;
  return attachments.some((attachment) => attachment?.sandboxPath)
    && /(?:измени|доработай|исправь|перепиши|обработай)/i.test(source);
}

export function shouldStartNewTopic(chat, text, attachments = []) {
  const clean = String(text || '').trim();
  if (!clean || CONTINUE_RE.test(clean)) return false;
  if (TOPIC_SWITCH_RE.test(clean)) return true;
  if (FOLLOWUP_START_RE.test(clean) || attachments.length) return false;

  const previous = [...(chat?.messages || [])]
    .reverse()
    .find((message) => message.role === 'user' && (message.content || '').trim());
  if (!previous) return false;
  const currentWords = topicWords(clean);
  const previousWords = topicWords(previous.content);
  if (currentWords.size < 8 || previousWords.size < 5) return false;
  const overlap = [...currentWords].filter((word) => previousWords.has(word)).length;
  return overlap === 0;
}

export function convertPlainQuestionsToSurvey(text) {
  const source = String(text || '').trim();
  if (!source || !source.includes('?')) return source;
  if (/(```|~~~)\s*question/i.test(source) || /["']question["']\s*:/i.test(source)) return source;
  // Не переписываем ответы с кодом: вопросительный знак внутри программы не
  // должен превращать весь ответ в опрос.
  if (/(```|~~~)/.test(source)) return source;

  const lines = source.split('\n');
  const candidates = [];
  const consumed = new Set();
  let current = null;

  for (let index = 0; index < lines.length; index++) {
    const raw = lines[index].trim();
    if (!raw) { current = null; continue; }
    const cleaned = raw
      .replace(/^#{1,6}\s*/, '')
      .replace(/^\s*(?:[-*•]|\d+[.)])\s+/, '')
      .replace(/^\*\*(.*?)\*\*$/, '$1')
      .trim();
    const pieces = cleaned.match(/[^?]{3,500}\?/g)?.map((part) => part.trim()) || [];
    if (pieces.length) {
      for (const question of pieces) {
        current = { question, multiple: false, options: [] };
        candidates.push(current);
      }
      consumed.add(index);
      continue;
    }
    const option = /^\s*(?:[-*•]|\d+[.)])\s+(.{1,180})$/.exec(raw);
    if (current && option) {
      current.options.push(option[1].trim());
      consumed.add(index);
    } else {
      current = null;
    }
  }

  if (!candidates.length) return source;
  const cue = /(?:уточн|ответьте|выберите|нужно знать|перед тем как|чтобы (?:сделать|подготовить|продолжить)|несколько вопросов|подскажите)/i.test(source);
  const shortQuestionResponse = source.length <= 800 && source.endsWith('?');
  if (candidates.length < 2 && !cue && !shortQuestionResponse) return source;

  const prefix = lines
    .filter((_, index) => !consumed.has(index))
    .join('\n')
    .trim();
  const payload = candidates.slice(0, 8).map((item) => ({
    question: item.question.slice(0, 500),
    multiple: item.options.length > 1 && /(?:несколько|все подходящие|можно выбрать)/i.test(item.question),
    options: [...new Set(item.options)].slice(0, 8),
  }));
  const block = `\`\`\`question\n${JSON.stringify(payload, null, 2)}\n\`\`\``;
  return prefix ? `${prefix}\n\n${block}` : block;
}

export function cleanContinuationStart(existing, incoming) {
  let next = String(incoming || '').replace(
    /^\s*(?:#{1,3}\s*)?(?:продолжение|продолжаю|continue|continuation)\s*[:.\-–—]*\s*/i,
    ''
  );
  const base = String(existing || '');
  const max = Math.min(1200, base.length, next.length);
  let overlap = 0;
  for (let size = max; size >= 24; size--) {
    if (base.slice(-size) === next.slice(0, size)) {
      overlap = size;
      break;
    }
  }
  next = next.slice(overlap);
  if (overlap) next = next.replace(/^\s+/, base.endsWith('\n') ? '' : '\n');
  return next;
}

// Генераторы «настоящих» файлов не-текстовых форматов (PDF, PPTX, DOCX, XLSX)
// из лёгкого текстового описания, которое пишет модель внутри блока кода
// ```pdf:name.pdf / ```pptx:name.pptx / ```docx:name.docx / ```xlsx:name.xlsx.
//
// Модель не умеет генерировать бинарные байты напрямую — она может только
// писать текст. Поэтому для этих форматов текст блока кода — не готовый файл,
// а простая разметка (похожая на markdown), которую мы здесь превращаем в
// настоящий .pdf/.pptx/.docx/.xlsx через соответствующие библиотеки, а затем
// отдаём как base64 в Rust-команду save_binary_file, которая пишет байты на
// диск. Синтаксис разметки описан пользователю модели в системном промпте
// (см. main.js) — здесь мы просто его разбираем.
import { invoke } from '@tauri-apps/api/core';

// Множество расширений, которые нужно собирать в бинарный файл, а не
// сохранять как обычный текст один-в-один.
export const BINARY_FORMATS = new Set(['pdf', 'pptx', 'docx', 'xlsx']);

// --- Общий разбор «лёгкого markdown» на список блоков ---------------------
// Понимает: # / ## / ### заголовки, - / * буллеты, 1. нумерованные пункты,
// пустая строка = разрыв абзаца, **жирный** инлайн. Этого достаточно для
// структурированных документов и не требует от модели ничего кроме обычного
// markdown, который она и так хорошо умеет писать.
function parseRichText(src) {
  const lines = (src || '').replace(/\r\n/g, '\n').split('\n');
  const blocks = [];
  let para = [];
  const flush = () => { if (para.length) { blocks.push({ type: 'p', text: para.join(' ') }); para = []; } };
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (!line.trim()) { flush(); continue; }
    const h = /^(#{1,3})\s+(.*)$/.exec(line);
    if (h) { flush(); blocks.push({ type: 'h' + h[1].length, text: h[2].trim() }); continue; }
    const bullet = /^\s*[-*]\s+(.*)$/.exec(line);
    if (bullet) { flush(); blocks.push({ type: 'li', text: bullet[1].trim() }); continue; }
    const numbered = /^\s*\d+[.)]\s+(.*)$/.exec(line);
    if (numbered) { flush(); blocks.push({ type: 'oli', text: numbered[1].trim() }); continue; }
    para.push(line.trim());
  }
  flush();
  return blocks;
}

// Разбивает строку с **жирным** на сегменты { text, bold }.
function splitBold(text) {
  const parts = [];
  const re = /\*\*([^*]+)\*\*/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push({ text: text.slice(last, m.index), bold: false });
    parts.push({ text: m[1], bold: true });
    last = re.lastIndex;
  }
  if (last < text.length) parts.push({ text: text.slice(last), bold: false });
  return parts.length ? parts : [{ text, bold: false }];
}

function arrayBufferToBase64(buf) {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

// --- PDF --------------------------------------------------------------
export async function generatePdfBase64(src) {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const marginX = 48;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const maxWidth = pageWidth - marginX * 2;
  let y = 56;

  const ensureSpace = (needed) => {
    if (y + needed > pageHeight - 48) { doc.addPage(); y = 56; }
  };

  const writeWrapped = (text, { size = 11, bold = false, indent = 0, lineHeight = 16 } = {}) => {
    doc.setFont('helvetica', bold ? 'bold' : 'normal');
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(text, maxWidth - indent);
    for (const line of lines) {
      ensureSpace(lineHeight);
      doc.text(line, marginX + indent, y);
      y += lineHeight;
    }
  };

  const blocks = parseRichText(src);
  for (const b of blocks) {
    if (b.type === 'h1') { y += 6; writeWrapped(b.text, { size: 20, bold: true, lineHeight: 26 }); y += 4; }
    else if (b.type === 'h2') { y += 4; writeWrapped(b.text, { size: 16, bold: true, lineHeight: 22 }); y += 2; }
    else if (b.type === 'h3') { writeWrapped(b.text, { size: 13, bold: true, lineHeight: 18 }); }
    else if (b.type === 'li' || b.type === 'oli') {
      const prefix = b.type === 'oli' ? '• ' : '• ';
      writeWrapped(prefix + b.text, { size: 11, indent: 12, lineHeight: 15 });
    } else {
      // Абзац: жирные сегменты рисуем отдельными строками через splitTextToSize
      // ради простоты — полноценная посегментная обёртка тут избыточна.
      const plain = b.text.replace(/\*\*([^*]+)\*\*/g, '$1');
      writeWrapped(plain, { size: 11, lineHeight: 15 });
      y += 4;
    }
  }

  const buf = doc.output('arraybuffer');
  return arrayBufferToBase64(buf);
}

// --- DOCX --------------------------------------------------------------
export async function generateDocxBase64(src) {
  const { Document, Packer, Paragraph, TextRun, HeadingLevel } = await import('docx');
  const blocks = parseRichText(src);
  const children = [];
  for (const b of blocks) {
    if (b.type === 'h1') children.push(new Paragraph({ text: b.text, heading: HeadingLevel.HEADING_1 }));
    else if (b.type === 'h2') children.push(new Paragraph({ text: b.text, heading: HeadingLevel.HEADING_2 }));
    else if (b.type === 'h3') children.push(new Paragraph({ text: b.text, heading: HeadingLevel.HEADING_3 }));
    else if (b.type === 'li') children.push(new Paragraph({ text: b.text, bullet: { level: 0 } }));
    else if (b.type === 'oli') children.push(new Paragraph({ text: b.text, numbering: { reference: 'amigo-numbering', level: 0 } }));
    else children.push(new Paragraph({ children: splitBold(b.text).map((s) => new TextRun({ text: s.text, bold: s.bold })) }));
  }
  const doc = new Document({
    numbering: { config: [{ reference: 'amigo-numbering', levels: [{ level: 0, format: 'decimal', text: '%1.', alignment: 'start' }] }] },
    sections: [{ children }],
  });
  const blob = await Packer.toBlob(doc);
  const buf = await blob.arrayBuffer();
  return arrayBufferToBase64(buf);
}

// --- PPTX ---------------------------------------------------------------
export async function readSandboxImageForPptx(chatId, requestedName) {
  if (!chatId || !requestedName) return null;
  const clean = String(requestedName).trim().replace(/^['"`]+|['"`]+$/g, '');
  try {
    return await invoke('sandbox_read_image', { chatId: String(chatId), filename: clean });
  } catch {}

  // Модель может слегка изменить регистр, добавить папку или забыть точное
  // расширение. Ищем безопасное соответствие среди реальных файлов чата.
  try {
    const files = await invoke('sandbox_list', { chatId: String(chatId) });
    const basename = clean.split(/[\\/]/).pop().toLocaleLowerCase();
    const stem = basename.replace(/\.[^.]+$/, '');
    const imageExt = /\.(png|jpe?g|gif|bmp|webp)$/i;
    const candidate = files.find((name) => name.toLocaleLowerCase() === clean.toLocaleLowerCase())
      || files.find((name) => name.split(/[\\/]/).pop().toLocaleLowerCase() === basename)
      || files.find((name) => imageExt.test(name) && name.split(/[\\/]/).pop().toLocaleLowerCase().replace(/\.[^.]+$/, '') === stem);
    if (candidate) {
      return await invoke('sandbox_read_image', { chatId: String(chatId), filename: candidate });
    }
  } catch {}
  return null;
}

// Слайды разделяются строкой из одних дефисов "---". Внутри слайда: первая
// "# Заголовок" — title слайда, "- пункт" — буллеты, обычный текст — тело.
export async function generatePptxBase64(src, chatId) {
  const PptxGenJS = (await import('pptxgenjs')).default;
  const pptx = new PptxGenJS();
  const rawSlides = (src || '').replace(/\r\n/g, '\n').split(/\n\s*---\s*\n/);

  for (const rawSlide of rawSlides) {
    if (!rawSlide.trim()) continue;
    // Картинка на слайде: отдельная строка вида ![img:имя_файла.jpg] —
    // имя файла берётся из песочницы этого диалога (модель сама кладёт
    // туда картинки через download_image, см. системный промпт в main.js).
    // Строку с этой разметкой убираем перед обычным разбором текста, чтобы
    // она не попала в заголовок/тело слайда как обычный текст.
    const imageFilenames = [];
    const slideText = rawSlide.replace(/!\[img:([^\]\n]+)\]/g, (_, name) => {
      imageFilenames.push(name.trim());
      return '';
    });

    const slide = pptx.addSlide();
    const blocks = parseRichText(slideText);
    let title = null;
    const bullets = [];
    const bodyParas = [];
    for (const b of blocks) {
      if (!title && (b.type === 'h1' || b.type === 'h2' || b.type === 'h3')) title = b.text;
      else if (b.type === 'li' || b.type === 'oli') bullets.push(b.text);
      else if (b.type === 'p') bodyParas.push(b.text);
      else if (!title) title = b.text; // запасной вариант, если заголовка нет
    }

    // До четырёх изображений на слайд. Читаем реальные файлы песочницы,
    // включая безопасный fallback по basename/регистру/имени без расширения.
    const imageDataUrls = [];
    for (const filename of imageFilenames.slice(0, 4)) {
      const dataUrl = await readSandboxImageForPptx(chatId, filename);
      if (dataUrl && !imageDataUrls.includes(dataUrl)) imageDataUrls.push(dataUrl);
    }
    const textW = imageDataUrls.length ? 5.2 : 9;

    let y = 0.4;
    if (title) {
      slide.addText(title, { x: 0.5, y, w: textW, h: 0.9, fontSize: 28, bold: true, color: '1a1a1a' });
      y += 1.0;
    }
    if (bodyParas.length) {
      slide.addText(bodyParas.join('\n'), { x: 0.5, y, w: textW, h: 1.2, fontSize: 16, color: '333333' });
      y += 1.3;
    }
    if (bullets.length) {
      slide.addText(
        bullets.map((t) => ({ text: t, options: { bullet: true, breakLine: true } })),
        { x: 0.5, y, w: textW, h: 5 - y, fontSize: 16, color: '333333', valign: 'top' }
      );
    }
    if (imageDataUrls.length === 1) {
      slide.addImage({ data: imageDataUrls[0], x: 6.0, y: 0.6, sizing: { type: 'contain', w: 3.4, h: 3.8 } });
    } else if (imageDataUrls.length === 2) {
      imageDataUrls.forEach((data, index) => {
        slide.addImage({ data, x: 6.0, y: 0.5 + index * 2.25, sizing: { type: 'contain', w: 3.4, h: 2.05 } });
      });
    } else if (imageDataUrls.length > 2) {
      imageDataUrls.forEach((data, index) => {
        const col = index % 2;
        const row = Math.floor(index / 2);
        slide.addImage({ data, x: 5.85 + col * 1.85, y: 0.65 + row * 2.05, sizing: { type: 'contain', w: 1.75, h: 1.85 } });
      });
    }
  }
  const base64 = await pptx.write({ outputType: 'base64' });
  return base64;
}

// --- XLSX ---------------------------------------------------------------
// Ожидает markdown-таблицу: | Заголовок1 | Заголовок2 | ... с разделительной
// строкой |---|---| сразу под шапкой — тот же синтаксис, что модель уже
// использует для обычных таблиц в чате.
export async function generateXlsxBase64(src) {
  const ExcelJS = (await import('exceljs')).default;
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Sheet1');

  const lines = (src || '').replace(/\r\n/g, '\n').split('\n').map((l) => l.trim()).filter(Boolean);
  const isSep = (l) => /^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/.test(l);
  const splitRow = (l) => {
    let s = l.trim();
    if (s.startsWith('|')) s = s.slice(1);
    if (s.endsWith('|')) s = s.slice(0, -1);
    return s.split('|').map((c) => c.trim());
  };

  const rows = lines.filter((l) => !isSep(l)).map(splitRow);
  if (rows.length) {
    sheet.addRow(rows[0]);
    sheet.getRow(1).font = { bold: true };
    for (let i = 1; i < rows.length; i++) sheet.addRow(rows[i]);
    sheet.columns.forEach((col) => {
      let max = 10;
      col.eachCell?.({ includeEmpty: true }, (cell) => { max = Math.max(max, String(cell.value ?? '').length + 2); });
      col.width = Math.min(max, 40);
    });
  }

  const buf = await workbook.xlsx.writeBuffer();
  return arrayBufferToBase64(buf);
}

// --- Единая точка входа ---------------------------------------------------
export async function generateBinaryFileBase64(ext, src, chatId) {
  switch (ext) {
    case 'pdf': return generatePdfBase64(src);
    case 'docx': return generateDocxBase64(src);
    case 'pptx': return generatePptxBase64(src, chatId);
    case 'xlsx': return generateXlsxBase64(src);
    default: throw new Error('unsupported_binary_format');
  }
}

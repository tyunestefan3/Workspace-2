# DskWrap — установка

DskWrap — локальное приложение для macOS. Оно смотрит, какое приложение на переднем плане, считает сессии, фокус, переключения, циклы и из этого собирает обзор, итоги и советы. Данные не уходят с Mac.

Собрать `.dmg` можно только **на Mac** (macOS 12+). Сборка на Apple Silicon даёт один образ и для ARM, и для Intel.

---

## Что нужно на Mac

Один раз в Terminal:

```zsh
xcode-select --install
```

Homebrew, если его ещё нет: https://brew.sh. Затем:

```zsh
brew uninstall rust
brew install node rustup
rustup default stable
source "$HOME/.cargo/env"
grep -q 'cargo/env' ~/.zshrc || echo 'source "$HOME/.cargo/env"' >> ~/.zshrc
rustup target add aarch64-apple-darwin x86_64-apple-darwin
which cargo
```

`which cargo` должен показать `/Users/…/.cargo/bin/cargo`.

**Не ставьте** `brew install rust`. Для Intel + Apple Silicon нужен именно `rustup`.

---

## Сборка и установка

Распакуйте архив **поверх** старой папки (или удалите её и распакуйте заново). Затем три отдельные строки — без `\` на конце:

```zsh
export PATH="$(dirname "$(rustup which cargo)"):$HOME/.cargo/bin:$PATH"
cd ~/Documents/DskWrap
zsh scripts/build-dskwrap.command
```

Готовые файлы:

```text
src-tauri/target/universal-apple-darwin/release/bundle/macos/DskWrap.app
src-tauri/target/universal-apple-darwin/release/bundle/dmg/DskWrap.dmg
release/DskWrap.dmg
```

Откройте `.dmg` и перетащите **DskWrap** в папку «Программы».

Первый запуск: правый клик → «Открыть» (приложение не подписано Apple Developer ID).

---

## После установки

1. Запустите DskWrap из «Программ» или из строки меню.
2. Пройдите введение. Внизу третьего шага — «Открывать при запуске».
3. Пользуйтесь Mac как обычно. Через день–два заполнятся обзор, итоги и советы.

Данные лежат только на этом Mac:

```
~/Library/Application Support/com.dskwrap.app/wrapped.sqlite
```

---

## Что считает приложение

Цепочка такая (всё локально, без облака):

```
приложение на экране
    → события (какое приложение, когда)
    → сессии (без простоя и сна)
    → метрики (время, фокус, взгляды, циклы, часы)
    → итоги / советы
```

Советы появляются только если есть сигнал: много переключений, частые взгляды, повторяющийся цикл, долгое возвращение в фокус. На тихом дне раздел будет пустым — так и задумано.

---

## Если сборка не нужна

Файл `preview.html` — интерактивный макет интерфейса с демо-данными. Откройте его в браузере. Это не живой сбор с вашего Mac.

---

## Частые проблемы

| Симптом | Что сделать |
|---|---|
| `xcode-select` не найден | `xcode-select --install` |
| «Rust не найден» / `cargo: command not found` | `rustup default stable` и `source "$HOME/.cargo/env"` |
| `x86_64-apple-darwin` target may not be installed | `brew uninstall rust`, затем `rustup target add x86_64-apple-darwin` |
| `which cargo` → `/opt/homebrew/bin/cargo` | Это Homebrew Rust. `brew uninstall rust`, дальше только rustup |
| Ошибка иконок | `pip3 install pillow` и снова `python3 scripts/generate-icons.py` |
| macOS не открывает приложение | ПКМ → Открыть. Или Системные настройки → Конфиденциальность → всё равно открыть |
| Пустые графики | Нужно реальное время работы |

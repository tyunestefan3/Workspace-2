# Desktop Wrapped — shareable macOS installer

This folder is where the build script copies:

```
Desktop-Wrapped.dmg
```

## Why it is empty here

A `.dmg` is a macOS disk image and can only be produced on a Mac
(Xcode CLT + Rust + Node). This Linux environment cannot emit one.

## How to get the DMG

On a Mac, from the project root:

```bash
./scripts/build-example.command
```

or:

```bash
npm install
python3 scripts/generate-icons.py
npm run tauri build
```

The file appears here as `release/Desktop-Wrapped.dmg`.

Alternatively, push a `v*` tag (or run the workflow by hand) — GitHub
Actions `.github/workflows/build-macos-dmg.yml` builds on `macos-latest`
and uploads the DMG as an artifact.

Unsigned builds open on the same Mac that compiled them. Sending to
other people additionally needs Apple Developer ID signing + notarization.

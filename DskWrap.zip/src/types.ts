// TypeScript mirrors of the Rust serialized types. Rust is the source of truth
// (§4); these types describe what the commands return, and the components only
// render them.

export type AppCategory =
  | "focus"
  | "communication"
  | "entertainment"
  | "utility"
  | "neutral"
  | "ignored";

export interface AppRecord {
  bundle_id: string;
  display_name: string;
  category: AppCategory;
  ignored: boolean;
}

export interface FocusBlock {
  start_ms: number;
  end_ms: number;
  duration_ms: number;
}

export interface HourBucket {
  start_ms: number;
  switches: number;
  checks: number;
  focus_seconds_ms: number;
  communication_seconds_ms: number;
  entertainment_seconds_ms: number;
  active_ms?: number;
}

export interface RecoveryAgg {
  count: number;
  total_ms: number;
}

export interface PeriodMetrics {
  wall_ms: number;
  tracked_ms: number;
  app_durations: [string, AppCategory, number][];
  category_durations: Record<string, number>;
  switches: number;
  switches_per_hour: number;
  quick_visits: number;
  checks: number;
  checks_per_app: Record<string, number>;
  focus_seconds_ms: number;
  longest_focus_ms: number;
  focus_blocks: FocusBlock[];
  recovery: { by_distractor: Record<string, RecoveryAgg>; samples: number };
  ngrams: [string[], number][];
  most_common_ngram: [string[], number] | null;
  hourly_buckets: HourBucket[];
  most_fragmented: [string, number] | null;
  strongest_focus_hour: [string, number] | null;
  away_ms?: number;
}

export type WrappedCard =
  | { kind: "your_week"; tracked_ms: number }
  | {
      kind: "main_character";
      bundle_id: string;
      display_name: string;
      duration_ms: number;
      category: AppCategory;
    }
  | { kind: "cant_resist"; bundle_id: string; display_name: string; checks: number }
  | { kind: "chaos_hour"; label: string; switches: number }
  | { kind: "deep_dive"; focus_ms: number }
  | { kind: "your_loop"; sequence: string[]; count: number }
  | { kind: "mac_type"; label: string };

export type MacType =
  | "DeepDiver"
  | "ContextSwitcher"
  | "NightOwl"
  | "Builder"
  | "Messenger"
  | "Balanced";

export interface WeeklyWrapped {
  start_ms: number;
  end_ms: number;
  tracked_ms: number;
  personality: MacType;
  cards: WrappedCard[];
}

export interface DebugInfo {
  tracker_state: string;
  last_event_ms: number | null;
  last_heartbeat_ms: number | null;
  events_today: number;
  working: boolean;
  current_app: string | null;
  switches_today: number;
  checks_today: number;
  quick_visits_today: number;
  tracked_today_ms: number;
}

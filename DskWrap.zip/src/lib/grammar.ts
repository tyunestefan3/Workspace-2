import type { Locale } from "../i18n";

/** Russian genitive for short app names: Терминал → Терминала. Latin names stay. */
export function ruGenitive(name: string): string {
  const n = name.trim();
  if (!n || !/[а-яё]/i.test(n)) return n;

  const lower = n.toLowerCase();
  const special: Record<string, string> = {
    терминал: "Терминала",
    почта: "Почты",
    заметки: "Заметок",
    сообщения: "Сообщений",
    календарь: "Календаря",
    музыка: "Музыки",
    "яндекс музыка": "Яндекс Музыки",
    фото: "Фото",
    настройки: "Настроек",
    "системные настройки": "Системных настроек",
    просмотр: "Просмотра",
    напоминания: "Напоминаний",
    карты: "Карт",
    часы: "Часов",
    книга: "Книги",
    книги: "Книг",
    finder: "Finder",
    "тор браузер": "Tor Browser",
  };
  if (special[lower]) return special[lower];

  const parts = n.split(/\s+/);
  if (parts.length > 1) {
    const last = ruGenitive(parts[parts.length - 1]);
    if (last !== parts[parts.length - 1]) return [...parts.slice(0, -1), last].join(" ");
    return n;
  }

  if (/[гкхжчшщ]а$/i.test(n)) return n.slice(0, -1) + "и";
  if (/а$/i.test(n)) return n.slice(0, -1) + "ы";
  if (/я$/i.test(n)) return n.slice(0, -1) + "и";
  if (/о$/i.test(n)) return n.slice(0, -1) + "а";
  if (/е$/i.test(n)) return n.slice(0, -1) + "я";
  if (/й$/i.test(n)) return n.slice(0, -1) + "я";
  if (/ь$/i.test(n)) return n.slice(0, -1) + "я";
  if (/[бвгджзклмнпрстфхцчшщ]$/i.test(n)) return n + "а";
  return n;
}

export function appInCase(name: string, locale: Locale, kind: "nom" | "gen" = "nom"): string {
  if (locale === "ru" && kind === "gen") return ruGenitive(name);
  return name;
}

export function fmtNum(n: number, locale: Locale, digits = 1): string {
  const tag = locale === "ru" ? "ru-RU" : locale === "es" ? "es" : locale === "fr" ? "fr-FR" : locale === "zh" ? "zh-CN" : "en";
  return n.toLocaleString(tag, {
    maximumFractionDigits: digits,
    minimumFractionDigits: Number.isInteger(n) ? 0 : digits,
  });
}

export function ruPlural(n: number, one: string, few: string, many: string): string {
  const v = Math.abs(Math.round(n));
  const n10 = v % 10;
  const n100 = v % 100;
  if (n10 === 1 && n100 !== 11) return one;
  if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) return few;
  return many;
}

/** "32 раза", "5 times", "1 vez" — never a broken "32 раз". */
export function fmtTimes(n: number, locale: Locale): string {
  const v = Math.round(n);
  if (locale === "ru") return `${v} ${ruPlural(v, "раз", "раза", "раз")}`;
  if (locale === "zh") return `${v} 次`;
  if (locale === "es") return v === 1 ? "1 vez" : `${v} veces`;
  if (locale === "fr") return v === 1 ? "1 fois" : `${v} fois`;
  return v === 1 ? "once" : `${v} times`;
}

export function fmtGlances(n: number, locale: Locale): string {
  const v = Math.round(n);
  if (locale === "ru") return `${v} ${ruPlural(v, "взгляд", "взгляда", "взглядов")}`;
  if (locale === "es") return v === 1 ? "1 mirada" : `${v} miradas`;
  if (locale === "fr") return v === 1 ? "1 coup d'œil" : `${v} coups d'œil`;
  if (locale === "zh") return v === 1 ? "1 次查看" : `${v} 次查看`;
  return v === 1 ? "1 glance" : `${v} glances`;
}

export function fmtSwitches(n: number, locale: Locale): string {
  const v = Math.round(n);
  if (locale === "ru") return `${v} ${ruPlural(v, "переключение", "переключения", "переключений")}`;
  if (locale === "es") return v === 1 ? "1 cambio" : `${v} cambios`;
  if (locale === "fr") return v === 1 ? "1 changement" : `${v} changements`;
  if (locale === "zh") return `${v} 次切换`;
  return v === 1 ? "1 switch" : `${v} switches`;
}

export function fmtVisits(n: number, locale: Locale): string {
  const v = Math.round(n);
  if (locale === "ru") {
    const adj = ruPlural(v, "короткий", "коротких", "коротких");
    const noun = ruPlural(v, "заход", "захода", "заходов");
    return `${v} ${adj} ${noun}`;
  }
  if (locale === "es") return v === 1 ? "1 visita breve" : `${v} visitas breves`;
  if (locale === "fr") return v === 1 ? "1 passage bref" : `${v} passages brefs`;
  if (locale === "zh") return `${v} 次短暂打开`;
  return v === 1 ? "1 brief visit" : `${v} brief visits`;
}

/** Complete phrase: "2 apps" / "2 приложения" / "2 apps" / "2 个应用". */
export function fmtApps(n: number, locale: Locale): string {
  const v = Math.round(n);
  if (locale === "ru") return `${v} ${ruPlural(v, "приложение", "приложения", "приложений")}`;
  if (locale === "zh") return `${v} 个应用`;
  if (locale === "es") return v === 1 ? "1 app" : `${v} apps`;
  if (locale === "fr") return v === 1 ? "1 app" : `${v} apps`;
  return v === 1 ? "1 app" : `${v} apps`;
}

/** Complete phrase for short focus stretches. */
export function fmtBlocks(n: number, locale: Locale): string {
  const v = Math.round(n);
  if (locale === "ru") {
    const adj = ruPlural(v, "короткий", "коротких", "коротких");
    const noun = ruPlural(v, "отрезок", "отрезка", "отрезков");
    return `${v} ${adj} ${noun} фокуса`;
  }
  if (locale === "es") return v === 1 ? "1 tramo corto de enfoque" : `${v} tramos cortos de enfoque`;
  if (locale === "fr") return v === 1 ? "1 court moment de focus" : `${v} courts moments de focus`;
  if (locale === "zh") return `${v} 段很短的专注`;
  return v === 1 ? "1 short focus block" : `${v} short focus blocks`;
}

export function fmtMinutes(min: number, locale: Locale | string): string {
  const n = Math.round(min);
  const loc = String(locale).slice(0, 2);
  return `${n} ${minutesWord(n, loc)}`;
}

function hoursWord(n: number, loc: string): string {
  if (loc === "ru") return ruPlural(n, "час", "часа", "часов");
  if (loc === "es") return n === 1 ? "hora" : "horas";
  if (loc === "fr") return n === 1 ? "heure" : "heures";
  if (loc === "zh") return "小时";
  return n === 1 ? "hour" : "hours";
}

function minutesWord(n: number, loc: string): string {
  if (loc === "ru") return ruPlural(n, "минута", "минуты", "минут");
  if (loc === "es") return n === 1 ? "minuto" : "minutos";
  if (loc === "fr") return n === 1 ? "minute" : "minutes";
  if (loc === "zh") return "分钟";
  return n === 1 ? "minute" : "minutes";
}

function secondsWord(n: number, loc: string): string {
  if (loc === "ru") return ruPlural(n, "секунда", "секунды", "секунд");
  if (loc === "es") return n === 1 ? "segundo" : "segundos";
  if (loc === "fr") return n === 1 ? "seconde" : "secondes";
  if (loc === "zh") return "秒";
  return n === 1 ? "second" : "seconds";
}

/** 1 hour 22 minutes / 1 час 22 минуты / 2 horas 3 minutos — declined, never "1 ч". */
export function fmtDuration(ms: number, locale: Locale | string): string {
  const loc = String(locale).slice(0, 2);
  const sec = Math.max(0, Math.floor(ms / 1000));
  const totalMin = Math.floor(sec / 60);
  const s = sec % 60;
  if (totalMin >= 60) {
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    if (m === 0) return `${h} ${hoursWord(h, loc)}`;
    return `${h} ${hoursWord(h, loc)} ${m} ${minutesWord(m, loc)}`;
  }
  if (totalMin > 0) return `${totalMin} ${minutesWord(totalMin, loc)}`;
  return `${s} ${secondsWord(s, loc)}`;
}

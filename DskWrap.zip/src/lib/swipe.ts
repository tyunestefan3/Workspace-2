import { useEffect, useRef, type RefObject } from "react";
import { SwipeGate, type SwipeDir } from "./swipeGate";

/**
 * Trackpad and two-finger swipe. One gesture turns one page; the next
 * gesture turns the next page. Inertia is not a lock, so a second swipe
 * is never swallowed, and one swipe never becomes three.
 */
export function useHorizontalSwipe(
  ref: RefObject<HTMLElement | null>,
  enabled: boolean,
  onStep: (dir: SwipeDir) => void,
) {
  const onStepRef = useRef(onStep);
  onStepRef.current = onStep;

  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled) return;

    const gate = new SwipeGate((dir) => onStepRef.current(dir));
    let quiet = 0;
    let two = false;
    let origin = 0;
    let last = 0;

    const arm = () => {
      window.clearTimeout(quiet);
      quiet = window.setTimeout(() => gate.quiet(), 72);
    };

    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey) return;
      const scale = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? window.innerHeight : 1;
      const dx = e.deltaX * scale;
      const dy = e.deltaY * scale;
      if (Math.abs(dy) > Math.abs(dx) * 1.15 && Math.abs(dy) > 0.8) return;
      if (Math.abs(dx) < 0.35) return;
      if (e.cancelable) e.preventDefault();
      arm();
      gate.wheel(performance.now(), dx, dy);
    };

    const mid = (list: TouchList) => (list[0].clientX + list[1].clientX) / 2;
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length !== 2) return;
      two = true;
      origin = mid(e.touches);
      last = origin;
    };
    const onTouchMove = (e: TouchEvent) => {
      if (!two || e.touches.length !== 2) return;
      last = mid(e.touches);
      if (Math.abs(last - origin) > 12 && e.cancelable) e.preventDefault();
    };
    const onTouchEnd = (e: TouchEvent) => {
      if (!two) return;
      if (e.touches.length >= 2) return;
      const dx = last - origin;
      two = false;
      if (Math.abs(dx) < 36) return;
      gate.quiet();
      onStepRef.current(dx < 0 ? 1 : -1);
    };
    const onTouchCancel = () => {
      two = false;
    };

    el.addEventListener("wheel", onWheel, { passive: false, capture: true });
    el.addEventListener("touchstart", onTouchStart, { passive: true });
    el.addEventListener("touchmove", onTouchMove, { passive: false });
    el.addEventListener("touchend", onTouchEnd);
    el.addEventListener("touchcancel", onTouchCancel);
    return () => {
      el.removeEventListener("wheel", onWheel, { capture: true });
      el.removeEventListener("touchstart", onTouchStart);
      el.removeEventListener("touchmove", onTouchMove);
      el.removeEventListener("touchend", onTouchEnd);
      el.removeEventListener("touchcancel", onTouchCancel);
      window.clearTimeout(quiet);
    };
  }, [enabled, ref]);
}

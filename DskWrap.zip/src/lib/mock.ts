// In-browser stand-in for the Tauri backend so the HTML preview is fully
// clickable: metrics, Wrapped, apps, pause, export, debug, locale.

import type {
  AppCategory,
  AppRecord,
  DebugInfo,
  HourBucket,
  PeriodMetrics,
  WeeklyWrapped,
} from "../types";

const HOUR = 3_600_000;
const MIN = 60_000;

const NAMES: Record<string, string> = {
  "com.microsoft.VSCode": "VS Code",
  "com.apple.Terminal": "Terminal",
  "com.jetbrains.intellij": "IntelliJ IDEA",
  "com.google.Chrome": "Chrome",
  "com.apple.Safari": "Safari",
  "org.telegram.desktop": "Telegram",
  "com.tinyspeck.slackmacgap": "Slack",
  "com.google.YouTube": "YouTube",
  "com.apple.finder": "Finder",
  "notion.id": "Notion",
  "com.figma.Desktop": "Figma",
  "com.spotify.client": "Spotify",
  "com.apple.mail": "Mail",
};

function startOfLocalDay(offsetDays = 0): number {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + offsetDays);
  return d.getTime();
}

function hourLabel(ms: number): string {
  const h = new Date(ms).getHours();
  return `${String(h).padStart(2, "0")}:00`;
}

function bucketsForDay(dayStart: number, scale: number): HourBucket[] {
  // Relative activity 0–1 by hour. Typical maker day.
  const focus = [0,0,0,0,0,0,0,0, 0.25,0.8,0.95,0.85, 0.4,0.55,0.7,0.75, 0.6,0.35,0.15,0.1, 0.05,0.2,0.1,0];
  const comm  = [0,0,0,0,0,0,0,0, 0.15,0.2,0.15,0.25, 0.3,0.2,0.35,0.3, 0.25,0.4,0.2,0.1, 0.05,0.1,0.05,0];
  const fun   = [0,0,0,0,0,0,0,0, 0,0,0,0, 0.05,0.1,0,0, 0.05,0.1,0.35,0.5, 0.4,0.25,0.15,0];
  const sw    = [0,0,0,0,0,0,0,0, 4,8,6,9, 12,10,18,16, 14,11,7,5, 3,6,4,1];
  const ck    = [0,0,0,0,0,0,0,0, 1,3,2,3, 4,3,6,5, 4,5,2,1, 1,2,1,0];
  return focus.map((_, h) => ({
    start_ms: dayStart + h * HOUR,
    switches: Math.round(sw[h] * scale),
    checks: Math.round(ck[h] * scale),
    focus_seconds_ms: Math.round(focus[h] * scale * 42 * MIN),
    communication_seconds_ms: Math.round(comm[h] * scale * 18 * MIN),
    entertainment_seconds_ms: Math.round(fun[h] * scale * 20 * MIN),
    active_ms: Math.round((focus[h] * 42 + comm[h] * 18 + fun[h] * 20) * scale * MIN),
  }));
}

function seedApps(): AppRecord[] {
  return [
    { bundle_id: "com.microsoft.VSCode", display_name: "VS Code", category: "focus", ignored: false },
    { bundle_id: "com.apple.Terminal", display_name: "Terminal", category: "focus", ignored: false },
    { bundle_id: "com.jetbrains.intellij", display_name: "IntelliJ IDEA", category: "focus", ignored: false },
    { bundle_id: "notion.id", display_name: "Notion", category: "focus", ignored: false },
    { bundle_id: "com.figma.Desktop", display_name: "Figma", category: "focus", ignored: false },
    { bundle_id: "com.google.Chrome", display_name: "Chrome", category: "neutral", ignored: false },
    { bundle_id: "com.apple.Safari", display_name: "Safari", category: "neutral", ignored: false },
    { bundle_id: "org.telegram.desktop", display_name: "Telegram", category: "communication", ignored: false },
    { bundle_id: "com.tinyspeck.slackmacgap", display_name: "Slack", category: "communication", ignored: false },
    { bundle_id: "com.apple.mail", display_name: "Mail", category: "communication", ignored: false },
    { bundle_id: "com.google.YouTube", display_name: "YouTube", category: "entertainment", ignored: false },
    { bundle_id: "com.spotify.client", display_name: "Spotify", category: "entertainment", ignored: false },
    { bundle_id: "com.apple.finder", display_name: "Finder", category: "utility", ignored: false },
  ];
}

function metricsFromBuckets(
  buckets: HourBucket[],
  scale: number,
  wallMs: number,
): PeriodMetrics {
  const focus = buckets.reduce((a, b) => a + b.focus_seconds_ms, 0);
  const comm = buckets.reduce((a, b) => a + b.communication_seconds_ms, 0);
  const fun = buckets.reduce((a, b) => a + b.entertainment_seconds_ms, 0);
  const utility = Math.round(18 * MIN * scale);
  const neutral = Math.round(55 * MIN * scale);
  const tracked = focus + comm + fun + utility + neutral;
  const switches = buckets.reduce((a, b) => a + b.switches, 0);
  const checks = buckets.reduce((a, b) => a + b.checks, 0);
  const hours = Math.max(wallMs / HOUR, 1);

  const strongest = [...buckets].sort((a, b) => b.focus_seconds_ms - a.focus_seconds_ms)[0];
  const chaos = [...buckets].sort((a, b) => b.switches - a.switches)[0];

  const now = Date.now();
  const today0 = startOfLocalDay(0);

  return {
    wall_ms: wallMs,
    tracked_ms: tracked,
    app_durations: [
      ["com.microsoft.VSCode", "focus", Math.round(focus * 0.62)],
      ["org.telegram.desktop", "communication", Math.round(comm * 0.55)],
      ["com.google.Chrome", "neutral", Math.round(neutral * 0.7)],
      ["com.tinyspeck.slackmacgap", "communication", Math.round(comm * 0.35)],
      ["com.apple.Terminal", "focus", Math.round(focus * 0.22)],
      ["com.google.YouTube", "entertainment", Math.round(fun * 0.7)],
      ["com.figma.Desktop", "focus", Math.round(focus * 0.1)],
      ["com.spotify.client", "entertainment", Math.round(fun * 0.25)],
      ["com.apple.finder", "utility", utility],
    ],
    category_durations: {
      focus,
      communication: comm,
      entertainment: fun,
      utility,
      neutral,
    },
    switches,
    switches_per_hour: switches / hours,
    quick_visits: Math.round(checks * 0.7),
    checks,
    checks_per_app: {
      "org.telegram.desktop": Math.round(checks * 0.48),
      "com.tinyspeck.slackmacgap": Math.round(checks * 0.27),
      "com.apple.mail": Math.round(checks * 0.14),
      "com.google.Chrome": Math.round(checks * 0.11),
    },
    focus_seconds_ms: focus,
    longest_focus_ms: Math.round(52 * MIN * Math.min(scale, 1.4)),
    focus_blocks: [
      { start_ms: today0 + 9 * HOUR, end_ms: today0 + 9 * HOUR + 48 * MIN, duration_ms: 48 * MIN },
      { start_ms: today0 + 10 * HOUR + 20 * MIN, end_ms: today0 + 11 * HOUR + 12 * MIN, duration_ms: 52 * MIN },
      { start_ms: today0 + 14 * HOUR + 5 * MIN, end_ms: today0 + 14 * HOUR + 38 * MIN, duration_ms: 33 * MIN },
      { start_ms: now - 80 * MIN, end_ms: now - 28 * MIN, duration_ms: 52 * MIN },
    ],
    recovery: {
      samples: Math.max(4, Math.round(8 * scale)),
      by_distractor: {
        "org.telegram.desktop": { count: Math.max(3, Math.round(5 * scale)), total_ms: Math.round(5 * scale) * 3.5 * MIN },
        "com.tinyspeck.slackmacgap": { count: Math.max(2, Math.round(3 * scale)), total_ms: Math.round(3 * scale) * 6 * MIN },
        "com.google.YouTube": { count: Math.max(1, Math.round(2 * scale)), total_ms: Math.round(2 * scale) * 11 * MIN },
      },
    },
    ngrams: [
      [["com.microsoft.VSCode", "org.telegram.desktop", "com.microsoft.VSCode"], Math.max(4, Math.round(11 * scale))],
      [["com.microsoft.VSCode", "com.google.Chrome", "com.microsoft.VSCode"], Math.max(3, Math.round(7 * scale))],
    ],
    most_common_ngram: [["com.microsoft.VSCode", "org.telegram.desktop", "com.microsoft.VSCode"], Math.max(4, Math.round(11 * scale))],
    hourly_buckets: buckets,
    most_fragmented: chaos ? [hourLabel(chaos.start_ms), chaos.switches] : null,
    strongest_focus_hour: strongest ? [hourLabel(strongest.start_ms), strongest.focus_seconds_ms] : null,
  };
}

function buildSeed() {
  const today0 = startOfLocalDay(0);
  const weekStart = startOfLocalDay(-((new Date().getDay() + 6) % 7)); // Monday
  const todayBuckets = bucketsForDay(today0, 1);
  const weekBuckets: HourBucket[] = [];
  for (let d = 0; d < 7; d++) {
    const scale = [0.85, 1, 1.05, 0.95, 1.1, 0.45, 0.25][d];
    weekBuckets.push(...bucketsForDay(weekStart + d * 24 * HOUR, scale));
  }
  const monthBuckets: HourBucket[] = [];
  for (let d = -27; d <= 0; d++) {
    const dow = new Date(startOfLocalDay(d)).getDay();
    const scale = dow === 0 || dow === 6 ? 0.3 : 0.7 + ((d + 40) % 5) * 0.08;
    monthBuckets.push(...bucketsForDay(startOfLocalDay(d), scale));
  }

  return {
    apps: seedApps(),
    deleted: new Set<string>(),
    trackerState: "active",
    locale: "en",
    paused: false,
    eventsToday: 186,
    lastEventMs: Date.now() - 42_000,
    lastHeartbeatMs: Date.now() - 8_000,
    metrics: {
      today: metricsFromBuckets(todayBuckets, 1, 16 * HOUR),
      week: metricsFromBuckets(weekBuckets, 5.2, 7 * 16 * HOUR),
      month: metricsFromBuckets(monthBuckets, 18, 28 * 16 * HOUR),
    } as Record<string, PeriodMetrics>,
  };
}

let state = buildSeed();

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v));
}

export function resetMock() {
  state = buildSeed();
}

export function appName(bundleId: string): string {
  const hit = state.apps.find((a) => a.bundle_id === bundleId);
  return hit?.display_name ?? NAMES[bundleId] ?? bundleId;
}

export const mock = {
  getDashboard(period: string): PeriodMetrics {
    const key = period === "today" || period === "month" ? period : "week";
    return clone(state.metrics[key]);
  },

  getWeeklyWrapped(): WeeklyWrapped {
    const m = state.metrics.week;
    const top = m.app_durations[0];
    const checks = Object.entries(m.checks_per_app).sort((a, b) => b[1] - a[1])[0];
    return {
      start_ms: startOfLocalDay(-((new Date().getDay() + 6) % 7)),
      end_ms: Date.now(),
      tracked_ms: m.tracked_ms,
      personality: "ContextSwitcher",
      cards: [
        { kind: "your_week", tracked_ms: m.tracked_ms },
        {
          kind: "main_character",
          bundle_id: top[0],
          display_name: appName(top[0]),
          duration_ms: top[2],
          category: top[1],
        },
        {
          kind: "cant_resist",
          bundle_id: checks[0],
          display_name: appName(checks[0]),
          checks: checks[1],
        },
        {
          kind: "chaos_hour",
          label: m.most_fragmented?.[0] ?? "15:00",
          switches: m.most_fragmented?.[1] ?? 18,
        },
        { kind: "deep_dive", focus_ms: m.longest_focus_ms },
        {
          kind: "your_loop",
          sequence: (m.most_common_ngram?.[0] ?? []).map(appName),
          count: m.most_common_ngram?.[1] ?? 11,
        },
        { kind: "mac_type", label: "THE CONTEXT SWITCHER" },
      ],
    };
  },

  getApplications(): AppRecord[] {
    return clone(state.apps.filter((a) => !state.deleted.has(a.bundle_id)));
  },

  setAppCategory(bundleId: string, category: string) {
    const app = state.apps.find((a) => a.bundle_id === bundleId);
    if (app) app.category = category as AppCategory;
  },

  setAppIgnored(bundleId: string, ignored: boolean) {
    const app = state.apps.find((a) => a.bundle_id === bundleId);
    if (app) app.ignored = ignored;
  },

  deleteAppHistory(bundleId: string): number {
    state.deleted.add(bundleId);
    state.apps = state.apps.filter((a) => a.bundle_id !== bundleId);
    return 12;
  },

  deleteAllTracking() {
    state.apps = [];
    state.eventsToday = 0;
    const empty = metricsFromBuckets([], 0, HOUR);
    empty.app_durations = [];
    empty.category_durations = {};
    empty.checks_per_app = {};
    empty.focus_blocks = [];
    empty.ngrams = [];
    empty.most_common_ngram = null;
    empty.most_fragmented = null;
    empty.strongest_focus_hour = null;
    empty.recovery = { samples: 0, by_distractor: {} };
    empty.tracked_ms = 0;
    empty.focus_seconds_ms = 0;
    empty.switches = 0;
    empty.checks = 0;
    empty.longest_focus_ms = 0;
    state.metrics.today = clone(empty);
    state.metrics.week = clone(empty);
    state.metrics.month = clone(empty);
  },

  exportJson(): string {
    return JSON.stringify(
      {
        apps: state.apps,
        events: sampleEvents(),
        exported_at: new Date().toISOString(),
        preview: true,
      },
      null,
      2,
    );
  },

  exportCsv(): string {
    const rows = ["timestamp_ms,event_type,bundle_id", ...sampleEvents().map((e) => `${e.timestamp_ms},${e.event_type},${e.bundle_id ?? ""}`)];
    return rows.join("\n");
  },

  pause() {
    state.paused = true;
    state.trackerState = "paused";
  },

  resume() {
    state.paused = false;
    state.trackerState = "active";
  },

  getTrackerState(): string {
    return state.trackerState;
  },

  setTrackerState(s: string) {
    state.trackerState = s;
  },

  getDebug(): DebugInfo {
    const today = state.metrics.today;
    const top = today.app_durations[0];
    const alive = state.trackerState === "active" || state.trackerState === "idle" || state.trackerState === "private";
    return {
      tracker_state: state.trackerState,
      last_event_ms: state.lastEventMs,
      last_heartbeat_ms: state.lastHeartbeatMs,
      events_today: state.eventsToday,
      working: alive && Date.now() - state.lastHeartbeatMs < 90_000,
      current_app: state.trackerState === "active" && top ? appName(top[0]) : null,
      switches_today: today.switches,
      checks_today: today.checks,
      quick_visits_today: today.quick_visits,
      tracked_today_ms: today.tracked_ms,
    };
  },

  setLocale(locale: string) {
    state.locale = locale;
  },

  getLocale(): string {
    return state.locale;
  },

  generateWeek() {
    state = buildSeed();
    state.eventsToday = 240;
    state.lastEventMs = Date.now();
    state.lastHeartbeatMs = Date.now();
    state.trackerState = "active";
  },

  sampleEvents,
};

function sampleEvents() {
  const t0 = startOfLocalDay(0) + 9 * HOUR;
  const seq: [string, string | null][] = [
    ["tracker_start", null],
    ["app_active", "com.microsoft.VSCode"],
    ["app_active", "org.telegram.desktop"],
    ["app_active", "com.microsoft.VSCode"],
    ["app_active", "com.tinyspeck.slackmacgap"],
    ["app_active", "com.microsoft.VSCode"],
    ["app_active", "com.google.Chrome"],
    ["idle_start", null],
    ["idle_end", null],
    ["app_active", "com.microsoft.VSCode"],
    ["app_active", "com.google.YouTube"],
    ["app_active", "com.microsoft.VSCode"],
  ];
  return seq.map(([event_type, bundle_id], i) => ({
    timestamp_ms: t0 + i * 7 * MIN,
    event_type,
    bundle_id,
  }));
}

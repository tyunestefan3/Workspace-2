// Lightweight local-time formatting helpers. The backend gives UTC ms; we
// render in the user's local timezone (§22) and active UI locale.

import { BCP47, type Locale } from "../i18n";

export { fmtDuration } from "./grammar";

export function fmtDate(ms: number, locale: Locale): string {
  const d = new Date(ms);
  return d
    .toLocaleDateString(BCP47[locale], { month: "short", day: "numeric" })
    .replace(/[.,]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function fmtDateTime(ms: number, locale: Locale): string {
  const d = new Date(ms);
  const day = d
    .toLocaleDateString(BCP47[locale], { month: "short", day: "numeric" })
    .replace(/[.,]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  const tm = d.toLocaleTimeString(BCP47[locale], { hour: "2-digit", minute: "2-digit", hour12: false });
  return `${day} ${tm}`;
}

export function fmtHourLabel(ms: number): string {
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, "0")}:00`;
}

import type { HourBucket, PeriodMetrics } from "../types";
import type { Locale, TFn } from "../i18n";
import { fmtDuration } from "./format";
import { appInCase, fmtNum, fmtTimes, fmtVisits, fmtSwitches, fmtGlances, fmtApps, fmtBlocks } from "./grammar";

export interface Rec {
  id: string;
  title: string;
  why: string;
  next: string;
  weight: number;
}

function hourOf(ms: number) {
  return new Date(ms).getHours();
}

function bucketMs(b: HourBucket) {
  return b.active_ms ?? b.focus_seconds_ms + b.communication_seconds_ms + b.entertainment_seconds_ms;
}

function isBrowser(id: string) {
  return /safari|chrome|firefox|edge|brave|opera|arc|browser|yandex|duckduckgo|vivaldi|tor/.test(id.toLowerCase());
}

function isMail(id: string, name: string) {
  return /mail|outlook|thunderbird/.test(`${id} ${name}`.toLowerCase());
}

function isFinder(id: string, name: string) {
  return /finder/.test(`${id} ${name}`.toLowerCase());
}

function isFunApp(id: string, name: string) {
  return /youtube|iina|spotify|netflix|vlc|twitch|music|кино|музык/.test(`${id} ${name}`.toLowerCase());
}

function sumWhere(buckets: HourBucket[], pred: (b: HourBucket) => boolean, pick: (b: HourBucket) => number) {
  return buckets.filter(pred).reduce((a, b) => a + pick(b), 0);
}

function hh(ms: number) {
  return `${String(hourOf(ms)).padStart(2, "0")}:00`;
}

export function recommend(
  m: PeriodMetrics,
  t: TFn,
  nameOf: (id: string) => string,
  period: "today" | "week" | "month",
  locale: Locale = "en",
): Rec[] {
  const recs: Rec[] = [];
  const tracked = Math.max(m.tracked_ms, 1);
  const focusShare = m.focus_seconds_ms / tracked;
  const commShare = (m.category_durations?.communication ?? 0) / tracked;
  const funShare = (m.category_durations?.entertainment ?? 0) / tracked;
  const utilShare = (m.category_durations?.utility ?? 0) / tracked;
  const topCheck = Object.entries(m.checks_per_app).sort((a, b) => b[1] - a[1])[0];
  const recov = Object.entries(m.recovery.by_distractor).sort((a, b) => b[1].count - a[1].count)[0];
  const span = period === "today" ? 1 : period === "week" ? 7 : 28;
  const checksPerDay = topCheck ? topCheck[1] / span : 0;
  const apps = (m.app_durations ?? []).filter(([, , dur]) => dur >= 60_000);
  const top = apps[0];
  const second = apps[1];
  const buckets = m.hourly_buckets ?? [];
  const lateMs = sumWhere(buckets, (b) => hourOf(b.start_ms) >= 22 || hourOf(b.start_ms) < 5, bucketMs);
  const nightMs = sumWhere(buckets, (b) => hourOf(b.start_ms) < 5, bucketMs);
  const morning = buckets
    .filter((b) => hourOf(b.start_ms) >= 8 && hourOf(b.start_ms) <= 11)
    .sort((a, b) => b.switches - a.switches)[0];
  const lunch = buckets
    .filter((b) => hourOf(b.start_ms) >= 12 && hourOf(b.start_ms) <= 13)
    .sort((a, b) => bucketMs(b) - bucketMs(a))[0];
  const afterLunch = buckets
    .filter((b) => hourOf(b.start_ms) >= 13 && hourOf(b.start_ms) <= 16)
    .sort((a, b) => b.switches - a.switches)[0];
  const peakBucket = [...buckets].sort((a, b) => b.focus_seconds_ms - a.focus_seconds_ms)[0];
  const firstActive = [...buckets].find((b) => bucketMs(b) > 5 * 60_000);
  const lastActive = [...buckets].reverse().find((b) => bucketMs(b) > 5 * 60_000);
  const shortBlocks = (m.focus_blocks ?? []).filter((b) => b.duration_ms < 8 * 60_000).length;
  const eveningMs = sumWhere(buckets, (b) => hourOf(b.start_ms) >= 18, bucketMs);
  const workHoursFun = sumWhere(
    buckets,
    (b) => hourOf(b.start_ms) >= 9 && hourOf(b.start_ms) <= 18,
    (b) => b.entertainment_seconds_ms,
  );
  const morningFun = sumWhere(
    buckets,
    (b) => hourOf(b.start_ms) >= 8 && hourOf(b.start_ms) <= 11,
    (b) => b.entertainment_seconds_ms,
  );
  const morningComm = sumWhere(
    buckets,
    (b) => hourOf(b.start_ms) >= 8 && hourOf(b.start_ms) <= 11,
    (b) => b.communication_seconds_ms,
  );
  const eveningComm = sumWhere(buckets, (b) => hourOf(b.start_ms) >= 19, (b) => b.communication_seconds_ms);
  const noonFocus = sumWhere(buckets, (b) => hourOf(b.start_ms) >= 10 && hourOf(b.start_ms) <= 12, (b) => b.focus_seconds_ms);
  const slumpFocus = sumWhere(buckets, (b) => hourOf(b.start_ms) >= 14 && hourOf(b.start_ms) <= 16, (b) => b.focus_seconds_ms);
  const weekendMs = sumWhere(buckets, (b) => [0, 6].includes(new Date(b.start_ms).getDay()), bucketMs);

  const push = (id: string, weight: number, title: string, why: string, next: string) => {
    recs.push({ id, weight, title, why, next });
  };

  if (m.most_fragmented && m.most_fragmented[1] >= 10) {
    push(
      "chaos",
      90 + Math.min(m.most_fragmented[1], 30),
      t("rec.chaos.title"),
      t("rec.chaos.why", { hour: m.most_fragmented[0], n: fmtSwitches(m.most_fragmented[1], locale) }),
      t("rec.chaos.next", { hour: m.most_fragmented[0] }),
    );
  }

  if (topCheck && checksPerDay >= 6) {
    const app = nameOf(topCheck[0]);
    push(
      "checks",
      80 + Math.min(checksPerDay, 40),
      t("rec.checks.title", { app }),
      t("rec.checks.why", { app, n: fmtTimes(topCheck[1], locale) }),
      t("rec.checks.next", { app }),
    );
  }

  const ngram = [...(m.ngrams ?? [])]
    .filter(([ids, n]) => n >= 4 && ids.length >= 2 && new Set(ids.map((id) => nameOf(id).trim().toLowerCase())).size >= 2)
    .sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)[0];
  if (ngram && ngram[1] >= 4 && ngram[0].length >= 3) {
    const loop = ngram[0].map(nameOf).join(" → ");
    push(
      "threeLoop",
      78 + ngram[1],
      t("rec.threeLoop.title"),
      t("rec.threeLoop.why", { loop, n: fmtTimes(ngram[1], locale) }),
      t("rec.threeLoop.next", { app: nameOf(ngram[0][1] ?? ngram[0][0]) }),
    );
  } else if (ngram && ngram[1] >= 4 && ngram[0].length >= 2) {
    const loop = ngram[0].map(nameOf).join(" → ");
    push(
      "loop",
      75 + ngram[1],
      t("rec.loop.title"),
      t("rec.loop.why", { loop, n: fmtTimes(ngram[1], locale) }),
      t("rec.loop.next", { app: nameOf(ngram[0][1] ?? ngram[0][0]) }),
    );
  }

  if (ngram && ngram[0].some((id) => isFinder(id, nameOf(id))) && ngram[1] >= 4) {
    push(
      "loopFinder",
      61,
      t("rec.loopFinder.title"),
      t("rec.loopFinder.why", { n: fmtTimes(ngram[1], locale) }),
      t("rec.loopFinder.next"),
    );
  }

  if (recov && m.recovery.samples >= 3) {
    const avg = recov[1].count ? recov[1].total_ms / recov[1].count : 0;
    const app = nameOf(recov[0]);
    if (avg >= 2 * 60_000) {
      const fun = isFunApp(recov[0], app);
      push(
        fun ? "recovFun" : "recovery",
        70 + recov[1].count,
        t(fun ? "rec.recovFun.title" : "rec.recovery.title"),
        t(fun ? "rec.recovFun.why" : "rec.recovery.why", {
          app: appInCase(app, locale, "gen"),
          duration: fmtDuration(avg, locale),
          n: fmtTimes(recov[1].count, locale),
        }),
        t(fun ? "rec.recovFun.next" : "rec.recovery.next", { app }),
      );
    }
  }

  if (m.switches_per_hour >= 8 && m.tracked_ms >= 15 * 60_000) {
    push(
      "switches",
      60 + m.switches_per_hour,
      t("rec.switches.title"),
      t("rec.switches.why", { n: fmtNum(m.switches_per_hour, locale) }),
      t("rec.switches.next"),
    );
  }

  if (m.strongest_focus_hour && m.strongest_focus_hour[1] >= 20 * 60_000) {
    push(
      "best",
      55,
      t("rec.best.title"),
      t("rec.best.why", {
        hour: m.strongest_focus_hour[0],
        duration: fmtDuration(m.strongest_focus_hour[1], locale),
      }),
      t("rec.best.next", { hour: m.strongest_focus_hour[0] }),
    );
  }

  if (m.longest_focus_ms >= 40 * 60_000) {
    push(
      "keep",
      40,
      t("rec.keep.title"),
      t("rec.keep.why", { duration: fmtDuration(m.longest_focus_ms, locale) }),
      t("rec.keep.next"),
    );
  }

  if (focusShare < 0.45 && m.tracked_ms > 2 * 3600_000) {
    push(
      "focusShare",
      65,
      t("rec.focus.title"),
      t("rec.focus.why", { pct: Math.round(focusShare * 100) }),
      t("rec.focus.next"),
    );
  }

  if (m.quick_visits >= 20) {
    push(
      "quick",
      50,
      t("rec.quick.title"),
      t("rec.quick.why", { n: fmtVisits(m.quick_visits, locale) }),
      t("rec.quick.next"),
    );
  }

  if (lateMs >= 45 * 60_000 && lateMs / tracked >= 0.18) {
    push("late", 58, t("rec.late.title"), t("rec.late.why", { duration: fmtDuration(lateMs, locale) }), t("rec.late.next"));
  }

  if (funShare >= 0.28 && m.tracked_ms > 90 * 60_000) {
    push("leisure", 52, t("rec.leisure.title"), t("rec.leisure.why", { pct: Math.round(funShare * 100) }), t("rec.leisure.next"));
  }

  if (commShare >= 0.32 && m.tracked_ms > 90 * 60_000) {
    push("chat", 62, t("rec.chat.title"), t("rec.chat.why", { pct: Math.round(commShare * 100) }), t("rec.chat.next"));
  }

  if (top && top[2] / tracked >= 0.55 && m.tracked_ms > 2 * 3600_000) {
    const app = nameOf(top[0]);
    push(
      "oneApp",
      48,
      t("rec.oneApp.title", { app }),
      t("rec.oneApp.why", { app, pct: Math.round((top[2] / tracked) * 100) }),
      t("rec.oneApp.next", { app }),
    );
  }

  if (m.tracked_ms >= 3 * 3600_000 && m.longest_focus_ms < 12 * 60_000) {
    push("noDeep", 68, t("rec.noDeep.title"), t("rec.noDeep.why", { duration: fmtDuration(m.longest_focus_ms, locale) }), t("rec.noDeep.next"));
  }

  if (apps.length >= 12 && m.tracked_ms > 2 * 3600_000) {
    push("manyApps", 44, t("rec.manyApps.title"), t("rec.manyApps.why", { n: fmtApps(apps.length, locale) }), t("rec.manyApps.next"));
  }

  if (funShare < 0.04 && focusShare >= 0.5 && m.tracked_ms > 4 * 3600_000) {
    push("rest", 36, t("rec.rest.title"), t("rec.rest.why"), t("rec.rest.next"));
  }

  if (m.strongest_focus_hour) {
    const h = parseInt(m.strongest_focus_hour[0], 10);
    if (h >= 21 || h < 6) {
      push("night", 46, t("rec.night.title"), t("rec.night.why", { hour: m.strongest_focus_hour[0] }), t("rec.night.next"));
    }
  }

  if (top && second && top[2] > 0 && second[2] / top[2] >= 0.72) {
    push(
      "split",
      42,
      t("rec.split.title"),
      t("rec.split.why", { a: nameOf(top[0]), b: nameOf(second[0]) }),
      t("rec.split.next", { a: nameOf(top[0]), b: nameOf(second[0]) }),
    );
  }

  if (morning && morning.switches >= 12) {
    const hour = hh(morning.start_ms);
    push(
      "morning",
      57,
      t("rec.morning.title"),
      t("rec.morning.why", { hour, n: fmtSwitches(morning.switches, locale) }),
      t("rec.morning.next", { hour }),
    );
  }

  if (top && isBrowser(top[0]) && top[2] / tracked >= 0.35) {
    const app = nameOf(top[0]);
    push(
      "browser",
      47,
      t("rec.browser.title", { app }),
      t("rec.browser.why", { app, pct: Math.round((top[2] / tracked) * 100) }),
      t("rec.browser.next", { app }),
    );
  }

  if (peakBucket && peakBucket.focus_seconds_ms >= 20 * 60_000 && peakBucket.communication_seconds_ms >= 12 * 60_000) {
    const hour = hh(peakBucket.start_ms);
    push(
      "peakLeak",
      64,
      t("rec.peakLeak.title"),
      t("rec.peakLeak.why", { hour, duration: fmtDuration(peakBucket.communication_seconds_ms, locale) }),
      t("rec.peakLeak.next", { hour }),
    );
  }

  if (m.focus_blocks.length >= 4 && shortBlocks / m.focus_blocks.length >= 0.7 && m.tracked_ms > 2 * 3600_000) {
    push("shortFocus", 49, t("rec.shortFocus.title"), t("rec.shortFocus.why", { n: fmtBlocks(shortBlocks, locale) }), t("rec.shortFocus.next"));
  }

  if (lateMs >= 90 * 60_000) {
    push("sleep", 53, t("rec.sleep.title"), t("rec.sleep.why", { duration: fmtDuration(lateMs, locale) }), t("rec.sleep.next"));
  }

  if (firstActive && hourOf(firstActive.start_ms) >= 11 && m.tracked_ms > 2 * 3600_000) {
    push("lateStart", 34, t("rec.lateStart.title"), t("rec.lateStart.why", { hour: hh(firstActive.start_ms) }), t("rec.lateStart.next"));
  }

  if (utilShare >= 0.22 && m.tracked_ms > 2 * 3600_000) {
    push("tools", 38, t("rec.tools.title"), t("rec.tools.why", { pct: Math.round(utilShare * 100) }), t("rec.tools.next"));
  }

  if (afterLunch && afterLunch.switches >= 12) {
    const hour = hh(afterLunch.start_ms);
    push(
      "afterLunch",
      56,
      t("rec.afterLunch.title"),
      t("rec.afterLunch.why", { hour, n: fmtSwitches(afterLunch.switches, locale) }),
      t("rec.afterLunch.next", { hour }),
    );
  }

  if (firstActive && hourOf(firstActive.start_ms) < 7 && m.tracked_ms > 2 * 3600_000) {
    push("earlyStart", 33, t("rec.earlyStart.title"), t("rec.earlyStart.why", { hour: hh(firstActive.start_ms) }), t("rec.earlyStart.next"));
  }

  if (nightMs >= 30 * 60_000) {
    push("midnight", 51, t("rec.midnight.title"), t("rec.midnight.why", { duration: fmtDuration(nightMs, locale) }), t("rec.midnight.next"));
  }

  if (noonFocus >= 25 * 60_000 && slumpFocus < noonFocus * 0.35 && m.tracked_ms > 4 * 3600_000) {
    push("slump", 41, t("rec.slump.title"), t("rec.slump.why"), t("rec.slump.next"));
  }

  if (apps.length >= 2 && apps.length <= 3 && m.tracked_ms > 3 * 3600_000) {
    push("fewApps", 32, t("rec.fewApps.title"), t("rec.fewApps.why", { n: fmtApps(apps.length, locale) }), t("rec.fewApps.next"));
  }

  if (morningFun >= 25 * 60_000) {
    push("funMorning", 45, t("rec.funMorning.title"), t("rec.funMorning.why", { duration: fmtDuration(morningFun, locale) }), t("rec.funMorning.next"));
  }

  if (eveningComm >= 25 * 60_000) {
    push("chatEvening", 43, t("rec.chatEvening.title"), t("rec.chatEvening.why", { duration: fmtDuration(eveningComm, locale) }), t("rec.chatEvening.next"));
  }

  if (m.most_fragmented && m.strongest_focus_hour && m.most_fragmented[0] === m.strongest_focus_hour[0]) {
    push(
      "mixedHour",
      72,
      t("rec.mixedHour.title"),
      t("rec.mixedHour.why", { hour: m.most_fragmented[0] }),
      t("rec.mixedHour.next", { hour: m.most_fragmented[0] }),
    );
  }

  if (m.focus_blocks.length === 1 && m.tracked_ms > 3 * 3600_000) {
    push("oneBlock", 50, t("rec.oneBlock.title"), t("rec.oneBlock.why", { duration: fmtDuration(m.focus_blocks[0].duration_ms, locale) }), t("rec.oneBlock.next"));
  }

  if (m.switches_per_hour >= 15 && m.checks < m.switches * 0.3 && m.tracked_ms >= 15 * 60_000) {
    push("hop", 54, t("rec.hop.title"), t("rec.hop.why", { n: fmtNum(m.switches_per_hour, locale) }), t("rec.hop.next"));
  }

  if (topCheck && m.switches >= 8 && m.checks > m.switches * 1.2) {
    push(
      "stare",
      51,
      t("rec.stare.title", { app: nameOf(topCheck[0]) }),
      t("rec.stare.why", { app: nameOf(topCheck[0]), n: fmtGlances(topCheck[1], locale) }),
      t("rec.stare.next", { app: nameOf(topCheck[0]) }),
    );
  }

  if (top && top[1] === "communication" && top[2] / tracked >= 0.3) {
    const app = nameOf(top[0]);
    push("topChat", 59, t("rec.topChat.title", { app }), t("rec.topChat.why", { app, pct: Math.round((top[2] / tracked) * 100) }), t("rec.topChat.next", { app }));
  }

  if (top && top[1] === "entertainment" && top[2] / tracked >= 0.25) {
    const app = nameOf(top[0]);
    push("topFun", 58, t("rec.topFun.title", { app }), t("rec.topFun.why", { app, pct: Math.round((top[2] / tracked) * 100) }), t("rec.topFun.next", { app }));
  }

  const finderApp = apps.find(([id, , dur]) => isFinder(id, nameOf(id)) && dur >= 20 * 60_000);
  if (finderApp) {
    push("finder", 40, t("rec.finder.title"), t("rec.finder.why", { duration: fmtDuration(finderApp[2], locale) }), t("rec.finder.next"));
  }

  const mailApp = apps.find(([id]) => isMail(id, nameOf(id)));
  const mailChecks = Object.entries(m.checks_per_app).find(([id]) => isMail(id, nameOf(id)));
  if ((mailApp && mailApp[2] >= 25 * 60_000) || (mailChecks && mailChecks[1] >= 8)) {
    const app = nameOf(mailApp?.[0] ?? mailChecks![0]);
    push("mail", 46, t("rec.mail.title", { app }), t("rec.mail.why", { app }), t("rec.mail.next", { app }));
  }

  if (workHoursFun >= 40 * 60_000) {
    push("videoDay", 47, t("rec.videoDay.title"), t("rec.videoDay.why", { duration: fmtDuration(workHoursFun, locale) }), t("rec.videoDay.next"));
  }

  if ((m.away_ms ?? 0) >= 3 * 3600_000 && m.tracked_ms >= 60 * 60_000) {
    push("awayDay", 37, t("rec.awayDay.title"), t("rec.awayDay.why", { duration: fmtDuration(m.away_ms ?? 0, locale) }), t("rec.awayDay.next"));
  }

  if (m.tracked_ms >= 10 * 3600_000) {
    push("longDay", 39, t("rec.longDay.title"), t("rec.longDay.why", { duration: fmtDuration(m.tracked_ms, locale) }), t("rec.longDay.next"));
  }

  if (m.tracked_ms >= 30 * 60_000 && m.tracked_ms <= 2.5 * 3600_000 && m.switches_per_hour >= 18) {
    push("shortIntense", 48, t("rec.shortIntense.title"), t("rec.shortIntense.why", { n: fmtNum(m.switches_per_hour, locale) }), t("rec.shortIntense.next"));
  }

  if (focusShare >= 0.72 && m.tracked_ms >= 6 * 3600_000) {
    push("burnout", 43, t("rec.burnout.title"), t("rec.burnout.why", { pct: Math.round(focusShare * 100) }), t("rec.burnout.next"));
  }

  if (morningComm >= 20 * 60_000) {
    push("commMorning", 44, t("rec.commMorning.title"), t("rec.commMorning.why", { duration: fmtDuration(morningComm, locale) }), t("rec.commMorning.next"));
  }

  if (commShare < 0.03 && m.tracked_ms > 4 * 3600_000) {
    push("noChat", 31, t("rec.noChat.title"), t("rec.noChat.why"), t("rec.noChat.next"));
  }

  if (eveningMs / tracked >= 0.55 && m.tracked_ms > 2 * 3600_000) {
    push("eveningOnly", 35, t("rec.eveningOnly.title"), t("rec.eveningOnly.why", { pct: Math.round((eveningMs / tracked) * 100) }), t("rec.eveningOnly.next"));
  }

  if (lunch && (lunch.entertainment_seconds_ms >= 15 * 60_000 || lunch.switches >= 10)) {
    push("lunchScroll", 42, t("rec.lunchScroll.title"), t("rec.lunchScroll.why"), t("rec.lunchScroll.next"));
  }

  if (firstActive && firstActive.entertainment_seconds_ms > firstActive.focus_seconds_ms && bucketMs(firstActive) >= 15 * 60_000) {
    push("firstHourFun", 45, t("rec.firstHourFun.title"), t("rec.firstHourFun.why", { hour: hh(firstActive.start_ms) }), t("rec.firstHourFun.next"));
  }

  if (lastActive && lastActive.communication_seconds_ms >= 12 * 60_000) {
    push("lastHourChat", 36, t("rec.lastHourChat.title"), t("rec.lastHourChat.why", { hour: hh(lastActive.start_ms) }), t("rec.lastHourChat.next"));
  }

  if (period !== "today" && weekendMs / tracked >= 0.45 && m.tracked_ms > 2 * 3600_000) {
    push("weekend", 38, t("rec.weekend.title"), t("rec.weekend.why", { pct: Math.round((weekendMs / tracked) * 100) }), t("rec.weekend.next"));
  }

  return recs.sort((a, b) => b.weight - a.weight || a.id.localeCompare(b.id)).slice(0, 7);
}

/**
 * One trackpad swipe = one page. The next swipe must still land.
 *
 * macOS keeps sending wheel events after the finger lifts. A lock that
 * stays up for that whole tail — and resets whenever those events arrive —
 * swallows the next swipe, so the user can never get past page one.
 *
 * After a page turn we ignore only the decaying tail. A pause, a died-down
 * tail, or a new impulse that is clearly stronger than that tail starts
 * the next page immediately. Animation is not part of this gate.
 *
 * deltaX > 0 (fingers left) = next.
 */
export type SwipeDir = 1 | -1;

const THRESH = 32;
const GAP_RESET = 64;

export class SwipeGate {
  private phase: "idle" | "coast" = "idle";
  private acc = 0;
  private vel = 0;
  private dipped = false;
  private coastAt = 0;
  private lastT = -1;
  private coastSign: SwipeDir | 0 = 0;

  constructor(private readonly onStep: (dir: SwipeDir) => void) {}

  quiet(): void {
    this.phase = "idle";
    this.acc = 0;
    this.vel = 0;
    this.dipped = false;
    this.coastSign = 0;
  }

  wheel(t: number, dx: number, dy: number): void {
    const adx = Math.abs(dx);
    const ady = Math.abs(dy);
    const gap = this.lastT >= 0 ? t - this.lastT : 1000;
    this.lastT = t;

    if (ady > adx * 1.15 && ady > 0.8) {
      this.acc = 0;
      return;
    }
    if (adx < 0.35) return;

    if (gap > GAP_RESET) this.quiet();

    if (this.phase === "coast") {
      const age = t - this.coastAt;
      const prev = this.vel;
      this.vel = prev * 0.62 + adx * 0.38;
      if (adx < 8 || this.vel < 10) this.dipped = true;

      const reversed =
        this.dipped &&
        age > 70 &&
        this.coastSign !== 0 &&
        Math.sign(dx) !== this.coastSign &&
        adx >= 14;
      const punch = this.dipped && age > 48 && adx >= 12 && adx > prev * 1.28;
      if (!reversed && !punch) return;

      this.phase = "idle";
      this.acc = 0;
      this.vel = adx;
      this.dipped = false;
      this.coastSign = 0;
    }

    this.acc += dx;
    this.vel = this.vel * 0.45 + adx * 0.55;
    if (Math.abs(this.acc) < THRESH) return;
    this.commit(this.acc > 0 ? 1 : -1, t, adx);
  }

  private commit(dir: SwipeDir, t: number, adx: number): void {
    this.phase = "coast";
    this.coastAt = t;
    this.acc = 0;
    this.vel = Math.max(adx, 16);
    this.dipped = false;
    this.coastSign = dir;
    this.onStep(dir);
  }
}

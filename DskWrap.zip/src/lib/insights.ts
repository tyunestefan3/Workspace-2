import type { PeriodMetrics } from "../types";
import type { Locale, TFn } from "../i18n";
import { fmtDuration } from "./format";
import { appInCase, fmtGlances, fmtSwitches, fmtTimes } from "./grammar";

export interface InsightView {
  kind: string;
  text: string;
}

export function insightsFrom(m: PeriodMetrics, t: TFn, nameOf: (id: string) => string, locale: Locale = "en"): InsightView[] {
  const out: InsightView[] = [];

  if ((m.away_ms ?? 0) >= 15 * 60_000) {
    out.push({
      kind: "COMPUTER_OFF",
      text: t("insight.computerOff", { duration: fmtDuration(m.away_ms ?? 0, locale) }),
    });
  }

  const topCheck = Object.entries(m.checks_per_app).sort((a, b) => b[1] - a[1])[0];
  if (topCheck && topCheck[1] >= 3) {
    out.push({
      kind: "MOST_CHECKED_APP",
      text: t("insight.mostChecked", { app: nameOf(topCheck[0]), n: fmtGlances(topCheck[1], locale) }),
    });
  }
  if (m.longest_focus_ms >= 60_000) {
    out.push({
      kind: "LONGEST_FOCUS",
      text: t("insight.longestFocus", { duration: fmtDuration(m.longest_focus_ms, locale) }),
    });
  }
  if (m.most_fragmented && m.most_fragmented[1] >= 3) {
    out.push({
      kind: "CHAOS_HOUR",
      text: t("insight.chaosHour", {
        label: m.most_fragmented[0],
        n: fmtSwitches(m.most_fragmented[1], locale),
      }),
    });
  }
  const loop = [...(m.ngrams ?? [])]
    .filter(([ids, n]) => n >= 3 && ids.length >= 2 && new Set(ids.map((id) => nameOf(id).trim().toLowerCase())).size >= 2)
    .sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)[0];
  if (loop) {
    out.push({
      kind: "COMMON_LOOP",
      text: t("insight.commonLoop", {
        loop: loop[0].map(nameOf).join(" → "),
        n: fmtTimes(loop[1], locale),
      }),
    });
  }
  const rec = Object.entries(m.recovery.by_distractor).sort((a, b) => b[1].count - a[1].count)[0];
  if (rec && m.recovery.samples >= 3) {
    const avg = rec[1].count > 0 ? rec[1].total_ms / rec[1].count : 0;
    out.push({
      kind: "RECOVERY",
      text: t("insight.recovery", { app: appInCase(nameOf(rec[0]), locale, "gen"), duration: fmtDuration(avg, locale) }),
    });
  }
  if (m.strongest_focus_hour && m.strongest_focus_hour[1] >= 5 * 60_000) {
    out.push({
      kind: "STRONGEST_FOCUS",
      text: t("insight.strongestFocus", {
        label: m.strongest_focus_hour[0],
        duration: fmtDuration(m.strongest_focus_hour[1], locale),
      }),
    });
  }
  return out;
}

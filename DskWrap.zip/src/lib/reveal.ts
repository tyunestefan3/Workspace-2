import { useEffect } from "react";

/**
 * Continuation arrives from nowhere: first screen composes in a short cascade,
 * anything below the fold waits until you reach it, then materializes in place.
 * No slide-up — that would come from somewhere.
 */
export function useReveal(resetKey: unknown) {
  useEffect(() => {
    const root = document.querySelector(".main");
    if (!root) return;

    const nodes = Array.from(root.querySelectorAll<HTMLElement>(".rise"));
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      nodes.forEach((el) => el.classList.add("in"));
      return;
    }

    nodes.forEach((el) => el.classList.remove("in"));

    let cascade = 0;
    const show = (el: HTMLElement, wait: number) => {
      if (el.classList.contains("in") || el.dataset.revealing === "1") return;
      el.dataset.revealing = "1";
      window.setTimeout(() => {
        el.classList.add("in");
        delete el.dataset.revealing;
      }, wait);
    };

    const io = new IntersectionObserver(
      (entries) => {
        entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)
          .forEach((e) => {
            const el = e.target as HTMLElement;
            io.unobserve(el);
            const late = e.boundingClientRect.top > root.clientHeight * 0.58;
            if (late) {
              show(el, 50);
              return;
            }
            const extra = Number(el.dataset.delay ?? 0);
            show(el, extra + cascade * 90);
            cascade += 1;
          });
      },
      { root, threshold: 0.02, rootMargin: "0px 0px 25% 0px" },
    );

    nodes.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [resetKey]);
}

/** Never show reverse-DNS ids (`com.apple.Safari`) in the UI. */

const SPECIAL: Record<string, string> = {
  finder: "Finder",
  safari: "Safari",
  terminal: "Terminal",
  preview: "Preview",
  notes: "Notes",
  mail: "Mail",
  ical: "Calendar",
  mobilesms: "Messages",
  facetime: "FaceTime",
  systemsettings: "System Settings",
  systempreferences: "System Settings",
  xcode: "Xcode",
  music: "Music",
  ibooksx: "Books",
  textedit: "TextEdit",
  calculator: "Calculator",
  appstore: "App Store",
  torbrowser: "Tor Browser",
  vscode: "VS Code",
  vscodeinsiders: "VS Code",
  iterm2: "iTerm",
  slackmacgap: "Slack",
};

export function looksLikeBundleId(s: string): boolean {
  const t = s.trim();
  if (!t.includes(".")) return false;
  const head = t.split(".")[0]?.toLowerCase() ?? "";
  return ["com", "org", "net", "io", "ru", "co", "dev", "app", "tv", "me", "us", "ch"].includes(head)
    || (t.match(/\./g) ?? []).length >= 2;
}

export function isJunkApp(bundleId: string, displayName?: string, durMs = 1): boolean {
  if (durMs < 5_000) return true;
  const h = `${bundleId} ${displayName ?? ""}`.toLowerCase();
  return (
    /loginwindow|notificationcenter|controlcenter|spotlight|windowmanager|systemuiserver|wallpaper/.test(h)
    || h.includes("центр уведомлен")
    || h.includes("notification center")
    || h.includes("control center")
  );
}

export function prettyName(bundleId: string, displayName?: string): string {
  const d = (displayName ?? "").trim();
  if (d && !looksLikeBundleId(d) && d.toLowerCase() !== "loginwindow") return d;
  const last = bundleId.split(".").pop() ?? bundleId;
  const hit = SPECIAL[last.toLowerCase()];
  if (hit) return hit;
  const low = bundleId.toLowerCase();
  if (low.includes("telegram")) return "Telegram";
  if (low.includes("safari")) return "Safari";
  if (!last) return bundleId;
  return last
    .replace(/[-_]+/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/^./, (c) => c.toUpperCase());
}

// Thin wrappers over Tauri commands. In the HTML preview (no Tauri) we fall
// back to the in-browser mock so every screen is interactive.
import { invoke } from "@tauri-apps/api/core";
import type { AppRecord, DebugInfo, PeriodMetrics, WeeklyWrapped } from "../types";
import { isTauri } from "./env";
import { mock, resetMock } from "./mock";

async function call<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  if (isTauri()) return invoke<T>(cmd, args);
  switch (cmd) {
    case "get_dashboard":
      return mock.getDashboard(String(args?.period ?? "week")) as T;
    case "get_weekly_wrapped":
      return mock.getWeeklyWrapped() as T;
    case "get_applications":
      return mock.getApplications() as T;
    case "set_app_category":
      mock.setAppCategory(String(args?.bundleId), String(args?.category));
      return undefined as T;
    case "set_app_ignored":
      mock.setAppIgnored(String(args?.bundleId), Boolean(args?.ignored));
      return undefined as T;
    case "delete_app_history":
      return mock.deleteAppHistory(String(args?.bundleId)) as T;
    case "delete_all_tracking":
      mock.deleteAllTracking();
      return undefined as T;
    case "export_json":
      return mock.exportJson() as T;
    case "export_csv":
      return mock.exportCsv() as T;
    case "pause":
      mock.pause();
      return undefined as T;
    case "resume":
      mock.resume();
      return undefined as T;
    case "get_tracker_state":
      return mock.getTrackerState() as T;
    case "get_debug":
      return mock.getDebug() as T;
    case "set_locale":
      mock.setLocale(String(args?.locale ?? "en"));
      return undefined as T;
    case "get_locale":
      return mock.getLocale() as T;
    case "set_launch_at_start":
    case "set_stop_on_quit":
    case "set_onboarded":
    case "hide_to_tray":
      return undefined as T;
    case "get_launch_at_start":
      return true as T;
    case "get_stop_on_quit":
      return false as T;
    case "get_onboarded":
      return (typeof localStorage !== "undefined" && localStorage.getItem("dw_onboarded") === "1") as T;
    default:
      throw new Error(`unknown mock command: ${cmd}`);
  }
}

export const api = {
  getDashboard: (period: string) => call<PeriodMetrics>("get_dashboard", { period }),
  getWeeklyWrapped: (period: string) => call<WeeklyWrapped>("get_weekly_wrapped", { period }),
  getApplications: () => call<AppRecord[]>("get_applications"),
  setAppCategory: (bundleId: string, category: string) =>
    call("set_app_category", { bundleId, category }),
  setAppIgnored: (bundleId: string, ignored: boolean) =>
    call("set_app_ignored", { bundleId, ignored }),
  deleteAppHistory: (bundleId: string) => call<number>("delete_app_history", { bundleId }),
  deleteAllTracking: () => call("delete_all_tracking"),
  exportJson: () => call<string>("export_json"),
  exportCsv: () => call<string>("export_csv"),
  pause: (durationMs?: number) => call("pause", { durationMs: durationMs ?? null }),
  resume: () => call("resume"),
  getTrackerState: () => call<string>("get_tracker_state"),
  getDebug: () => call<DebugInfo>("get_debug"),
  setLocale: (locale: string) => call("set_locale", { locale }),
  getLocale: () => call<string>("get_locale"),
  setLaunchAtStart: (enabled: boolean) => call("set_launch_at_start", { enabled }),
  getLaunchAtStart: () => call<boolean>("get_launch_at_start"),
  hideToTray: () => call("hide_to_tray"),
  getStopOnQuit: () => call<boolean>("get_stop_on_quit"),
  setStopOnQuit: (enabled: boolean) => call("set_stop_on_quit", { enabled }),
  getOnboarded: () => call<boolean>("get_onboarded"),
  setOnboarded: (done: boolean) => call("set_onboarded", { done }),
  resetDemo: () => {
    resetMock();
    return Promise.resolve();
  },
  generateWeek: () => {
    mock.generateWeek();
    return Promise.resolve();
  },
  simulateState: (s: string) => {
    mock.setTrackerState(s);
    return Promise.resolve();
  },
};

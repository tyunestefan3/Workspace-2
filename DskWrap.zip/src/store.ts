import { create } from "zustand";
import { detectPref, saveTheme, type ThemePref } from "./lib/theme";

type Page = "dashboard" | "wrapped" | "applications" | "recs" | "settings" | "debug";

interface AppStore {
  page: Page;
  period: "today" | "week" | "month";
  trackerState: string;
  onboarded: boolean;
  theme: ThemePref;
  setPage: (p: Page) => void;
  setPeriod: (p: AppStore["period"]) => void;
  setTrackerState: (s: string) => void;
  setOnboarded: (v: boolean) => void;
  setTheme: (t: ThemePref) => void;
}

export const useAppStore = create<AppStore>((set) => ({
  page: "dashboard",
  period: "today",
  trackerState: "active",
  onboarded: typeof localStorage !== "undefined" && localStorage.getItem("dw_onboarded") === "1",
  theme: typeof document !== "undefined" ? detectPref() : "system",
  setPage: (p) => set({ page: p }),
  setPeriod: (p) => set({ period: p }),
  setTrackerState: (s) => set({ trackerState: s }),
  setOnboarded: (v) => {
    try {
      if (v) localStorage.setItem("dw_onboarded", "1");
      else localStorage.removeItem("dw_onboarded");
    } catch {
      /* ignore */
    }
    void import("./lib/api").then(({ api }) => api.setOnboarded(v).catch(() => {}));
    set({ onboarded: v });
  },
  setTheme: (t) => {
    saveTheme(t);
    set({ theme: t });
  },
}));

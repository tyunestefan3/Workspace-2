import { useEffect, useRef, useState } from "react";
import { flushSync } from "react-dom";
import { useAppStore } from "./store";
import { applyTheme, type Theme, type ThemePref } from "./lib/theme";
import { ThemeReveal } from "./components/ThemeReveal";
import { api } from "./lib/api";
import { Dashboard } from "./pages/Dashboard";
import { Wrapped } from "./pages/Wrapped";
import { Applications } from "./pages/Applications";
import { Settings } from "./pages/Settings";
import { Debug } from "./pages/Debug";
import { Recommendations } from "./pages/Recommendations";
import { Onboarding } from "./pages/Onboarding";
import { stateKey, useI18n, type MsgKey } from "./i18n";

const SECTIONS: { id: "dashboard" | "wrapped" | "applications" | "recs" | "settings" | "debug"; label: MsgKey }[] = [
  { id: "dashboard", label: "nav.dashboard" },
  { id: "wrapped", label: "nav.wrapped" },
  { id: "applications", label: "nav.applications" },
  { id: "recs", label: "nav.recs" },
  { id: "settings", label: "nav.settings" },
  { id: "debug", label: "nav.debug" },
];

export default function App() {
  const { page, setPage, trackerState, setTrackerState, onboarded, setOnboarded, theme, setTheme } = useAppStore();
  const { t } = useI18n();
  const [menu, setMenu] = useState(false);
  const [sheetMounted, setSheetMounted] = useState(false);
  const [sheetIn, setSheetIn] = useState(false);
  const menuRef = useRef(false);
  menuRef.current = menu;
  const [burst, setBurst] = useState<{
    theme: Theme;
    pref: ThemePref;
    from: Theme;
    x: number;
    y: number;
  } | null>(null);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    if (theme !== "system") return;
    const mq = window.matchMedia("(prefers-color-scheme: light)");
    const onChange = () => applyTheme("system");
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, [theme]);

  useEffect(() => {
    const onBurst = (e: Event) => {
      const d = (e as CustomEvent).detail as {
        theme: Theme;
        pref: ThemePref;
        from: Theme;
        x: number;
        y: number;
      };
      setBurst(d);
    };
    window.addEventListener("dw-theme", onBurst);
    return () => window.removeEventListener("dw-theme", onBurst);
  }, []);

  useEffect(() => {
    const refresh = () => api.getTrackerState().then(setTrackerState).catch(() => {});
    refresh();
    const timer = setInterval(refresh, 5000);
    return () => clearInterval(timer);
  }, [setTrackerState]);

  useEffect(() => {
    api.getOnboarded().then((done) => {
      if (done) setOnboarded(true);
    }).catch(() => {});
  }, [setOnboarded]);

  useEffect(() => {
    if (!menu) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenu(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menu]);

  useEffect(() => {
    if (menu) {
      setSheetMounted(true);
      return;
    }
    setSheetIn(false);
  }, [menu]);

  useEffect(() => {
    if (!sheetMounted || !menu) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setSheetIn(true);
      return;
    }
    let inner = 0;
    const outer = requestAnimationFrame(() => {
      inner = requestAnimationFrame(() => {
        if (menuRef.current) setSheetIn(true);
      });
    });
    return () => {
      cancelAnimationFrame(outer);
      cancelAnimationFrame(inner);
    };
  }, [sheetMounted, menu]);

  useEffect(() => {
    if (menu || !sheetMounted) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const t = window.setTimeout(() => setSheetMounted(false), reduce ? 0 : 520);
    return () => clearTimeout(t);
  }, [menu, sheetMounted]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && (e.key === "q" || e.key === "Q")) {
        e.preventDefault();
        e.stopPropagation();
        void api.hideToTray();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, []);

  const stateLabel = (() => {
    const key = stateKey(trackerState);
    return key ? t(key) : trackerState;
  })();

  const go = (id: (typeof SECTIONS)[number]["id"]) => {
    setPage(id);
    setMenu(false);
  };

  return (
    <div className={`app${menu ? " menu-lock" : ""}`}>
      {burst && (
        <ThemeReveal
          x={burst.x}
          y={burst.y}
          from={burst.from}
          to={burst.theme}
          onCovered={() => {
            flushSync(() => setTheme(burst.pref));
          }}
          onDone={() => setBurst(null)}
        />
      )}
      {!onboarded ? (
        <main className="main onb-main">
          <Onboarding onDone={() => setOnboarded(true)} />
        </main>
      ) : (
        <>
          <header className="top">
            <span className="brand">
              <img src="/icon.png" width={28} height={28} alt="" />
              <span>DskWrap</span>
            </span>
            <div className="spacer" />
            <span className={`pulse is-${trackerState}`} title={stateLabel} />
            <button
              className={`burger ${menu ? "open" : ""}`}
              aria-label={t("nav.menu")}
              aria-expanded={menu}
              onClick={() => setMenu((v) => !v)}
            >
              <span />
              <span />
              <span />
            </button>
          </header>

          {sheetMounted && (
            <div className={`sheet${sheetIn ? " in" : ""}`} role="dialog" aria-label={t("nav.menu")}>
              <button className="sheet-dim" aria-label={t("nav.close")} onClick={() => setMenu(false)} />
              <aside className="sheet-panel">
                <div className="sheet-head">
                  <img src="/icon.png" width={40} height={40} alt="" />
                  <div>
                    <div className="sheet-name">DskWrap</div>
                    <div className="sheet-line">{t("dashboard.subtitle")}</div>
                  </div>
                  <button className="x" aria-label={t("nav.close")} onClick={() => setMenu(false)}>
                    ×
                  </button>
                </div>
                <nav className="sheet-nav">
                  {SECTIONS.map((s, i) => (
                    <div key={s.id}>
                      {i === 4 && <div className="sheet-rule" />}
                      <button className={page === s.id ? "on" : ""} onClick={() => go(s.id)}>
                        {t(s.label)}
                      </button>
                    </div>
                  ))}
                </nav>
              </aside>
            </div>
          )}

          <main className="main">
            {page === "dashboard" && <Dashboard />}
            {page === "wrapped" && <Wrapped />}
            {page === "applications" && <Applications />}
            {page === "settings" && <Settings />}
            {page === "recs" && <Recommendations />}
            {page === "debug" && <Debug />}
          </main>
        </>
      )}
    </div>
  );
}

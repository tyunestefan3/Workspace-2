import { LOCALES } from "./types";
import { useI18n } from "./index";

export function LanguagePills({ compact = false }: { compact?: boolean }) {
  const { locale, setLocale, t } = useI18n();
  return (
    <div className={`lang-pills ${compact ? "compact" : ""}`} role="group" aria-label={t("onb.chooseLanguage")}>
      {LOCALES.map((l) => (
        <button
          key={l.id}
          type="button"
          className={locale === l.id ? "active" : ""}
          onClick={() => setLocale(l.id)}
        >
          {l.native}
        </button>
      ))}
    </div>
  );
}

export function LanguageSelect() {
  const { locale, setLocale, t } = useI18n();
  return (
    <select
      className="nav-lang"
      value={locale}
      aria-label={t("settings.language")}
      onChange={(e) => setLocale(e.target.value as typeof locale)}
    >
      {LOCALES.map((l) => (
        <option key={l.id} value={l.id}>
          {l.native}
        </option>
      ))}
    </select>
  );
}

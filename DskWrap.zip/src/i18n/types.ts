import type { en } from "./en";

export type MsgKey = keyof typeof en;
export type Locale = "en" | "ru" | "es" | "zh" | "fr";

export type TFn = (key: MsgKey, vars?: Record<string, string | number>) => string;

export const LOCALES: { id: Locale; native: string }[] = [
  { id: "en", native: "English" },
  { id: "ru", native: "Русский" },
  { id: "es", native: "Español" },
  { id: "zh", native: "中文" },
  { id: "fr", native: "Français" },
];

export const BCP47: Record<Locale, string> = {
  en: "en",
  ru: "ru-RU",
  es: "es",
  zh: "zh-CN",
  fr: "fr-FR",
};

export function isLocale(v: string): v is Locale {
  return v === "en" || v === "ru" || v === "es" || v === "zh" || v === "fr";
}

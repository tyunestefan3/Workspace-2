import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api } from "../lib/api";
import { en } from "./en";
import { es } from "./es";
import { fr } from "./fr";
import { ru } from "./ru";
import { zh } from "./zh";
import { BCP47, LOCALES, isLocale, type Locale, type MsgKey, type TFn } from "./types";

export { BCP47, LOCALES, isLocale };
export type { Locale, MsgKey, TFn };

const TABLES: Record<Locale, Record<MsgKey, string>> = { en, ru, es, zh, fr };

const STORAGE_KEY = "dw_locale";

export function detectLocale(): Locale {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && isLocale(saved)) return saved;
  } catch {
    /* ignore */
  }
  const nav = (typeof navigator !== "undefined" ? navigator.language : "en").toLowerCase();
  if (nav.startsWith("ru")) return "ru";
  if (nav.startsWith("es")) return "es";
  if (nav.startsWith("zh")) return "zh";
  if (nav.startsWith("fr")) return "fr";
  return "en";
}

export function applyHtmlLang(locale: Locale) {
  if (typeof document === "undefined") return;
  document.documentElement.lang = BCP47[locale];
}

function interpolate(template: string, vars?: Record<string, string | number>): string {
  if (!vars) return template;
  let out = template;
  for (const [k, v] of Object.entries(vars)) {
    out = out.split(`{${k}}`).join(String(v));
  }
  return out;
}

interface I18nValue {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: TFn;
}

const I18nContext = createContext<I18nValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(detectLocale);

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next);
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      /* ignore */
    }
    applyHtmlLang(next);
    api.setLocale(next).catch(() => {});
  }, []);

  useEffect(() => {
    applyHtmlLang(locale);
    api.setLocale(locale).catch(() => {});
  }, [locale]);

  const t = useCallback<TFn>(
    (key, vars) => interpolate(TABLES[locale][key] ?? TABLES.en[key] ?? key, vars),
    [locale],
  );

  const value = useMemo(() => ({ locale, setLocale, t }), [locale, setLocale, t]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used inside I18nProvider");
  return ctx;
}

export function categoryKey(cat: string): MsgKey {
  switch (cat) {
    case "focus":
      return "cat.focus";
    case "communication":
      return "cat.communication";
    case "entertainment":
      return "cat.entertainment";
    case "utility":
      return "cat.utility";
    case "ignored":
      return "cat.ignored";
    default:
      return "cat.neutral";
  }
}

export function stateKey(state: string): MsgKey | null {
  switch (state) {
    case "active":
      return "state.active";
    case "idle":
      return "state.idle";
    case "sleeping":
      return "state.sleeping";
    case "paused":
      return "state.paused";
    case "private":
      return "state.private";
    default:
      return null;
  }
}

export function personalityKey(kind: string): MsgKey {
  switch (kind) {
    case "DeepDiver":
      return "personality.DeepDiver";
    case "ContextSwitcher":
      return "personality.ContextSwitcher";
    case "NightOwl":
      return "personality.NightOwl";
    case "Builder":
      return "personality.Builder";
    case "Messenger":
      return "personality.Messenger";
    default:
      return "personality.Balanced";
  }
}

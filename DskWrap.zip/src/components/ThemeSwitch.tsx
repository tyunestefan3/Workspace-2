import { useRef, useState } from "react";
import { useI18n } from "../i18n";
import { resolveTheme, type ThemePref } from "../lib/theme";
import { useAppStore } from "../store";

const OPTIONS: ThemePref[] = ["system", "light", "dark"];

export function ThemeSwitch() {
  const { t } = useI18n();
  const theme = useAppStore((s) => s.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const [flash, setFlash] = useState<ThemePref | null>(null);
  const lock = useRef(false);
  const systemRef = useRef<HTMLButtonElement>(null);
  const lightRef = useRef<HTMLButtonElement>(null);
  const darkRef = useRef<HTMLButtonElement>(null);
  const refs = { system: systemRef, light: lightRef, dark: darkRef };

  const pick = (next: ThemePref) => {
    if (next === theme || lock.current) return;
    const el = refs[next].current;
    const box = el?.getBoundingClientRect();
    const x = box ? box.left + box.width / 2 : window.innerWidth / 2;
    const y = box ? box.top + box.height / 2 : window.innerHeight / 2;
    const visualNow = resolveTheme(theme);
    const visualNext = resolveTheme(next);
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (visualNow === visualNext || reduce) {
      setTheme(next);
      setFlash(next);
      window.setTimeout(() => setFlash(null), 700);
      return;
    }

    lock.current = true;
    setFlash(next);
    window.dispatchEvent(
      new CustomEvent("dw-theme", {
        detail: { theme: visualNext, pref: next, from: visualNow, x, y },
      }),
    );
    window.setTimeout(() => {
      lock.current = false;
      setFlash(null);
    }, 320);
  };

  const label = (id: ThemePref) =>
    id === "system" ? t("settings.themeSystem") : id === "light" ? t("settings.themeLight") : t("settings.themeDark");

  return (
    <div className="theme-cards">
      {OPTIONS.map((id) => (
        <button
          key={id}
          ref={refs[id]}
          type="button"
          className={`theme-card ${theme === id ? "on" : ""} ${flash === id ? "play" : ""}`}
          onClick={() => pick(id)}
        >
          <span className="theme-glyph">{id === "system" ? <SystemIcon /> : id === "light" ? <SunIcon /> : <MoonIcon />}</span>
          <span className="theme-card-label">{label(id)}</span>
        </button>
      ))}
    </div>
  );
}

function MoonIcon() {
  return (
    <svg viewBox="0 0 48 48" width="40" height="40" aria-hidden>
      <path fill="currentColor" d="M30.4 8.6a16.6 16.6 0 1 1-17.8 24.6 13.6 13.6 0 0 0 17.8-24.6z" />
    </svg>
  );
}

function SunIcon() {
  const angles = [0, 45, 90, 135, 180, 225, 270, 315];
  return (
    <svg viewBox="0 0 48 48" width="40" height="40" aria-hidden className="sun-svg">
      <circle cx="24" cy="24" r="8.4" fill="currentColor" />
      {angles.map((a) => (
        <g key={a} transform={`rotate(${a} 24 24)`}>
          <line className="sun-ray" x1="24" y1="13.6" x2="24" y2="5.2" />
        </g>
      ))}
    </svg>
  );
}

function SystemIcon() {
  return (
    <svg viewBox="0 0 48 48" width="40" height="40" aria-hidden>
      <circle cx="24" cy="24" r="14" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <path fill="currentColor" d="M24 10a14 14 0 0 0 0 28z" />
    </svg>
  );
}

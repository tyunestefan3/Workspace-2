import { useEffect, useRef } from "react";
import type { Theme } from "../lib/theme";

export function ThemeReveal({
  x,
  y,
  from,
  onCovered,
  onDone,
}: {
  x: number;
  y: number;
  from: Theme;
  to: Theme;
  onCovered: () => void;
  onDone: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const covered = useRef(onCovered);
  const done = useRef(onDone);
  covered.current = onCovered;
  done.current = onDone;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const root = document.documentElement;
    root.classList.add("theme-animating");

    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      el.style.opacity = "0";
      root.classList.remove("theme-animating");
      done.current();
    };

    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      covered.current();
      close();
      return;
    }

    // New settings paint under this overlay of the *old* colour.
    covered.current();

    const w = window.innerWidth;
    const h = window.innerHeight;
    const maxR = Math.hypot(Math.max(x, w - x), Math.max(y, h - y)) + 8;
    const setHole = (rad: number) => {
      const g = `radial-gradient(circle at ${x}px ${y}px, transparent ${rad}px, #000 ${rad}px)`;
      el.style.setProperty("-webkit-mask-image", g);
      el.style.setProperty("mask-image", g);
    };
    setHole(0);

    const duration = 220;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / duration);
      const e = 1 - (1 - t) * (1 - t) * (1 - t);
      setHole(e * maxR);
      if (t < 1) raf = requestAnimationFrame(tick);
      else close();
    };
    raf = requestAnimationFrame(tick);
    const watchdog = window.setTimeout(close, duration + 80);

    return () => {
      window.clearTimeout(watchdog);
      cancelAnimationFrame(raf);
      root.classList.remove("theme-animating");
    };
  }, [x, y, from]);

  return <div ref={ref} className={`theme-burst from-${from}`} aria-hidden />;
}

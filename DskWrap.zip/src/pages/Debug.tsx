import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { isPreview } from "../lib/env";
import { fmtDateTime, fmtDuration } from "../lib/format";
import { mock } from "../lib/mock";
import { useI18n } from "../i18n";
import { useAppStore } from "../store";
import type { DebugInfo } from "../types";

export function Debug() {
  const { t, locale } = useI18n();
  const setTrackerState = useAppStore((s) => s.setTrackerState);
  const [info, setInfo] = useState<DebugInfo | null>(null);
  const [msg, setMsg] = useState("");
  const [raw, setRaw] = useState<string | null>(null);

  const load = () => api.getDebug().then(setInfo).catch(() => {});

  useEffect(() => {
    load();
    const timer = setInterval(load, 3000);
    return () => clearInterval(timer);
  }, []);

  const simulate = async (s: string) => {
    await api.simulateState(s);
    setTrackerState(s);
    setMsg(t("debug.simulated"));
    load();
  };

  return (
    <div className="container">
      <h1>{t("debug.title")}</h1>
      <p className="subtitle">{t("debug.subtitle")}</p>

      <div className="grid cols-2">
        <div className="panel">
          <h3>{t("debug.tracker")}</h3>
          <div className={`debug-status ${info == null ? "" : info.working ? "on" : "off"}`}>
            <span className="dot" />
            <span>{info == null ? "—" : info.working ? t("debug.running") : t("debug.stopped")}</span>
          </div>
          <Row label={t("debug.state")} value={info == null ? "—" : info.working ? t("debug.inWork") : t("debug.off")} />
          <Row label={t("debug.currentApp")} value="DskWrap" />
        </div>

        <div className="panel">
          <h3>{t("debug.todayTitle")}</h3>
          <Row label={t("debug.trackedToday")} value={fmtDuration(info?.tracked_today_ms ?? 0, locale)} />
          <Row label={t("debug.switchesToday")} value={String(info?.switches_today ?? 0)} />
          <Row label={t("debug.checksToday")} value={String(info?.checks_today ?? 0)} />
          <Row label={t("debug.quickToday")} value={String(info?.quick_visits_today ?? 0)} />
        </div>

        <div className="panel debug-log">
          <h3>{t("debug.data")}</h3>
          <div className="row" style={{ marginBottom: 10 }}>
            <button
              className="btn ghost sm"
              onClick={() =>
                api.exportJson().then((s) => {
                  setRaw(s);
                })
              }
            >
              {t("debug.showRaw")}
            </button>
            {isPreview() && (
              <>
                <button
                  className="btn ghost sm"
                  onClick={async () => {
                    await api.generateWeek();
                    setTrackerState("active");
                    setMsg(t("debug.generated"));
                    load();
                  }}
                >
                  {t("debug.generateWeek")}
                </button>
                <button className="btn ghost sm" onClick={() => simulate("idle")}>
                  {t("debug.simulateIdle")}
                </button>
                <button className="btn ghost sm" onClick={() => simulate("sleeping")}>
                  {t("debug.simulateSleep")}
                </button>
                <button className="btn ghost sm" onClick={() => simulate("active")}>
                  {t("debug.simulateActive")}
                </button>
              </>
            )}
          </div>
          <p className="muted" style={{ fontSize: 13 }}>
            {t("debug.hint")}
          </p>
          {msg && <p className="muted">{msg}</p>}
        </div>
      </div>

      {isPreview() && (
        <>
          <hr />
          <h2>{t("debug.events")}</h2>
          <div className="panel">
            <table className="events">
              <thead>
                <tr>
                  <th>time</th>
                  <th>type</th>
                  <th>app</th>
                </tr>
              </thead>
              <tbody>
                {mock.sampleEvents().map((e, i) => (
                  <tr key={i}>
                    <td>{fmtDateTime(e.timestamp_ms, locale)}</td>
                    <td>{e.event_type}</td>
                    <td>{e.bundle_id ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {raw && (
        <>
          <hr />
          <pre className="raw">{raw}</pre>
        </>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="app-row" style={{ padding: "8px 10px" }}>
      <span className="name" style={{ fontWeight: 400 }}>
        {label}
      </span>
      <span className="dur">{value}</span>
    </div>
  );
}

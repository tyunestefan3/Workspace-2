import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/api";
import { categoryKey, useI18n } from "../i18n";
import type { AppRecord } from "../types";
import { prettyName } from "../lib/names";
import { useReveal } from "../lib/reveal";
import { Avatar } from "./Dashboard";

const CATEGORIES = ["focus", "communication", "entertainment", "utility", "neutral", "ignored"] as const;

export function Applications() {
  const { t } = useI18n();
  const [apps, setApps] = useState<AppRecord[]>([]);
  const [q, setQ] = useState("");

  const load = () => api.getApplications().then(setApps).catch(() => {});
  useEffect(() => {
    load();
    const id = setInterval(load, 12_000);
    return () => clearInterval(id);
  }, []);

  useReveal(apps.length);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return apps;
    return apps.filter(
      (a) => a.display_name.toLowerCase().includes(s) || a.bundle_id.toLowerCase().includes(s),
    );
  }, [apps, q]);

  const setCategory = async (bundleId: string, category: string) => {
    await api.setAppCategory(bundleId, category);
    load();
  };
  const setIgnored = async (bundleId: string, ignored: boolean) => {
    await api.setAppIgnored(bundleId, ignored);
    load();
  };
  const deleteHistory = async (bundleId: string) => {
    if (confirm(t("apps.confirmDelete", { bundle: prettyName(bundleId) }))) {
      await api.deleteAppHistory(bundleId);
      load();
    }
  };

  return (
    <div className="container">
      <div className="rise">
        <h1>{t("apps.title")}</h1>
        <p className="subtitle">{t("apps.subtitle")}</p>
        <input
          className="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t("apps.search")}
        />
      </div>

      <div className="panel rise" style={{ marginTop: 14 }}>
        {filtered.map((a) => (
          <div className={`app-row ${a.ignored ? "dim" : ""}`} key={a.bundle_id}>
            <Avatar name={prettyName(a.bundle_id, a.display_name)} cat={a.category} />
            <div className="grow">
              <div className="name">{prettyName(a.bundle_id, a.display_name)}</div>
            </div>
            <select
              value={a.category}
              onChange={(e) => setCategory(a.bundle_id, e.target.value)}
              className="select"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {t(categoryKey(c))}
                </option>
              ))}
            </select>
            <label className="check">
              <input
                type="checkbox"
                checked={a.ignored}
                onChange={(e) => setIgnored(a.bundle_id, e.target.checked)}
              />
              {t("apps.ignore")}
            </label>
            <button className="btn ghost sm" onClick={() => deleteHistory(a.bundle_id)}>
              {t("apps.delHistory")}
            </button>
          </div>
        ))}
        {apps.length === 0 && <p className="muted">{t("apps.empty")}</p>}
        {apps.length > 0 && filtered.length === 0 && <p className="muted">{t("apps.noneMatch")}</p>}
      </div>
    </div>
  );
}

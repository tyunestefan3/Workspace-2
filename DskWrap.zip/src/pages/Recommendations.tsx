import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/api";
import { recommend } from "../lib/recs";
import { appName as mockName } from "../lib/mock";
import { prettyName } from "../lib/names";
import { useI18n } from "../i18n";
import { useReveal } from "../lib/reveal";
import type { AppRecord, PeriodMetrics } from "../types";

export function Recommendations() {
  const { t, locale } = useI18n();
  const [period, setPeriod] = useState<"today" | "week">("week");
  const [m, setM] = useState<PeriodMetrics | null>(null);
  const [apps, setApps] = useState<AppRecord[]>([]);

  useEffect(() => {
    const load = () => api.getDashboard(period).then(setM).catch(() => {});
    load();
    const id = setInterval(load, 12_000);
    return () => clearInterval(id);
  }, [period]);
  useEffect(() => {
    api.getApplications().then(setApps).catch(() => {});
  }, []);

  const nameOf = (id: string) =>
    prettyName(id, apps.find((a) => a.bundle_id === id)?.display_name ?? mockName(id));
  const recs = useMemo(() => (m ? recommend(m, t, nameOf, period, locale) : []), [m, t, apps, period, locale]);

  useReveal(`${period}-${recs.length}`);

  return (
    <div className="container">
      <div className="rise">
        <h1>{t("rec.title")}</h1>
        <p className="subtitle">{t("rec.subtitle")}</p>
        <div className="row" style={{ marginBottom: 18 }}>
          {(["today", "week"] as const).map((p) => (
            <button key={p} className={`btn ghost sm ${period === p ? "selected" : ""}`} onClick={() => setPeriod(p)}>
              {t(p === "today" ? "dashboard.today" : "dashboard.week")}
            </button>
          ))}
        </div>
      </div>
      {recs.length === 0 && <p className="muted rise">{t("rec.empty")}</p>}
      <div className="recs">
        {recs.map((r, i) => (
          <article className="rec rise" key={r.id}>
            <div className="rec-n">{String(i + 1).padStart(2, "0")}</div>
            <h2 className="rec-h">{r.title}</h2>
            <div className="rec-k">{t("rec.why")}</div>
            <p>{r.why}</p>
            <div className="rec-k">{t("rec.do")}</div>
            <p className="rec-next">{r.next}</p>
          </article>
        ))}
      </div>
    </div>
  );
}

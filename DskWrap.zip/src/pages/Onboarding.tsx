import { useState } from "react";
import { api } from "../lib/api";
import { LanguagePills } from "../i18n/LanguageSwitch";
import { useI18n } from "../i18n";

export function Onboarding({ onDone }: { onDone: () => void }) {
  const { t } = useI18n();
  const [step, setStep] = useState(0);
  const [launchAtStart, setLaunchAtStart] = useState(true);
  const [ask, setAsk] = useState(false);

  const finish = (launch: boolean) => {
    setLaunchAtStart(launch);
    void api.setLaunchAtStart(launch);
    onDone();
  };

  const isLast = step === 2;

  return (
    <div className="onb">
      <img className="mark" src="/icon.png" width="88" height="88" alt="DskWrap" />
      <div className="onb-name">DskWrap</div>
      {step === 0 && (
        <div className="onb-langs">
          <LanguagePills />
        </div>
      )}

      <div className="onb-body">
        {step === 0 && (
          <>
            <div className="onb-title">{t("onb.step1.big")}</div>
            <p className="muted onb-lead">{t("onb.step1.text")}</p>
          </>
        )}
        {step === 1 && (
          <>
            <div className="kicker">{t("onb.step2.kicker")}</div>
            <div className="onb-title">{t("onb.step2.big")}</div>
            <p className="muted onb-lead">{t("onb.step2.text")}</p>
          </>
        )}
        {step === 2 && (
          <>
            <div className="kicker">{t("onb.step3.kicker")}</div>
            <div className="seegrid">
              <div className="seecol">
                <div className="colh">{t("onb.unsees")}</div>
                <div className="no">{t("onb.norecord.screen")}</div>
                <div className="no">{t("onb.norecord.keys")}</div>
                <div className="no">{t("onb.norecord.urls")}</div>
              </div>
              <div className="seecol">
                <div className="colh">{t("onb.sees")}</div>
                <div className="yes">{t("onb.record.whichApp")}</div>
                <div className="yes">{t("onb.record.whenSwitch")}</div>
                <div className="yes">{t("onb.record.howLong")}</div>
              </div>
            </div>
            <label className="launch-line">
              <input
                type="checkbox"
                checked={launchAtStart}
                onChange={(e) => setLaunchAtStart(e.target.checked)}
              />
              {t("onb.launchAtLogin")}
            </label>
          </>
        )}
      </div>

      <div className="row onb-actions">
        {!isLast ? (
          <button className="btn onb-btn" onClick={() => setStep((n) => n + 1)}>
            {t("onb.next")}
          </button>
        ) : (
          <button className="btn onb-btn" onClick={() => finish(launchAtStart)}>
            {t("onb.start")}
          </button>
        )}
        <button className="btn ghost onb-btn" onClick={() => setAsk(true)}>
          {t("onb.skip")}
        </button>
      </div>
      <div className="onb-step">
        {t("onb.stepOf", { n: step + 1, total: 3 })}
      </div>

      {ask && (
        <div className="modal">
          <div className="modal-box">
            <div style={{ fontSize: 22, fontWeight: 600 }}>{t("onb.askLogin")}</div>
            <p className="muted" style={{ margin: "12px 0 22px" }}>
              {t("onb.askLoginText")}
            </p>
            <div className="row" style={{ justifyContent: "center" }}>
              <button className="btn" onClick={() => finish(true)}>
                {t("onb.yes")}
              </button>
              <button className="btn ghost" onClick={() => finish(false)}>
                {t("onb.no")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

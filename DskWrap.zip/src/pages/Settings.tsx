import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { LanguagePills } from "../i18n/LanguageSwitch";
import { useI18n } from "../i18n";
import { useReveal } from "../lib/reveal";
import { useAppStore } from "../store";
import { ThemeSwitch } from "../components/ThemeSwitch";

function download(name: string, content: string, mime = "application/octet-stream") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function Settings() {
  const { t } = useI18n();
  const { trackerState, setTrackerState } = useAppStore();
  const [msg, setMsg] = useState("");
  const [launch, setLaunch] = useState(false);
  const paused = trackerState === "paused";

  useReveal("settings");

  useEffect(() => {
    api.getLaunchAtStart().then(setLaunch).catch(() => {});
  }, []);

  const notify = (s: string) => setMsg(s);

  const pause = async (ms?: number) => {
    await api.pause(ms);
    setTrackerState("paused");
    notify(t("settings.paused"));
  };
  const resume = async () => {
    await api.resume();
    setTrackerState("active");
    notify(t("settings.resumed"));
  };

  const toggleLaunch = async (on: boolean) => {
    await api.setLaunchAtStart(on);
    setLaunch(on);
  };

  const exportJson = async () => {
    const s = await api.exportJson();
    download("dskwrap.json", s, "application/json");
    notify(t("settings.exportedJson"));
  };
  const exportCsv = async () => {
    const s = await api.exportCsv();
    download("dskwrap-events.csv", s, "text/csv");
    notify(t("settings.exportedCsv"));
  };
  const deleteAll = async () => {
    if (confirm(t("settings.confirmDeleteAll"))) {
      await api.deleteAllTracking();
      notify(t("settings.deleted"));
    }
  };
  return (
    <div className="container">
      <div className="rise">
        <h1>{t("settings.title")}</h1>
        <p className="subtitle">{t("settings.subtitle")}</p>
      </div>

      <div className="panel theme-panel rise" data-delay="40">
        <h3>{t("settings.appearance")}</h3>
        <ThemeSwitch />
      </div>

      <div className="grid cols-2 rise" data-delay="80">
        <div className="panel">
          <h3>{t("settings.language")}</h3>
          <LanguagePills />
          <p className="hint">{t("settings.languageHint")}</p>
        </div>

        <div className="panel">
          <h3>{t("settings.tracking")}</h3>
          <div className="row" style={{ marginBottom: 10 }}>
            {paused ? (
              <button className="btn" onClick={resume}>
                {t("settings.resume")}
              </button>
            ) : (
              <>
                <button className="btn ghost" onClick={() => pause(15 * 60_000)}>
                  {t("settings.pause15")}
                </button>
                <button className="btn ghost" onClick={() => pause(60 * 60_000)}>
                  {t("settings.pause1h")}
                </button>
                <button className="btn danger" onClick={() => pause()}>
                  {t("settings.pauseForever")}
                </button>
              </>
            )}
          </div>
          <p className="hint" style={{ margin: 0 }}>
            {t("settings.idleHint")}
          </p>
        </div>

        <div className="panel">
          <h3>{t("settings.startup")}</h3>
          <label className="check launch-check">
            <input type="checkbox" checked={launch} onChange={(e) => toggleLaunch(e.target.checked)} />
            {t("settings.launchAtStart")}
          </label>
          <p className="hint" style={{ marginTop: 8 }}>
            {t("settings.launchAtStartHint")}
          </p>
          <p className="hint" style={{ marginTop: 12 }}>
            {t("settings.stopOnQuitHint")}
          </p>
        </div>

        <div className="panel">
          <h3>{t("settings.privacy")}</h3>
          <div className="row" style={{ marginBottom: 8 }}>
            <button className="btn ghost sm" onClick={exportJson}>
              {t("settings.exportJson")}
            </button>
            <button className="btn ghost sm" onClick={exportCsv}>
              {t("settings.exportCsv")}
            </button>
          </div>
          <button className="btn danger" onClick={deleteAll}>
            {t("settings.deleteAll")}
          </button>
          <p className="hint">{t("settings.privacyNote")}</p>
        </div>
      </div>

      {msg && (
        <p className="muted" style={{ marginTop: 14 }}>
          {msg}
        </p>
      )}
    </div>
  );
}

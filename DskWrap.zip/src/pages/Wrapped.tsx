import { useEffect, useRef, useState } from "react";
import { api } from "../lib/api";
import { fmtDuration } from "../lib/format";
import { prettyName } from "../lib/names";
import { fmtGlances, fmtSwitches } from "../lib/grammar";
import { personalityKey, useI18n, type Locale, type TFn } from "../i18n";
import { useReveal } from "../lib/reveal";
import { useHorizontalSwipe } from "../lib/swipe";
import type { WeeklyWrapped, WrappedCard } from "../types";

export function Wrapped() {
  const { t, locale } = useI18n();
  const [data, setData] = useState<WeeklyWrapped | null>(null);
  const [idx, setIdx] = useState(0);
  const [motion, setMotion] = useState<{ dir: 1 | -1; from: number } | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const idxRef = useRef(0);
  const lastTurn = useRef(0);
  const clearMotion = useRef(0);
  idxRef.current = idx;

  useEffect(() => {
    api.getWeeklyWrapped("week").then(setData).catch(() => {});
  }, []);

  const goTo = (next: number) => {
    const cards = data?.cards;
    if (!cards?.length) return;
    const dest = Math.max(0, Math.min(cards.length - 1, next));
    const cur = idxRef.current;
    if (dest === cur) return;
    const now = performance.now();
    const fast = now - lastTurn.current < 240;
    lastTurn.current = now;
    window.clearTimeout(clearMotion.current);
    if (fast) {
      setMotion(null);
    } else {
      setMotion({ dir: dest > cur ? 1 : -1, from: cur });
      clearMotion.current = window.setTimeout(() => setMotion(null), 680);
    }
    idxRef.current = dest;
    setIdx(dest);
  };
  const goToRef = useRef(goTo);
  goToRef.current = goTo;

  useHorizontalSwipe(stageRef, (data?.cards.length ?? 0) > 1, (dir) => {
    goToRef.current(idxRef.current + dir);
  });

  useEffect(() => {
    if (!data) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") goToRef.current(idxRef.current + 1);
      if (e.key === "ArrowLeft") goToRef.current(idxRef.current - 1);
    };
    window.addEventListener("keydown", onKey);

    const stage = stageRef.current;
    if (!stage) return () => window.removeEventListener("keydown", onKey);

    let x0: number | null = null;
    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType !== "mouse" || e.button !== 0) return;
      x0 = e.clientX;
    };
    const onPointerUp = (e: PointerEvent) => {
      if (x0 == null) return;
      const dx = e.clientX - x0;
      x0 = null;
      if (Math.abs(dx) < 72) return;
      goToRef.current(idxRef.current + (dx < 0 ? 1 : -1));
    };
    const onPointerCancel = () => {
      x0 = null;
    };

    stage.addEventListener("pointerdown", onPointerDown);
    stage.addEventListener("pointerup", onPointerUp);
    stage.addEventListener("pointercancel", onPointerCancel);
    return () => {
      window.removeEventListener("keydown", onKey);
      stage.removeEventListener("pointerdown", onPointerDown);
      stage.removeEventListener("pointerup", onPointerUp);
      stage.removeEventListener("pointercancel", onPointerCancel);
    };
  }, [data]);

  useReveal(data?.cards.length ?? 0);

  if (!data) {
    return (
      <div className="container">
        <p className="muted">{t("wrapped.loading")}</p>
      </div>
    );
  }

  if (!data.cards.length || data.tracked_ms <= 0) {
    return (
      <div className="container">
        <h1>{t("wrapped.title")}</h1>
        <p className="subtitle">{t("wrapped.empty")}</p>
      </div>
    );
  }

  const card = data.cards[Math.min(idx, data.cards.length - 1)];
  const personality = t(personalityKey(data.personality));

  return (
    <div className="container wrap-page">
      <div className="wrap-hero" ref={stageRef}>
        <div className="wrap-hero-head">
          <h1>{t("wrapped.title")}</h1>
          <p className="subtitle">
            {t("wrapped.subtitle", { duration: fmtDuration(data.tracked_ms, locale), personality })}
          </p>
        </div>
        <div className="wrap-frame">
          {motion && data.cards[motion.from] && (
            <div className={`wrap-sheet leave ${motion.dir > 0 ? "to-next" : "to-prev"}`} aria-hidden>
              <div className={`card-preview wrap-card kind-${data.cards[motion.from].kind}`}>
                <CardView card={data.cards[motion.from]} t={t} locale={locale} personality={data.personality} />
              </div>
            </div>
          )}
          <div key={idx} className={`wrap-sheet ${motion ? (motion.dir > 0 ? "enter-next" : "enter-prev") : ""}`}>
            <div className={`card-preview wrap-card kind-${card.kind}`}>
              <CardView card={card} t={t} locale={locale} personality={data.personality} />
            </div>
          </div>
        </div>
        <div className="dots">
          {data.cards.map((c, i) => (
            <button
              key={i}
              className={`dot ${i === idx ? "on" : ""}`}
              onClick={() => goTo(i)}
              aria-label={c.kind}
            />
          ))}
        </div>
        <div className="row wrap-nav">
          <button className="btn ghost" onClick={() => goTo(idx - 1)} disabled={idx === 0}>
            ←
          </button>
          <span className="muted">
            {idx + 1} / {data.cards.length}
          </span>
          <button
            className="btn ghost"
            onClick={() => goTo(idx + 1)}
            disabled={idx >= data.cards.length - 1}
          >
            →
          </button>
        </div>
      </div>

      <section className="block rise">
        <h2>{t("wrapped.allCards")}</h2>
        <div className="grid cols-3">
          {data.cards.map((c, i) => (
            <div
              className={`panel card-thumb ${i === idx ? "on" : ""}`}
              key={i}
              onClick={() => goTo(i)}
            >
              <div className={`card-preview kind-${c.kind}`} style={{ minHeight: 168, padding: 20 }}>
                <CardView card={c} t={t} locale={locale} compact personality={data.personality} />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function CardView({
  card,
  compact,
  t,
  locale,
  personality,
}: {
  card: WrappedCard;
  compact?: boolean;
  t: TFn;
  locale: Locale;
  personality: string;
}) {
  const bigStyle = compact ? { fontSize: 22 } : undefined;
  switch (card.kind) {
    case "your_week":
      return (
        <>
          <div className="kicker">{t("wrapped.yourWeek")}</div>
          <div className="big" style={bigStyle}>
            {fmtDuration(card.tracked_ms, locale)}
          </div>
          <div className="muted">{t("wrapped.tracked")}</div>
        </>
      );
    case "main_character":
      return (
        <>
          <div className="kicker">{t("wrapped.mainCharacter")}</div>
          <div className="big" style={bigStyle}>
            {prettyName(card.bundle_id, card.display_name)}
          </div>
          <div className="muted">{fmtDuration(card.duration_ms, locale)}</div>
        </>
      );
    case "cant_resist":
      return (
        <>
          <div className="kicker">{t("wrapped.cantResist")}</div>
          <div className="big" style={bigStyle}>
            {prettyName(card.bundle_id, card.display_name)}
          </div>
          <div className="muted">{fmtGlances(card.checks, locale)}</div>
        </>
      );
    case "chaos_hour":
      return (
        <>
          <div className="kicker">{t("wrapped.chaosHour")}</div>
          <div className="big" style={bigStyle}>
            {card.label}
          </div>
          <div className="muted">{fmtSwitches(card.switches, locale)}</div>
        </>
      );
    case "deep_dive":
      return (
        <>
          <div className="kicker">{t("wrapped.deepDive")}</div>
          <div className="big" style={bigStyle}>
            {fmtDuration(card.focus_ms, locale)}
          </div>
          <div className="muted">{t("wrapped.longestFocus")}</div>
        </>
      );
    case "your_loop":
      return (
        <>
          <div className="kicker">{t("wrapped.yourLoop")}</div>
          <div className="big" style={compact ? { fontSize: 18 } : undefined}>
            {card.sequence.map((s) => prettyName(s, s)).join(" → ")} ×{card.count}
          </div>
        </>
      );
    case "mac_type":
      return (
        <>
          <div className="kicker">{t("wrapped.macType")}</div>
          <div className="big" style={bigStyle}>
            {t(personalityKey(personality))}
          </div>
        </>
      );
  }
}

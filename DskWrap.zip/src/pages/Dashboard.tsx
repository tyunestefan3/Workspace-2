import { Children, useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { api } from "../lib/api";
import { fmtDateTime, fmtDuration } from "../lib/format";
import { insightsFrom } from "../lib/insights";
import { appName as mockName } from "../lib/mock";
import { prettyName, isJunkApp } from "../lib/names";
import { appInCase, fmtMinutes } from "../lib/grammar";
import { BCP47, categoryKey, useI18n } from "../i18n";
import { useReveal } from "../lib/reveal";
import { useHorizontalSwipe } from "../lib/swipe";
import type { AppRecord, HourBucket, PeriodMetrics } from "../types";

const CAT_ORDER = ["focus", "communication", "entertainment", "utility", "neutral"] as const;
const FOLD = 5;

export function Dashboard() {
  const { t, locale } = useI18n();
  const [period, setPeriod] = useState<"today" | "week" | "month">("today");
  const [m, setM] = useState<PeriodMetrics | null>(null);
  const [apps, setApps] = useState<AppRecord[]>([]);

  useEffect(() => {
    const load = () => api.getDashboard(period).then(setM).catch(() => {});
    load();
    const id = setInterval(load, 12_000);
    return () => clearInterval(id);
  }, [period]);
  useEffect(() => {
    const load = () => api.getApplications().then(setApps).catch(() => {});
    load();
    const id = setInterval(load, 12_000);
    return () => clearInterval(id);
  }, []);

  const nameOf = (id: string) =>
    prettyName(id, apps.find((a) => a.bundle_id === id)?.display_name ?? mockName(id));

  const insights = useMemo(() => (m ? insightsFrom(m, t, nameOf, locale) : []), [m, t, apps, locale]);

  const tracked = m?.tracked_ms ?? 0;

  const appList = useMemo(
    () => (m?.app_durations ?? []).filter(([bundle, , dur]) => !isJunkApp(bundle, nameOf(bundle), dur)),
    [m, apps],
  );
  const recoveryList = useMemo(
    () =>
      Object.entries(m?.recovery.by_distractor ?? {}).sort(
        (a, b) => b[1].count - a[1].count || b[1].total_ms - a[1].total_ms,
      ),
    [m],
  );
  const focusList = useMemo(() => [...(m?.focus_blocks ?? [])].reverse(), [m]);

  useReveal(m ? period : "wait");

  return (
    <div className="container">
      <div className="rise">
        <h1>
          {t(
            period === "today"
              ? "dashboard.today"
              : period === "week"
                ? "dashboard.week"
                : "dashboard.month",
          )}
        </h1>
        <p className="subtitle">{t("dashboard.subtitle")}</p>
        <div className="row" style={{ marginBottom: 18 }}>
          {(["today", "week", "month"] as const).map((p) => (
            <button
              key={p}
              className={`btn ghost sm ${period === p ? "selected" : ""}`}
              onClick={() => setPeriod(p)}
            >
              {t(p === "today" ? "dashboard.today" : p === "week" ? "dashboard.week" : "dashboard.month")}
            </button>
          ))}
        </div>
      </div>

      <div className="grid rise" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))" }} data-delay="40">
        <Stat label={t("dashboard.tracked")} value={fmtDuration(m?.tracked_ms ?? 0, locale)} />
        <Stat label={t("dashboard.focus")} value={fmtDuration(m?.focus_seconds_ms ?? 0, locale)} />
        <Stat label={t("dashboard.switches")} value={String(m?.switches ?? 0)} />
        <Stat label={t("dashboard.checks")} value={String(m?.checks ?? 0)} />
        <Stat label={t("dashboard.quickVisits")} value={String(m?.quick_visits ?? 0)} />
      </div>

      <div className="block rise">
        <div className="pair-board">
          <div className="pair-slot">
            <h2>{t("dashboard.categories")}</h2>
            <div className="panel pair-panel">
              {CAT_ORDER.map((cat) => {
                const ms = m?.category_durations?.[cat] ?? 0;
                const pct = tracked > 0 ? Math.round((ms / tracked) * 100) : 0;
                return (
                  <div className="cat-row" key={cat}>
                    <div className="cat-meta">
                      <span className={`badge ${cat}`}>{t(categoryKey(cat))}</span>
                      <span className="dur">{fmtDuration(ms, locale)}</span>
                    </div>
                    <div className="bar">
                      <div className={`bar-fill ${cat}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="pair-slot">
            <h2>{t("dashboard.topApps")}</h2>
            <RowPager key={`${period}-apps`} empty={t("dashboard.empty")} prev={t("dashboard.prev")} next={t("dashboard.next")}>
              {appList.map(([bundle, cat, dur]) => (
                <div className="app-row" key={bundle}>
                  <Avatar name={nameOf(bundle)} cat={cat} />
                  <span className="name">{nameOf(bundle)}</span>
                  <span className={`badge ${cat}`}>{t(categoryKey(cat))}</span>
                  <span className="dur">{fmtDuration(dur, locale)}</span>
                </div>
              ))}
            </RowPager>
          </div>
        </div>
      </div>

      <section className="block rise">
        <h2>{t("dashboard.heatmap")}</h2>
        <div className="panel">
          {m && m.hourly_buckets.some((b) => hourValue(b) > 0) ? (
            <Heatmap buckets={m.hourly_buckets} period={period} locale={locale} />
          ) : (
            <p className="muted">{t("dashboard.emptyHeatmap")}</p>
          )}
        </div>
      </section>

      <div className="block rise">
        <div className="pair-board">
          <div className="pair-slot">
            <h2>{t("dashboard.insights")}</h2>
            <RowPager key={`${period}-notes`} empty={t("dashboard.empty")} prev={t("dashboard.prev")} next={t("dashboard.next")}>
              {insights.map((ins) => (
                <div className="insight" key={ins.kind} title={ins.text}>
                  <span className="insight-dot" />
                  <span>{ins.text}</span>
                </div>
              ))}
            </RowPager>
          </div>
          <div className="pair-slot">
            <h2>{t("dashboard.recovery")}</h2>
            <RowPager key={`${period}-recovery`} empty={t("dashboard.empty")} prev={t("dashboard.prev")} next={t("dashboard.next")}>
              {recoveryList.map(([app, agg]) => (
                <div className="app-row" key={app}>
                  <span className="name">{t("dashboard.afterApp", { app: appInCase(nameOf(app), locale, "gen") })}</span>
                  <span className="dur">
                    {t("dashboard.avg", { duration: fmtDuration(agg.count ? agg.total_ms / agg.count : 0, locale) })}
                    {" · "}
                    {agg.count}×
                  </span>
                </div>
              ))}
            </RowPager>
          </div>
        </div>
      </div>

      <section className="block rise">
        <h2>{t("dashboard.focusBlocks")}</h2>
        <RowPager key={`${period}-focus`} size={15} empty={t("dashboard.empty")} prev={t("dashboard.prev")} next={t("dashboard.next")}>
          {focusList.map((b, i) => (
            <div className="app-row" key={`${b.start_ms}-${i}`}>
              <span className="name">{fmtDateTime(b.start_ms, locale)}</span>
              <span className="dur">{fmtDuration(b.duration_ms, locale)}</span>
            </div>
          ))}
        </RowPager>
      </section>
    </div>
  );
}

function RowPager({
  children,
  empty,
  prev,
  next,
  size = FOLD,
}: {
  children: ReactNode;
  empty: string;
  prev: string;
  next: string;
  size?: number;
}) {
  const root = useRef<HTMLDivElement>(null);
  const items = Children.toArray(children);
  const pages = Math.max(1, Math.ceil(items.length / size));
  const [raw, setRaw] = useState(0);
  const [motion, setMotion] = useState<{ dir: number; from: number } | null>(null);
  const page = Math.min(raw, pages - 1);
  const pageRef = useRef(page);
  const lastTurn = useRef(0);
  const clearMotion = useRef(0);
  pageRef.current = page;

  const sliceOf = (index: number) => items.slice(index * size, index * size + size);
  const slotted = size <= FOLD;

  const go = (delta: number) => {
    if (delta === 0 || pages <= 1) return;
    const cur = pageRef.current;
    const nextPage = (cur + delta + pages) % pages;
    if (nextPage === cur) return;
    const now = performance.now();
    const fast = now - lastTurn.current < 420;
    lastTurn.current = now;
    window.clearTimeout(clearMotion.current);
    if (fast) {
      setMotion(null);
    } else {
      setMotion({ dir: delta, from: cur });
      clearMotion.current = window.setTimeout(() => setMotion(null), 560);
    }
    setRaw(nextPage);
  };

  useHorizontalSwipe(root, pages > 1, go);

  const sheet = (index: number) =>
    items.length === 0 ? <p className="muted">{empty}</p> : sliceOf(index);

  return (
    <div ref={root} className="panel pair-panel pager">
      <div
        className={slotted ? "pager-stage slotted" : "pager-stage"}
        style={slotted ? ({ "--fold": size } as CSSProperties) : undefined}
      >
        {motion && (
          <div className={`pager-sheet leave ${motion.dir > 0 ? "to-next" : "to-prev"}`} aria-hidden>
            {sheet(motion.from)}
          </div>
        )}
        <div className={`pager-sheet ${motion ? (motion.dir > 0 ? "enter-next" : "enter-prev") : ""}`}>
          {sheet(page)}
        </div>
      </div>
      {pages > 1 && (
        <div className="pager-nav">
          <button type="button" className="pager-btn" aria-label={prev} onClick={() => go(-1)}>
            <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden>
              <path d="M14 6l-6 6 6 6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span className="pager-count">{page + 1} / {pages}</span>
          <button type="button" className="pager-btn" aria-label={next} onClick={() => go(1)}>
            <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden>
              <path d="M10 6l6 6-6 6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      )}
    </div>
  );
}



function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="panel">
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

export function Avatar({ name, cat }: { name: string; cat: string }) {
  return <span className={`avatar ${cat}`}>{name.slice(0, 1).toUpperCase()}</span>;
}

function Heatmap({
  buckets,
  period,
  locale,
}: {
  buckets: HourBucket[];
  period: "today" | "week" | "month";
  locale: string;
}) {
  const max = Math.max(1, ...buckets.map(hourValue));
  const loc = BCP47[locale as keyof typeof BCP47] ?? locale;

  if (period === "today") {
    const byH = pad24(buckets);
    return (
      <div className="dayhours">
        {byH.map((b, h) => {
          const v = b ? hourValue(b) : 0;
          return (
            <div className="col" key={h} title={`${String(h).padStart(2, "0")}:00 · ${fmtMinutes(v / 60000, locale)}`}>
              <div className={`bar ${v > 0 ? "on" : ""}`} style={{ opacity: cellOpacity(v, max) }} />
              <div className="n">{String(h).padStart(2, "0")}</div>
            </div>
          );
        })}
      </div>
    );
  }

  if (period === "month") {
    return <MonthCal buckets={buckets} locale={loc} />;
  }

  const days = groupByDay(buckets);
  const labels = days.map((d) =>
    new Date(d[0].start_ms)
      .toLocaleDateString(loc, { weekday: "short" })
      .replace(/[.]/g, ""),
  );

  return (
    <div className="heat-wrap">
      <div
        className="heat-tbl"
        style={{ gridTemplateColumns: `28px repeat(${Math.max(days.length, 1)}, minmax(0, 1fr))` }}
      >
        <span />
        {labels.map((l, i) => (
          <span className="cap" key={i}>{l}</span>
        ))}
        {Array.from({ length: 24 }, (_, h) => [
          <span className="hr" key={`h${h}`}>{h % 3 === 0 ? String(h).padStart(2, "0") : ""}</span>,
          ...days.map((day, di) => {
            const b = pad24(day)[h];
            const v = b ? hourValue(b) : 0;
            return (
              <span
                className={`cell ${v > 0 ? "on" : ""}`}
                key={`${di}-${h}`}
                title={b ? `${hourOf(b.start_ms)} · ${fmtMinutes(v / 60000, locale)}` : ""}
                style={{ opacity: cellOpacity(v, max) }}
              />
            );
          }),
        ])}
      </div>
    </div>
  );
}

function MonthCal({ buckets, locale }: { buckets: HourBucket[]; locale: string }) {
  const byDay = new Map<string, { ms: number; start: Date }>();
  for (const b of buckets) {
    const d = new Date(b.start_ms);
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    const cur = byDay.get(key);
    const add = hourValue(b);
    if (cur) cur.ms += add;
    else byDay.set(key, { ms: add, start: new Date(d.getFullYear(), d.getMonth(), d.getDate()) });
  }
  const entries = [...byDay.values()].sort((a, b) => a.start.getTime() - b.start.getTime());
  if (!entries.length) return null;

  const first = entries[0].start;
  const last = entries[entries.length - 1].start;
  const pad = (first.getDay() + 6) % 7;
  const days: ({ date: Date; ms: number } | null)[] = Array.from({ length: pad }, () => null);
  const cursor = new Date(first);
  while (cursor.getTime() <= last.getTime()) {
    const key = `${cursor.getFullYear()}-${cursor.getMonth()}-${cursor.getDate()}`;
    days.push({ date: new Date(cursor), ms: byDay.get(key)?.ms ?? 0 });
    cursor.setDate(cursor.getDate() + 1);
  }
  while (days.length % 7 !== 0) days.push(null);

  const max = Math.max(1, ...entries.map((e) => e.ms));
  const wd = weekdayLabels(locale);

  return (
    <div className="cal">
      {wd.map((w) => (
        <div className="cal-wd" key={w}>{w}</div>
      ))}
      {days.map((cell, i) => {
        if (!cell) return <div className="cal-day empty" key={`e${i}`} />;
        const on = cell.ms > 0;
        const t = on ? 0.22 + Math.sqrt(cell.ms / max) * 0.78 : 0;
        return (
          <div
            className={`cal-day ${on ? "on" : "off"}`}
            key={cell.date.toISOString()}
            title={`${cell.date.toLocaleDateString(locale)} · ${fmtMinutes(cell.ms / 60000, locale)}`}
            style={
              on
                ? {
                    background: `rgba(var(--heat-on-rgb),${t})`,
                    color: t > 0.55 ? "var(--heat-on-fg)" : "var(--text)",
                  }
                : undefined
            }
          >
            {cell.date.getDate()}
          </div>
        );
      })}
    </div>
  );
}

function weekdayLabels(locale: string): string[] {
  const monday = Date.UTC(2021, 5, 7);
  return Array.from({ length: 7 }, (_, i) =>
    new Date(monday + i * 86400000)
      .toLocaleDateString(locale, { weekday: "short", timeZone: "UTC" })
      .replace(/[.]/g, ""),
  );
}

function hourValue(b: HourBucket): number {
  return b.active_ms ?? b.focus_seconds_ms + b.communication_seconds_ms + b.entertainment_seconds_ms;
}

function cellOpacity(v: number, max: number): number {
  if (v <= 0) return 0.06;
  return 0.26 + Math.sqrt(v / Math.max(max, 1)) * 0.74;
}

function hourOf(ms: number) {
  return `${String(new Date(ms).getHours()).padStart(2, "0")}:00`;
}

function groupByDay(buckets: HourBucket[]): HourBucket[][] {
  const map = new Map<string, HourBucket[]>();
  for (const b of buckets) {
    const d = new Date(b.start_ms);
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    const arr = map.get(key) ?? [];
    arr.push(b);
    map.set(key, arr);
  }
  return [...map.values()];
}

function pad24(day: HourBucket[]): (HourBucket | null)[] {
  const byH = new Map(day.map((b) => [new Date(b.start_ms).getHours(), b]));
  return Array.from({ length: 24 }, (_, h) => byH.get(h) ?? null);
}

// Smoke-check that the recommendation engine fires on real-shaped metrics
// (the same numbers the Rust analytics produce).

function recommend(m, period = "week") {
  const recs = [];
  const tracked = Math.max(m.tracked_ms, 1);
  const focusShare = m.focus_seconds_ms / tracked;
  const topCheck = Object.entries(m.checks_per_app).sort((a, b) => b[1] - a[1])[0];
  const recov = Object.entries(m.recovery.by_distractor).sort((a, b) => b[1].count - a[1].count)[0];
  const span = period === "today" ? 1 : 7;
  const checksPerDay = topCheck ? topCheck[1] / span : 0;

  if (m.most_fragmented && m.most_fragmented[1] >= 10) recs.push("chaos");
  if (topCheck && checksPerDay >= 6) recs.push("checks");
  if (m.most_common_ngram && m.most_common_ngram[1] >= 4) recs.push("loop");
  if (recov && m.recovery.samples >= 3) {
    const avg = recov[1].total_ms / recov[1].count;
    if (avg >= 120000) recs.push("recovery");
  }
  if (m.switches_per_hour >= 8) recs.push("switches");
  if (m.strongest_focus_hour && m.strongest_focus_hour[1] >= 20 * 60000) recs.push("best");
  if (m.longest_focus_ms >= 40 * 60000) recs.push("keep");
  if (focusShare < 0.45 && m.tracked_ms > 2 * 3600000) recs.push("focusShare");
  if (m.quick_visits >= 20) recs.push("quick");
  return recs;
}

const week = {
  tracked_ms: 38 * 3600000,
  focus_seconds_ms: 24 * 3600000,
  switches_per_hour: 9.1,
  quick_visits: 96,
  longest_focus_ms: 52 * 60000,
  checks_per_app: { "org.telegram.desktop": 71 },
  most_fragmented: ["15:00", 18],
  most_common_ngram: [["vscode", "telegram", "vscode"], 11],
  strongest_focus_hour: ["10:00", 40 * 60000],
  recovery: {
    samples: 8,
    by_distractor: { "org.telegram.desktop": { count: 5, total_ms: 5 * 3.5 * 60000 } },
  },
};

const quiet = {
  tracked_ms: 30 * 60000,
  focus_seconds_ms: 28 * 60000,
  switches_per_hour: 2,
  quick_visits: 1,
  longest_focus_ms: 20 * 60000,
  checks_per_app: {},
  most_fragmented: null,
  most_common_ngram: null,
  strongest_focus_hour: null,
  recovery: { samples: 0, by_distractor: {} },
};

const weekHits = recommend(week, "week");
const quietHits = recommend(quiet, "today");

const need = ["chaos", "checks", "loop", "recovery", "switches", "best", "keep", "quick"];
for (const id of need) {
  if (!weekHits.includes(id)) {
    console.error("missing rec on a busy week:", id, weekHits);
    process.exit(1);
  }
}
if (quietHits.length !== 0) {
  console.error("quiet day should stay silent, got", quietHits);
  process.exit(1);
}

console.log("analysis engine: OK");
console.log("  busy week fires:", weekHits.join(", "));
console.log("  quiet day stays silent");

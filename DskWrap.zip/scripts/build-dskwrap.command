#!/bin/zsh
# Собирает универсальный DskWrap.app + DskWrap.dmg (Apple Silicon + Intel).
# Запускать ОДНОЙ командой, без \ в конце и без склейки со следующей строкой:
#   zsh scripts/build-dskwrap.command
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -f "$HOME/.cargo/env" ]]; then
  source "$HOME/.cargo/env"
fi
export PATH="$HOME/.cargo/bin:/opt/homebrew/opt/rustup/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

if ! command -v node >/dev/null; then
  echo "Node.js не найден. Выполните:"
  echo "  brew install node"
  exit 1
fi

if ! xcode-select -p >/dev/null 2>&1; then
  echo "Нет Xcode Command Line Tools. Выполните:"
  echo "  xcode-select --install"
  exit 1
fi

if ! command -v rustup >/dev/null; then
  echo "Нужен rustup (не brew rust). Выполните:"
  echo "  brew uninstall rust"
  echo "  brew install rustup"
  echo "  rustup default stable"
  echo "Затем снова: zsh scripts/build-dskwrap.command"
  exit 1
fi

# Homebrew rustup даёт команду rustup, но не кладёт cargo в PATH.
# Берём cargo из toolchain, который rustup уже поставил.
if ! command -v cargo >/dev/null || ! command -v rustc >/dev/null; then
  rustup default stable >/dev/null || true
  if [[ -f "$HOME/.cargo/env" ]]; then
    source "$HOME/.cargo/env"
  fi
  CARGO_REAL="$(rustup which cargo 2>/dev/null || true)"
  RUSTC_REAL="$(rustup which rustc 2>/dev/null || true)"
  if [[ -n "$CARGO_REAL" && -x "$CARGO_REAL" ]]; then
    export PATH="$(dirname "$CARGO_REAL"):$HOME/.cargo/bin:$PATH"
  fi
  if [[ -n "$RUSTC_REAL" && -x "$RUSTC_REAL" ]]; then
    export PATH="$(dirname "$RUSTC_REAL"):$PATH"
  fi
fi

if ! command -v cargo >/dev/null; then
  echo "cargo не в PATH. Homebrew rustup так устроен. Ищу toolchain…"
  rustup default stable
  CARGO_REAL="$(rustup which cargo)"
  if [[ ! -x "$CARGO_REAL" ]]; then
    echo "rustup which cargo не сработал. Пришлите вывод:"
    echo "  which rustup"
    echo "  rustup show"
    echo "  rustup which cargo"
    echo "  ls \"\$HOME/.cargo/bin\""
    echo "  ls \"\$HOME/.rustup/toolchains\""
    exit 1
  fi
  mkdir -p "$HOME/.cargo/bin"
  export PATH="$(dirname "$CARGO_REAL"):$HOME/.cargo/bin:$PATH"
fi

if ! command -v cargo >/dev/null; then
  echo "cargo всё ещё не найден. Пришлите вывод:"
  echo "  which rustup; rustup show; rustup which cargo"
  exit 1
fi

if command -v brew >/dev/null && brew list rust >/dev/null 2>&1; then
  echo "Снимаю Homebrew-пакет rust — он ломает универсальную сборку."
  brew uninstall rust || true
  hash -r
fi

echo "cargo: $(command -v cargo)"
echo "rustc host: $(rustc -vV | awk -F': ' '/^host:/{print $2}')"

echo "Ставлю цели Apple Silicon и Intel…"
rustup target add aarch64-apple-darwin
rustup target add x86_64-apple-darwin

if ! rustup target list --installed | grep -qx 'x86_64-apple-darwin'; then
  echo "Цель x86_64-apple-darwin не установилась. Пришлите вывод:"
  echo "  rustup target list --installed"
  echo "  rustup show"
  exit 1
fi

npm install

python3 scripts/generate-dmg-bg.py 2>/dev/null || true

echo "Собираю универсальный бинарник (Apple Silicon + Intel)…"
npm run tauri build -- --target universal-apple-darwin

APP_DIR="src-tauri/target/universal-apple-darwin/release/bundle/macos/DskWrap.app"
DMG_DIR="src-tauri/target/universal-apple-darwin/release/bundle/dmg"
if [[ ! -d "$APP_DIR" ]]; then
  APP_DIR="src-tauri/target/release/bundle/macos/DskWrap.app"
  DMG_DIR="src-tauri/target/release/bundle/dmg"
fi

mkdir -p "$DMG_DIR"
DMG_FILES=("$DMG_DIR"/*.dmg(N))
if (( ${#DMG_FILES[@]} > 0 )); then
  mv -f "$DMG_FILES[1]" "$DMG_DIR/DskWrap.dmg"
fi

FINAL_DMG="$DMG_DIR/DskWrap.dmg"
[[ -d "$APP_DIR" ]] || { echo "DskWrap.app не найден после сборки"; exit 1; }
[[ -s "$FINAL_DMG" ]] || { echo "DskWrap.dmg не создан"; exit 1; }

mkdir -p release
cp -f "$FINAL_DMG" release/DskWrap.dmg

echo "Сборка завершена (Apple Silicon + Intel)."
echo "Приложение: $APP_DIR"
echo "Образ: $FINAL_DMG"
open "$DMG_DIR" || true

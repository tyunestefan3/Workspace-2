#!/usr/bin/env python3
from pathlib import Path
import base64

ROOT = Path(__file__).resolve().parents[1]
ICON = base64.b64encode((ROOT / "public" / "icon.png").read_bytes()).decode()
HTML = r"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>DskWrap</title>
<style>
:root{--bg:#070708;--panel:#101012;--panel2:#161618;--line:rgba(255,255,255,.06);--text:#ececec;--muted:#7a7a82;--bad:#c45b5b}
*{box-sizing:border-box}html,body{height:100%;margin:0}
body{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI",sans-serif;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased}
.app{display:flex;flex-direction:column;height:100%;min-width:0}
.top{display:flex;align-items:center;gap:12px;padding:14px 18px;border-bottom:1px solid var(--line);flex-shrink:0}
.brand{display:inline-flex;align-items:center;gap:10px;font-weight:600;font-size:15px}
.brand img{width:28px;height:28px;border-radius:7px;background:#000}
.spacer{flex:1}
.pulse{width:7px;height:7px;border-radius:99px;background:#d0d0d0}
.pulse.paused{background:var(--bad)}.pulse.idle{background:#5a5a60}
.burger{width:36px;height:36px;border:0;background:transparent;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:5px;cursor:pointer}
.burger i{display:block;width:16px;height:1.5px;background:var(--text);transition:.2s}
.burger.open i:nth-child(1){transform:translateY(6.5px) rotate(45deg)}
.burger.open i:nth-child(2){opacity:0}
.burger.open i:nth-child(3){transform:translateY(-6.5px) rotate(-45deg)}
.sheet{position:fixed;inset:0;z-index:40}
.dim{position:absolute;inset:0;background:rgba(0,0,0,.62);border:0;cursor:pointer}
.panel-m{position:absolute;top:0;right:0;bottom:0;width:min(320px,86vw);background:#0a0a0b;border-left:1px solid var(--line);padding:28px 22px}
.sheet-head{display:flex;gap:12px;align-items:center;margin-bottom:28px}
.sheet-head img{border-radius:10px;background:#000}
.x{margin-left:auto;width:32px;height:32px;border:0;background:transparent;color:var(--text);font-size:20px;cursor:pointer;line-height:1;flex-shrink:0}
.modal{position:fixed;inset:0;z-index:50;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.72);padding:20px}
.modal-box{background:#101012;border:1px solid var(--line);border-radius:16px;padding:28px 24px;max-width:360px;width:100%;text-align:center}
.rise{opacity:0;filter:blur(10px);transform:scale(.992);transition:opacity 1.05s cubic-bezier(.16,1,.3,1),filter .9s cubic-bezier(.16,1,.3,1),transform 1.1s cubic-bezier(.16,1,.3,1)}
.rise.in{opacity:1;filter:blur(0);transform:none}
.block{margin-top:36px}
.seegrid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:22px;text-align:left}
.seecol{background:#0c0c0e;border:1px solid var(--line);border-radius:14px;padding:18px 16px 16px;min-height:168px;display:flex;flex-direction:column}
.colh{font-size:11px;letter-spacing:.5px;text-transform:uppercase;color:var(--muted);margin-bottom:12px}
.no,.yes{margin:0;padding:8px 0;font-size:14px;line-height:1.35;min-height:38px;border-top:1px solid var(--line)}
.no{color:#5a5a60;text-decoration:line-through;text-decoration-color:#3a3a40}
.yes{color:#d4d4d6}
.launch-line{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:22px;font-size:14px;color:var(--text);cursor:pointer}
.heatbox{overflow-x:auto}
.heat-tbl{display:grid;grid-template-columns:36px repeat(7,minmax(28px,1fr));gap:3px;align-items:center;min-width:280px}
.heat-tbl .cap{font-size:10px;color:var(--muted);text-align:center}
.heat-tbl .hr{font-size:10px;color:var(--muted);text-align:right;padding-right:6px}
.heat-tbl .cell{height:10px;border-radius:2px;background:#d0d0d4}
.dayhours{display:grid;grid-template-columns:repeat(24,1fr);gap:3px}
.dayhours .col{display:flex;flex-direction:column;align-items:center;gap:4px;min-width:0}
.dayhours .bar{width:100%;height:36px;border-radius:3px;background:#d0d0d4}
.dayhours .n{font-size:9px;color:var(--muted)}
.swipe{touch-action:pan-y;cursor:grab}
.wrap-hero{width:calc(100% + 44px);margin:-28px -22px 8px;padding:28px 22px 22px;background:#09090b;border-bottom:1px solid var(--line);touch-action:pan-y;overscroll-behavior-x:contain;user-select:none}
.wrap-card{width:100%;max-width:none!important;min-height:min(48vh,420px);padding:40px 4px 28px;border:0;border-radius:0;background:transparent}
.wrap-card .k{font-size:13px;letter-spacing:2px;color:#b8b8be}
.wrap-card .big{font-size:clamp(40px,6.4vw,72px);line-height:1.05;letter-spacing:-1.2px}
.wrap-nav{margin-top:10px;justify-content:center}
.recs{display:flex;flex-direction:column;gap:14px}
.rec{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:20px}
.rec-n{font-size:11px;letter-spacing:1px;color:var(--muted);margin-bottom:8px}
.rec-h{font-size:18px;font-weight:600;letter-spacing:-.3px;margin:0 0 14px}
.rec-k{font-size:11px;letter-spacing:.5px;text-transform:uppercase;color:var(--muted);margin:10px 0 4px}
.rec p{margin:0;font-size:14px;line-height:1.5;color:#c4c4c8}
.rec-next{color:var(--text)!important}
.sheet-name{font-weight:600;font-size:16px}
.sheet-line{color:var(--muted);font-size:13px;margin-top:2px}
.sheet-nav button{width:100%;text-align:left;background:transparent;border:0;color:var(--muted);font-size:16px;padding:11px 10px;border-radius:8px;cursor:pointer}
.sheet-nav button.on{color:var(--text);background:var(--panel2)}
.rule{height:1px;background:var(--line);margin:10px}
.main{flex:1;overflow:auto;padding:28px 22px 48px}
.wrap{max-width:860px;margin:0 auto;min-width:0}
h1{font-size:22px;margin:0 0 4px;font-weight:600;letter-spacing:-.2px}
h2{font-size:13px;margin:0 0 10px;font-weight:500;color:var(--muted);letter-spacing:.4px;text-transform:uppercase}
.sub{color:var(--muted);margin:0 0 22px;font-size:14px;line-height:1.45}
.grid{display:grid;gap:14px}
.c2{grid-template-columns:repeat(auto-fit,minmax(240px,1fr))}
.c5{grid-template-columns:repeat(auto-fit,minmax(140px,1fr))}
.box{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px;min-width:0}
.box h3{margin:0 0 12px;font-size:12px;color:var(--muted);letter-spacing:.4px;font-weight:500;text-transform:uppercase}
.sv{font-size:26px;font-weight:600;letter-spacing:-.4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sl{color:var(--muted);font-size:12px;margin-top:6px}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.muted{color:var(--muted)}
hr{border:none;border-top:1px solid var(--line);margin:22px 0}
.btn{background:#ececec;color:#111;border:0;padding:9px 14px;border-radius:8px;font-size:13px;cursor:pointer;font-weight:550}
.btn.g{background:transparent;color:var(--text);border:1px solid var(--line)}
.btn.d{background:transparent;color:#e07070;border:1px solid rgba(196,91,91,.35)}
.btn.s{padding:5px 9px;font-size:12px}
.btn.on{border-color:#888;background:var(--panel2)}
.ar{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:8px;background:var(--panel2);margin-bottom:6px;min-width:0}
.ar:last-child{margin-bottom:0}
.nm{flex:1;font-weight:500;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.du{color:var(--muted);font-variant-numeric:tabular-nums;font-size:13px;flex-shrink:0}
.bd{font-size:10px;padding:2px 7px;border-radius:99px;background:rgba(255,255,255,.05);color:var(--muted);flex-shrink:0}
.av{width:26px;height:26px;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;flex-shrink:0;background:#1c1c1f;color:#bbb}
.bar{height:3px;background:#1c1c1f;border-radius:99px;overflow:hidden;margin-top:6px}
.fill{height:100%;background:#d0d0d4}
.hours{display:grid;grid-template-columns:repeat(24,1fr);gap:2px;height:28px}
.hc{border-radius:2px;background:#d0d0d4}
.hl{display:flex;justify-content:space-between;margin-top:6px;font-size:10px;color:var(--muted)}
.heat{display:grid;grid-auto-flow:column;grid-template-rows:repeat(24,8px);gap:2px}
.heat b{display:block;width:12px;border-radius:2px;background:#d0d0d4}
.ins{display:flex;gap:10px;padding:8px 0;font-size:13px;line-height:1.45;color:#c8c8cc;border-top:1px solid var(--line)}
.ins:first-child{border-top:0}
.doti{width:4px;height:4px;border-radius:99px;background:#888;margin-top:8px;flex-shrink:0}
.pills{display:flex;gap:6px;flex-wrap:wrap}
.pills button{background:transparent;border:1px solid var(--line);color:var(--muted);padding:6px 11px;border-radius:999px;cursor:pointer;font-size:13px}
.pills button.on{background:#ececec;color:#111;border-color:transparent}
.card{background:#0c0c0e;border:1px solid var(--line);border-radius:16px;padding:36px 28px;min-height:260px;display:flex;flex-direction:column;justify-content:center;gap:10px}
.k{text-transform:uppercase;letter-spacing:1.6px;font-size:11px;color:var(--muted)}
.big{font-size:clamp(22px,4.4vw,36px);font-weight:600;line-height:1.15;letter-spacing:-.5px;overflow-wrap:anywhere}
.dots{display:flex;gap:6px;justify-content:center;margin-top:14px}
.dots button{width:6px;height:6px;border-radius:99px;border:0;background:#2a2a2e;padding:0;cursor:pointer}
.dots button.on{background:#d0d0d4;width:16px}
.search,.sel{background:var(--panel2);color:var(--text);border:1px solid var(--line);padding:9px 11px;border-radius:8px;font-size:13px}
.search{width:100%;margin-bottom:14px}
.sel{max-width:42%}
.chk{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted);white-space:nowrap}
.onb{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%;text-align:center;padding:32px 20px}
.mark{width:72px;height:72px;border-radius:18px;background:#000;margin-bottom:14px}
.toast{margin-top:14px;color:var(--muted);font-size:13px}
.dimrow{opacity:.45}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{text-align:left;padding:8px 6px;border-bottom:1px solid var(--line)}
th{color:var(--muted);font-weight:500;font-size:10px;text-transform:uppercase}
</style>
</head>
<body>
<div class="app" id="root"></div>
<script>
const ICON="data:image/png;base64,__ICON__";
const L=[
  {id:"en",n:"English"},{id:"ru",n:"Русский"},{id:"es",n:"Español"},{id:"zh",n:"中文"},{id:"fr",n:"Français"}
];
const T={
en:{
  sub:"Learn more about yourself.",
  today:"Today",week:"Week",month:"Month",
  time:"Time",focus:"Focus",sw:"Switches",gl:"Glances",brief:"Brief visits",
  cats:"Categories",apps:"Apps",hours:"Hours",notes:"Notes",back:"Back to focus",foc:"Focus",
  empty:"Nothing here yet. Use your Mac — this page will fill up.",
  wrap:"Wrapped",deck:"Deck",thisw:"This week",all:"in total",lead:"Lead role",hard:"Hard to ignore",
  glances:"{n} glances",busy:"Busiest hour",swN:"{n} switches",deep:"Deep stretch",long:"longest focus",
  loop:"Your loop",typ:"Your type",pers:"Switcher",
  appsT:"Apps",appsS:"Say how you use them. Stored only on this Mac.",hide:"Hide",clear:"Clear",
  search:"Search",none:"Nothing matches.",
  set:"Settings",setS:"Language, pause, and data. Everything stays on this Mac.",
  lang:"Language",langH:"Interface language.",
  about:"Learn more about yourself",
  p15:"Pause 15 min",p1:"Pause 1 hour",p:"Until I resume",cont:"Resume",
  idle:"Five minutes without mouse or keyboard are not counted.",login:"Open DskWrap when the Mac starts.",
  data:"Data",json:"Export JSON",csv:"Export CSV",del:"Delete all data",
  priv:"No screen, keystrokes, URLs or files. Nothing leaves this Mac.",
  paused:"Paused.",resumed:"Resumed.",saved:"Saved.",wiped:"Data deleted.",
  prev:"Preview",intro:"Show intro again",reset:"Reset demo",demo:"Local demo data.",
  diag:"Diagnostics",st:"Status",last:"Last event",hb:"Last heartbeat",ev:"Events today",
  log:"Log",show:"Show JSON",hint:"For checking the interface only.",
  fill:"Fill a week",idleB:"Idle",sleepB:"Sleep",liveB:"Live",
  o1:"Learn more about yourself.",o1t:"DskWrap shows how the day unfolds on your Mac. Only you see it.",
  o2k:"Private",o2:"No account. No cloud.",o2t:"Everything stays on this Mac.",
  o3k:"What DskWrap sees",ok1:"which app is in front",ok2:"when you switch",ok3:"how long you stay",
  no1:"the screen",no2:"keystrokes",no3:"URLs and files",
  sees:"Sees",unsees:"Does not see",
  ask:"Open at launch?",askT:"DskWrap can start when the Mac starts.",yes:"Yes",no:"No",
  next:"Continue",skip:"Skip",begin:"Begin",launch:"Open at launch",step:"{n} / {total}",
  days:"Mon Tue Wed Thu Fri Sat Sun",
  menu:"Menu",secT:"Today",secW:"Wrapped",secA:"Apps",secR:"Advice",secS:"Settings",secD:"Diagnostics",
  rT:"Advice",rS:"From your numbers — not slogans. Do one thing tomorrow.",
  rWhy:"Why",rDo:"Tomorrow",
  r1t:"Protect the broken hour",r1w:"15:00 had 18 switches. That is chopping, not work.",r1n:"From 14:45 mute chat. One slot, one task.",
  r2t:"Batch Telegram",r2w:"Telegram was opened 71 times. Most glances last seconds and cost a restart.",r2n:"Two windows a day. Hide the badge the rest of the time.",
  r3t:"Break the loop",r3w:"VS Code → Telegram → VS Code happened 11 times. The middle app is the leak.",r3n:"Put Telegram on another desktop. Come back only on a timer.",
  r4t:"Returns are expensive",r4w:"After Telegram it takes about 3–4 minutes to focus again.",r4n:"Either 20 seconds and close it, or ten minutes on purpose. No in-between.",
  r5t:"Hard work at 10:00",r5w:"Your strongest focus sits around 10:00.",r5n:"Put the hardest task there. No mail in that slot.",
  after:"After {app}",avg:"{d} avg",
  cF:"focus",cC:"chat",cE:"leisure",cU:"tools",cN:"other"
},
ru:{
  sub:"Узнайте о себе больше.",
  today:"Сегодня",week:"Неделя",month:"Месяц",
  time:"Время",focus:"Фокус",sw:"Переключения",gl:"Взгляды",brief:"Короткие заходы",
  cats:"Категории",apps:"Приложения",hours:"Часы",notes:"Заметки",back:"Снова в фокусе",foc:"Фокус",
  empty:"Пока пусто.",
  wrap:"Итоги",deck:"Карты",thisw:"Эта неделя",all:"всего",lead:"Главная роль",hard:"Трудно не заглянуть",
  glances:"{n} взглядов",busy:"Самый плотный час",swN:"{n} переключений",deep:"Глубокий отрезок",long:"самый длинный фокус",
  loop:"Ваш цикл",typ:"Ваш тип",pers:"Переключения",
  appsT:"Приложения",appsS:"Отметьте, как вы ими пользуетесь. Только на этом Mac.",hide:"Скрыть",clear:"Очистить",
  search:"Поиск",none:"Ничего не нашлось.",
  set:"Настройки",setS:"Язык, пауза и данные. Всё остаётся на этом Mac.",
  lang:"Язык",langH:"Язык интерфейса.",
  about:"Узнайте о себе больше",
  p15:"Пауза 15 мин",p1:"Пауза 1 час",p:"До отмены",cont:"Продолжить",
  idle:"Пять минут без мыши и клавиатуры не считаются.",login:"Открывать DskWrap вместе с запуском Mac.",
  data:"Данные",json:"Экспорт JSON",csv:"Экспорт CSV",del:"Удалить все данные",
  priv:"Ни экрана, ни клавиш, ни ссылок, ни файлов. Ничего не покидает этот Mac.",
  paused:"На паузе.",resumed:"Снова в работе.",saved:"Сохранено.",wiped:"Данные удалены.",
  prev:"Превью",intro:"Показать введение снова",reset:"Сбросить демо",demo:"Локальные демо-данные.",
  diag:"Диагностика",st:"Статус",last:"Последнее событие",hb:"Последний сигнал",ev:"Событий сегодня",
  log:"Журнал",show:"Показать JSON",hint:"Только чтобы проверить интерфейс.",
  fill:"Заполнить неделю",idleB:"Простой",sleepB:"Сон",liveB:"Сейчас",
  o1:"Узнайте о себе больше.",o1t:"DskWrap показывает, как проходит день на Mac. Это видите только вы.",
  o2k:"Приватно",o2:"Без аккаунта. Без облака.",o2t:"Всё остаётся на этом Mac.",
  o3k:"Что видит DskWrap",ok1:"какое приложение впереди",ok2:"когда вы переключаетесь",ok3:"как долго остаётесь",
  no1:"экран",no2:"клавиши",no3:"ссылки и файлы",
  sees:"Видит",unsees:"Не видит",
  ask:"Открывать при запуске?",askT:"DskWrap может стартовать вместе с системой.",yes:"Да",no:"Нет",
  next:"Дальше",skip:"Пропустить",begin:"Начать",launch:"Открывать при запуске",step:"{n} / {total}",
  days:"пн вт ср чт пт сб вс",
  menu:"Меню",secT:"Сегодня",secW:"Итоги",secA:"Приложения",secR:"Советы",secS:"Настройки",secD:"Диагностика",
  rT:"Советы",rS:"По вашим цифрам, не общие слова. Завтра — одно действие.",
  rWhy:"Почему",rDo:"Завтра",
  r1t:"Закройте рваный час",r1w:"В 15:00 было 18 переключений. Это дробление, не работа.",r1n:"С 14:45 выключите чаты. Один слот — одна задача.",
  r2t:"Соберите Telegram в пачку",r2w:"Telegram открывался 71 раз. Взгляд на секунды стоит перезапуска внимания.",r2n:"Два окна в день. В остальное время уберите бейдж.",
  r3t:"Разорвите цикл",r3w:"VS Code → Telegram → VS Code повторился 11 раз. Течёт среднее звено.",r3n:"Вынесите Telegram на другой рабочий стол. Возвращайтесь только по таймеру.",
  r4t:"Возврат дорого стоит",r4w:"После Telegram в среднем 3–4 минуты, пока снова попадёте в фокус.",r4n:"Либо 20 секунд и закрыть, либо десять минут осознанно. Середины нет.",
  r5t:"Трудное — в 10:00",r5w:"Самый крепкий фокус около 10:00.",r5n:"В этот час — только самая сложная задача. Без почты.",
  after:"После {app}",avg:"{d} в среднем",
  cF:"фокус",cC:"общение",cE:"отдых",cU:"инструменты",cN:"другое"
},
es:{
  sub:"Conócete un poco más.",today:"Hoy",week:"Semana",month:"Mes",time:"Tiempo",focus:"Enfoque",sw:"Cambios",gl:"Miradas",brief:"Visitas breves",
  cats:"Categorías",apps:"Apps",hours:"Horas",notes:"Notas",back:"De vuelta al enfoque",foc:"Enfoque",empty:"Aún no hay nada.",
  wrap:"Resumen",deck:"Cartas",thisw:"Esta semana",all:"en total",lead:"Papel principal",hard:"Difícil no mirar",
  glances:"{n} miradas",busy:"Hora más densa",swN:"{n} cambios",deep:"Tramo profundo",long:"enfoque más largo",
  loop:"Tu bucle",typ:"Tu tipo",pers:"Cambios",
  appsT:"Apps",appsS:"Di cómo las usas. Solo en este Mac.",hide:"Ocultar",clear:"Borrar",search:"Buscar",none:"Nada coincide.",
  set:"Ajustes",setS:"Conócete un poco más — en privado.",lang:"Idioma",langH:"Idioma de la interfaz.",about:"Conócete un poco más",
  p15:"Pausa 15 min",p1:"Pausa 1 hora",p:"Hasta cancelar",cont:"Reanudar",idle:"Cinco minutos sin ratón ni teclado no se cuentan.",login:"Abrir DskWrap al arrancar el Mac.",
  data:"Datos",json:"Exportar JSON",csv:"Exportar CSV",del:"Borrar todos los datos",
  priv:"Ni pantalla, ni teclas, ni URL, ni archivos.",paused:"En pausa.",resumed:"De nuevo.",saved:"Guardado.",wiped:"Datos borrados.",
  prev:"Vista previa",intro:"Ver la intro otra vez",reset:"Restablecer demo",demo:"Datos locales de demo.",
  diag:"Diagnóstico",st:"Estado",last:"Último evento",hb:"Última señal",ev:"Eventos de hoy",log:"Registro",show:"Ver JSON",hint:"Solo para revisar la interfaz.",
  fill:"Llenar una semana",idleB:"Inactivo",sleepB:"Reposo",liveB:"Activo",
  o1:"Conócete un poco más.",o1t:"DskWrap muestra cómo transcurre el día en tu Mac. Solo lo ves tú.",
  o2k:"Privado",o2:"Sin cuenta. Sin nube.",o2t:"Todo se queda en este Mac.",
  o3k:"Qué ve DskWrap",ok1:"qué app está delante",ok2:"cuándo cambias",ok3:"cuánto te quedas",
  no1:"la pantalla",no2:"teclas",no3:"URL y archivos",
  sees:"Ve",unsees:"No ve",
  ask:"¿Abrir al arrancar?",askT:"DskWrap puede iniciarse con el sistema.",yes:"Sí",no:"No",
  next:"Seguir",skip:"Saltar",begin:"Empezar",launch:"Abrir al arrancar",step:"{n} / {total}",
  days:"lun mar mié jue vie sáb dom",
  menu:"Menú",secT:"Hoy",secW:"Resumen",secA:"Apps",secR:"Consejos",secS:"Ajustes",secD:"Diagnóstico",
  rT:"Consejos",rS:"Según tus números. Mañana, una sola acción.",
  rWhy:"Por qué",rDo:"Mañana",
  r1t:"Protege la hora rota",r1w:"A las 15:00 hubo 18 cambios. Eso es picar, no trabajar.",r1n:"Desde las 14:45, silencia el chat. Un bloque, una tarea.",
  r2t:"Agrupa Telegram",r2w:"Telegram se abrió 71 veces. Un vistazo cuesta reiniciar.",r2n:"Dos ventanas al día. El resto, sin badge.",
  r3t:"Rompe el bucle",r3w:"VS Code → Telegram → VS Code ocurrió 11 veces.",r3n:"Pon Telegram en otro escritorio. Vuelve solo con temporizador.",
  r4t:"Volver cuesta caro",r4w:"Tras Telegram tardas 3–4 min en volver al enfoque.",r4n:"O 20 segundos y cierras, o diez minutos a propósito.",
  r5t:"Lo difícil, a las 10:00",r5w:"Tu mejor enfoque está hacia las 10:00.",r5n:"Ahí, la tarea más dura. Sin correo.",
  after:"Tras {app}",avg:"{d} de media",cF:"enfoque",cC:"charla",cE:"ocio",cU:"herramientas",cN:"otro"
},
zh:{
  sub:"多了解一点自己。",today:"今天",week:"本周",month:"本月",time:"时间",focus:"专注",sw:"切换",gl:"查看",brief:"短暂打开",
  cats:"分类",apps:"应用",hours:"时段",notes:"笔记",back:"回到专注",foc:"专注",empty:"还是空的。",
  wrap:"回顾",deck:"卡片",thisw:"这一周",all:"合计",lead:"主角",hard:"忍不住看",
  glances:"{n} 次瞄一眼",busy:"最密的一小时",swN:"{n} 次切换",deep:"沉浸时段",long:"最长专注",
  loop:"你的循环",typ:"你的类型",pers:"频繁切换",
  appsT:"应用",appsS:"标明你怎么用它们。只留在这台 Mac 上。",hide:"隐藏",clear:"清除",search:"搜索",none:"没有匹配项。",
  set:"设置",setS:"语言、暂停和数据。全部留在这台 Mac 上。",lang:"语言",langH:"界面语言。",about:"多了解一点自己",
  p15:"暂停 15 分钟",p1:"暂停 1 小时",p:"直到取消",cont:"继续",idle:"鼠标和键盘五分钟不动，这段时间不计入。",login:"开机时打开 DskWrap。",
  data:"数据",json:"导出 JSON",csv:"导出 CSV",del:"删除全部数据",
  priv:"不记录屏幕、按键、网址或文件。",paused:"已暂停。",resumed:"已继续。",saved:"已保存。",wiped:"数据已删除。",
  prev:"预览",intro:"再看一遍介绍",reset:"重置演示",demo:"本地演示数据。",
  diag:"诊断",st:"状态",last:"最近事件",hb:"最近信号",ev:"今日事件",log:"日志",show:"查看 JSON",hint:"仅用于检查界面。",
  fill:"填满一周",idleB:"空闲",sleepB:"休眠",liveB:"进行中",
  o1:"多了解一点自己。",o1t:"DskWrap 呈现你在 Mac 上的一天。只有你看得到。",
  o2k:"私密",o2:"无需账号。没有云。",o2t:"一切都留在这台 Mac 上。",
  o3k:"DskWrap 看到什么",ok1:"前台是哪个应用",ok2:"你何时切换",ok3:"停留多久",
  no1:"屏幕",no2:"按键",no3:"网址和文件",
  next:"继续",skip:"跳过",begin:"开始",launch:"开机时打开",step:"{n} / {total}",
  menu:"菜单",secT:"今天",secW:"回顾",secA:"应用",secS:"设置",secD:"诊断",
  after:"离开 {app} 之后",avg:"平均 {d}",cF:"专注",cC:"沟通",cE:"休闲",cU:"工具",cN:"其他",
  sees:"看得到",unsees:"看不到",yes:"是",no:"否",
  ask:"开机时打开？",askT:"DskWrap 可以随系统一起启动。",
  days:"一 二 三 四 五 六 日",
  secR:"建议",
  rT:"建议",rS:"根据你的数字，不是套话。明天只做一件事。",
  rWhy:"原因",rDo:"明天",
  r1t:"守住最碎的一小时",r1w:"15:00 出现了 18 次切换。那是把时间切碎，不是在工作。",r1n:"14:45 起关掉聊天。一个小时只做一件事。",
  r2t:"不要零碎地打开 Telegram",r2w:"Telegram 打开了 71 次。看一眼只要几秒，注意力却要重来。",r2n:"每天只开两段。其余时间去掉角标。",
  r3t:"打断这个循环",r3w:"VS Code → Telegram → VS Code 重复了 11 次。通常是第二个应用把你带走。",r3n:"把 Telegram 放到另一个桌面。只按计时器再回去。",
  r4t:"回来的代价很高",r4w:"离开 Telegram 后平均要 3–4 分钟才能再专注。",r4n:"要么 20 秒关掉，要么认真用十分钟。不要停在中间。",
  r5t:"难事放在 10:00",r5w:"最强的专注大约在 10:00。",r5n:"这个小时只做最难的那件事。不要看邮件。"
},
fr:{
  sub:"Apprenez-en plus sur vous-même.",today:"Aujourd'hui",week:"Semaine",month:"Mois",time:"Temps",focus:"Focus",sw:"Changements",gl:"Coups d'œil",brief:"Passages brefs",
  cats:"Catégories",apps:"Apps",hours:"Heures",notes:"Notes",back:"Retour au focus",foc:"Focus",empty:"Encore vide.",
  wrap:"Bilan",deck:"Cartes",thisw:"Cette semaine",all:"au total",lead:"Rôle principal",hard:"Difficile de ne pas regarder",
  glances:"{n} coups d'œil",busy:"Heure la plus dense",swN:"{n} changements",deep:"Tranche profonde",long:"plus long focus",
  loop:"Votre boucle",typ:"Votre type",pers:"Changements",
  appsT:"Apps",appsS:"Dites comment vous les utilisez. Uniquement sur ce Mac.",hide:"Masquer",clear:"Effacer",search:"Rechercher",none:"Aucune correspondance.",
  set:"Réglages",setS:"Langue, pause et données. Tout reste sur ce Mac.",lang:"Langue",langH:"Langue de l'interface.",about:"Apprenez-en davantage sur vous",
  p15:"Pause 15 min",p1:"Pause 1 heure",p:"Jusqu'à annulation",cont:"Reprendre",idle:"Cinq minutes sans souris ni clavier ne sont pas comptées.",login:"Ouvrir DskWrap au démarrage du Mac.",
  data:"Données",json:"Exporter JSON",csv:"Exporter CSV",del:"Supprimer toutes les données",
  priv:"Ni écran, ni frappes, ni URL, ni fichiers.",paused:"En pause.",resumed:"Repris.",saved:"Enregistré.",wiped:"Données supprimées.",
  prev:"Aperçu",intro:"Revoir l'intro",reset:"Réinitialiser la démo",demo:"Données locales de démo.",
  diag:"Diagnostic",st:"Statut",last:"Dernier événement",hb:"Dernier signal",ev:"Événements du jour",log:"Journal",show:"Voir le JSON",hint:"Uniquement pour vérifier l'interface.",
  fill:"Remplir une semaine",idleB:"Inactif",sleepB:"Veille",liveB:"En cours",
  o1:"Apprenez-en plus sur vous-même.",o1t:"DskWrap montre comment se déroule la journée sur votre Mac. Personne d'autre ne le voit.",
  o2k:"Privé",o2:"Pas de compte. Pas de cloud.",o2t:"Tout reste sur ce Mac.",
  o3k:"Ce que voit DskWrap",ok1:"quelle app est devant",ok2:"quand vous changez",ok3:"combien de temps vous restez",
  no1:"l'écran",no2:"les frappes",no3:"les URL et fichiers",
  sees:"Voit",unsees:"Ne voit pas",
  ask:"Ouvrir au démarrage ?",askT:"DskWrap peut se lancer avec le système.",yes:"Oui",no:"Non",
  next:"Continuer",skip:"Passer",begin:"Commencer",launch:"Ouvrir au démarrage",step:"{n} / {total}",
  days:"lun mar mer jeu ven sam dim",
  menu:"Menu",secT:"Aujourd'hui",secW:"Bilan",secA:"Apps",secR:"Conseils",secS:"Réglages",secD:"Diagnostic",
  rT:"Conseils",rS:"D'après vos chiffres. Demain : une action.",
  rWhy:"Pourquoi",rDo:"Demain",
  r1t:"Protégez l'heure cassée",r1w:"À 15:00, il y a eu 18 changements. Cela morcelle le travail au lieu de l'avancer.",r1n:"Dès 14:45, coupez le chat. Un créneau, une tâche.",
  r2t:"Regroupez Telegram",r2w:"Telegram a été ouvert 71 fois. Un coup d'œil coûte un redémarrage.",r2n:"Deux fenêtres par jour. Pas de pastille le reste du temps.",
  r3t:"Cassez la boucle",r3w:"VS Code → Telegram → VS Code : 11 fois.",r3n:"Mettez Telegram sur un autre bureau. Minuteur seulement.",
  r4t:"Revenir coûte cher",r4w:"Après Telegram, 3–4 min pour retrouver le focus.",r4n:"Soit 20 secondes et vous fermez, soit dix minutes pour de vrai.",
  r5t:"Le difficile, à 10:00",r5w:"Votre meilleur focus est vers 10:00.",r5n:"Là, la tâche la plus dure. Pas de mail.",
  after:"Après {app}",avg:"{d} en moyenne",cF:"focus",cC:"échange",cE:"loisir",cU:"outils",cN:"autre"
}
};
const nav=[["dashboard","secT"],["wrapped","secW"],["applications","secA"],["recs","secR"],["settings","secS"],["debug","secD"]];
const CATS=[["focus","cF"],["communication","cC"],["entertainment","cE"],["utility","cU"],["neutral","cN"]];
function seed(){return [
  ["VS Code","focus"],["Terminal","focus"],["Chrome","neutral"],["Telegram","communication"],
  ["Slack","communication"],["YouTube","entertainment"],["Figma","focus"],["Finder","utility"]
].map(([n,c])=>({n,c,id:n,hide:false}));}
const S={
  locale:(navigator.language||"ru").slice(0,2),
  page:"dashboard", onboarded:false, step:0, menu:false, period:"today", card:0,
  tracker:"active", apps:seed(), q:"", toast:"", raw:false, launch:true, ask:false
};
if(!T[S.locale]) S.locale="en";
function t(k,v){let s=(T[S.locale]&&T[S.locale][k])||T.en[k]||k; if(v) Object.keys(v).forEach(x=>s=s.split("{"+x+"}").join(v[x])); return s;}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]));}
function dur(sec){sec=Math.round(sec);const m=Math.floor(sec/60),h=Math.floor(m/60);if(h) return h+"h "+String(m%60).padStart(2,"0")+"m"; if(m) return m+"m"; return sec+"s";}
function pills(){return `<div class="pills">${L.map(l=>`<button class="${S.locale===l.id?"on":""}" data-a="loc" data-v="${l.id}">${l.n}</button>`).join("")}</div>`;}
function av(n){return `<span class="av">${esc(n.slice(0,1))}</span>`;}
function viewOnb(){
  const last=S.step===2;
  const modal=S.ask?`<div class="modal"><div class="modal-box">
    <div class="big" style="font-size:22px">${t("ask")}</div>
    <p class="muted" style="margin:12px 0 22px">${t("askT")}</p>
    <div class="row" style="justify-content:center"><button class="btn" data-a="lyes">${t("yes")}</button><button class="btn g" data-a="lno">${t("no")}</button></div>
  </div></div>`:"";
  return `<div class="onb">
    <img class="mark" src="${ICON}" alt="DskWrap"/>
    <div class="muted" style="margin-bottom:18px">DskWrap</div>
    ${S.step===0?`<div style="margin-bottom:22px">${pills()}</div>`:""}
    <div style="max-width:560px;width:100%">
      ${S.step===0?`<div class="big">${t("o1")}</div><p class="muted" style="margin-top:10px;line-height:1.5">${t("o1t")}</p>`:""}
      ${S.step===1?`<div class="k">${t("o2k")}</div><div class="big" style="margin-top:8px">${t("o2")}</div><p class="muted" style="margin-top:10px">${t("o2t")}</p>`:""}
      ${S.step===2?`<div class="k">${t("o3k")}</div>
        <div class="seegrid">
          <div class="seecol"><div class="colh">${t("unsees")}</div><div class="no">${t("no1")}</div><div class="no">${t("no2")}</div><div class="no">${t("no3")}</div></div>
          <div class="seecol"><div class="colh">${t("sees")}</div><div class="yes">${t("ok1")}</div><div class="yes">${t("ok2")}</div><div class="yes">${t("ok3")}</div></div>
        </div>
        <label class="launch-line"><input type="checkbox" ${S.launch?"checked":""} data-a="launch"> ${t("launch")}</label>`:""}
    </div>
    <div class="row" style="margin-top:24px;justify-content:center">
      ${last?`<button class="btn" data-a="done">${t("begin")}</button>`:`<button class="btn" data-a="next">${t("next")}</button>`}
      <button class="btn g" data-a="skip">${t("skip")}</button>
    </div>
    <div class="muted" style="margin-top:14px;font-size:12px">${t("step",{n:S.step+1,total:3})}</div>
    ${modal}
  </div>`;
}

const MET={
  today:{t:6*3600+42*60,f:4*3600+18*60,sw:86,gl:24,br:17,cats:[62,18,12,4,8],
    apps:[["VS Code",3*3600+12*60,"focus"],["Telegram",38*60,"communication"],["Chrome",44*60,"neutral"],["Slack",24*60,"communication"],["YouTube",36*60,"entertainment"]],
    rec:[["Telegram","3m",5],["Slack","6m",3]],
    foc:[["09:00","48m"],["10:20","52m"],["14:05","33m"]],
    h:[0,0,0,0,0,0,0,0,.25,.8,.95,.85,.4,.55,.7,.75,.6,.35,.15,.1,.05,.2,.1,0]},
  week:{t:38*3600+12*60,f:24*3600+5*60,sw:512,gl:148,br:96,cats:[58,16,11,5,10],
    apps:[["VS Code",18*3600,"focus"],["Telegram",3*3600+50*60,"communication"],["Chrome",2*3600,"neutral"],["Terminal",3*3600,"focus"],["YouTube",2*3600+50*60,"entertainment"]],
    rec:[["Telegram","3m",28],["Slack","6m",16]],foc:[["Mon 09:12","46m"],["Tue 10:04","52m"]],h:null}
};
MET.month=Object.assign({},MET.week,{t:148*3600,f:92*3600,sw:1980,gl:540});

function hoursBar(h){
  return `<div class="dayhours">${h.map((v,i)=>`<div class="col"><div class="bar" style="opacity:${.12+v*.88}"></div><div class="n">${String(i).padStart(2,"0")}</div></div>`).join("")}</div>`;
}
function weekHeat(){
  const days=t("days").split(" ");
  const p=[0,0,0,0,0,0,0,0,.3,.8,1,.85,.4,.55,.75,.7,.55,.3,.2,.15,.1,.25,.15,0], sc=[.85,1,1.05,.95,1.1,.45,.25];
  let cells=`<span></span>${days.map(d=>`<span class="cap">${d}</span>`).join("")}`;
  for(let h=0;h<24;h++){
    cells+=`<span class="hr">${String(h).padStart(2,"0")}</span>`;
    for(let d=0;d<7;d++) cells+=`<span class="cell" style="opacity:${.12+p[h]*sc[d]*.88}"></span>`;
  }
  return `<div class="heatbox"><div class="heat-tbl">${cells}</div></div>`;
}

function viewDash(){
  const m=MET[S.period]||MET.today;
  return `<div class="wrap">
    <h1 class="rise">${t("today")}</h1><p class="sub rise">${t("sub")}</p>
    <div class="row" style="margin-bottom:18px">
      ${["today","week","month"].map(p=>`<button class="btn g s ${S.period===p?"on":""}" data-a="per" data-v="${p}">${t(p==="today"?"today":p==="week"?"week":"month")}</button>`).join("")}
    </div>
    <div class="grid c5">
      ${[["time",dur(m.t)],["focus",dur(m.f)],["sw",m.sw],["gl",m.gl],["brief",m.br]].map(([k,v])=>`<div class="box rise"><div class="sv">${v}</div><div class="sl">${t(k)}</div></div>`).join("")}
    </div><hr>
    <div class="grid c2">
      <div class="rise"><h2>${t("cats")}</h2><div class="box">${CATS.map((c,i)=>`<div style="margin-bottom:12px"><div style="display:flex;justify-content:space-between"><span class="bd">${t(c[1])}</span><span class="du">${m.cats[i]}%</span></div><div class="bar"><div class="fill" style="width:${m.cats[i]}%"></div></div></div>`).join("")}</div></div>
      <div class="rise"><h2>${t("apps")}</h2><div class="box">${m.apps.map(([n,s,c])=>`<div class="ar">${av(n)}<span class="nm">${esc(n)}</span><span class="bd">${t(CATS.find(x=>x[0]===c)[1])}</span><span class="du">${dur(s)}</span></div>`).join("")}</div></div>
    </div><hr>
    <div class="rise"><h2>${t("hours")}</h2><div class="box">${m.h?hoursBar(m.h):weekHeat()}</div></div><hr>
    <div class="grid c2">
      <div class="rise"><h2>${t("notes")}</h2><div class="box">
        <div class="ins"><i class="doti"></i><span>Telegram — ${S.period==="today"?24:71} ${t("glances",{n:""}).replace(" ","")?"":""}${t("glances",{n:S.period==="today"?24:71})}</span></div>
        <div class="ins"><i class="doti"></i><span>${t("deep")}: 52m</span></div>
        <div class="ins"><i class="doti"></i><span>${t("busy")}: 15:00</span></div>
        <div class="ins"><i class="doti"></i><span>VS Code → Telegram → VS Code ×11</span></div>
      </div></div>
      <div class="rise"><h2>${t("back")}</h2><div class="box">${m.rec.map(([n,d,c])=>`<div class="ar"><span class="nm">${t("after",{app:n})}</span><span class="du">${t("avg",{d})} · ${c}×</span></div>`).join("")}</div></div>
    </div><hr>
    <div class="rise"><h2>${t("foc")}</h2><div class="box">${m.foc.map(([a,d])=>`<div class="ar"><span class="nm">${a}</span><span class="du">${d}</span></div>`).join("")}</div></div>
  </div>`;
}

function cards(){return [
  {k:"thisw", html:()=>`<div class="k">${t("thisw")}</div><div class="big">${dur(MET.week.t)}</div><div class="muted">${t("all")}</div>`},
  {k:"lead", html:()=>`<div class="k">${t("lead")}</div><div class="big">VS Code</div><div class="muted">${dur(18*3600)}</div>`},
  {k:"hard", html:()=>`<div class="k">${t("hard")}</div><div class="big">Telegram</div><div class="muted">${t("glances",{n:71})}</div>`},
  {k:"busy", html:()=>`<div class="k">${t("busy")}</div><div class="big">15:00</div><div class="muted">${t("swN",{n:18})}</div>`},
  {k:"deep", html:()=>`<div class="k">${t("deep")}</div><div class="big">52m</div><div class="muted">${t("long")}</div>`},
  {k:"loop", html:()=>`<div class="k">${t("loop")}</div><div class="big" style="font-size:22px">VS Code → Telegram → VS Code ×11</div>`},
  {k:"typ", html:()=>`<div class="k">${t("typ")}</div><div class="big">${t("pers")}</div>`},
];}
function viewWrap(){
  const cs=cards(), i=Math.min(S.card,cs.length-1);
  return `<div class="wrap wrap-page">
    <div class="wrap-hero" id="swipe">
    <h1>${t("wrap")}</h1><p class="sub">${t("pers")}</p>
    <div class="card wrap-card swipe">${cs[i].html()}</div>
    <div class="dots">${cs.map((_,n)=>`<button class="${n===i?"on":""}" data-a="card" data-v="${n}"></button>`).join("")}</div>
    <div class="row wrap-nav">
      <button class="btn g" data-a="card" data-v="${i-1}" ${i===0?"disabled":""}>←</button>
      <span class="muted">${i+1} / ${cs.length}</span>
      <button class="btn g" data-a="card" data-v="${i+1}" ${i>=cs.length-1?"disabled":""}>→</button>
    </div>
    </div>
  </div>`;
}

function viewApps(){
  const q=S.q.trim().toLowerCase();
  const list=S.apps.filter(a=>!q||a.n.toLowerCase().includes(q));
  return `<div class="wrap">
    <h1>${t("appsT")}</h1><p class="sub">${t("appsS")}</p>
    <input class="search" id="q" value="${esc(S.q)}" placeholder="${t("search")}"/>
    <div class="box">${list.length?list.map(a=>`<div class="ar ${a.hide?"dimrow":""}">
      ${av(a.n)}<span class="nm">${esc(a.n)}</span>
      <select class="sel" data-a="cat" data-id="${esc(a.n)}">${CATS.map(c=>`<option value="${c[0]}" ${a.c===c[0]?"selected":""}>${t(c[1])}</option>`).join("")}</select>
      <label class="chk"><input type="checkbox" ${a.hide?"checked":""} data-a="hid" data-id="${esc(a.n)}"> ${t("hide")}</label>
      <button class="btn g s" data-a="rm" data-id="${esc(a.n)}">${t("clear")}</button>
    </div>`).join(""):`<p class="muted">${S.apps.length?t("none"):t("empty")}</p>`}</div>
  </div>`;
}

function viewSet(){
  const paused=S.tracker==="paused";
  return `<div class="wrap">
    <h1>${t("set")}</h1><p class="sub">${t("setS")}</p>
    <div class="grid c2">
      <div class="box"><h3>${t("lang")}</h3>${pills()}<p class="muted" style="font-size:13px;margin-top:12px">${t("langH")}</p></div>
      <div class="box"><h3>${t("about")}</h3>
        <div class="row">${paused?`<button class="btn" data-a="res">${t("cont")}</button>`
          :`<button class="btn g" data-a="pau">${t("p15")}</button><button class="btn g" data-a="pau">${t("p1")}</button><button class="btn d" data-a="pau">${t("p")}</button>`}</div>
        <p class="muted" style="font-size:13px;margin-top:10px">${t("idle")}</p>
        <p class="muted" style="font-size:13px">${t("login")}</p>
      </div>
      <div class="box"><h3>${t("data")}</h3>
        <div class="row" style="margin-bottom:10px"><button class="btn g s" data-a="json">${t("json")}</button><button class="btn g s" data-a="csv">${t("csv")}</button></div>
        <button class="btn d" data-a="wipe">${t("del")}</button>
        <p class="muted" style="font-size:13px;margin-top:12px">${t("priv")}</p>
      </div>
      <div class="box"><h3>${t("prev")}</h3>
        <p class="muted" style="font-size:13px;margin-bottom:12px">${t("demo")}</p>
        <div class="row"><button class="btn g s" data-a="replay">${t("intro")}</button><button class="btn g s" data-a="reset">${t("reset")}</button></div>
      </div>
    </div>${S.toast?`<p class="toast">${esc(S.toast)}</p>`:""}
  </div>`;
}

function viewRecs(){
  const today=S.period==="today";
  const items=today?[
    {t:"r1t",w:"r1w",n:"r1n"},
    {t:"r5t",w:"r5w",n:"r5n"},
    {t:"r4t",w:"r4w",n:"r4n"},
    {t:"r3t",w:"r3w",n:"r3n"}
  ]:[
    {t:"r1t",w:"r1w",n:"r1n"},
    {t:"r2t",w:"r2w",n:"r2n"},
    {t:"r3t",w:"r3w",n:"r3n"},
    {t:"r4t",w:"r4w",n:"r4n"}
  ];
  return `<div class="wrap">
    <h1 class="rise">${t("rT")}</h1><p class="sub rise">${t("rS")}</p>
    <div class="row" style="margin-bottom:18px">
      <button class="btn g s ${S.period==="today"?"on":""}" data-a="per" data-v="today">${t("today")}</button>
      <button class="btn g s ${S.period!=="today"?"on":""}" data-a="per" data-v="week">${t("week")}</button>
    </div>
    <div class="recs">${items.map((r,i)=>`<article class="rec rise">
      <div class="rec-n">${String(i+1).padStart(2,"0")}</div>
      <h2 class="rec-h">${t(r.t)}</h2>
      <div class="rec-k">${t("rWhy")}</div><p>${t(r.w)}</p>
      <div class="rec-k">${t("rDo")}</div><p class="rec-next">${t(r.n)}</p>
    </article>`).join("")}</div>
  </div>`;
}
function viewDbg(){
  return `<div class="wrap">
    <h1>${t("diag")}</h1><p class="sub">${t("hint")}</p>
    <div class="grid c2">
      <div class="box"><h3>${t("st")}</h3>
        <div class="ar"><span class="nm">${t("st")}</span><span class="du">${S.tracker}</span></div>
        <div class="ar"><span class="nm">${t("last")}</span><span class="du">16:41</span></div>
        <div class="ar"><span class="nm">${t("ev")}</span><span class="du">186</span></div>
      </div>
      <div class="box"><h3>${t("log")}</h3>
        <div class="row">
          <button class="btn g s" data-a="raw">${t("show")}</button>
          <button class="btn g s" data-a="fill">${t("fill")}</button>
          <button class="btn g s" data-a="sim" data-v="idle">${t("idleB")}</button>
          <button class="btn g s" data-a="sim" data-v="sleeping">${t("sleepB")}</button>
          <button class="btn g s" data-a="sim" data-v="active">${t("liveB")}</button>
        </div>
      </div>
    </div>
    <hr><div class="box"><table><tr><th>time</th><th>type</th><th>app</th></tr>
      <tr><td>09:00</td><td>app</td><td>VS Code</td></tr>
      <tr><td>09:12</td><td>app</td><td>Telegram</td></tr>
      <tr><td>09:12</td><td>app</td><td>VS Code</td></tr>
    </table></div>
    ${S.raw?`<pre class="box" style="margin-top:14px;overflow:auto;font-size:12px">${esc(JSON.stringify({apps:S.apps,tracker:S.tracker},null,2))}</pre>`:""}
  </div>`;
}

function shell(inner){
  return `<div class="app">
    <header class="top">
      <span class="brand"><img src="${ICON}" alt="">DskWrap</span>
      <div class="spacer"></div>
      <span class="pulse ${S.tracker}"></span>
      <button class="burger ${S.menu?"open":""}" data-a="menu" aria-label="${t("menu")}"><i></i><i></i><i></i></button>
    </header>
    ${S.menu?`<div class="sheet">
      <button class="dim" data-a="menu"></button>
      <aside class="panel-m">
        <div class="sheet-head"><img src="${ICON}" width="40" height="40" alt=""><div><div class="sheet-name">DskWrap</div><div class="sheet-line">${t("sub")}</div></div><button class="x" data-a="menu" aria-label="×">×</button></div>
        <nav class="sheet-nav">${nav.map((n,i)=>`${i===4?'<div class="rule"></div>':""}<button class="${S.page===n[0]?"on":""}" data-a="go" data-v="${n[0]}">${t(n[1])}</button>`).join("")}</nav>
      </aside>
    </div>`:""}
    <main class="main">${inner}</main>
  </div>`;
}

function reveal(){
  const root=document.querySelector(".main");
  if(!root) return;
  const nodes=[...root.querySelectorAll(".rise")];
  if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){ nodes.forEach(el=>el.classList.add("in")); return; }
  let cascade=0;
  const io=new IntersectionObserver((ents)=>{
    ents.filter(e=>e.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top).forEach(e=>{
      const el=e.target; io.unobserve(el);
      const late=e.boundingClientRect.top>root.clientHeight*0.58;
      const wait=late?50:cascade*72;
      if(!late) cascade+=1;
      setTimeout(()=>el.classList.add("in"), wait);
    });
  },{root,threshold:0.12,rootMargin:"0px 0px -8% 0px"});
  nodes.forEach(el=>io.observe(el));
}
function render(){
  const root=document.getElementById("root");
  if(!S.onboarded){ root.innerHTML=viewOnb(); bind(); return; }
  const inner=S.page==="dashboard"?viewDash():S.page==="wrapped"?viewWrap():S.page==="applications"?viewApps():S.page==="recs"?viewRecs():S.page==="settings"?viewSet():viewDbg();
  root.innerHTML=shell(inner); bind(); reveal(); bindSwipe();
}
function bindSwipe(){
  const el=document.getElementById("swipe");
  if(!el) return;
  let acc=0, lock=false, x0=null;
  const step=dir=>{
    if(lock) return;
    const n=Math.max(0,Math.min(6,S.card+dir));
    if(n===S.card) return;
    S.card=n; lock=true; acc=0; render();
    setTimeout(()=>lock=false,280);
  };
  el.addEventListener("wheel",e=>{
    const dx=e.deltaX+(e.shiftKey?e.deltaY:0);
    if(Math.abs(dx)<1.2) return;
    if(Math.abs(e.deltaY)>0 && Math.abs(dx)<Math.abs(e.deltaY)*0.55) return;
    e.preventDefault();
    acc+=dx;
    if(acc>42) step(1); else if(acc<-42) step(-1);
  },{passive:false});
  el.addEventListener("pointerdown",e=>{ x0=e.clientX; });
  el.addEventListener("pointerup",e=>{
    if(x0==null) return; const dx=e.clientX-x0; x0=null;
    if(Math.abs(dx)<48) return; step(dx<0?1:-1);
  });
}
function bind(){
  document.querySelectorAll("[data-a]").forEach(el=>{
    const a=el.getAttribute("data-a");
    if(el.tagName==="SELECT"){ el.onchange=e=>{const x=S.apps.find(z=>z.n===el.getAttribute("data-id")); if(x) x.c=e.target.value; render();}; return; }
    if(el.type==="checkbox"&&a==="hid"){ el.onchange=e=>{const x=S.apps.find(z=>z.n===el.getAttribute("data-id")); if(x) x.hide=e.target.checked; render();}; return; }
    if(el.type==="checkbox"&&a==="launch"){ el.onchange=e=>S.launch=e.target.checked; return; }
    el.onclick=()=>act(a,el);
  });
  const q=document.getElementById("q");
  if(q){ q.oninput=e=>{S.q=e.target.value; const pos=q.selectionStart; render(); const nq=document.getElementById("q"); if(nq){ nq.focus(); nq.setSelectionRange(pos,pos);} }; }
}
function act(a,el){
  const v=el.getAttribute("data-v"), id=el.getAttribute("data-id");
  if(a==="loc") S.locale=v;
  if(a==="menu") S.menu=!S.menu;
  if(a==="go"){ S.page=v; S.menu=false; }
  if(a==="per") S.period=v;
  if(a==="card") S.card=Math.max(0,Math.min(6,+v));
  if(a==="next") S.step=Math.min(2,S.step+1);
  if(a==="skip"){ S.ask=true; render(); return; }
  if(a==="lyes"){ S.launch=true; S.ask=false; S.onboarded=true; S.page="dashboard"; }
  if(a==="lno"){ S.launch=false; S.ask=false; S.onboarded=true; S.page="dashboard"; }
  if(a==="done"){ S.onboarded=true; S.page="dashboard"; }
  if(a==="replay"){ S.onboarded=false; S.step=0; S.menu=false; }
  if(a==="reset"){ S.apps=seed(); S.tracker="active"; S.toast=t("saved"); }
  if(a==="pau"){ S.tracker="paused"; S.toast=t("paused"); }
  if(a==="res"){ S.tracker="active"; S.toast=t("resumed"); }
  if(a==="sim") S.tracker=v;
  if(a==="fill"){ S.apps=seed(); S.tracker="active"; }
  if(a==="json"||a==="csv") S.toast=t("saved");
  if(a==="wipe"){ if(confirm(t("del"))) {S.apps=[]; S.toast=t("wiped");} }
  if(a==="rm") S.apps=S.apps.filter(x=>x.n!==id);
  if(a==="raw") S.raw=!S.raw;
  render();
}
document.addEventListener("keydown",e=>{
  if(e.key==="Escape"&&S.menu){S.menu=false;render();}
  if(S.page==="wrapped"&&S.onboarded){ if(e.key==="ArrowRight"){S.card=Math.min(6,S.card+1);render();} if(e.key==="ArrowLeft"){S.card=Math.max(0,S.card-1);render();} }
});
render();
</script>
</body>
</html>
"""

out = ROOT / "preview.html"
out.write_text(HTML.replace("__ICON__", ICON), encoding="utf-8")
print(f"wrote {out} ({out.stat().st_size} bytes)")

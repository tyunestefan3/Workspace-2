#!/usr/bin/env python3
"""Generate Tauri / macOS / Windows / iOS / Android icons from the source mark.

Source preference:
  1) scripts/../app-icon-source.jpeg (or the uploaded photo)
  2) app-icon.png

Writes:
  app-icon.png                          1024×1024 master
  src-tauri/icons/icon.icns             macOS
  src-tauri/icons/icon.ico              Windows
  src-tauri/icons/*.png                 Tauri + Store logos
  src-tauri/icons/ios/*.png
  src-tauri/icons/android/mipmap-*/**.png
"""

from __future__ import annotations

import struct
import sys
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ICONS = ROOT / "src-tauri" / "icons"
UPLOAD = Path("/home/user/uploads/photo-output.jpeg")


def load_source() -> Image.Image:
    candidates = [
        UPLOAD,
        ROOT / "app-icon-source.jpeg",
        ROOT / "app-icon.png",
    ]
    src = next((p for p in candidates if p.exists()), None)
    if src is None:
        sys.exit("no source image found")
    print(f"source: {src}")
    im = Image.open(src).convert("RGBA")
    # Snap JPEG mush to true black / true white so the mark stays crisp at 16px.
    px = im.load()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if r < 14 and g < 14 and b < 14:
                px[x, y] = (0, 0, 0, 255)
            elif r > 238 and g > 238 and b > 238:
                px[x, y] = (255, 255, 255, 255)
    # Square crop (centred) then 1024 master.
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    im = im.crop((left, top, left + side, top + side))
    return im.resize((1024, 1024), Image.Resampling.LANCZOS)


def save_png(im: Image.Image, path: Path, size: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    resized = im.resize((size, size), Image.Resampling.LANCZOS)
    resized.save(path, format="PNG", optimize=True)


def png_bytes(im: Image.Image, size: int) -> bytes:
    import io

    buf = io.BytesIO()
    im.resize((size, size), Image.Resampling.LANCZOS).save(buf, format="PNG", optimize=True)
    return buf.getvalue()


def write_icns(im: Image.Image, path: Path) -> None:
    # PNG-compressed ICNS (macOS 10.7+). Types match what `tauri icon` emits.
    entries = {
        b"icp4": 16,
        b"icp5": 32,
        b"icp6": 64,
        b"ic07": 128,
        b"ic08": 256,
        b"ic09": 512,
        b"ic10": 1024,
        b"ic11": 32,   # 16@2x
        b"ic12": 64,   # 32@2x
        b"ic13": 256,  # 128@2x
        b"ic14": 512,  # 256@2x
    }
    chunks: list[bytes] = []
    for ostype, size in entries.items():
        data = png_bytes(im, size)
        chunks.append(ostype + struct.pack(">I", 8 + len(data)) + data)
    body = b"".join(chunks)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"icns" + struct.pack(">I", 8 + len(body)) + body)
    print(f"  icns {path} ({path.stat().st_size} bytes)")


def write_ico(im: Image.Image, path: Path) -> None:
    # Multi-size ICO with embedded PNGs (Vista+). Pillow on this image
    # otherwise collapses to a single 16×16 entry.
    sizes = [16, 24, 32, 48, 64, 128, 256]
    blobs = [png_bytes(im, s) for s in sizes]
    offset = 6 + 16 * len(sizes)
    entries = []
    body = b""
    for size, blob in zip(sizes, blobs):
        w = 0 if size >= 256 else size
        h = 0 if size >= 256 else size
        entries.append(struct.pack("<BBBBHHII", w, h, 0, 0, 1, 32, len(blob), offset))
        offset += len(blob)
        body += blob
    header = struct.pack("<HHH", 0, 1, len(sizes))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(header + b"".join(entries) + body)
    print(f"  ico  {path} ({path.stat().st_size} bytes)")


def main() -> None:
    master = load_source()
    master_path = ROOT / "app-icon.png"
    master.save(master_path, format="PNG", optimize=True)
    print(f"  master {master_path} {master.size}")

    # Core Tauri / macOS / Windows set referenced by tauri.conf.json
    for name, size in {
        "32x32.png": 32,
        "64x64.png": 64,
        "128x128.png": 128,
        "128x128@2x.png": 256,
        "icon.png": 1024,
        "StoreLogo.png": 50,
        "Square30x30Logo.png": 30,
        "Square44x44Logo.png": 44,
        "Square71x71Logo.png": 71,
        "Square89x89Logo.png": 89,
        "Square107x107Logo.png": 107,
        "Square142x142Logo.png": 142,
        "Square150x150Logo.png": 150,
        "Square284x284Logo.png": 284,
        "Square310x310Logo.png": 310,
    }.items():
        save_png(master, ICONS / name, size)

    write_icns(master, ICONS / "icon.icns")
    write_ico(master, ICONS / "icon.ico")

    ios = {
        "AppIcon-20x20@1x.png": 20,
        "AppIcon-20x20@2x.png": 40,
        "AppIcon-20x20@2x-1.png": 40,
        "AppIcon-20x20@3x.png": 60,
        "AppIcon-29x29@1x.png": 29,
        "AppIcon-29x29@2x.png": 58,
        "AppIcon-29x29@2x-1.png": 58,
        "AppIcon-29x29@3x.png": 87,
        "AppIcon-40x40@1x.png": 40,
        "AppIcon-40x40@2x.png": 80,
        "AppIcon-40x40@2x-1.png": 80,
        "AppIcon-40x40@3x.png": 120,
        "AppIcon-60x60@2x.png": 120,
        "AppIcon-60x60@3x.png": 180,
        "AppIcon-76x76@1x.png": 76,
        "AppIcon-76x76@2x.png": 152,
        "AppIcon-83.5x83.5@2x.png": 167,
        "AppIcon-512@2x.png": 1024,
    }
    for name, size in ios.items():
        save_png(master, ICONS / "ios" / name, size)

    android = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192,
    }
    fg = {
        "mipmap-mdpi": 108,
        "mipmap-hdpi": 162,
        "mipmap-xhdpi": 216,
        "mipmap-xxhdpi": 324,
        "mipmap-xxxhdpi": 432,
    }
    for folder, size in android.items():
        d = ICONS / "android" / folder
        save_png(master, d / "ic_launcher.png", size)
        save_png(master, d / "ic_launcher_round.png", size)
        save_png(master, d / "ic_launcher_foreground.png", fg[folder])

    print("icons ready")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Plain DMG field — no art. Finder draws the icons."""
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "src-tauri" / "images" / "dmg-background.png"
LW, LH = 720, 480
COLOR = (7, 7, 8, 255)


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGBA", (LW, LH), COLOR)
    img.save(OUT, format="PNG", optimize=True)
    img2 = Image.new("RGBA", (LW * 2, LH * 2), COLOR)
    img2.save(OUT.with_name("dmg-background@2x.png"), format="PNG", optimize=True)
    print(f"wrote {OUT} {img.size}")


if __name__ == "__main__":
    main()

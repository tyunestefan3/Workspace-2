#!/bin/zsh
# Совместимость со старым именем. Сборка: zsh scripts/build-dskwrap.command
cd "$(dirname "$0")/.."
exec zsh scripts/build-dskwrap.command

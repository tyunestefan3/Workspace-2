//! Unit tests for the tracker state machine (§11, §56). Pure logic — no OS.

use desktop_wrapped::models::{EventType, TrackerConfig};
use desktop_wrapped::{Tracker, TrackerMessage, TrackerState};

fn cfg() -> TrackerConfig {
    let mut c = TrackerConfig::default();
    c.self_bundle_id = "desktopwrapped".to_string();
    c
}

fn types(events: &[desktop_wrapped::Event]) -> Vec<EventType> {
    events.iter().map(|e| e.event_type).collect()
}

#[test]
fn start_records_tracker_start_and_app_active() {
    let c = cfg();
    let mut t = Tracker::default();
    let ev = t.start(1000, Some("vscode".into()), &c);
    assert_eq!(types(&ev), vec![EventType::TrackerStart, EventType::AppActive]);
    assert_eq!(t.state, TrackerState::Active { bundle_id: "vscode".into() });
    assert_eq!(ev[1].bundle_id.as_deref(), Some("vscode"));
}

#[test]
fn start_ignored_app_goes_private() {
    let c = cfg();
    let mut t = Tracker::default();
    let ev = t.start(1000, Some("desktopwrapped".into()), &c);
    assert_eq!(types(&ev), vec![EventType::TrackerStart]); // not app_active for self
    assert_eq!(t.state, TrackerState::Private);
}

#[test]
fn duplicate_activation_is_noop() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1000, Some("vscode".into()), &c);
    let ev = t.on(TrackerMessage::AppActivated("vscode".into()), 5000, &c);
    assert!(ev.is_empty());
    assert_eq!(t.state, TrackerState::Active { bundle_id: "vscode".into() });
}

#[test]
fn switch_records_new_app_active() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1000, Some("vscode".into()), &c);
    let ev = t.on(TrackerMessage::AppActivated("telegram".into()), 2000, &c);
    assert_eq!(types(&ev), vec![EventType::AppActive]);
    assert_eq!(ev[0].bundle_id.as_deref(), Some("telegram"));
}

#[test]
fn ignored_app_enters_private_then_allowed_records() {
    let c = cfg(); // "1password" not pre-ignored; use self to test ignored
    let mut t = Tracker::default();
    let _ = t.start(1000, Some("vscode".into()), &c);
    // Go to an ignored app (self).
    let ev1 = t.on(TrackerMessage::AppActivated("desktopwrapped".into()), 2000, &c);
    assert_eq!(types(&ev1), vec![EventType::AppActive]);
    assert_eq!(ev1[0].bundle_id.as_deref(), Some("desktopwrapped"));
    assert_eq!(t.state, TrackerState::Private);
    // Return to allowed app.
    let ev2 = t.on(TrackerMessage::AppActivated("vscode".into()), 3000, &c);
    assert_eq!(types(&ev2), vec![EventType::AppActive]);
    assert_eq!(ev2[0].bundle_id.as_deref(), Some("vscode"));
    assert_eq!(t.state, TrackerState::Active { bundle_id: "vscode".into() });
}

#[test]
fn idle_start_is_backdated_from_now_minus_idle() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1_000_000, Some("vscode".into()), &c);
    // at 2_000_000 we detect idle of 300_000ms → idle_start should be 1_700_000.
    let ev = t.on(TrackerMessage::IdleDetected { idle_ms: 300_000 }, 2_000_000, &c);
    assert_eq!(types(&ev), vec![EventType::IdleStart]);
    assert_eq!(ev[0].timestamp_ms, 1_700_000);
    assert_eq!(t.state, TrackerState::Idle);
}

#[test]
fn user_returned_records_idle_end_and_app_active() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1_000_000, Some("vscode".into()), &c);
    let _ = t.on(TrackerMessage::IdleDetected { idle_ms: 300_000 }, 2_000_000, &c);
    let ev = t.on(
        TrackerMessage::UserReturned { foreground: Some("chrome".into()) },
        3_000_000,
        &c,
    );
    assert_eq!(types(&ev), vec![EventType::IdleEnd, EventType::AppActive]);
    assert_eq!(ev[1].bundle_id.as_deref(), Some("chrome"));
    assert_eq!(t.state, TrackerState::Active { bundle_id: "chrome".into() });
}

#[test]
fn sleep_wake_transitions() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1000, Some("vscode".into()), &c);
    let ev = t.on(TrackerMessage::Sleep, 2000, &c);
    assert_eq!(types(&ev), vec![EventType::Sleep]);
    assert_eq!(t.state, TrackerState::Sleeping);
    let ev = t.on(TrackerMessage::Wake, 3_000_000, &c);
    assert_eq!(types(&ev), vec![EventType::Wake]);
    assert_eq!(t.state, TrackerState::Idle); // foreground arrives as AppActivated
    let ev = t.on(TrackerMessage::AppActivated("vscode".into()), 3_000_001, &c);
    assert_eq!(types(&ev), vec![EventType::AppActive]);
    assert_eq!(t.state, TrackerState::Active { bundle_id: "vscode".into() });
}

#[test]
fn pause_resume_transitions() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1000, Some("vscode".into()), &c);
    let ev = t.on(TrackerMessage::Pause, 2000, &c);
    assert_eq!(types(&ev), vec![EventType::Pause]);
    assert_eq!(t.state, TrackerState::Paused);
    let ev = t.on(TrackerMessage::Resume, 5000, &c);
    assert_eq!(types(&ev), vec![EventType::Resume]);
    assert_eq!(t.state, TrackerState::Idle);
}

#[test]
fn loginwindow_is_sleep_not_an_app() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1000, Some("vscode".into()), &c);
    let ev = t.on(TrackerMessage::AppActivated("com.apple.loginwindow".into()), 2000, &c);
    assert_eq!(types(&ev), vec![EventType::Sleep]);
    assert_eq!(t.state, TrackerState::Sleeping);
    let ev = t.on(TrackerMessage::AppActivated("com.apple.loginwindow".into()), 3000, &c);
    assert!(ev.is_empty());
    let ev = t.on(TrackerMessage::AppActivated("vscode".into()), 4000, &c);
    assert_eq!(types(&ev), vec![EventType::AppActive]);
    assert_eq!(t.state, TrackerState::Active { bundle_id: "vscode".into() });
}

#[test]
fn start_on_loginwindow_does_not_track() {
    let c = cfg();
    let mut t = Tracker::default();
    let ev = t.start(1000, Some("loginwindow".into()), &c);
    assert_eq!(types(&ev), vec![EventType::TrackerStart]);
    assert_eq!(t.state, TrackerState::Sleeping);
}

#[test]
fn shutdown_emits_tracker_stop() {
    let c = cfg();
    let mut t = Tracker::default();
    let _ = t.start(1000, Some("vscode".into()), &c);
    let ev = t.on(TrackerMessage::Shutdown, 9000, &c);
    assert_eq!(types(&ev), vec![EventType::TrackerStop]);
}

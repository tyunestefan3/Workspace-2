//! Integration tests for the core: reconstruction + analytics + insights.
//! The expected values below are the *specified* semantics (§28–§37), so this
//! is where we lock in the fixes from the review.

use std::collections::BTreeMap;

use desktop_wrapped::analytics::compute_period;
use desktop_wrapped::fixtures;
use desktop_wrapped::models::{AppCategory, Event, EventType, TrackerConfig};
use desktop_wrapped::reconstruct::{category_map, reconstruct_sessions};
use desktop_wrapped::{TimeRange, fmt_duration};

fn cfg(mut c: TrackerConfig) -> TrackerConfig {
    c.self_bundle_id = "desktopwrapped".to_string();
    c
}

fn focus_cats() -> BTreeMap<String, AppCategory> {
    let mut m = BTreeMap::new();
    m.insert("vscode".to_string(), AppCategory::Focus);
    m.insert("terminal".to_string(), AppCategory::Focus);
    m.insert("telegram".to_string(), AppCategory::Communication);
    m.insert("slack".to_string(), AppCategory::Communication);
    m.insert("chrome".to_string(), AppCategory::Neutral);
    m.insert("youtube".to_string(), AppCategory::Entertainment);
    m
}

/// §60: switch count, checks, quick visits.
#[test]
fn switch_check_quick_visit() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 30 * 60_000, EventType::AppActive, Some("telegram")),
        Event::new(start + 30 * 60_000 + 20_000, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 2 * fixtures::HOUR_MS };
    let s = reconstruct_sessions(&events, &cfg(TrackerConfig::default()), range);
    assert_eq!(s.len(), 3);
    // vscode first session 30m; vscode last session 1h29m40s.
    let vscode_ms: i64 = s.iter().filter(|x| x.bundle_id == "vscode").map(|x| x.duration_ms()).sum();
    assert_eq!(vscode_ms, 30 * 60_000 + (2 * fixtures::HOUR_MS - (30 * 60_000 + 20_000)));
    let m = compute_period(&s, &focus_cats(), &cfg(TrackerConfig::default()), range);
    assert_eq!(m.switches, 2);
    assert_eq!(m.checks_per_app.get("telegram"), Some(&1));
    assert_eq!(m.checks, 1);
    assert_eq!(m.quick_visits, 1);
    assert_eq!(m.focus_seconds_ms, vscode_ms);
}

/// §58: duplicate app_active (notification + reconciliation) must not create a
/// new session.
#[test]
fn duplicate_events_collapse() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 5_000, EventType::AppActive, Some("vscode")),
        Event::new(start + 60_000, EventType::AppActive, Some("telegram")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + fixtures::HOUR_MS };
    let s = reconstruct_sessions(&events, &cfg(TrackerConfig::default()), range);
    assert_eq!(s.len(), 2);
    let m = compute_period(&s, &focus_cats(), &cfg(TrackerConfig::default()), range);
    assert_eq!(m.switches, 1);
}

/// §12/§20: idle time must never be attributed to an app.
#[test]
fn idle_excluded() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 30 * 60_000, EventType::AppActive, Some("vscode")),
        Event::new(start + 40 * 60_000, EventType::IdleStart, None),
        Event::new(start + 52 * 60_000, EventType::IdleEnd, None),
        Event::new(start + 52 * 60_000, EventType::AppActive, Some("chrome")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + fixtures::HOUR_MS };
    let s = reconstruct_sessions(&events, &cfg(TrackerConfig::default()), range);
    // vscode session closes at idle_start (40m); chrome from 52m.
    assert_eq!(s.iter().find(|x| x.bundle_id == "vscode").unwrap().duration_ms(), 40 * 60_000);
    let m = compute_period(&s, &focus_cats(), &cfg(TrackerConfig::default()), range);
    assert_eq!(m.tracked_ms, 40 * 60_000 + (fixtures::HOUR_MS - 52 * 60_000));
}

/// §15: sleep/wake must not be counted as app usage.
#[test]
fn sleep_wake_excluded() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 60 * 60_000, EventType::Sleep, None),
        Event::new(start + 6 * fixtures::HOUR_MS, EventType::Wake, None),
        Event::new(start + 6 * fixtures::HOUR_MS, EventType::AppActive, Some("chrome")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 8 * fixtures::HOUR_MS };
    let s = reconstruct_sessions(&events, &cfg(TrackerConfig::default()), range);
    assert_eq!(s.iter().find(|x| x.bundle_id == "vscode").unwrap().duration_ms(), 60 * 60_000);
    // The 5h sleep gap is not tracked.
    assert_eq!(s.len(), 2);
}

/// §18: an open session must be closed at the crash cutoff (heartbeat), not at
/// the window end, so we never fabricate time after the machine died.
#[test]
fn crash_tail_not_fabricated() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 10 * 60_000, EventType::AppActive, Some("vscode")),
        // nothing after — the process died.
    ];
    let heartbeat = start + 12 * 60_000; // last confirmed alive moment
    let range = TimeRange { start_ms: start, end_ms: heartbeat };
    let s = reconstruct_sessions(&events, &cfg(TrackerConfig::default()), range);
    assert_eq!(s.len(), 1);
    assert_eq!(s[0].duration_ms(), 12 * 60_000); // closes at heartbeat, not window end
}

/// §31: a short allowed interruption must not break a focus block, and its
/// seconds must not be added to focus time. A long one must break the block.
#[test]
fn focus_block_interruption_rules() {
    let start = 9 * fixtures::HOUR_MS;
    // 15s telegram (allowed, <= 30s) does not break; 5m chrome breaks.
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 10 * 60_000, EventType::AppActive, Some("telegram")),
        Event::new(start + 10 * 60_000 + 15_000, EventType::AppActive, Some("vscode")),
        Event::new(start + 20 * 60_000, EventType::AppActive, Some("chrome")),
        Event::new(start + 25 * 60_000, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 60 * 60_000 };
    let c = cfg(TrackerConfig::default());
    let s = reconstruct_sessions(&events, &c, range);
    let m = compute_period(&s, &focus_cats(), &c, range);
    // focus seconds = vscode 10m + vscode (09:10:15→09:20)=9m45s + vscode (09:25→10:00)=35m
    // = 54m45s. (Telegram's 15s is an allowed interruption, not focus time.)
    assert_eq!(m.focus_seconds_ms, 3_285_000);
    // blocks: [vscode+tg+vscode]=20m, then [vscode]=35m => longest 35m.
    assert_eq!(m.longest_focus_ms, 35 * 60_000);
    // telegram's 15s was a check and a quick visit, but not focus time.
    assert_eq!(m.checks_per_app.get("telegram"), Some(&1));
}

/// §31: a 60s telegram (exceeding the 30s tolerance) breaks the block.
#[test]
fn focus_block_long_interruption_breaks() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 10 * 60_000, EventType::AppActive, Some("telegram")),
        Event::new(start + 11 * 60_000, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 60 * 60_000 };
    let c = cfg(TrackerConfig::default());
    let s = reconstruct_sessions(&events, &c, range);
    let m = compute_period(&s, &focus_cats(), &c, range);
    // two separate blocks: 10m and (60m-11m)=49m => longest 49m.
    assert_eq!(m.focus_blocks.len(), 2);
    assert_eq!(m.longest_focus_ms, 49 * 60_000);
}

/// §37: recovery time from leaving focus to returning, attributed to the
/// distractor app.
#[test]
fn recovery_time() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 5 * 60_000, EventType::AppActive, Some("chrome")),
        Event::new(start + 10 * 60_000, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 60 * 60_000 };
    let c = cfg(TrackerConfig::default());
    let s = reconstruct_sessions(&events, &c, range);
    let m = compute_period(&s, &focus_cats(), &c, range);
    // One recovery of 5m, distractor chrome.
    assert_eq!(m.recovery.samples, 1);
    assert_eq!(m.recovery.by_distractor.get("chrome").unwrap().count, 1);
    assert_eq!(m.recovery.overall_avg_ms(), Some(5 * 60_000));
}

/// loginwindow / lock screen must never become a session, and must close the previous app.
#[test]
fn loginwindow_is_not_an_app() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 10 * 60_000, EventType::AppActive, Some("com.apple.loginwindow")),
        Event::new(start + 4 * fixtures::HOUR_MS, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 5 * fixtures::HOUR_MS };
    let s = reconstruct_sessions(&events, &cfg(TrackerConfig::default()), range);
    assert!(s.iter().all(|x| !x.bundle_id.to_ascii_lowercase().contains("loginwindow")));
    assert_eq!(s.len(), 2);
    assert_eq!(s[0].duration_ms(), 10 * 60_000);
    // The hours at the login window are a gap, not vscode and not loginwindow.
    assert_eq!(s[1].started_at_ms, start + 4 * fixtures::HOUR_MS);
}

/// Sleep from a power-off must not be given to the last app.
#[test]
fn sleep_after_app_is_a_gap() {
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 20 * 60_000, EventType::Sleep, None),
        Event::new(start + 8 * fixtures::HOUR_MS, EventType::Wake, None),
        Event::new(start + 8 * fixtures::HOUR_MS, EventType::AppActive, Some("safari")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 10 * fixtures::HOUR_MS };
    let s = reconstruct_sessions(&events, &cfg(TrackerConfig::default()), range);
    assert_eq!(s.iter().find(|x| x.bundle_id == "vscode").unwrap().duration_ms(), 20 * 60_000);
    assert!(s.iter().all(|x| x.bundle_id != "loginwindow"));
}

/// §25: an ignored app produces no session and must not count as a switch.
#[test]
fn ignored_app_no_session() {
    let start = 9 * fixtures::HOUR_MS;
    let mut c = cfg(TrackerConfig::default());
    c.ignore_bundle_ids.push("1password".to_string());
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 10 * 60_000, EventType::AppActive, Some("1password")),
        Event::new(start + 12 * 60_000, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 60 * 60_000 };
    let s = reconstruct_sessions(&events, &c, range);
    assert_eq!(s.len(), 2);
    assert!(s.iter().all(|x| x.bundle_id != "1password"));
    let m = compute_period(&s, &focus_cats(), &c, range);
    assert_eq!(m.switches, 0); // vscode -> vscode is not a switch
}

/// §36: most common n-gram loop.
#[test]
fn common_loop() {
    let start = 9 * fixtures::HOUR_MS;
    let mut events = Vec::new();
    for i in 0..3 {
        events.push(Event::new(start + i as i64 * 60_000, EventType::AppActive, Some("vscode")));
        events.push(Event::new(start + i as i64 * 60_000 + 5_000, EventType::AppActive, Some("telegram")));
        events.push(Event::new(start + i as i64 * 60_000 + 10_000, EventType::AppActive, Some("vscode")));
    }
    let range = TimeRange { start_ms: start, end_ms: start + 10 * 60_000 };
    let c = cfg(TrackerConfig::default());
    let s = reconstruct_sessions(&events, &c, range);
    let m = compute_period(&s, &focus_cats(), &c, range);
    let (seq, count) = m.most_common_ngram.unwrap();
    assert_eq!(seq, vec!["vscode".to_string(), "telegram".to_string(), "vscode".to_string()]);
    assert_eq!(count, 3);
}

/// §41: a pure deep-work day classifies as a Deep Diver.
#[test]
fn personality_deep_diver() {
    use desktop_wrapped::personality::{classify, MacType};
    let start = 9 * fixtures::HOUR_MS;
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 60 * 60_000, EventType::AppActive, Some("terminal")),
        Event::new(start + 2 * 60 * 60_000, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 3 * 60 * 60_000 };
    let c = cfg(TrackerConfig::default());
    let s = reconstruct_sessions(&events, &c, range);
    let m = compute_period(&s, &focus_cats(), &c, range);
    assert_eq!(classify(&m, &focus_cats()), MacType::DeepDiver);
}

/// End-to-end: put a synthetic week through SQLite and back, then run analytics.
#[test]
fn db_roundtrip_and_analytics() {
    let path = std::env::temp_dir().join("dw_core_test.sqlite");
    let _ = std::fs::remove_file(&path);
    {
        let mut conn = desktop_wrapped::db::open(&path).unwrap();
        for app in fixtures::default_apps() {
            desktop_wrapped::db::upsert_app(&conn, &app).unwrap();
        }
        // Add a tracker self-record to prove it's excluded from sessions.
        let week = fixtures::week(1_800_000_000_000);
        for e in week.iter().take(50) {
            desktop_wrapped::db::insert_event(&mut conn, e).unwrap();
        }
    }
    let conn = desktop_wrapped::db::open(&path).unwrap();
    let (s, e) = desktop_wrapped::db::event_extent(&conn).unwrap().unwrap();
    let range = TimeRange { start_ms: s, end_ms: e };
    let apps = desktop_wrapped::db::apps(&conn).unwrap();
    let cats = category_map(&apps);
    let evs = desktop_wrapped::db::events_in_range(&conn, s, e).unwrap();
    let c = cfg(TrackerConfig::default());
    let sessions = reconstruct_sessions(&evs, &c, range);
    assert!(!sessions.is_empty());
    let m = compute_period(&sessions, &cats, &c, range);
    assert!(m.tracked_ms > 0);
    assert!(m.switches > 0);
    assert!(fmt_duration(m.tracked_ms).contains("h"));
    let _ = std::fs::remove_file(&path);
}

/// §40: the Weekly Wrapped deck is built from the verified analytics and only
/// includes cards with enough evidence.
#[test]
fn weekly_wrapped_deck() {
    use desktop_wrapped::wrapped::{weekly, WrappedCard};
    let start = 9 * fixtures::HOUR_MS;
    let events = fixtures::rich_day(start);
    let range = TimeRange { start_ms: start, end_ms: start + 24 * fixtures::HOUR_MS };
    let c = cfg(TrackerConfig::default());
    let sessions = reconstruct_sessions(&events, &c, range);
    let m = compute_period(&sessions, &focus_cats(), &c, range);
    let apps = fixtures::default_apps();
    let cat = category_map(&apps);
    let mac = desktop_wrapped::personality::classify(&m, &cat);
    let deck = weekly(&m, &apps, &c, mac, range.start_ms, range.end_ms);
    assert!(deck.cards.len() >= 5);
    assert!(deck.cards.iter().any(|c| matches!(c, WrappedCard::YourWeek { .. })));
    assert!(deck.cards.iter().any(|c| matches!(c, WrappedCard::MainCharacter { .. })));
    assert!(deck.cards.iter().any(|c| matches!(c, WrappedCard::YourLoop { .. })));
    // The deck ends with the personality card.
    assert!(matches!(deck.cards.last(), Some(WrappedCard::MacType { .. })));
}

/// §40: no "loud" card from a single observation.
#[test]
fn weekly_wrapped_respects_min_samples() {
    use desktop_wrapped::wrapped::{weekly, WrappedCard};
    let start = 9 * fixtures::HOUR_MS;
    // One telegram check only — below min_samples.
    let events = vec![
        Event::new(start, EventType::AppActive, Some("vscode")),
        Event::new(start + 60_000, EventType::AppActive, Some("telegram")),
        Event::new(start + 75_000, EventType::AppActive, Some("vscode")),
    ];
    let range = TimeRange { start_ms: start, end_ms: start + 2 * fixtures::HOUR_MS };
    let c = cfg(TrackerConfig::default());
    let sessions = reconstruct_sessions(&events, &c, range);
    let m = compute_period(&sessions, &focus_cats(), &c, range);
    let apps = fixtures::default_apps();
    let cat = category_map(&apps);
    let mac = desktop_wrapped::personality::classify(&m, &cat);
    let deck = weekly(&m, &apps, &c, mac, range.start_ms, range.end_ms);
    // CantResist should NOT appear (1 check < min_samples=3).
    assert!(!deck.cards.iter().any(|c| matches!(c, WrappedCard::CantResist { .. })));
}

/// §50/§51: export then wipe then per-app delete.
#[test]
fn export_and_delete() {
    use desktop_wrapped::export as ex;
    let path = std::env::temp_dir().join("dw_export_test.sqlite");
    let _ = std::fs::remove_file(&path);
    {
        let mut conn = desktop_wrapped::db::open(&path).unwrap();
        let events = fixtures::week(1_800_000_000_000);
        for e in events.iter().take(40) {
            desktop_wrapped::db::insert_event(&mut conn, e).unwrap();
        }
    }
    let conn = desktop_wrapped::db::open(&path).unwrap();
    let json = ex::export_json(&conn).unwrap();
    assert!(json.contains("\"events\""));
    assert!(json.contains("\"apps\""));
    let csv = ex::export_csv(&conn).unwrap();
    assert!(csv.starts_with("timestamp_ms,event_type,bundle_id\n"));
    assert!(csv.lines().count() >= 2);

    // Per-app delete only removes that app's events.
    let before = desktop_wrapped::db::count_events(&conn).unwrap();
    let deleted = desktop_wrapped::db::delete_app_events(&conn, fixtures::VSCODE).unwrap();
    let after = desktop_wrapped::db::count_events(&conn).unwrap();
    assert!(deleted > 0);
    assert_eq!(after, before - deleted as i64);

    // Delete all.
    desktop_wrapped::db::delete_all_data(&conn).unwrap();
    assert_eq!(desktop_wrapped::db::count_events(&conn).unwrap(), 0);
    let _ = std::fs::remove_file(&path);
}

/// §27 / §49: period presets resolve to monotonic, non-empty window.
#[test]
fn period_presets() {
    use desktop_wrapped::period::{Period, resolve};
    let now = 1_800_000_000_000; // arbitrary instant
    for p in [Period::Today, Period::Yesterday, Period::Week, Period::Month] {
        let r = resolve(now, p);
        assert!(r.end_ms > r.start_ms, "{} should be non-empty", p.label());
    }
    let week = resolve(now, Period::Week);
    let month = resolve(now, Period::Month);
    // This week is 7 days; month covers it.
    assert!(week.end_ms - week.start_ms >= 7 * fixtures::DAY_MS - 1);
    assert!(month.end_ms - month.start_ms >= week.end_ms - week.start_ms);
}

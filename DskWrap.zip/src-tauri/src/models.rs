//! Domain model: the immutable event log and everything derived from it.
//!
//! This is the boundary the spec cares most about (§3, §75). `Event` is the
//! source of truth. Everything above it (`Session`, metrics, insights) is
//! derived and must be re-buildable from events at any time.

use serde::{Deserialize, Serialize};

/// The kinds of raw events the tracker can persist (§7).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EventType {
    TrackerStart,
    TrackerStop,
    AppActive,
    IdleStart,
    IdleEnd,
    Sleep,
    Wake,
    Pause,
    Resume,
}

/// One immutable row of the event log. Timestamps are UTC unix milliseconds.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Event {
    pub timestamp_ms: i64,
    pub event_type: EventType,
    #[serde(default)]
    pub bundle_id: Option<String>,
}

impl Event {
    pub fn new(timestamp_ms: i64, event_type: EventType, bundle_id: Option<&str>) -> Self {
        Self {
            timestamp_ms,
            event_type,
            bundle_id: bundle_id.map(str::to_string),
        }
    }
}

/// User-assignable category for an app (§23). `Ignored` means the tracker
/// stops recording it entirely (§25).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AppCategory {
    Focus,
    Communication,
    Entertainment,
    Utility,
    Neutral,
    Ignored,
}

/// Metadata about an application (its category/ignore state). Stored in `apps`
/// table; the user is always able to override the shipped default (§24).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppRecord {
    pub bundle_id: String,
    pub display_name: String,
    pub category: AppCategory,
    pub ignored: bool,
}

/// A contiguous window during which a single app was in the foreground,
/// with idle / sleep / pause / private time excluded (§20).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Session {
    pub bundle_id: String,
    pub started_at_ms: i64,
    pub ended_at_ms: i64,
}

impl Session {
    pub fn duration_ms(&self) -> i64 {
        self.ended_at_ms - self.started_at_ms
    }
}

/// Everything the analytics engine needs to be deterministic about an app.
#[derive(Debug, Clone)]
pub struct TrackerConfig {
    /// treat the app's own bundle id as a non-event (fix #1 in the critique).
    pub self_bundle_id: String,
    /// bundle ids to ignore by default (noise/private).
    pub ignore_bundle_ids: Vec<String>,
    /// milliseconds of no keyboard/mouse input before we consider the user idle.
    pub idle_threshold_ms: i64,
    /// a communication/etc visit at or below this length does not break a focus block.
    pub interruption_tol_ms: i64,
    /// a session at or below this length counts as a quick visit (§29).
    pub quick_visit_tol_ms: i64,
    /// a "check" is prev==next and middle <= this (§30).
    pub check_tol_ms: i64,
    /// categories that may interrupt a focus block without breaking it (§31).
    pub allowed_interrupt_categories: Vec<AppCategory>,
    /// ignore recoveries longer than this; a gap that long is a real break.
    pub max_recovery_ms: i64,
    /// minimum samples for a behavioral insight to be surfaced (§38).
    pub min_samples: u32,
}

impl Default for TrackerConfig {
    fn default() -> Self {
        Self {
            self_bundle_id: "com.dskwrap.app".to_string(),
            ignore_bundle_ids: vec![],
            idle_threshold_ms: 5 * 60 * 1000,
            interruption_tol_ms: 30 * 1000,
            quick_visit_tol_ms: 60 * 1000,
            check_tol_ms: 60 * 1000,
            allowed_interrupt_categories: vec![
                AppCategory::Communication,
                AppCategory::Entertainment,
                AppCategory::Neutral,
            ],
            max_recovery_ms: 30 * 60 * 1000,
            min_samples: 3,
        }
    }
}

//! Insight Engine (§39–§41). Takes numbers and picks interesting facts.
//! Deterministic templates, no LLM. Every insight carries a confidence and a
//! sample count so the UI can decide *not* to shout something from one sample.

use crate::analytics::PeriodMetrics;
use crate::models::TrackerConfig;

#[derive(Debug, Clone)]
pub struct Insight {
    pub kind: String,
    pub confidence: f32,
    pub sample_count: u32,
    pub text: String,
}

fn conf(samples: u32, min: u32) -> f32 {
    if samples >= min * 4 {
        1.0
    } else {
        (samples as f32 / (min * 4) as f32).clamp(0.0, 1.0)
    }
}

fn fmt_dur(ms: i64) -> String {
    let sec = ms / 1000;
    let m = sec / 60;
    let s = sec % 60;
    if m >= 60 {
        let h = m / 60;
        let mm = m % 60;
        format!("{}h {:02}m", h, mm)
    } else if m > 0 {
        format!("{}m", m)
    } else {
        format!("{}s", s)
    }
}

pub fn generate(metrics: &PeriodMetrics, config: &TrackerConfig) -> Vec<Insight> {
    let mut out = Vec::new();

    // MOST CHECKED APP
    if let Some((app, count)) = metrics
        .checks_per_app
        .iter()
        .max_by_key(|(_, c)| **c)
        .map(|(a, c)| (a.clone(), *c))
    {
        if count >= config.min_samples {
            out.push(Insight {
                kind: "MOST_CHECKED_APP".into(),
                confidence: conf(count, config.min_samples),
                sample_count: count,
                text: format!("You checked {} {} times this period.", app, count),
            });
        }
    }

    // LONGEST FOCUS
    if metrics.longest_focus_ms > 0 {
        out.push(Insight {
            kind: "LONGEST_FOCUS".into(),
            confidence: 1.0,
            sample_count: metrics.focus_blocks.len() as u32,
            text: format!(
                "Your longest focus block was {}.",
                fmt_dur(metrics.longest_focus_ms)
            ),
        });
    }

    // MOST FRAGMENTED HOUR
    if let Some((label, switches)) = &metrics.most_fragmented {
        out.push(Insight {
            kind: "CHAOS_HOUR".into(),
            confidence: conf(*switches, 5),
            sample_count: *switches,
            text: format!("Your most fragmented hour was {} — {} context switches.", label, switches),
        });
    }

    // MOST COMMON LOOP
    if let Some((seq, count)) = &metrics.most_common_ngram {
        if *count >= config.min_samples && seq.len() >= 2 {
            out.push(Insight {
                kind: "COMMON_LOOP".into(),
                confidence: conf(*count, config.min_samples),
                sample_count: *count,
                text: format!("Your most common loop — {} — happened {} times.", seq.join(" → "), count),
            });
        }
    }

    // RECOVERY (only with enough samples)
    if metrics.recovery.samples >= config.min_samples {
        if let Some((app, agg)) = metrics
            .recovery
            .by_distractor
            .iter()
            .max_by_key(|(_, a)| a.count)
            .map(|(a, ag)| (a.clone(), ag))
        {
            out.push(Insight {
                kind: "RECOVERY".into(),
                confidence: conf(agg.count, config.min_samples),
                sample_count: agg.count,
                text: format!(
                    "After {} you returned to focus in {} on average.",
                    app,
                    fmt_dur(agg.avg_ms() as i64)
                ),
            });
        }
    }

    // STRONGEST FOCUS HOUR
    if let Some((label, focus)) = &metrics.strongest_focus_hour {
        out.push(Insight {
            kind: "STRONGEST_FOCUS".into(),
            confidence: conf((*focus / 60_000) as u32, 15),
            sample_count: (*focus / 60_000) as u32,
            text: format!("Your strongest focus window was around {} — {} of Focus time.", label, fmt_dur(*focus)),
        });
    }

    out
}

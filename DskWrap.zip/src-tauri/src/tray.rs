//! Menu bar shell. The window can close; the tray icon and tracker stay.

use tauri::menu::{Menu, MenuItem, PredefinedMenuItem, Submenu};
use tauri::tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};
use tauri::{AppHandle, Manager, Runtime};

use crate::commands::AppState;
use crate::i18n;
use crate::time::fmt_duration_locale;
use std::sync::{Arc, Mutex};
use std::time::Duration;

/// Last today-line published into the tray menu. Compared so we replace the
/// menu only when the duration actually changes (about once a minute).
struct TodayCache {
    last: Mutex<String>,
}

pub fn build_tray<R: Runtime>(app: &AppHandle<R>, locale: &str) -> tauri::Result<()> {
    let menu = make_menu(app, locale)?;
    let icon = tauri::image::Image::from_bytes(include_bytes!("../icons/tray-template@2x.png"))?;
    let builder = TrayIconBuilder::with_id("main")
        .icon(icon)
        .icon_as_template(true)
        .menu(&menu)
        .tooltip("DskWrap")
        .show_menu_on_left_click(false)
        .on_menu_event(|app, event| handle_menu_event(app, event.id().as_ref()))
        .on_tray_icon_event(|tray, event| {
            if let TrayIconEvent::Click {
                button_state: MouseButtonState::Down,
                ..
            } = &event
            {
                // Refresh before macOS shows the menu, so the row is not the
                // snapshot from launch.
                refresh_today_now(tray.app_handle());
            }
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                show_main_window(tray.app_handle());
            }
        });
    builder.build(app)?;
    install_app_menu(app, locale)?;
    ensure_cache(app);
    if let Some(tray) = app.tray_by_id("main") {
        let _ = tray.set_tooltip(Some(today_line(app, locale)));
    }
    spawn_today_refresh(app.clone());
    Ok(())
}

pub fn rebuild_tray<R: Runtime>(app: &AppHandle<R>, locale: &str) -> tauri::Result<()> {
    if let Some(tray) = app.tray_by_id("main") {
        let menu = make_menu(app, locale)?;
        tray.set_menu(Some(menu))?;
    }
    install_app_menu(app, locale)?;
    Ok(())
}

fn locale_of<R: Runtime>(app: &AppHandle<R>) -> String {
    app.try_state::<Arc<AppState>>()
        .and_then(|s| s.locale.lock().ok().map(|g| g.clone()))
        .unwrap_or_else(|| "en".to_string())
}

fn ensure_cache<R: Runtime>(app: &AppHandle<R>) {
    if app.try_state::<TodayCache>().is_none() {
        app.manage(TodayCache {
            last: Mutex::new(String::new()),
        });
    }
}

fn line_changed<R: Runtime>(app: &AppHandle<R>, line: &str) -> bool {
    let Some(slot) = app.try_state::<TodayCache>() else {
        return true;
    };
    let last = slot.last.lock().unwrap();
    *last != line
}

fn remember_line<R: Runtime>(app: &AppHandle<R>, line: &str) {
    if let Some(slot) = app.try_state::<TodayCache>() {
        *slot.last.lock().unwrap() = line.to_string();
    }
}

/// Install a fresh tray menu when the today line changed, or when the user is
/// about to open it. macOS keeps the title captured at `set_menu` time, so
/// rewriting the item in place is not enough. The app menu is left alone.
fn republish_tray_menu<R: Runtime>(app: &AppHandle<R>, locale: &str, line: &str, force: bool) {
    ensure_cache(app);
    if let Some(tray) = app.tray_by_id("main") {
        let _ = tray.set_tooltip(Some(line));
    }
    if !force && !line_changed(app, line) {
        return;
    }
    if let Ok(menu) = make_menu(app, locale) {
        if let Some(tray) = app.tray_by_id("main") {
            if tray.set_menu(Some(menu)).is_ok() {
                remember_line(app, line);
                let _ = tray.set_tooltip(Some(line));
            }
        }
    }
}

/// Recompute today's tracked time and paint it onto the menu row.
/// Does not rebuild the app menu — that reset Cmd+Q when it ran on a timer.
pub fn refresh_today<R: Runtime>(app: &AppHandle<R>) {
    let app2 = app.clone();
    let _ = app.run_on_main_thread(move || {
        let locale = locale_of(&app2);
        let line = today_line(&app2, &locale);
        republish_tray_menu(&app2, &locale, &line, false);
    });
}

fn refresh_today_now<R: Runtime>(app: &AppHandle<R>) {
    let locale = locale_of(app);
    let line = today_line(app, &locale);
    republish_tray_menu(app, &locale, &line, false);
}

fn spawn_today_refresh<R: Runtime>(app: AppHandle<R>) {
    std::thread::spawn(move || {
        loop {
            std::thread::sleep(Duration::from_secs(8));
            refresh_today(&app);
        }
    });
}

/// macOS app menu without Quit. Cmd+Q is Hide — only the tray item really quits.
pub fn install_app_menu<R: Runtime>(app: &AppHandle<R>, locale: &str) -> tauri::Result<()> {
    let s = i18n::tray(locale);
    let hide = MenuItem::with_id(app, "cmdq_hide", s.hide, true, Some("CmdOrCtrl+Q"))?;
    let sep1 = PredefinedMenuItem::separator(app)?;
    let sep2 = PredefinedMenuItem::separator(app)?;
    let copy = PredefinedMenuItem::copy(app, None)?;
    let cut = PredefinedMenuItem::cut(app, None)?;
    let paste = PredefinedMenuItem::paste(app, None)?;
    let select_all = PredefinedMenuItem::select_all(app, None)?;

    let app_menu = Submenu::with_items(app, "DskWrap", true, &[&hide, &sep1])?;
    let edit = Submenu::with_items(app, s.edit, true, &[&cut, &copy, &paste, &sep2, &select_all])?;
    let menu = Menu::with_items(app, &[&app_menu, &edit])?;
    app.set_menu(menu)?;
    Ok(())
}

fn today_line<R: Runtime>(app: &AppHandle<R>, locale: &str) -> String {
    let s = i18n::tray(locale);
    let ms = app
        .try_state::<Arc<AppState>>()
        .map(|st| crate::commands::today_tracked_ms(st.inner()))
        .unwrap_or(0);
    if ms <= 0 {
        format!("{}{}", s.today_prefix, s.today_empty)
    } else {
        format!("{}{}", s.today_prefix, fmt_duration_locale(ms, locale))
    }
}

fn make_menu<R: Runtime>(app: &AppHandle<R>, locale: &str) -> tauri::Result<Menu<R>> {
    let s = i18n::tray(locale);
    let open = MenuItem::with_id(app, "open", s.open, true, None::<&str>)?;
    let today = MenuItem::with_id(app, "today", today_line(app, locale), false, None::<&str>)?;
    let pause15 = MenuItem::with_id(app, "pause15", s.pause15, true, None::<&str>)?;
    let pause1h = MenuItem::with_id(app, "pause1h", s.pause1h, true, None::<&str>)?;
    let pause_tomorrow = MenuItem::with_id(app, "pauseTomorrow", s.pause_tomorrow, true, None::<&str>)?;
    let pause_forever = MenuItem::with_id(app, "pauseForever", s.pause_forever, true, None::<&str>)?;
    let resume = MenuItem::with_id(app, "resume", s.resume, true, None::<&str>)?;
    let settings = MenuItem::with_id(app, "settings", s.settings, true, None::<&str>)?;
    let quit = MenuItem::with_id(app, "quit", s.quit, true, None::<&str>)?;

    let pause = Submenu::with_items(
        app,
        s.pause,
        true,
        &[&pause15, &pause1h, &pause_tomorrow, &pause_forever],
    )?;
    let sep = PredefinedMenuItem::separator(app)?;

    Menu::with_items(app, &[&today, &open, &sep, &pause, &resume, &sep, &settings, &quit])
}

pub fn handle_menu_event<R: Runtime>(app: &AppHandle<R>, id: &str) {
    match id {
        "open" | "settings" => show_main_window(app),
        "cmdq_hide" => hide_to_tray(app),
        "quit" => {
            crate::commands::request_real_quit(app);
            app.exit(0);
        }
        "pause15" => apply_pause(app, Some(15 * 60_000)),
        "pause1h" => apply_pause(app, Some(60 * 60_000)),
        "pauseTomorrow" => apply_pause(app, Some(8 * 60 * 60_000)),
        "pauseForever" => apply_pause(app, None),
        "resume" => apply_resume(app),
        _ => {}
    }
}

pub fn show_main_window<R: Runtime>(app: &AppHandle<R>) {
    #[cfg(target_os = "macos")]
    {
        let _ = app.set_activation_policy(tauri::ActivationPolicy::Regular);
    }
    if let Some(win) = app.get_webview_window("main") {
        let _ = win.show();
        let _ = win.unminimize();
        let _ = win.set_focus();
    }
}

pub fn hide_to_tray<R: Runtime>(app: &AppHandle<R>) {
    for (_, win) in app.webview_windows() {
        let _ = win.hide();
    }
    #[cfg(target_os = "macos")]
    {
        let _ = app.set_activation_policy(tauri::ActivationPolicy::Accessory);
    }
}

fn apply_pause<R: Runtime>(app: &AppHandle<R>, duration_ms: Option<i64>) {
    if let Some(state) = app.try_state::<Arc<AppState>>() {
        let _ = crate::commands::apply_pause(state.inner(), duration_ms);
    }
}

fn apply_resume<R: Runtime>(app: &AppHandle<R>) {
    if let Some(state) = app.try_state::<Arc<AppState>>() {
        let _ = crate::commands::apply_resume(state.inner());
    }
}

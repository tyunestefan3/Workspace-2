//! Entry point. In a Tauri app the binary simply calls the library's `run()`,
//! which builds the window/tray and dispatches to the platform-agnostic core.

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    desktop_wrapped::run();
}

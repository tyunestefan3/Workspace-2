//! Synthetic timelines (§61). These let us verify analytics on realistic
//! histories without waiting a real week — and power the demo CLI.

use crate::models::{AppCategory, AppRecord, Event, EventType};

pub const VSCODE: &str = "com.microsoft.VSCode";
pub const TERMINAL: &str = "com.apple.Terminal";
pub const CHROME: &str = "com.google.Chrome";
pub const SAFARI: &str = "com.apple.Safari";
pub const TELEGRAM: &str = "org.telegram.desktop";
pub const SLACK: &str = "com.tinyspeck.slackmacgap";
pub const YOUTUBE: &str = "com.google.YouTube";
pub const FINDER: &str = "com.apple.finder";

/// Shipped local category mapping (§24). The user can override any of these.
pub fn default_apps() -> Vec<AppRecord> {
    vec![
        AppRecord { bundle_id: VSCODE.into(), display_name: "VS Code".into(), category: AppCategory::Focus, ignored: false },
        AppRecord { bundle_id: TERMINAL.into(), display_name: "Terminal".into(), category: AppCategory::Focus, ignored: false },
        AppRecord { bundle_id: "com.jetbrains.intellij".into(), display_name: "IntelliJ IDEA".into(), category: AppCategory::Focus, ignored: false },
        AppRecord { bundle_id: CHROME.into(), display_name: "Chrome".into(), category: AppCategory::Neutral, ignored: false },
        AppRecord { bundle_id: SAFARI.into(), display_name: "Safari".into(), category: AppCategory::Neutral, ignored: false },
        AppRecord { bundle_id: TELEGRAM.into(), display_name: "Telegram".into(), category: AppCategory::Communication, ignored: false },
        AppRecord { bundle_id: SLACK.into(), display_name: "Slack".into(), category: AppCategory::Communication, ignored: false },
        AppRecord { bundle_id: YOUTUBE.into(), display_name: "YouTube".into(), category: AppCategory::Entertainment, ignored: false },
        AppRecord { bundle_id: FINDER.into(), display_name: "Finder".into(), category: AppCategory::Utility, ignored: false },
    ]
}

/// A building block of a synthetic timeline. Seconds are relative offsets.
#[derive(Clone, Copy)]
pub enum Blk {
    App(&'static str, u64),
    Idle(u64),
    Sleep(u64),
}

/// Turn blocks into raw events starting at `start_ms`. Each `App` emits a
/// single `app_active`; idle/sleep emit start+end pairs. Returns events and the
/// timestamp just after the last block.
pub fn build_timeline_with_end(start_ms: i64, blocks: &[Blk]) -> (Vec<Event>, i64) {
    let mut t = start_ms;
    let mut events = Vec::new();
    for b in blocks {
        match b {
            Blk::App(bundle, secs) => {
                events.push(Event::new(t, EventType::AppActive, Some(bundle)));
                t += (*secs as i64) * 1000;
            }
            Blk::Idle(secs) => {
                events.push(Event::new(t, EventType::IdleStart, None));
                t += (*secs as i64) * 1000;
                events.push(Event::new(t, EventType::IdleEnd, None));
            }
            Blk::Sleep(secs) => {
                events.push(Event::new(t, EventType::Sleep, None));
                t += (*secs as i64) * 1000;
                events.push(Event::new(t, EventType::Wake, None));
            }
        }
    }
    (events, t)
}

/// Convenience wrapper that discards the end timestamp.
pub fn build_timeline(start_ms: i64, blocks: &[Blk]) -> Vec<Event> {
    build_timeline_with_end(start_ms, blocks).0
}

/// The block schedule of one "developer day": a deep-work morning full of tiny
/// Telegram/Slack checks, a real break, a fragmented afternoon, and an evening
/// unwind. Produces the loops, checks, recovery and fragmentation the insights
/// are designed to find.
fn event_blocks() -> Vec<Blk> {
    let mut b: Vec<Blk> = Vec::new();
    for i in 0..6 {
        b.push(Blk::App(VSCODE, 12 * 60));
        b.push(Blk::App(TELEGRAM, 12));
        b.push(Blk::App(VSCODE, 15 * 60));
        if i % 2 == 0 {
            b.push(Blk::App(SLACK, 15));
            b.push(Blk::App(VSCODE, 8 * 60));
        }
    }
    b.push(Blk::App(TERMINAL, 25 * 60));
    b.push(Blk::Idle(12 * 60));
    // Real break, then return-to-focus (recovery).
    b.push(Blk::App(CHROME, 25 * 60));
    b.push(Blk::App(VSCODE, 30 * 60));
    // Fragmented afternoon.
    for _ in 0..10 {
        b.push(Blk::App(CHROME, 2 * 60));
        b.push(Blk::App(TELEGRAM, 20));
        b.push(Blk::App(VSCODE, 6 * 60));
    }
    // Evening entertainment + a bit of late focus.
    b.push(Blk::App(YOUTUBE, 6 * 60));
    b.push(Blk::App(VSCODE, 2 * 60));
    b
}

/// Events for one "developer day" starting at `start_ms`.
pub fn rich_day(start_ms: i64) -> Vec<Event> {
    build_timeline(start_ms, &event_blocks())
}

/// Like [`rich_day`] but also returns the timestamp just after the last event
/// (so callers can append a sleep at the correct moment).
pub fn rich_day_with_end(start_ms: i64) -> (Vec<Event>, i64) {
    build_timeline_with_end(start_ms, &event_blocks())
}

/// A full synthetic week (7 days). A `Sleep`/`Wake` pair is inserted each night
/// so days never bleed into each other (§15) — without it, an open session
/// would run across midnight and inflate durations (the lid-closed risk).
pub fn week(monday_start: i64) -> Vec<Event> {
    const DAY: i64 = 86_400_000;
    let mut events = Vec::new();
    for d in 0..7 {
        let base = monday_start + d * DAY;
        let (mut day, end) = rich_day_with_end(base);
        events.append(&mut day);
        // night sleep between this day and the next; the next day begins at `base + DAY`.
        events.push(Event::new(end, EventType::Sleep, None));
        events.push(Event::new(base + DAY, EventType::Wake, None));
    }
    events
}

pub const HOUR_MS: i64 = 3_600_000;
pub const DAY_MS: i64 = 86_400_000;

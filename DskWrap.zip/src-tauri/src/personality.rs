//! Personality (§41). A playful, deterministic classification — not a
//! psychological test. Underlying signal is a small set of thresholds so the
//! label is reproducible from the same metrics.

use chrono::Timelike;
use serde::{Deserialize, Serialize};
use crate::analytics::PeriodMetrics;
use crate::models::AppCategory;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MacType {
    DeepDiver,
    ContextSwitcher,
    NightOwl,
    Builder,
    Messenger,
    Balanced,
}

impl MacType {
    pub fn label(self) -> &'static str {
        match self {
            MacType::DeepDiver => "DEEP DIVER",
            MacType::ContextSwitcher => "THE CONTEXT SWITCHER",
            MacType::NightOwl => "NIGHT OWL",
            MacType::Builder => "THE BUILDER",
            MacType::Messenger => "THE MESSENGER",
            MacType::Balanced => "THE ALL-ROUNDER",
        }
    }
}

/// Hours after 22:00 local, used for the "late activity" heuristic.
const NIGHT_HOUR: u32 = 22;

pub fn classify(metrics: &PeriodMetrics, categories: &std::collections::BTreeMap<String, AppCategory>) -> MacType {
    let switches_per_hour = metrics.switches_per_hour;
    let focus_fraction = if metrics.tracked_ms > 0 {
        metrics.focus_seconds_ms as f64 / metrics.tracked_ms as f64
    } else {
        0.0
    };

    // Late activity: how much tracked time falls in the night window.
    let mut late_ms: i64 = 0;
    for s in lateness_buckets(metrics, categories) {
        late_ms += s;
    }
    let late_fraction = if metrics.tracked_ms > 0 {
        late_ms as f64 / metrics.tracked_ms as f64
    } else {
        0.0
    };

    let switcher = switches_per_hour >= 25.0;
    let diver = focus_fraction >= 0.6 && switches_per_hour < 15.0;
    let night_owl = late_fraction >= 0.25;
    let builder = metrics
        .app_durations
        .iter()
        .find(|(_, cat, _)| *cat == AppCategory::Focus)
        .is_some();
    let messenger = metrics.checks as f64 / (metrics.switches.max(1) as f64) >= 0.4;

    if switcher {
        MacType::ContextSwitcher
    } else if night_owl {
        MacType::NightOwl
    } else if messenger {
        MacType::Messenger
    } else if diver {
        MacType::DeepDiver
    } else if builder {
        MacType::Builder
    } else {
        MacType::Balanced
    }
}

fn lateness_buckets(
    metrics: &PeriodMetrics,
    _categories: &std::collections::BTreeMap<String, AppCategory>,
) -> Vec<i64> {
    // Reconstruct from hourly buckets: a bucket whose local hour is >= NIGHT_HOUR
    // (or < 4) counts as "late".
    metrics
        .hourly_buckets
        .iter()
        .filter(|b| {
            let h = crate::time::local_dt(b.start_ms).hour();
            h >= NIGHT_HOUR || h < 4
        })
        .map(|b| b.focus_seconds_ms + b.communication_seconds_ms + b.entertainment_seconds_ms)
        .collect()
}

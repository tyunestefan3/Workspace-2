//! Session reconstruction (§20). Raw events -> sessions with idle/sleep/pause
//! excluded. This is the place where several of the correctness fixes land:

use std::collections::BTreeMap;

use crate::models::{Event, EventType, Session, TrackerConfig};

/// A closed time window on which we want sessions (clamps open ends).
#[derive(Debug, Clone, Copy)]
pub struct TimeRange {
    pub start_ms: i64,
    pub end_ms: i64,
}

/// Errors the tracker treats as "we do not know" (crash tail/private) — never
/// counted as app usage.
const UNKNOWN: &str = "__unknown__";

/// Build sessions for the events *within* `range`, clamping the first session's
/// start and the last session's end to the range boundaries.
///
/// Semantics guaranteed by this function:
///  * idle / sleep / pause / ignored/private intervals are gaps, never timed.
///  * a repeated `app_active` for the same app (notification + reconciliation,
///    §58) extends the current session instead of creating a zero-length one.
///  * the app's own bundle and configured ignore-list never appear as sessions.
///  * the last open session is closed at `range.end` (or `now`), never left
///    dangling — otherwise analytics and live data disagree.
pub fn reconstruct_sessions(
    events: &[Event],
    config: &TrackerConfig,
    range: TimeRange,
) -> Vec<Session> {
    reconstruct_sessions_until(events, config, range, range.end_ms)
}

/// Same as [`reconstruct_sessions`], but a dangling last session is closed at
/// `until_ms` instead of `range.end`. Use this when the tracker is private/idle
/// so we do not invent hours after the last real event.
pub fn reconstruct_sessions_until(
    events: &[Event],
    config: &TrackerConfig,
    range: TimeRange,
    until_ms: i64,
) -> Vec<Session> {
    // A stable snapshot of ignore decisions so the closure stays simple.
    let ignore = |bundle_id: &str| -> bool {
        bundle_id.is_empty()
            || bundle_id == config.self_bundle_id
            || config.ignore_bundle_ids.iter().any(|b| b == bundle_id)
            || crate::catalog::is_noise_bundle(bundle_id)
    };

    let mut sessions: Vec<Session> = Vec::new();
    // Option<(bundle, active_start)>
    let mut active: Option<(String, i64)> = None;

    for ev in events {
        let ts = ev.timestamp_ms.clamp(range.start_ms, range.end_ms);
        match ev.event_type {
            EventType::AppActive => {
                let Some(bundle) = ev.bundle_id.as_deref() else { continue };
                if ignore(bundle) {
                    // ignored/private -> leave the current app, record nothing.
                    if let Some((app, start)) = active.take() {
                        sessions.push(Session {
                            bundle_id: app,
                            started_at_ms: start,
                            ended_at_ms: ts,
                        });
                    }
                    continue;
                }
                match &active {
                    Some((app, start)) if app == bundle => {
                        // Same app as before (dedup of notification+reconcile):
                        // extend, do not close/re-open.
                        let _ = start;
                    }
                    Some((app, start)) => {
                        // Different real app: close the old, open the new.
                        sessions.push(Session {
                            bundle_id: app.clone(),
                            started_at_ms: *start,
                            ended_at_ms: ts,
                        });
                        active = Some((bundle.to_string(), ts));
                    }
                    None => {
                        active = Some((bundle.to_string(), ts));
                    }
                }
            }
            EventType::IdleStart | EventType::Sleep | EventType::Pause | EventType::TrackerStop => {
                if let Some((app, start)) = active.take() {
                    sessions.push(Session {
                        bundle_id: app,
                        started_at_ms: start,
                        ended_at_ms: ts,
                    });
                }
            }
            EventType::IdleEnd | EventType::Wake | EventType::Resume | EventType::TrackerStart => {
                // Gap is over; the next app_active opens a session.
            }
        }
    }

    if let Some((app, start)) = active.take() {
        sessions.push(Session {
            bundle_id: app,
            started_at_ms: start,
            ended_at_ms: until_ms.clamp(range.start_ms, range.end_ms),
        });
    }

    // Clamp and drop degenerate/zero-length sessions and any unknown artifacts.
    sessions
        .into_iter()
        .filter_map(|s| {
            let start = s.started_at_ms.clamp(range.start_ms, range.end_ms);
            let end = s.ended_at_ms.clamp(range.start_ms, range.end_ms);
            if end <= start {
                None
            } else if s.bundle_id == UNKNOWN {
                None
            } else {
                Some(Session {
                    bundle_id: s.bundle_id,
                    started_at_ms: start,
                    ended_at_ms: end,
                })
            }
        })
        .collect()
}

/// Map every bundle that appears to its category, from the apps table.
pub fn category_map(apps: &[crate::models::AppRecord]) -> BTreeMap<String, crate::models::AppCategory> {
    let mut m = BTreeMap::new();
    for a in apps {
        if a.ignored {
            m.insert(a.bundle_id.clone(), crate::models::AppCategory::Ignored);
        } else {
            m.insert(a.bundle_id.clone(), a.category);
        }
    }
    m
}

/// The ordered sequence of distinct app visits (bundle ids), used for n-gram
/// patterns. `UNKNOWN`/ignored entries are already absent from sessions.
pub fn visit_sequence(sessions: &[Session]) -> Vec<String> {
    sessions.iter().map(|s| s.bundle_id.clone()).collect()
}

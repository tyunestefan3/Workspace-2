//! Desktop Wrapped — Tauri 2 app entry.
//!
//! Everything that decides *what* the app shows is in the platform-agnostic
//! modules below (models/db/analytics/...). The macOS tracker lives behind the
//! `TrackerMessage` boundary in `tracker/`. The frontend (React) only calls the
//! commands in `commands.rs` and renders.

pub mod analytics;
pub mod catalog;
pub mod commands;
pub mod db;
pub mod export;
pub mod fixtures;
pub mod i18n;
pub mod insights;
pub mod models;
pub mod period;
pub mod personality;
pub mod reconstruct;
pub mod time;
pub mod tracker;
pub mod tray;
pub mod wrapped;

pub use models::Event;
pub use reconstruct::TimeRange;
pub use time::fmt_duration;
pub use tracker::{Tracker, TrackerMessage, TrackerState};

use std::path::PathBuf;
use std::sync::atomic::AtomicBool;
use std::sync::Arc;

use commands::AppState;
use tauri::Manager;

/// The app data directory holds the SQLite DB (§8). Nothing else is written
/// anywhere; no telemetry leaves the machine.
fn data_dir(app: &tauri::AppHandle) -> PathBuf {
    let dir = app
        .path()
        .app_data_dir()
        .unwrap_or_else(|_| PathBuf::from("./data"));
    let _ = std::fs::create_dir_all(&dir);
    dir
}

fn load_locale(dir: &PathBuf) -> String {
    std::fs::read_to_string(dir.join("locale.txt"))
        .ok()
        .map(|s| i18n::normalize(s.trim()).to_string())
        .unwrap_or_else(|| i18n::detect().to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_autostart::Builder::new().build())
        .setup(|app| {
            let handle = app.handle();
            let dir = data_dir(handle);
            let db_path = dir.join("wrapped.sqlite");
            let locale = load_locale(&dir);
            let stop_on_quit = commands::load_stop_on_quit(&dir);

            // Open + configure the DB, then mark an unclean shutdown until we
            // exit cleanly (§18). Crash recovery reads this next launch.
            let conn = db::open(&db_path)?;
            db::set_clean_shutdown(&conn, false)?;
            let _ = db::prune_unseen_apps(&conn);
            let _ = db::rewrite_system_away(&conn);
            commands::close_stale_gap(&conn);

            let config = models::TrackerConfig::default();
            let state = AppState {
                db_path: db_path.clone(),
                conn: Arc::new(std::sync::Mutex::new(conn)),
                tracker: Arc::new(std::sync::Mutex::new(tracker::Tracker::default())),
                config: Arc::new(std::sync::Mutex::new(config)),
                tracking: AtomicBool::new(true),
                pause_until_ms: std::sync::Mutex::new(None),
                locale: std::sync::Mutex::new(locale.clone()),
                stop_on_quit: AtomicBool::new(stop_on_quit),
                allow_exit: AtomicBool::new(false),
            };
            app.manage(Arc::new(state));

            #[cfg(target_os = "macos")]
            {
                let _ = handle.set_activation_policy(tauri::ActivationPolicy::Accessory);
            }

            tray::build_tray(handle, &locale)?;

            // Start the macOS tracker driver (no-op on non-macOS).
            let stop = Arc::new(AtomicBool::new(false));
            #[cfg(target_os = "macos")]
            {
                let state_arc = app.state::<Arc<AppState>>().inner().clone();
                tracker::macos::spawn_driver(state_arc, stop.clone(), handle.clone());
            }
            #[cfg(not(target_os = "macos"))]
            {
                let _ = &stop; // keep the stop handle alive on non-macOS too
            }

            Ok(())
        })
        .on_window_event(|window, event| {
            // Closing the dashboard must not stop tracking (§46). Hide the
            // window, keep the process and the menu bar icon alive.
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                api.prevent_close();
                tray::hide_to_tray(window.app_handle());
            }
        })
        .invoke_handler(tauri::generate_handler![
            commands::get_dashboard,
            commands::get_weekly_wrapped,
            commands::get_applications,
            commands::set_app_category,
            commands::set_app_ignored,
            commands::delete_app_history,
            commands::delete_all_tracking,
            commands::export_json,
            commands::export_csv,
            commands::pause,
            commands::resume,
            commands::get_tracker_state,
            commands::get_debug,
            commands::set_locale,
            commands::get_locale,
            commands::set_launch_at_start,
            commands::get_stop_on_quit,
            commands::set_stop_on_quit,
            commands::get_onboarded,
            commands::set_onboarded,
            commands::get_launch_at_start,
            commands::hide_to_tray,
        ])
        .on_menu_event(|app, event| {
            crate::tray::handle_menu_event(app, event.id().as_ref());
        })
        .build(tauri::generate_context!())
        .expect("error while building DskWrap")
        .run(|app, event| match event {
            tauri::RunEvent::ExitRequested { api, .. } => {
                // Cmd+Q, red button, and macOS "Quit DskWrap" must not kill tracking.
                // Only tray «Выйти» sets allow_exit. Cancelling here also makes
                // macOS ask about DskWrap on shutdown.
                let allow = app
                    .try_state::<Arc<AppState>>()
                    .map(|s| s.allow_exit.load(std::sync::atomic::Ordering::Relaxed))
                    .unwrap_or(false);
                if !allow {
                    api.prevent_exit();
                    tray::hide_to_tray(app);
                }
            }
            tauri::RunEvent::Exit => {
                if let Some(state) = app.try_state::<Arc<AppState>>() {
                    if let Ok(conn) = state.conn.lock() {
                        let _ = db::set_clean_shutdown(&conn, true);
                    }
                }
            }
            _ => {}
        });
}

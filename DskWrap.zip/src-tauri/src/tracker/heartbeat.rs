//! Heartbeat (§17). A single writer updates `last_heartbeat_at_ms` at a steady
//! cadence so that, after a crash, `last_heartbeat` is the last moment we are
//! *sure* the process was alive — and we never fabricate time past it (§18).

/// The crash cutoff: the last heartbeat, or the last known event, whichever is
/// later. Used by recovery to clamp the open session (§18, §73).
pub fn crash_cutoff(last_event_at_ms: Option<i64>, last_heartbeat_at_ms: Option<i64>) -> Option<i64> {
    match (last_event_at_ms, last_heartbeat_at_ms) {
        (Some(a), Some(b)) => Some(a.max(b)),
        (Some(a), None) => Some(a),
        (None, Some(b)) => Some(b),
        (None, None) => None,
    }
}

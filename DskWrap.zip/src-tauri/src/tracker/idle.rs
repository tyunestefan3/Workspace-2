//! Idle detection (§12–§13). We only need *how long since last input* —
//! computed by CoreGraphics — never the input itself, so no Input Monitoring /
//! Accessibility permission is required.

/// kCGEventSourceStateHIDSystemState
const HID_SYSTEM_STATE: i32 = 1;
/// kCGAnyInputEventType (`~0`)
const ANY_INPUT_EVENT_TYPE: u32 = u32::MAX;

#[link(name = "CoreGraphics", kind = "framework")]
extern "C" {
    fn CGEventSourceSecondsSinceLastEventType(state_id: i32, event_type: u32) -> f64;
}

/// Seconds since the last keyboard/mouse event. This reads only a counter, not
/// the key/click data (§12).
pub fn seconds_since_last_input() -> f64 {
    // SAFETY: documented C API, no pointers. Returns CFTimeInterval.
    let secs = unsafe { CGEventSourceSecondsSinceLastEventType(HID_SYSTEM_STATE, ANY_INPUT_EVENT_TYPE) };
    if secs.is_finite() && secs >= 0.0 {
        secs
    } else {
        0.0
    }
}

//! macOS foreground tracking via AppKit's `NSWorkspace`.
//! NSWorkspace is queried on the main thread — a background call often returns nil.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use tauri::{AppHandle, Emitter, Manager};

use crate::commands::AppState;
use crate::models::{AppRecord, EventType};
use crate::tracker::state::{TrackerMessage, TrackerState};
use crate::tracker::{HEARTBEAT_INTERVAL_SECS, IDLE_CHECK_INTERVAL_MS, RECONCILE_INTERVAL_MS};

pub fn frontmost_bundle_id() -> Option<String> {
    use objc2_app_kit::NSWorkspace;
    let ws = NSWorkspace::sharedWorkspace();
    let app = ws.frontmostApplication()?;
    app.bundleIdentifier().map(|s| s.to_string())
}

pub fn frontmost_display_name() -> Option<String> {
    use objc2_app_kit::NSWorkspace;
    let ws = NSWorkspace::sharedWorkspace();
    let app = ws.frontmostApplication()?;
    app.localizedName().map(|s| s.to_string())
}

fn frontmost_on_main(handle: &AppHandle) -> (Option<String>, Option<String>) {
    let (tx, rx) = std::sync::mpsc::sync_channel(1);
    let _ = handle.run_on_main_thread(move || {
        let _ = tx.send((frontmost_bundle_id(), frontmost_display_name()));
    });
    rx.recv_timeout(Duration::from_millis(250)).unwrap_or((None, None))
}

fn persist(state: &Arc<AppState>, events: Vec<crate::models::Event>, display_name: Option<&str>) {
    let mut c = state.conn.lock().unwrap();
    for e in events {
        let _ = crate::db::insert_event(&mut c, &e);
        if e.event_type != EventType::AppActive {
            continue;
        }
        let Some(bundle) = e.bundle_id.as_deref() else { continue };
        if crate::catalog::is_noise_bundle(bundle)
            || display_name.is_some_and(crate::catalog::is_system_away_name)
        {
            continue;
        }
        let name = crate::catalog::friendly_name(bundle, display_name.unwrap_or(bundle));
        let category = crate::catalog::category_for(bundle, &name);
        let _ = crate::db::touch_app(
            &c,
            &AppRecord {
                bundle_id: bundle.to_string(),
                display_name: name,
                category,
                ignored: false,
            },
        );
    }
}

fn feed(
    state: &Arc<AppState>,
    handle: &AppHandle,
    msg: TrackerMessage,
    now_ms: i64,
    display_name: Option<&str>,
) {
    let config = state.config.lock().unwrap().clone();
    let events = {
        let mut t = state.tracker.lock().unwrap();
        t.on(msg, now_ms, &config)
    };
    persist(state, events, display_name);
    emit_state(state, handle);
}

pub fn spawn_driver(state: Arc<AppState>, stop: Arc<AtomicBool>, handle: AppHandle) {
    std::thread::spawn(move || {
        let mut ever_idle = false;
        let mut last_poll = Instant::now();
        let mut last_idle = Instant::now();
        let mut last_heartbeat = Instant::now();
        let mut last_tick_ms = chrono::Utc::now().timestamp_millis();

        {
            let now_ms = chrono::Utc::now().timestamp_millis();
            let config = state.config.lock().unwrap().clone();
            let (initial, name) = frontmost_on_main(&handle);
            let events = {
                let mut t = state.tracker.lock().unwrap();
                t.start(now_ms, initial, &config)
            };
            persist(&state, events, name.as_deref());
            emit_state(&state, &handle);
            crate::tray::refresh_today(&handle);
        }

        while !stop.load(Ordering::Relaxed) {
            let now_ms = chrono::Utc::now().timestamp_millis();

            // Process was frozen (sleep / power-off). Do not give those hours
            // to whatever app was frontmost, or to loginwindow.
            if now_ms.saturating_sub(last_tick_ms) >= 120_000 {
                feed(&state, &handle, TrackerMessage::Sleep, last_tick_ms, None);
                feed(&state, &handle, TrackerMessage::Wake, now_ms, None);
            }
            last_tick_ms = now_ms;

            if let Some(until) = *state.pause_until_ms.lock().unwrap() {
                if now_ms >= until {
                    *state.pause_until_ms.lock().unwrap() = None;
                    state.tracking.store(true, Ordering::Relaxed);
                    feed(&state, &handle, TrackerMessage::Resume, now_ms, None);
                }
            }

            let tracking = state.tracking.load(Ordering::Relaxed);
            let paused = matches!(state.tracker.lock().unwrap().state, TrackerState::Paused);

            if tracking && !paused {
                if last_poll.elapsed() >= Duration::from_millis(RECONCILE_INTERVAL_MS) {
                    last_poll = Instant::now();
                    let (bundle, name) = frontmost_on_main(&handle);
                    if let Some(bundle) = bundle {
                        feed(
                            &state,
                            &handle,
                            TrackerMessage::AppActivated(bundle),
                            now_ms,
                            name.as_deref(),
                        );
                    }
                }

                if last_idle.elapsed() >= Duration::from_millis(IDLE_CHECK_INTERVAL_MS) {
                    last_idle = Instant::now();
                    let idle_secs = crate::tracker::idle::seconds_since_last_input();
                    let threshold_secs = {
                        let config = state.config.lock().unwrap();
                        config.idle_threshold_ms as f64 / 1000.0
                    };
                    let is_idle = idle_secs > threshold_secs;
                    if is_idle && !ever_idle {
                        feed(
                            &state,
                            &handle,
                            TrackerMessage::IdleDetected {
                                idle_ms: (idle_secs * 1000.0) as i64,
                            },
                            now_ms,
                            None,
                        );
                    } else if !is_idle && ever_idle {
                        let (fg, name) = frontmost_on_main(&handle);
                        feed(
                            &state,
                            &handle,
                            TrackerMessage::UserReturned { foreground: fg },
                            now_ms,
                            name.as_deref(),
                        );
                    }
                    ever_idle = is_idle;
                }
            }

            if last_heartbeat.elapsed() >= Duration::from_secs(HEARTBEAT_INTERVAL_SECS) {
                last_heartbeat = Instant::now();
                let c = state.conn.lock().unwrap();
                let _ = crate::db::update_heartbeat(&c, now_ms);
            }

            std::thread::sleep(Duration::from_millis(IDLE_CHECK_INTERVAL_MS));
        }
    });
}

fn emit_state(state: &Arc<AppState>, handle: &AppHandle) {
    let label = state.tracker.lock().unwrap().state.label().to_string();
    let _ = handle.emit("tracker-state", label);
}

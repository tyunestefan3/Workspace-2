//! Crash recovery (§18). If the previous process died uncleanly, we must not
//! credit an open session past the last moment we knew it was alive
//! (`last_heartbeat`). We clamp the report/analysis window end to the crash
//! cutoff so the tail after a shutdown is "untracked", not "app time".

use crate::reconstruct::TimeRange;

/// Decide the end of the window to analyze for a crash recovery. Returns the
/// event/range as-is on a clean shutdown; on an unclean one it returns a range
/// whose end is the crash cutoff.
pub fn recovery_range(
    range: TimeRange,
    clean_shutdown: bool,
    last_event_at_ms: Option<i64>,
    last_heartbeat_at_ms: Option<i64>,
) -> TimeRange {
    if clean_shutdown {
        return range;
    }
    let cutoff = super::heartbeat::crash_cutoff(last_event_at_ms, last_heartbeat_at_ms);
    match cutoff {
        Some(c) if c < range.end_ms => TimeRange { start_ms: range.start_ms, end_ms: c },
        _ => range,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unclean_shutdown_clamps_to_heartbeat() {
        let range = TimeRange { start_ms: 1000, end_ms: 9_000_000 };
        // last heartbeat far before window end -> the "lid closed" scenario.
        let r = recovery_range(range, false, Some(1_000), Some(2_000));
        assert_eq!(r.end_ms, 2_000);
    }

    #[test]
    fn clean_shutdown_keeps_full_range() {
        let range = TimeRange { start_ms: 1000, end_ms: 9_000_000 };
        let r = recovery_range(range, true, Some(1_000), Some(2_000));
        assert_eq!(r.end_ms, 9_000_000);
    }
}

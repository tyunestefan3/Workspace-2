//! Tracker state machine (§11, §56). Pure Rust: the OS layer (NSWorkspace,
//! idle, sleep/wake) only feeds `TrackerMessage`s; this machine owns the state
//! transitions and decides which *immutable events* to persist. Because the
//! logic is platform-free, it is fully unit-testable here.

use serde::Serialize;

use crate::models::{Event, EventType, TrackerConfig};

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum TrackerState {
    Active { bundle_id: String },
    Idle,
    Sleeping,
    Paused,
    Private,
}

impl TrackerState {
    pub fn active_bundle(&self) -> Option<&str> {
        match self {
            TrackerState::Active { bundle_id } => Some(bundle_id),
            _ => None,
        }
    }
    pub fn label(&self) -> &'static str {
        match self {
            TrackerState::Active { .. } => "active",
            TrackerState::Idle => "idle",
            TrackerState::Sleeping => "sleeping",
            TrackerState::Paused => "paused",
            TrackerState::Private => "private",
        }
    }
}

/// One input to the machine. The driver observes the OS and translates raw
/// events into these, so the machine never touches macOS directly.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TrackerMessage {
    /// An app is now frontmost (from notification *or* reconciliation).
    AppActivated(String),
    /// The user has been idle for `idle_ms`; the machine computes the true
    /// `idle_start = now - idle_ms` so the event is accurate (§13).
    IdleDetected { idle_ms: i64 },
    /// The user returned from idle; `foreground` is the current app, if any.
    UserReturned { foreground: Option<String> },
    Sleep,
    Wake,
    Pause,
    Resume,
    Shutdown,
}

pub fn is_ignored(bundle_id: &str, config: &TrackerConfig) -> bool {
    bundle_id.is_empty()
        || bundle_id == config.self_bundle_id
        || config.ignore_bundle_ids.iter().any(|b| b == bundle_id)
        || crate::catalog::is_noise_bundle(bundle_id)
}

#[derive(Debug, Clone)]
pub struct Tracker {
    pub state: TrackerState,
}

impl Default for Tracker {
    fn default() -> Self {
        Self { state: TrackerState::Idle }
    }
}

impl Tracker {
    /// The driver calls this once at launch, before any messages, with the
    /// foreground app (if any). Emits `tracker_start` then a first `app_active`
    /// when appropriate (§19, §11).
    pub fn start(&mut self, now_ms: i64, initial: Option<String>, config: &TrackerConfig) -> Vec<Event> {
        let mut events = vec![Event::new(now_ms, EventType::TrackerStart, None)];
        match initial {
            Some(b) if crate::catalog::is_system_away(&b) => {
                // Login window / lock: the Mac is not being used.
                self.state = TrackerState::Sleeping;
            }
            Some(b) if !is_ignored(&b, config) => {
                self.state = TrackerState::Active { bundle_id: b.clone() };
                events.push(Event::new(now_ms, EventType::AppActive, Some(&b)));
            }
            Some(_) => {
                self.state = TrackerState::Private;
            }
            None => {
                self.state = TrackerState::Idle;
            }
        }
        events
    }

    /// Apply one message, returning the events to persist. The caller commits
    /// them; if the commit fails it must not assume they were saved (§57).
    pub fn on(&mut self, msg: TrackerMessage, now_ms: i64, config: &TrackerConfig) -> Vec<Event> {
        match msg {
            TrackerMessage::AppActivated(bundle) => {
                if is_ignored(&bundle, config) {
                    if matches!(self.state, TrackerState::Private) {
                        vec![]
                    } else {
                        // Emit the ignored bundle so reconstruction closes the
                        // previous app. Otherwise Safari (etc.) stays "open"
                        // until now and swallows hours.
                        self.state = TrackerState::Private;
                        vec![Event::new(now_ms, EventType::AppActive, Some(&bundle))]
                    }
                } else {
                    let same_active = matches!(&self.state, TrackerState::Active { bundle_id } if *bundle_id == bundle);
                    if same_active {
                        // notification + reconciliation duplicate → nothing recorded (§58)
                        vec![]
                    } else {
                        self.state = TrackerState::Active { bundle_id: bundle.clone() };
                        vec![Event::new(now_ms, EventType::AppActive, Some(&bundle))]
                    }
                }
            }
            TrackerMessage::IdleDetected { idle_ms } => {
                if matches!(self.state, TrackerState::Active { .. } | TrackerState::Private) {
                    let idle_start = now_ms - idle_ms;
                    self.state = TrackerState::Idle;
                    vec![Event::new(idle_start, EventType::IdleStart, None)]
                } else {
                    vec![]
                }
            }
            TrackerMessage::UserReturned { foreground } => {
                let mut events = Vec::new();
                if self.state == TrackerState::Idle {
                    events.push(Event::new(now_ms, EventType::IdleEnd, None));
                }
                match foreground {
                    Some(b) if crate::catalog::is_system_away(&b) => {
                        self.state = TrackerState::Sleeping;
                        events.push(Event::new(now_ms, EventType::Sleep, None));
                    }
                    Some(b) if !is_ignored(&b, config) => {
                        self.state = TrackerState::Active { bundle_id: b.clone() };
                        events.push(Event::new(now_ms, EventType::AppActive, Some(&b)));
                    }
                    Some(_) => {
                        self.state = TrackerState::Private;
                    }
                    None => {
                        if self.state != TrackerState::Idle {
                            self.state = TrackerState::Idle;
                        }
                    }
                }
                events
            }
            TrackerMessage::Sleep => {
                if self.state == TrackerState::Sleeping {
                    vec![]
                } else {
                    self.state = TrackerState::Sleeping;
                    vec![Event::new(now_ms, EventType::Sleep, None)]
                }
            }
            TrackerMessage::Wake => {
                if self.state == TrackerState::Sleeping {
                    // Foreground will arrive as an AppActivated after this.
                    self.state = TrackerState::Idle;
                    vec![Event::new(now_ms, EventType::Wake, None)]
                } else {
                    vec![]
                }
            }
            TrackerMessage::Pause => {
                if self.state == TrackerState::Paused {
                    vec![]
                } else {
                    self.state = TrackerState::Paused;
                    vec![Event::new(now_ms, EventType::Pause, None)]
                }
            }
            TrackerMessage::Resume => {
                if self.state == TrackerState::Paused {
                    // Foreground will arrive as an AppActivated after this.
                    self.state = TrackerState::Idle;
                    vec![Event::new(now_ms, EventType::Resume, None)]
                } else {
                    vec![]
                }
            }
            TrackerMessage::Shutdown => {
                self.state = TrackerState::Idle;
                vec![Event::new(now_ms, EventType::TrackerStop, None)]
            }
        }
    }
}

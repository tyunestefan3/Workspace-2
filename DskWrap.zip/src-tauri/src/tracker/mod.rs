//! Tracker subsystem (§11, §56). The state machine is platform-agnostic; the
//! macOS-specific drivers (NSWorkspace, idle, sleep/wake) feed it messages and
//! are compiled only on macOS.

pub mod state;

#[cfg(target_os = "macos")]
pub mod idle;
#[cfg(target_os = "macos")]
pub mod macos;
pub mod heartbeat;
pub mod recovery;

pub use state::{Tracker, TrackerMessage, TrackerState};

/// How often to reconcile the actual foreground app with our state (§10).
pub const RECONCILE_INTERVAL_MS: u64 = 400;
/// How often to poll idle (§12).
pub const IDLE_CHECK_INTERVAL_MS: u64 = 400;
/// How often to write a heartbeat (§17).
pub const HEARTBEAT_INTERVAL_SECS: u64 = 30;

//! Tauri commands (§4). The React frontend never computes anything — it only
//! calls these and renders. Rust is the single source of truth.

use std::path::PathBuf;
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex};

use serde::Serialize;
use tauri::{AppHandle, Manager, State};

use crate::analytics::{PeriodMetrics, compute_period};
use crate::db;
use crate::models::{AppCategory, AppRecord, TrackerConfig};
use crate::period::{Period, resolve};
use crate::reconstruct::{TimeRange, category_map, reconstruct_sessions_until};
use crate::tracker::{Tracker, TrackerMessage};
use crate::wrapped;

pub struct AppState {
    pub db_path: PathBuf,
    pub conn: Arc<Mutex<rusqlite::Connection>>,
    pub tracker: Arc<Mutex<Tracker>>,
    pub config: Arc<Mutex<TrackerConfig>>,
    pub tracking: AtomicBool,
    pub pause_until_ms: Mutex<Option<i64>>,
    pub locale: Mutex<String>,
    pub stop_on_quit: AtomicBool,
    pub allow_exit: AtomicBool,
}

fn now_ms() -> i64 {
    chrono::Utc::now().timestamp_millis()
}

/// Resolve a period string ("today"/"yesterday"/"week"/"month") to a range.
/// Uses "now" as the reference, which is what a live app wants.
fn resolve_period(period: &str) -> TimeRange {
    let p = match period {
        "yesterday" => Period::Yesterday,
        "month" => Period::Month,
        "today" => Period::Today,
        _ => Period::Week,
    };
    resolve(now_ms(), p)
}

/// Load metrics for a resolved range straight from the DB.
fn metrics_for(state: &Arc<AppState>, range: TimeRange) -> PeriodMetrics {
    // config → tracker → conn. The driver locks config before tracker; the
    // opposite order deadlocks the menu-bar refresh against live tracking.
    let config = state.config.lock().unwrap().clone();
    let tracker_state = state.tracker.lock().unwrap().state.clone();
    let conn = state.conn.lock().unwrap();
    let apps = db::apps(&conn).unwrap_or_default();
    let mut categories = category_map(&apps);
    for a in &apps {
        categories.entry(a.bundle_id.clone()).or_insert_with(|| {
            crate::catalog::category_for(&a.bundle_id, &a.display_name)
        });
    }
    let events = db::events_in_range(&conn, range.start_ms, range.end_ms).unwrap_or_default();
    let last_ev = events.iter().map(|e| e.timestamp_ms).max();
    let now = now_ms();
    // Always cap at *now*. Closing at range.end (tomorrow midnight) invented
    // ~12 leftover hours for whatever app was frontmost.
    let until = match tracker_state {
        crate::tracker::TrackerState::Active { .. } => now.min(range.end_ms),
        _ => last_ev.unwrap_or(range.start_ms).min(now).min(range.end_ms),
    };
    let sessions = reconstruct_sessions_until(&events, &config, range, until);
    let mut metrics = compute_period(&sessions, &categories, &config, range);
    metrics.away_ms = away_ms(&events, range, until);
    metrics
}

/// Sleep / power-off / login-window spans inside the range.
fn away_ms(events: &[crate::models::Event], range: TimeRange, until: i64) -> i64 {
    use crate::models::EventType;
    let mut off = 0i64;
    let mut sleep_at: Option<i64> = None;
    for ev in events {
        let ts = ev.timestamp_ms.clamp(range.start_ms, range.end_ms);
        match ev.event_type {
            EventType::Sleep | EventType::TrackerStop => {
                if sleep_at.is_none() {
                    sleep_at = Some(ts);
                }
            }
            EventType::Wake | EventType::TrackerStart | EventType::AppActive | EventType::IdleEnd | EventType::Resume => {
                if let Some(start) = sleep_at.take() {
                    off += (ts - start).max(0);
                }
            }
            _ => {}
        }
    }
    if let Some(start) = sleep_at {
        off += (until.clamp(range.start_ms, range.end_ms) - start).max(0);
    }
    off
}

#[tauri::command]
pub fn get_dashboard(state: State<Arc<AppState>>, period: String) -> PeriodMetrics {
    metrics_for(state.inner(), resolve_period(&period))
}

pub fn today_tracked_ms(state: &Arc<AppState>) -> i64 {
    metrics_for(state, resolve_period("today")).tracked_ms
}

#[tauri::command]
pub fn get_weekly_wrapped(state: State<Arc<AppState>>, period: String) -> wrapped::WeeklyWrapped {
    let range = resolve_period(&period);
    let metrics = metrics_for(state.inner(), range);
    let conn = state.conn.lock().unwrap();
    let apps = db::apps_seen(&conn).unwrap_or_default();
    let categories = category_map(&apps);
    let config = state.config.lock().unwrap().clone();
    let mac = crate::personality::classify(&metrics, &categories);
    wrapped::weekly(&metrics, &apps, &config, mac, range.start_ms, range.end_ms)
}

#[tauri::command]
pub fn get_applications(state: State<Arc<AppState>>) -> Vec<AppRecord> {
    let conn = state.conn.lock().unwrap();
    db::apps_seen(&conn)
        .unwrap_or_default()
        .into_iter()
        .filter(|a| {
            !crate::catalog::is_noise_bundle(&a.bundle_id)
                && !crate::catalog::is_system_away_name(&a.display_name)
                && !crate::catalog::is_noise_name(&a.display_name)
        })
        .map(|mut a| {
            a.display_name = crate::catalog::friendly_name(&a.bundle_id, &a.display_name);
            a
        })
        .collect()
}

#[tauri::command]
pub fn set_app_category(state: State<Arc<AppState>>, bundle_id: String, category: String) -> Result<(), String> {
    let cat = parse_category(&category)?;
    let conn = state.conn.lock().unwrap();
    set_app_category_inner(&conn, &bundle_id, cat).map_err(|e| e.to_string())
}

fn set_app_category_inner(conn: &rusqlite::Connection, bundle_id: &str, cat: AppCategory) -> rusqlite::Result<()> {
    conn.execute(
        "UPDATE apps SET category = ?1 WHERE bundle_id = ?2",
        rusqlite::params![category_str(cat), bundle_id],
    )?;
    Ok(())
}

#[tauri::command]
pub fn set_app_ignored(state: State<Arc<AppState>>, bundle_id: String, ignored: bool) -> Result<(), String> {
    let conn = state.conn.lock().unwrap();
    conn.execute(
        "UPDATE apps SET ignored = ?1 WHERE bundle_id = ?2",
        rusqlite::params![ignored as i32, bundle_id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn delete_app_history(state: State<Arc<AppState>>, bundle_id: String) -> Result<u64, String> {
    let conn = state.conn.lock().unwrap();
    db::delete_app_events(&conn, &bundle_id)
        .map(|n| n as u64)
        .map_err(|e| e.to_string())
}

#[tauri::command]
pub fn delete_all_tracking(state: State<Arc<AppState>>) -> Result<(), String> {
    let conn = state.conn.lock().unwrap();
    db::delete_all_data(&conn).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn export_json(state: State<Arc<AppState>>) -> Result<String, String> {
    let conn = state.conn.lock().unwrap();
    crate::export::export_json(&conn)
}

#[tauri::command]
pub fn export_csv(state: State<Arc<AppState>>) -> Result<String, String> {
    let conn = state.conn.lock().unwrap();
    crate::export::export_csv(&conn)
}

pub fn apply_pause(state: &Arc<AppState>, duration_ms: Option<i64>) -> Result<(), String> {
    persist_pause(state, duration_ms)
}

pub fn apply_resume(state: &Arc<AppState>) -> Result<(), String> {
    *state.pause_until_ms.lock().unwrap() = None;
    state.tracking.store(true, std::sync::atomic::Ordering::Relaxed);
    let config = state.config.lock().unwrap().clone();
    let mut tracker = state.tracker.lock().unwrap();
    let events = tracker.on(TrackerMessage::Resume, now_ms(), &config);
    let mut conn = state.conn.lock().unwrap();
    for e in events {
        db::insert_event(&mut conn, &e).map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
pub fn pause(state: State<Arc<AppState>>, duration_ms: Option<i64>) -> Result<(), String> {
    apply_pause(state.inner(), duration_ms)
}

fn persist_pause(state: &Arc<AppState>, duration_ms: Option<i64>) -> Result<(), String> {
    let until = duration_ms.filter(|d| *d > 0).map(|d| now_ms() + d);
    *state.pause_until_ms.lock().unwrap() = until;
    state.tracking.store(false, std::sync::atomic::Ordering::Relaxed);
    let config = state.config.lock().unwrap().clone();
    let mut tracker = state.tracker.lock().unwrap();
    let events = tracker.on(TrackerMessage::Pause, now_ms(), &config);
    let mut conn = state.conn.lock().unwrap();
    for e in events {
        db::insert_event(&mut conn, &e).map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
pub fn resume(state: State<Arc<AppState>>) -> Result<(), String> {
    apply_resume(state.inner())
}

#[tauri::command]
pub fn get_tracker_state(state: State<Arc<AppState>>) -> String {
    state.tracker.lock().unwrap().state.label().to_string()
}

#[tauri::command]
pub fn get_debug(state: State<Arc<AppState>>) -> DebugInfo {
    let (last_event, last_heartbeat, events_today) = {
        let conn = state.conn.lock().unwrap();
        let (last_event, last_heartbeat) = heartbeat_info(&conn);
        let events_today = event_count_since(&conn, start_of_today());
        (last_event, last_heartbeat, events_today)
    };
    let tracker_state = state.tracker.lock().unwrap().state.label().to_string();
    let current_app = current_app_name(state.inner());
    let metrics = metrics_for(state.inner(), resolve_period("today"));
    let now = now_ms();
    let fresh = last_heartbeat
        .map(|hb| now.saturating_sub(hb) <= 90_000)
        .unwrap_or(false);
    let working = fresh && tracker_state != "paused" && tracker_state != "sleeping";
    DebugInfo {
        tracker_state,
        last_event_ms: last_event,
        last_heartbeat_ms: last_heartbeat,
        events_today,
        working,
        current_app,
        switches_today: metrics.switches,
        checks_today: metrics.checks,
        quick_visits_today: metrics.quick_visits,
        tracked_today_ms: metrics.tracked_ms,
    }
}

fn current_app_name(state: &Arc<AppState>) -> Option<String> {
    let bundle = {
        let tracker = state.tracker.lock().unwrap();
        tracker.state.active_bundle().map(|s| s.to_string())
    }?;
    let stored = {
        let conn = state.conn.lock().unwrap();
        db::apps(&conn).ok().and_then(|apps| {
            apps.into_iter()
                .find(|a| a.bundle_id == bundle)
                .map(|a| a.display_name)
        })
    };
    Some(crate::catalog::friendly_name(
        &bundle,
        stored.as_deref().unwrap_or(&bundle),
    ))
}

fn heartbeat_info(conn: &rusqlite::Connection) -> (Option<i64>, Option<i64>) {
    let r = conn
        .query_row(
            "SELECT last_event_at_ms, last_heartbeat_at_ms FROM tracker_state WHERE id = 1",
            [],
            |row| Ok((row.get::<_, Option<i64>>(0)?, row.get::<_, Option<i64>>(1)?)),
        )
        .unwrap_or((None, None));
    r
}

fn event_count_since(conn: &rusqlite::Connection, since: i64) -> i64 {
    conn.query_row(
        "SELECT COUNT(*) FROM events WHERE timestamp_ms >= ?1",
        [since],
        |row| row.get(0),
    )
    .unwrap_or(0)
}

fn start_of_today() -> i64 {
    resolve(now_ms(), crate::period::Period::Today).start_ms
}

#[derive(Serialize)]
pub struct DebugInfo {
    pub tracker_state: String,
    pub last_event_ms: Option<i64>,
    pub last_heartbeat_ms: Option<i64>,
    pub events_today: i64,
    pub working: bool,
    pub current_app: Option<String>,
    pub switches_today: u32,
    pub checks_today: u32,
    pub quick_visits_today: u32,
    pub tracked_today_ms: i64,
}

fn parse_category(s: &str) -> Result<AppCategory, String> {
    Ok(match s {
        "focus" => AppCategory::Focus,
        "communication" => AppCategory::Communication,
        "entertainment" => AppCategory::Entertainment,
        "utility" => AppCategory::Utility,
        "ignored" => AppCategory::Ignored,
        "neutral" => AppCategory::Neutral,
        _ => return Err(format!("unknown category: {}", s)),
    })
}

fn category_str(c: AppCategory) -> &'static str {
    match c {
        AppCategory::Focus => "focus",
        AppCategory::Communication => "communication",
        AppCategory::Entertainment => "entertainment",
        AppCategory::Utility => "utility",
        AppCategory::Neutral => "neutral",
        AppCategory::Ignored => "ignored",
    }
}

#[tauri::command]
pub fn set_locale(app: AppHandle, state: State<Arc<AppState>>, locale: String) -> Result<(), String> {
    let loc = crate::i18n::normalize(&locale);
    {
        let mut current = state.locale.lock().unwrap();
        *current = loc.to_string();
    }
    if let Some(dir) = state.db_path.parent() {
        let _ = std::fs::write(dir.join("locale.txt"), loc);
    }
    crate::tray::rebuild_tray(&app, loc).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn get_locale(state: State<Arc<AppState>>) -> String {
    state.locale.lock().unwrap().clone()
}

/// If the previous run died or the Mac slept, close the dangling session at
/// the last heartbeat so overnight hours are not given to Safari.
pub fn close_stale_gap(conn: &rusqlite::Connection) {
    let now = now_ms();
    let Some(hb) = db::last_heartbeat(conn) else { return };
    if now.saturating_sub(hb) < 2 * 60_000 {
        return;
    }
    let _ = conn.execute(
        "INSERT INTO events (timestamp_ms, event_type, bundle_id, created_at_ms) VALUES (?1, 'sleep', NULL, ?2)",
        rusqlite::params![hb, now],
    );
    let _ = conn.execute(
        "INSERT INTO events (timestamp_ms, event_type, bundle_id, created_at_ms) VALUES (?1, 'wake', NULL, ?2)",
        rusqlite::params![now, now],
    );
}

#[tauri::command]
pub fn set_launch_at_start(app: AppHandle, enabled: bool) -> Result<(), String> {
    use tauri_plugin_autostart::ManagerExt;
    let mgr = app.autolaunch();
    if enabled {
        mgr.enable().map_err(|e| e.to_string())
    } else {
        mgr.disable().map_err(|e| e.to_string())
    }
}

#[tauri::command]
pub fn get_launch_at_start(app: AppHandle) -> Result<bool, String> {
    use tauri_plugin_autostart::ManagerExt;
    app.autolaunch().is_enabled().map_err(|e| e.to_string())
}

#[tauri::command]
pub fn hide_to_tray(app: AppHandle) {
    crate::tray::hide_to_tray(&app);
}

fn flag_path(state: &AppState, name: &str) -> PathBuf {
    state
        .db_path
        .parent()
        .map(|p| p.join(name))
        .unwrap_or_else(|| PathBuf::from(name))
}

fn read_flag(state: &AppState, name: &str) -> bool {
    std::fs::read_to_string(flag_path(state, name))
        .ok()
        .map(|s| s.trim() == "1")
        .unwrap_or(false)
}

fn write_flag(state: &AppState, name: &str, on: bool) {
    let _ = std::fs::write(flag_path(state, name), if on { "1" } else { "0" });
}

pub fn load_stop_on_quit(dir: &PathBuf) -> bool {
    std::fs::read_to_string(dir.join("stop_on_quit"))
        .ok()
        .map(|s| s.trim() == "1")
        .unwrap_or(false)
}

pub fn load_onboarded(dir: &PathBuf) -> bool {
    std::fs::read_to_string(dir.join("onboarded"))
        .ok()
        .map(|s| s.trim() == "1")
        .unwrap_or(false)
}

#[tauri::command]
pub fn get_stop_on_quit(state: State<Arc<AppState>>) -> bool {
    state.stop_on_quit.load(std::sync::atomic::Ordering::Relaxed)
}

#[tauri::command]
pub fn set_stop_on_quit(state: State<Arc<AppState>>, enabled: bool) -> Result<(), String> {
    state
        .stop_on_quit
        .store(enabled, std::sync::atomic::Ordering::Relaxed);
    write_flag(state.inner(), "stop_on_quit", enabled);
    Ok(())
}

#[tauri::command]
pub fn get_onboarded(state: State<Arc<AppState>>) -> bool {
    read_flag(state.inner(), "onboarded")
}

#[tauri::command]
pub fn set_onboarded(state: State<Arc<AppState>>, done: bool) -> Result<(), String> {
    write_flag(state.inner(), "onboarded", done);
    Ok(())
}

pub fn request_real_quit<R: tauri::Runtime>(app: &tauri::AppHandle<R>) {
    if let Some(state) = app.try_state::<Arc<AppState>>() {
        state.allow_exit.store(true, std::sync::atomic::Ordering::Relaxed);
        state.tracking.store(false, std::sync::atomic::Ordering::Relaxed);
        let config = state.config.lock().unwrap().clone();
        let events = {
            let mut t = state.tracker.lock().unwrap();
            t.on(TrackerMessage::Shutdown, now_ms(), &config)
        };
        if let Ok(mut conn) = state.conn.lock() {
            for e in events {
                let _ = db::insert_event(&mut conn, &e);
            }
            let _ = db::set_clean_shutdown(&conn, true);
        }
    }
}

pub fn should_prevent_quit(state: &AppState) -> bool {
    if state.allow_exit.load(std::sync::atomic::Ordering::Relaxed) {
        return false;
    }
    !state.stop_on_quit.load(std::sync::atomic::Ordering::Relaxed)
}

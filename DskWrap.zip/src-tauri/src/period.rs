//! Period presets (§27, §49). All timestamps are stored in UTC ms; the *buckets*
//! and "what is today" are interpreted in the user's local timezone, so DST and
//! travel are handled at the boundary, not in the data.

use chrono::{Days, Datelike, Local, LocalResult, NaiveDate, TimeZone};

use crate::reconstruct::TimeRange;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Period {
    Today,
    Yesterday,
    Week,
    Month,
    Custom,
}

impl Period {
    pub fn label(self) -> &'static str {
        match self {
            Period::Today => "Today",
            Period::Yesterday => "Yesterday",
            Period::Week => "This week",
            Period::Month => "This month",
            Period::Custom => "Custom",
        }
    }
}

/// Midnight (00:00 local) converted to UTC ms for a given date.
fn local_midnight_utc_ms(date: NaiveDate) -> i64 {
    let naive = date.and_hms_opt(0, 0, 0).expect("0:00 is a valid time");
    match Local.from_local_datetime(&naive) {
        LocalResult::Single(dt) => dt.timestamp_millis(),
        LocalResult::Ambiguous(a, _) => a.timestamp_millis(),
        LocalResult::None => chrono::Utc.from_utc_datetime(&naive).timestamp_millis(),
    }
}

/// Resolve a preset relative to `now_ms`. Week starts on Monday (§49).
pub fn resolve(now_ms: i64, period: Period) -> TimeRange {
    let now = crate::time::local_dt(now_ms);
    let today = now.date_naive();

    let (start_date, end_date) = match period {
        Period::Today => (today, today.succ_opt().unwrap_or(today)),
        Period::Yesterday => {
            let y = today.pred_opt().unwrap_or(today);
            (y, today)
        }
        Period::Week => {
            let back = today.weekday().num_days_from_monday();
            let monday = today.checked_sub_days(Days::new(back as u64)).unwrap_or(today);
            (monday, monday.checked_add_days(Days::new(7)).unwrap_or(today))
        }
        Period::Month => {
            let first = NaiveDate::from_ymd_opt(today.year(), today.month(), 1).unwrap_or(today);
            let next = if today.month() == 12 {
                NaiveDate::from_ymd_opt(today.year() + 1, 1, 1).unwrap_or(today)
            } else {
                NaiveDate::from_ymd_opt(today.year(), today.month() + 1, 1).unwrap_or(today)
            };
            (first, next)
        }
        Period::Custom => (today, today.succ_opt().unwrap_or(today)),
    };

    let start_ms = local_midnight_utc_ms(start_date);
    let end_ms = local_midnight_utc_ms(end_date);
    TimeRange { start_ms, end_ms }
}

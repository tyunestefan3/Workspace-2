//! Analytics engine (§27–§37). Input: derived sessions + app categories.
//! Output: numbers only. The Insight Engine (§39) turns these into text.

use serde::Serialize;
use std::collections::BTreeMap;

use crate::models::{AppCategory, Session, TrackerConfig};
use crate::time::local_dt;
use chrono::{Datelike, Duration as ChronoDuration, Timelike};
use crate::reconstruct::{TimeRange, visit_sequence};

/// A derived "you were in focus" block. `duration_ms` counts only the Focus
/// seconds; the block may contain tiny allowed interruptions (§31).
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct FocusBlock {
    pub start_ms: i64,
    pub end_ms: i64,
    pub duration_ms: i64,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize)]
pub struct RecoveryAgg {
    pub count: u32,
    pub total_ms: i64,
}

impl RecoveryAgg {
    pub fn avg_ms(&self) -> f64 {
        if self.count == 0 {
            0.0
        } else {
            self.total_ms as f64 / self.count as f64
        }
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize)]
pub struct RecoveryStats {
    pub by_distractor: BTreeMap<String, RecoveryAgg>,
    pub samples: u32,
}

impl RecoveryStats {
    pub fn overall_avg_ms(&self) -> Option<i64> {
        if self.samples == 0 {
            None
        } else {
            let total: i64 = self.by_distractor.values().map(|a| a.total_ms).sum();
            Some(total / self.samples as i64)
        }
    }
}

/// One local-hour bucket of the heatmap (§33).
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize)]
pub struct HourBucket {
    pub start_ms: i64,
    pub switches: u32,
    pub checks: u32,
    pub focus_seconds_ms: i64,
    pub communication_seconds_ms: i64,
    pub entertainment_seconds_ms: i64,
    /// All tracked time in this hour (every category). Used by the heatmap.
    #[serde(default)]
    pub active_ms: i64,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct PeriodMetrics {
    pub wall_ms: i64,
    pub tracked_ms: i64,
    /// (bundle, category, duration_ms) sorted desc.
    pub app_durations: Vec<(String, AppCategory, i64)>,
    pub category_durations: BTreeMap<AppCategory, i64>,
    pub switches: u32,
    pub switches_per_hour: f64,
    pub quick_visits: u32,
    pub checks: u32,
    pub checks_per_app: BTreeMap<String, u32>,
    pub focus_seconds_ms: i64,
    pub longest_focus_ms: i64,
    pub focus_blocks: Vec<FocusBlock>,
    pub recovery: RecoveryStats,
    /// (sequence, count), sorted by count desc then n desc.
    pub ngrams: Vec<(Vec<String>, u32)>,
    pub most_common_ngram: Option<(Vec<String>, u32)>,
    pub hourly_buckets: Vec<HourBucket>,
    /// (bucket local label, switches) for the most fragmented hour.
    pub most_fragmented: Option<(String, u32)>,
    /// (bucket local label, focus ms) for the strongest focus hour.
    pub strongest_focus_hour: Option<(String, i64)>,
    /// Time the Mac was asleep / off / at the login window. Not app usage.
    #[serde(default)]
    pub away_ms: i64,
}

/// Local-hour identity used to bucket the heatmap.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct HourKey(i32, u32, u32, u32);

fn local_hour_key(ms: i64) -> HourKey {
    let dt = local_dt(ms);
    HourKey(dt.year(), dt.month(), dt.day(), dt.hour())
}

fn local_hour_label(ms: i64) -> String {
    let dt = local_dt(ms);
    format!("{:02}:00", dt.hour())
}

pub fn compute_period(
    sessions: &[Session],
    categories: &BTreeMap<String, AppCategory>,
    config: &TrackerConfig,
    range: TimeRange,
) -> PeriodMetrics {
    let mut m = PeriodMetrics {
        wall_ms: range.end_ms - range.start_ms,
        ..Default::default()
    };

    // --- durations by app and by category + tracked total ---
    let mut by_app: BTreeMap<String, (AppCategory, i64)> = BTreeMap::new();
    for s in sessions {
        let cat = category_of(s, categories);
        let e = by_app.entry(s.bundle_id.clone()).or_insert((cat, 0));
        e.1 += s.duration_ms();
        m.tracked_ms += s.duration_ms();
        *m.category_durations.entry(cat).or_insert(0) += s.duration_ms();
    }
    let mut app_durations: Vec<(String, AppCategory, i64)> = by_app
        .into_iter()
        .map(|(b, (c, d))| (b, c, d))
        .collect();
    app_durations.sort_by(|a, b| b.2.cmp(&a.2).then_with(|| a.0.cmp(&b.0)));
    m.app_durations = app_durations;

    // --- switches (only between different apps; §28) ---
    for w in sessions.windows(2) {
        if w[0].bundle_id != w[1].bundle_id {
            m.switches += 1;
        }
    }
    let elapsed_ms = {
        let now = chrono::Utc::now().timestamp_millis();
        (now.min(range.end_ms) - range.start_ms).max(60_000)
    };
    m.switches_per_hour = m.switches as f64 / (elapsed_ms as f64 / 3_600_000.0);

    // --- quick visits (§29) ---
    m.quick_visits = sessions
        .iter()
        .filter(|s| s.duration_ms() <= config.quick_visit_tol_ms)
        .count() as u32;

    // --- checks: prev == next, middle short, middle != prev (§30) ---
    let mut checks: BTreeMap<String, u32> = BTreeMap::new();
    if sessions.len() >= 3 {
        for i in 1..sessions.len() - 1 {
            let prev = &sessions[i - 1];
            let cur = &sessions[i];
            let next = &sessions[i + 1];
            if cur.duration_ms() <= config.check_tol_ms
                && prev.bundle_id == next.bundle_id
                && cur.bundle_id != prev.bundle_id
            {
                *checks.entry(cur.bundle_id.clone()).or_insert(0) += 1;
            }
        }
    }
    m.checks = checks.values().sum();
    m.checks_per_app = checks;

    // --- focus seconds (direct sum of Focus-category time) ---
    m.focus_seconds_ms = sessions
        .iter()
        .filter(|s| category_of(s, categories) == AppCategory::Focus)
        .map(|s| s.duration_ms())
        .sum();

    // --- focus blocks with allowed interruptions (§31) ---
    m.focus_blocks = build_focus_blocks(sessions, categories, config);
    m.longest_focus_ms = m.focus_blocks.iter().map(|b| b.duration_ms).max().unwrap_or(0);

    // --- recovery time (§37) ---
    m.recovery = build_recovery(sessions, categories, config, &m.focus_blocks);

    // --- n-grams (§36) ---
    let seq = visit_sequence(sessions);
    m.ngrams = ngrams(&seq);
    m.most_common_ngram = m.ngrams.first().cloned();

    // --- hourly buckets (§33) ---
    m.hourly_buckets = build_hourly_buckets(sessions, categories, config, range);
    if let Some(b) = m.hourly_buckets.iter().max_by_key(|b| b.switches) {
        if b.switches > 0 {
            m.most_fragmented = Some((local_hour_label(b.start_ms), b.switches));
        }
    }
    if let Some(b) = m.hourly_buckets.iter().max_by_key(|b| b.focus_seconds_ms) {
        if b.focus_seconds_ms > 0 {
            m.strongest_focus_hour = Some((local_hour_label(b.start_ms), b.focus_seconds_ms));
        }
    }

    m
}

fn category_of(s: &Session, categories: &BTreeMap<String, AppCategory>) -> AppCategory {
    categories.get(&s.bundle_id).copied().unwrap_or(AppCategory::Neutral)
}

fn is_allowed_interrupt(cat: AppCategory, config: &TrackerConfig) -> bool {
    config.allowed_interrupt_categories.contains(&cat)
}

fn build_focus_blocks(
    sessions: &[Session],
    categories: &BTreeMap<String, AppCategory>,
    config: &TrackerConfig,
) -> Vec<FocusBlock> {
    let mut blocks = Vec::new();
    let mut cur: Option<FocusBlock> = None;
    for s in sessions {
        let cat = category_of(s, categories);
        if cat == AppCategory::Focus {
            match &mut cur {
                Some(b) => {
                    b.duration_ms += s.duration_ms();
                    b.end_ms = s.ended_at_ms;
                }
                None => {
                    cur = Some(FocusBlock {
                        start_ms: s.started_at_ms,
                        end_ms: s.ended_at_ms,
                        duration_ms: s.duration_ms(),
                    });
                }
            }
        } else if is_allowed_interrupt(cat, config) && s.duration_ms() <= config.interruption_tol_ms {
            // Short allowed interruption: block continues, its seconds are not
            // added to focus time and do not extend block end.
        } else {
            // Long interruption or disallowed category: close the block.
            if let Some(b) = cur.take() {
                blocks.push(b);
            }
        }
    }
    if let Some(b) = cur {
        blocks.push(b);
    }
    blocks
}

fn build_recovery(
    sessions: &[Session],
    categories: &BTreeMap<String, AppCategory>,
    config: &TrackerConfig,
    blocks: &[FocusBlock],
) -> RecoveryStats {
    let mut stats = RecoveryStats::default();
    let mut prev_block: Option<&FocusBlock> = None;
    for blk in blocks {
        if let Some(prev) = prev_block {
            let gap_ms = blk.start_ms - prev.end_ms;
            if gap_ms > 0 && gap_ms <= config.max_recovery_ms {
                // First non-focus session within the gap is the distractor.
                let distractor = sessions
                    .iter()
                    .filter(|s| {
                        s.started_at_ms >= prev.end_ms
                            && s.started_at_ms < blk.start_ms
                            && category_of(s, categories) != AppCategory::Focus
                    })
                    .min_by_key(|s| s.started_at_ms)
                    .map(|s| s.bundle_id.clone());
                if let Some(d) = distractor {
                    let e = stats.by_distractor.entry(d).or_default();
                    e.count += 1;
                    e.total_ms += gap_ms;
                    stats.samples += 1;
                }
            }
        }
        prev_block = Some(blk);
    }
    stats
}

fn ngrams(seq: &[String]) -> Vec<(Vec<String>, u32)> {
    let mut counts: BTreeMap<Vec<String>, u32> = BTreeMap::new();
    for n in [2usize, 3, 4] {
        if seq.len() < n {
            continue;
        }
        for w in seq.windows(n) {
            if w.len() < 2 || w.iter().all(|id| id == &w[0]) {
                continue;
            }
            *counts.entry(w.to_vec()).or_insert(0) += 1;
        }
    }
    let mut v: Vec<(Vec<String>, u32)> = counts.into_iter().collect();
    v.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| b.0.len().cmp(&a.0.len())));
    v
}

fn hour_start_ms(ms: i64) -> i64 {
    let dt = local_dt(ms);
    dt.with_minute(0)
        .and_then(|d| d.with_second(0))
        .and_then(|d| d.with_nanosecond(0))
        .map(|d| d.timestamp_millis())
        .unwrap_or(ms)
}

fn next_hour_ms(ms: i64) -> i64 {
    let dt = local_dt(hour_start_ms(ms));
    (dt + ChronoDuration::hours(1)).timestamp_millis()
}

fn build_hourly_buckets(
    sessions: &[Session],
    categories: &BTreeMap<String, AppCategory>,
    config: &TrackerConfig,
    range: TimeRange,
) -> Vec<HourBucket> {
    let mut map: BTreeMap<HourKey, HourBucket> = BTreeMap::new();

    let mut cursor = hour_start_ms(range.start_ms);
    while cursor < range.end_ms {
        let key = local_hour_key(cursor);
        map.entry(key).or_insert(HourBucket {
            start_ms: cursor,
            ..Default::default()
        });
        let next = next_hour_ms(cursor);
        if next <= cursor {
            break;
        }
        cursor = next;
    }

    for s in sessions {
        let mut t = s.started_at_ms;
        while t < s.ended_at_ms {
            let hour_end = next_hour_ms(t);
            let slice_end = hour_end.min(s.ended_at_ms);
            let dur = (slice_end - t).max(0);
            let key = local_hour_key(t);
            let b = map.entry(key).or_insert_with(|| HourBucket {
                start_ms: hour_start_ms(t),
                ..Default::default()
            });
            let cat = category_of(s, categories);
            b.active_ms += dur;
            b.focus_seconds_ms += if cat == AppCategory::Focus { dur } else { 0 };
            b.communication_seconds_ms += if cat == AppCategory::Communication { dur } else { 0 };
            b.entertainment_seconds_ms += if cat == AppCategory::Entertainment { dur } else { 0 };
            if hour_end <= t {
                break;
            }
            t = slice_end;
        }
    }

    // switches: attribute to the hour of the following session's start.
    for w in sessions.windows(2) {
        if w[0].bundle_id != w[1].bundle_id {
            let key = local_hour_key(w[1].started_at_ms);
            map.entry(key)
                .or_insert_with(|| HourBucket { start_ms: w[1].started_at_ms, ..Default::default() })
                .switches += 1;
        }
    }

    // checks: attribute to the hour of the checked app session.
    if sessions.len() >= 3 {
        for w in sessions.windows(3) {
            let cur = &w[1];
            if cur.duration_ms() <= config.check_tol_ms
                && w[0].bundle_id == w[2].bundle_id
                && cur.bundle_id != w[0].bundle_id
            {
                let key = local_hour_key(cur.started_at_ms);
                map.entry(key)
                    .or_insert_with(|| HourBucket { start_ms: cur.started_at_ms, ..Default::default() })
                    .checks += 1;
            }
        }
    }

    let mut v: Vec<HourBucket> = map.into_values().collect();
    v.sort_by_key(|b| b.start_ms);
    v
}

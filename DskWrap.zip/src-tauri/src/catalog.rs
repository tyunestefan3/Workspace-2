//! Known Mac apps (and common site wrappers) → category.
//! Applied only when an app is first seen. The user can override later.

use crate::models::AppCategory;

pub fn category_for(bundle_id: &str, display_name: &str) -> AppCategory {
    if let Some(c) = lookup(bundle_id) {
        return c;
    }
    heuristic(bundle_id, display_name)
}

/// Login window, lock screen, screensaver: the Mac is not being used.
/// Never a real app, never counted.
pub fn is_system_away(bundle_id: &str) -> bool {
    let l = bundle_id.to_ascii_lowercase();
    l == "loginwindow"
        || l.contains("loginwindow")
        || l == "com.apple.screensaver.engine"
        || l == "com.apple.screensaverengine"
        || l.contains("screensaver.engine")
        || l == "com.apple.securityagent"
        || l == "com.apple.lockoutagent"
        || l.contains("coreauthui")
        || l.contains("coreautha")
}

pub fn is_system_away_name(display_name: &str) -> bool {
    let l = display_name.to_ascii_lowercase();
    l == "loginwindow" || l.contains("login window") || l.contains("экран входа")
}

/// Never show reverse-DNS ids like `com.apple.Safari` in the UI.
pub fn looks_like_bundle_id(s: &str) -> bool {
    let l = s.trim();
    if l.is_empty() || !l.contains('.') {
        return false;
    }
    let head = l.split('.').next().unwrap_or("");
    matches!(head, "com" | "org" | "net" | "io" | "ru" | "co" | "dev" | "app" | "tv" | "me" | "us" | "ch" | "ph" | "im" | "md" | "abnerworks")
        || l.chars().filter(|c| *c == '.').count() >= 2
}

pub fn friendly_name(bundle_id: &str, display_name: &str) -> String {
    let d = display_name.trim();
    if !d.is_empty() && !looks_like_bundle_id(d) && !is_system_away_name(d) {
        return d.to_string();
    }
    humanize_bundle(bundle_id)
}

fn humanize_bundle(bundle_id: &str) -> String {
    let last = bundle_id.rsplit('.').next().unwrap_or(bundle_id).trim();
    let lower = last.to_ascii_lowercase();
    let special = match lower.as_str() {
        "finder" => "Finder",
        "safari" => "Safari",
        "terminal" => "Terminal",
        "preview" => "Preview",
        "notes" => "Notes",
        "mail" => "Mail",
        "ical" => "Calendar",
        "mobilesms" => "Messages",
        "facetime" => "FaceTime",
        "systemsettings" | "systempreferences" => "System Settings",
        "xcode" => "Xcode",
        "itunes" => "Music",
        "music" => "Music",
        "ibooksx" => "Books",
        "quicktimeplayerx" => "QuickTime",
        "textedit" => "TextEdit",
        "calculator" => "Calculator",
        "screencaptureui" | "screenshot" => "Screenshot",
        "appstore" => "App Store",
        "torbrowser" => "Tor Browser",
        "vscode" => "VS Code",
        "vscodeinsiders" => "VS Code",
        "iterm2" => "iTerm",
        "slackmacgap" => "Slack",
        _ => "",
    };
    if !special.is_empty() {
        return special.to_string();
    }
    let l = bundle_id.to_ascii_lowercase();
    if l.contains("telegram") {
        return "Telegram".into();
    }
    if l.contains("safari") {
        return "Safari".into();
    }
    if last.is_empty() {
        return bundle_id.to_string();
    }
    let mut out = String::new();
    for (i, c) in last.chars().enumerate() {
        if i > 0 && c.is_ascii_uppercase() {
            out.push(' ');
        }
        if i == 0 {
            for u in c.to_uppercase() {
                out.push(u);
            }
        } else {
            out.push(c);
        }
    }
    out.replace('_', " ").replace('-', " ")
}

pub fn is_noise_bundle(bundle_id: &str) -> bool {
    if is_system_away(bundle_id) {
        return true;
    }
    let l = bundle_id.to_ascii_lowercase();
    if matches!(
        l.as_str(),
        "com.apple.safari" | "com.apple.finder" | "com.apple.preview" | "com.apple.notes"
    ) {
        return false;
    }
    l.contains(".helper")
        || l.contains("crashpad")
        || l.contains(".xpc")
        || l.contains("webkit.networking")
        || l.contains("webkit.gpu")
        || l.contains("webkit.webcontent")
        || l.contains("com.apple.webkit")
        || l.contains("softwareupdated")
        || l.contains("coreservicesuiagent")
        || l.contains("nativemessaginghost")
        || l.contains("plugin-container")
        || l.contains(".renderer")
        || l.contains("gpu-process")
        || l.contains("notificationcenter")
        || l.contains("controlcenter")
        || l.contains("spotlight")
        || l.contains("systemuiserver")
        || l.contains("windowmanager")
        || l.contains("wallpaper")
        || l == "com.apple.dock"
        || l.contains("textinputmenuagent")
        || l.contains("airplayuiagent")
        || l.contains("siri")
}

pub fn is_noise_name(display_name: &str) -> bool {
    let l = display_name.to_ascii_lowercase();
    l.contains("notification center")
        || l.contains("control center")
        || l.contains("центр уведомлен")
        || l.contains("центр керування")
        || l.contains("spotlight")
        || l == "dock"
        || is_system_away_name(display_name)
}

fn lookup(bundle_id: &str) -> Option<AppCategory> {
    use AppCategory::*;
    for &(id, cat) in APPS {
        if id == bundle_id {
            return Some(cat);
        }
    }
    None
}

const APPS: &[(&str, AppCategory)] = &[
    // Focus — editors, IDEs, design, docs
    ("com.microsoft.VSCode", AppCategory::Focus),
    ("com.microsoft.VSCodeInsiders", AppCategory::Focus),
    ("com.todesktop.230313mzl4w4u92", AppCategory::Focus), // Cursor
    ("com.anysphere.cursor", AppCategory::Focus),
    ("dev.zed.Zed", AppCategory::Focus),
    ("com.exafunction.windsurf", AppCategory::Focus),
    ("com.apple.dt.Xcode", AppCategory::Focus),
    ("com.jetbrains.intellij", AppCategory::Focus),
    ("com.jetbrains.pycharm", AppCategory::Focus),
    ("com.jetbrains.WebStorm", AppCategory::Focus),
    ("com.jetbrains.CLion", AppCategory::Focus),
    ("com.jetbrains.goland", AppCategory::Focus),
    ("com.jetbrains.datagrip", AppCategory::Focus),
    ("com.jetbrains.phpstorm", AppCategory::Focus),
    ("com.jetbrains.rubymine", AppCategory::Focus),
    ("com.jetbrains.rider", AppCategory::Focus),
    ("com.google.android.studio", AppCategory::Focus),
    ("com.sublimetext.4", AppCategory::Focus),
    ("com.panic.Nova", AppCategory::Focus),
    ("com.barebones.bbedit", AppCategory::Focus),
    ("com.macromates.TextMate", AppCategory::Focus),
    ("com.github.atom", AppCategory::Focus),
    ("com.postmanlabs.mac", AppCategory::Focus),
    ("com.electron.dockerdesktop", AppCategory::Focus),
    ("com.docker.docker", AppCategory::Focus),
    ("com.figma.Desktop", AppCategory::Focus),
    ("com.adobe.Photoshop", AppCategory::Focus),
    ("com.adobe.illustrator", AppCategory::Focus),
    ("com.adobe.Illustrator", AppCategory::Focus),
    ("com.adobe.InDesign", AppCategory::Focus),
    ("com.adobe.PremierePro", AppCategory::Focus),
    ("com.adobe.AfterEffects", AppCategory::Focus),
    ("com.adobe.Acrobat.Pro", AppCategory::Focus),
    ("com.apple.FinalCut", AppCategory::Focus),
    ("com.apple.motionapp", AppCategory::Focus),
    ("com.apple.iMovieApp", AppCategory::Focus),
    ("com.apple.logic10", AppCategory::Focus),
    ("com.apple.garageband10", AppCategory::Focus),
    ("com.blackmagic-design.DaVinciResolve", AppCategory::Focus),
    ("com.bohemiancoding.sketch3", AppCategory::Focus),
    ("com.seriflabs.affinityphoto2", AppCategory::Focus),
    ("com.seriflabs.affinitydesigner2", AppCategory::Focus),
    ("md.obsidian", AppCategory::Focus),
    ("notion.id", AppCategory::Focus),
    ("com.lukilabs.lukiapp", AppCategory::Focus),
    ("com.craft.craft", AppCategory::Focus),
    ("com.apple.iWork.Pages", AppCategory::Focus),
    ("com.apple.iWork.Numbers", AppCategory::Focus),
    ("com.apple.iWork.Keynote", AppCategory::Focus),
    ("com.microsoft.Word", AppCategory::Focus),
    ("com.microsoft.Excel", AppCategory::Focus),
    ("com.microsoft.Powerpoint", AppCategory::Focus),
    ("com.microsoft.onenote.mac", AppCategory::Focus),
    ("com.github.GitHubClient", AppCategory::Focus),
    ("com.apple.Terminal", AppCategory::Focus),
    ("com.googlecode.iterm2", AppCategory::Focus),
    ("dev.warp.Warp-Stable", AppCategory::Focus),
    ("com.github.wez.wezterm", AppCategory::Focus),
    ("net.kovidgoyal.kitty", AppCategory::Focus),
    ("com.mitchellh.ghostty", AppCategory::Focus),
    ("co.zeit.hyper", AppCategory::Focus),
    ("com.replit.app", AppCategory::Focus),
    ("com.linear", AppCategory::Focus),
    ("com.trello", AppCategory::Focus),
    ("com.asana.desktop", AppCategory::Focus),
    ("com.clickup.desktop", AppCategory::Focus),
    ("com.todoist.mac.Todoist", AppCategory::Focus),
    ("com.culturedcode.ThingsMac", AppCategory::Focus),
    ("com.omnigroup.OmniFocus3", AppCategory::Focus),
    ("net.xmind.vana", AppCategory::Focus),
    ("com.mindnode.MindNode", AppCategory::Focus),
    ("abnerworks.Typora", AppCategory::Focus),
    ("com.uranusjr.macdown", AppCategory::Focus),
    ("com.tinyapp.TablePlus", AppCategory::Focus),
    ("com.sequel-ace.sequel-ace", AppCategory::Focus),
    ("com.mongodb.compass", AppCategory::Focus),
    ("com.getstatista.insomnia", AppCategory::Focus),
    ("com.usebruno.app", AppCategory::Focus),
    ("com.axosoft.gitkraken", AppCategory::Focus),
    ("com.fork.Fork", AppCategory::Focus),
    ("com.github.GitHubDesktop", AppCategory::Focus),
    ("org.wireshark.Wireshark", AppCategory::Focus),
    ("com.apple.dt.Instruments", AppCategory::Focus),
    ("com.apple.Playgrounds", AppCategory::Focus),
    ("com.panic.Transmit", AppCategory::Focus),
    ("com.apple.dt.CommandLineTools", AppCategory::Focus),

    // Communication
    ("org.telegram.desktop", AppCategory::Communication),
    ("ru.keepcoder.Telegram", AppCategory::Communication),
    ("com.tdesktop.Telegram", AppCategory::Communication),
    ("ph.telegra.Telegraph", AppCategory::Communication),
    ("net.whatsapp.WhatsApp", AppCategory::Communication),
    ("com.hnc.Discord", AppCategory::Communication),
    ("com.hnc.DiscordPTB", AppCategory::Communication),
    ("us.zoom.xos", AppCategory::Communication),
    ("com.microsoft.teams2", AppCategory::Communication),
    ("com.microsoft.teams", AppCategory::Communication),
    ("com.microsoft.Outlook", AppCategory::Communication),
    ("com.apple.mail", AppCategory::Communication),
    ("com.apple.MobileSMS", AppCategory::Communication),
    ("com.apple.FaceTime", AppCategory::Communication),
    ("com.skype.skype", AppCategory::Communication),
    ("com.viber.osx", AppCategory::Communication),
    ("org.whispersystems.signal-desktop", AppCategory::Communication),
    ("im.riot.app", AppCategory::Communication),
    ("ru.vk.desktop", AppCategory::Communication),
    ("ru.yandex.mail", AppCategory::Communication),
    ("com.readdle.smartemail", AppCategory::Communication),
    ("com.tinyspeck.slackmacgap", AppCategory::Communication),
    ("com.tinyspeck.slackmacgap.helper", AppCategory::Communication),
    ("com.apple.iCal", AppCategory::Communication),
    ("com.apple.reminders", AppCategory::Communication),
    ("com.flexibits.fantastical2.mac", AppCategory::Communication),
    ("com.openai.chat", AppCategory::Communication),
    ("com.anthropic.claudefordesktop", AppCategory::Communication),
    ("com.electron.perplexity", AppCategory::Communication),
    ("com.grammarly.ProjectLlama", AppCategory::Communication),
    ("com.loom.desktop", AppCategory::Communication),
    ("us.zoom.ringcentral", AppCategory::Communication),
    ("com.webex.meetingmanager", AppCategory::Communication),
    ("com.cisco.webexmeetingsapp", AppCategory::Communication),
    ("com.mattermost.desktop", AppCategory::Communication),
    ("com.rocket.chat", AppCategory::Communication),
    ("ch.protonmail.desktop", AppCategory::Communication),
    ("com.superhuman.electron", AppCategory::Communication),
    ("com.mimestream.Mimestream", AppCategory::Communication),
    ("ru.max.desktop", AppCategory::Communication),
    ("im.vector.app", AppCategory::Communication),

    // Entertainment
    ("com.spotify.client", AppCategory::Entertainment),
    ("com.apple.Music", AppCategory::Entertainment),
    ("com.apple.TV", AppCategory::Entertainment),
    ("com.apple.podcasts", AppCategory::Entertainment),
    ("com.google.YouTube", AppCategory::Entertainment),
    ("com.netflix.Netflix", AppCategory::Entertainment),
    ("tv.twitch", AppCategory::Entertainment),
    ("com.colliderli.iina", AppCategory::Entertainment),
    ("org.videolan.vlc", AppCategory::Entertainment),
    ("com.valvesoftware.steam", AppCategory::Entertainment),
    ("com.epicgames.EpicGamesLauncher", AppCategory::Entertainment),
    ("com.apple.iBooksX", AppCategory::Entertainment),
    ("com.apple.Photos", AppCategory::Entertainment),
    ("ru.yandex.desktop.music", AppCategory::Entertainment),
    ("com.apple.QuickTimePlayerX", AppCategory::Entertainment),
    ("com.hnc.DiscordPTB", AppCategory::Entertainment),
    ("com.blizzard.Battle.net", AppCategory::Entertainment),
    ("com.riotgames.LeagueofLegends.LeagueClient", AppCategory::Entertainment),
    ("com.nvidia.gfnpc.mall", AppCategory::Entertainment),
    ("tv.plex.desktop", AppCategory::Entertainment),
    ("com.colliderli.iina", AppCategory::Entertainment),
    ("com.elgato.StreamDeck", AppCategory::Utility),
    ("com.obsproject.obs-studio", AppCategory::Entertainment),
    ("ru.yandex.desktop.kino", AppCategory::Entertainment),
    ("com.apple.freeform", AppCategory::Focus),

    // Browsers
    ("com.apple.Safari", AppCategory::Neutral),
    ("com.google.Chrome", AppCategory::Neutral),
    ("com.google.Chrome.canary", AppCategory::Neutral),
    ("com.google.Chrome.beta", AppCategory::Neutral),
    ("org.mozilla.firefox", AppCategory::Neutral),
    ("org.mozilla.firefoxdeveloperedition", AppCategory::Neutral),
    ("com.microsoft.edgemac", AppCategory::Neutral),
    ("company.thebrowser.Browser", AppCategory::Neutral), // Arc
    ("company.thebrowser.dia", AppCategory::Neutral),
    ("com.brave.Browser", AppCategory::Neutral),
    ("com.operasoftware.Opera", AppCategory::Neutral),
    ("com.operasoftware.OperaGX", AppCategory::Neutral),
    ("ru.yandex.desktop.browser", AppCategory::Neutral),
    ("ru.yandex.desktop", AppCategory::Neutral),
    ("com.vivaldi.Vivaldi", AppCategory::Neutral),
    ("org.chromium.Chromium", AppCategory::Neutral),
    ("com.apple.SafariTechnologyPreview", AppCategory::Neutral),
    ("com.kagi.kagimacOS", AppCategory::Neutral),
    ("org.torproject.torbrowser", AppCategory::Neutral),
    ("com.duckduckgo.macos.browser", AppCategory::Neutral),
    ("com.sigmaos.sigmaos.macos", AppCategory::Neutral),
    ("com.browserosaurus", AppCategory::Utility),

    // Utility
    ("com.apple.finder", AppCategory::Utility),
    ("com.apple.Preview", AppCategory::Utility),
    ("com.apple.systempreferences", AppCategory::Utility),
    ("com.apple.SystemSettings", AppCategory::Utility),
    ("com.apple.ActivityMonitor", AppCategory::Utility),
    ("com.apple.Console", AppCategory::Utility),
    ("com.apple.DiskUtility", AppCategory::Utility),
    ("com.apple.calculator", AppCategory::Utility),
    ("com.apple.Notes", AppCategory::Utility),
    ("com.apple.TextEdit", AppCategory::Utility),
    ("com.apple.Stickies", AppCategory::Utility),
    ("com.apple.FontBook", AppCategory::Utility),
    ("com.apple.Screenshot", AppCategory::Utility),
    ("com.apple.screencaptureui", AppCategory::Utility),
    ("com.1password.1password", AppCategory::Utility),
    ("com.agilebits.onepassword7", AppCategory::Utility),
    ("com.bitwarden.desktop", AppCategory::Utility),
    ("com.lastpass.LastPass", AppCategory::Utility),
    ("com.raycast.macos", AppCategory::Utility),
    ("com.runningwithcrayons.Alfred", AppCategory::Utility),
    ("com.macpaw.CleanMyMac5", AppCategory::Utility),
    ("com.macpaw.CleanMyMac4", AppCategory::Utility),
    ("com.macpaw.CleanMyMac-mas", AppCategory::Utility),
    ("com.apple.AppStore", AppCategory::Utility),
    ("com.apple.dt.XcodePreviews", AppCategory::Focus),
    ("com.apple.Maps", AppCategory::Utility),
    ("com.apple.weather", AppCategory::Utility),
    ("com.apple.clock", AppCategory::Utility),
    ("com.apple.Home", AppCategory::Utility),
    ("com.apple.Shortcuts", AppCategory::Utility),
    ("com.apple.Passwords", AppCategory::Utility),
    ("com.apple.tips", AppCategory::Utility),
    ("com.apple.Image_Capture", AppCategory::Utility),
    ("com.apple.Dictionary", AppCategory::Utility),
    ("com.apple.VoiceMemos", AppCategory::Utility),
    ("com.apple.iChat", AppCategory::Communication),
    ("com.apple.AddressBook", AppCategory::Utility),
    ("com.apple.archiveutility", AppCategory::Utility),
    ("com.apple.ScriptEditor2", AppCategory::Focus),
    ("com.apple.Automator", AppCategory::Utility),
    ("com.apple.ColorSyncUtility", AppCategory::Utility),
    ("com.apple.DigitalColorMeter", AppCategory::Utility),
    ("com.apple.Grapher", AppCategory::Utility),
    ("com.apple.MigrationAssistant", AppCategory::Utility),
    ("com.apple.TimeMachine", AppCategory::Utility),
    ("com.apple.AirPortBaseStationAgent", AppCategory::Utility),
    ("com.lwouis.alt-tab-macos", AppCategory::Utility),
    ("com.if.Amphetamine", AppCategory::Utility),
    ("pl.maketheweb.cleanshotx", AppCategory::Utility),
    ("com.cleanshot.cleanshotx", AppCategory::Utility),
    ("com.mediaatelier.CheatSheet", AppCategory::Utility),
    ("com.knollsoft.Rectangle", AppCategory::Utility),
    ("com.lwouis.alt-tab-macos", AppCategory::Utility),
    ("secretive", AppCategory::Utility),
    ("com.apple.finder.Open-iCloudDrive", AppCategory::Utility),
    ("com.google.drivefs", AppCategory::Utility),
    ("com.microsoft.OneDrive", AppCategory::Utility),
    ("com.getdropbox.dropbox", AppCategory::Utility),
    ("ru.yandex.desktop.disk", AppCategory::Utility),
    ("com.apple.CloudDocs.MobileDocumentsFileProviderUI", AppCategory::Utility),
    ("com.apple.iCloudSettings", AppCategory::Utility),
    ("com.transmissionbt.transmission", AppCategory::Utility),
    ("org.m0k.transmission", AppCategory::Utility),
    ("org.qbittorrent.qBittorrent", AppCategory::Utility),
    ("com.colliderli.iina", AppCategory::Entertainment),
    ("io.tailscale.ipn.macsys", AppCategory::Utility),
    ("com.wireguard.macos", AppCategory::Utility),
    ("ch.protonvpn.mac", AppCategory::Utility),
    ("com.nordvpn.NordVPN", AppCategory::Utility),
    ("com.expressvpn.ExpressVPN", AppCategory::Utility),
    ("com.surfshark.vpnclient.macos", AppCategory::Utility),
    ("com.adguard.mac.AdGuard", AppCategory::Utility),
    ("com.apple.Safari.WebApp", AppCategory::Neutral),
];

fn heuristic(bundle_id: &str, display_name: &str) -> AppCategory {
    use AppCategory::*;
    let hay = format!("{} {}", bundle_id.to_ascii_lowercase(), display_name.to_ascii_lowercase());
    let has = |n: &str| hay.contains(n);

    if has("telegram") || has("whatsapp") || has("slack") || has("discord")
        || has("zoom") || has("teams") || has("skype") || has("mail")
        || has("message") || has("facetime") || has("viber") || has("signal")
        || has("mattermost") || (has("proton") && has("mail"))
    {
        return Communication;
    }
    if has("spotify") || has("youtube") || has("netflix") || has("twitch")
        || has("music") || has("podcast") || has("steam") || has("iina")
        || has("vlc") || has("plex") || has("кино") || has("музык")
    {
        return Entertainment;
    }
    if has("code") || has("xcode") || has("terminal") || has("iterm")
        || has("jetbrains") || has("pycharm") || has("webstorm") || has("intellij")
        || has("cursor") || has("sublime") || has("figma") || has("sketch")
        || has("photoshop") || has("obsidian") || has("notion") || has("pages")
        || has("keynote") || has("excel") || has("powerpoint") || has("word")
        || has("warp") || has("ghostty")
    {
        return Focus;
    }
    if has("finder") || has("preview") || has("settings") || has("preferenc")
        || has("1password") || has("bitwarden") || has("alfred") || has("raycast")
        || has("calculator") || has("cleanmymac") || has("dropbox") || has("onedrive")
    {
        return Utility;
    }
    if has("safari") || has("chrome") || has("firefox") || has("edge")
        || has("brave") || has("opera") || has("yandex") || has("browser") || has("arc")
    {
        return Neutral;
    }
    Neutral
}

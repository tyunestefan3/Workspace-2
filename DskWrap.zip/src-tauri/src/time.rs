//! Tiny local-time helpers. Everything is stored in UTC ms (§22); we only look
//! at *local* time when bucketing and labelling, so DST/offset handling stays
//! in one place.

use chrono::{DateTime, Local, TimeZone, Utc};

/// Convert a UTC unix-millis timestamp to a `DateTime<Local>`.
pub fn local_dt(ms: i64) -> DateTime<Local> {
    Utc.timestamp_millis_opt(ms)
        .single()
        .expect("valid unix ms")
        .with_timezone(&Local)
}

pub fn fmt_duration(ms: i64) -> String {
    let sec = ms / 1000;
    let m = sec / 60;
    if m >= 60 {
        format!("{}h {:02}m", m / 60, m % 60)
    } else if m > 0 {
        format!("{}m", m)
    } else {
        format!("{}s", sec % 60)
    }
}

fn ru_plural<'a>(n: i64, one: &'a str, few: &'a str, many: &'a str) -> &'a str {
    let v = n.abs();
    let n10 = v % 10;
    let n100 = v % 100;
    if n10 == 1 && n100 != 11 {
        one
    } else if (2..=4).contains(&n10) && !(12..=14).contains(&n100) {
        few
    } else {
        many
    }
}

fn hours_word(n: i64, loc: &str) -> String {
    match loc {
        "ru" => ru_plural(n, "час", "часа", "часов").to_string(),
        "es" => if n == 1 { "hora" } else { "horas" }.to_string(),
        "fr" => if n == 1 { "heure" } else { "heures" }.to_string(),
        "zh" => "小时".to_string(),
        _ => if n == 1 { "hour" } else { "hours" }.to_string(),
    }
}

fn minutes_word(n: i64, loc: &str) -> String {
    match loc {
        "ru" => ru_plural(n, "минута", "минуты", "минут").to_string(),
        "es" => if n == 1 { "minuto" } else { "minutos" }.to_string(),
        "fr" => if n == 1 { "minute" } else { "minutes" }.to_string(),
        "zh" => "分钟".to_string(),
        _ => if n == 1 { "minute" } else { "minutes" }.to_string(),
    }
}

fn seconds_word(n: i64, loc: &str) -> String {
    match loc {
        "ru" => ru_plural(n, "секунда", "секунды", "секунд").to_string(),
        "es" => if n == 1 { "segundo" } else { "segundos" }.to_string(),
        "fr" => if n == 1 { "seconde" } else { "secondes" }.to_string(),
        "zh" => "秒".to_string(),
        _ => if n == 1 { "second" } else { "seconds" }.to_string(),
    }
}

/// Grammatical duration for the tray and native chrome.
pub fn fmt_duration_locale(ms: i64, locale: &str) -> String {
    let loc = crate::i18n::normalize(locale);
    let sec = (ms / 1000).max(0);
    let total_min = sec / 60;
    let s = sec % 60;
    if total_min >= 60 {
        let h = total_min / 60;
        let m = total_min % 60;
        if m == 0 {
            format!("{} {}", h, hours_word(h, loc))
        } else {
            format!("{} {} {} {}", h, hours_word(h, loc), m, minutes_word(m, loc))
        }
    } else if total_min > 0 {
        format!("{} {}", total_min, minutes_word(total_min, loc))
    } else {
        format!("{} {}", s, seconds_word(s, loc))
    }
}

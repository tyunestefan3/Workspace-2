//! Weekly (and daily) Wrapped payloads (§40). This is the *deterministic*
//! bridge from analytics to the React UI: analytics computes numbers, this
//! module picks which cards to show and fills in text. No LLM. The UI never
//! recomputes anything — it only renders.

use serde::Serialize;

use crate::analytics::PeriodMetrics;
use crate::models::{AppCategory, AppRecord, TrackerConfig};
use crate::personality::MacType;

/// A single shareable card. The front-end maps `kind` to a template and just
/// fills in the fields.
#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum WrappedCard {
    YourWeek {
        tracked_ms: i64,
    },
    MainCharacter {
        bundle_id: String,
        display_name: String,
        duration_ms: i64,
        category: AppCategory,
    },
    CantResist {
        bundle_id: String,
        display_name: String,
        checks: u32,
    },
    ChaosHour {
        label: String,
        switches: u32,
    },
    DeepDive {
        focus_ms: i64,
    },
    YourLoop {
        sequence: Vec<String>,
        count: u32,
    },
    MacType {
        label: String,
    },
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct WeeklyWrapped {
    pub start_ms: i64,
    pub end_ms: i64,
    pub tracked_ms: i64,
    pub personality: MacType,
    pub cards: Vec<WrappedCard>,
}

fn display_name(apps: &[AppRecord], bundle_id: &str) -> String {
    let raw = apps
        .iter()
        .find(|a| a.bundle_id.eq_ignore_ascii_case(bundle_id))
        .map(|a| a.display_name.as_str())
        .unwrap_or("");
    crate::catalog::friendly_name(bundle_id, raw)
}

fn category_of<'a>(apps: &'a [AppRecord], bundle_id: &str) -> AppCategory {
    apps.iter()
        .find(|a| a.bundle_id == bundle_id)
        .map(|a| a.category)
        .unwrap_or(AppCategory::Neutral)
}

/// Build the ordered card deck. Only cards with enough evidence are included
/// (§38) — we do not shout "your most fragmented hour" from a single switch.
pub fn weekly(
    metrics: &PeriodMetrics,
    apps: &[AppRecord],
    config: &TrackerConfig,
    mac_type: MacType,
    start_ms: i64,
    end_ms: i64,
) -> WeeklyWrapped {
    if metrics.tracked_ms <= 0 {
        return WeeklyWrapped {
            start_ms,
            end_ms,
            tracked_ms: 0,
            personality: mac_type,
            cards: vec![],
        };
    }

    let mut cards = vec![WrappedCard::YourWeek {
        tracked_ms: metrics.tracked_ms,
    }];

    // Main character: top focus/any app by duration (not the self app).
    if let Some((bundle, _cat, dur)) = metrics.app_durations.first() {
        if *dur > 0 {
            cards.push(WrappedCard::MainCharacter {
                bundle_id: bundle.clone(),
                display_name: display_name(apps, bundle),
                duration_ms: *dur,
                category: category_of(apps, bundle),
            });
        }
    }

    // Can't resist: most checked app.
    if let Some((bundle, count)) = metrics
        .checks_per_app
        .iter()
        .max_by_key(|(_, c)| **c)
        .map(|(b, c)| (b.clone(), *c))
    {
        if count >= config.min_samples {
            cards.push(WrappedCard::CantResist {
                bundle_id: bundle.clone(),
                display_name: display_name(apps, &bundle),
                checks: count,
            });
        }
    }

    // Chaos hour: most fragmented hour.
    if let Some((label, switches)) = &metrics.most_fragmented {
        if *switches >= 3 {
            cards.push(WrappedCard::ChaosHour {
                label: label.clone(),
                switches: *switches,
            });
        }
    }

    // Deep dive: longest focus block.
    if metrics.longest_focus_ms > 0 {
        cards.push(WrappedCard::DeepDive {
            focus_ms: metrics.longest_focus_ms,
        });
    }

    // Your loop: most common n-gram.
    if let Some((seq, count)) = &metrics.most_common_ngram {
        if *count >= config.min_samples && seq.len() >= 2 {
            cards.push(WrappedCard::YourLoop {
                sequence: seq.iter().map(|b| display_name(apps, b)).collect(),
                count: *count,
            });
        }
    }

    // Mac type: fun recap, always last.
    cards.push(WrappedCard::MacType {
        label: mac_type.label().to_string(),
    });

    WeeklyWrapped {
        start_ms,
        end_ms,
        tracked_ms: metrics.tracked_ms,
        personality: mac_type,
        cards,
    }
}

//! SQLite persistence layer (§7, §8). Events live for ever; everything else is
//! derived. WAL + synchronous=FULL + a single writer (concurrency handled by
//! the tracker task in §56, which we mirror with a single &mut Connection).

use chrono::Utc;
use rusqlite::{Connection, OpenFlags};

use crate::models::{AppCategory, AppRecord, Event, EventType};

pub const SCHEMA_VERSION: i64 = 1;

pub fn open(path: &std::path::Path) -> rusqlite::Result<Connection> {
    let conn = Connection::open_with_flags(
        path,
        OpenFlags::SQLITE_OPEN_READ_WRITE | OpenFlags::SQLITE_OPEN_CREATE | OpenFlags::SQLITE_OPEN_URI,
    )?;
    configure(&conn)?;
    migrate(&conn)?;
    Ok(conn)
}

pub fn configure(conn: &Connection) -> rusqlite::Result<()> {
    conn.execute_batch(
        "PRAGMA journal_mode = WAL;
         PRAGMA synchronous = FULL;
         PRAGMA foreign_keys = ON;
         PRAGMA busy_timeout = 5000;",
    )?;
    Ok(())
}

/// Migrations are forward-only and versioned via `PRAGMA user_version` (§7).
pub fn migrate(conn: &Connection) -> rusqlite::Result<()> {
    conn.execute_batch(
        "CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp_ms INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            bundle_id TEXT,
            created_at_ms INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp_ms);
        CREATE INDEX IF NOT EXISTS idx_events_bundle_timestamp ON events(bundle_id, timestamp_ms);

        CREATE TABLE IF NOT EXISTS apps (
            bundle_id TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT 'neutral',
            ignored INTEGER NOT NULL DEFAULT 0,
            first_seen_at_ms INTEGER NOT NULL,
            last_seen_at_ms INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS tracker_state (
            id INTEGER PRIMARY KEY CHECK(id = 1),
            current_bundle_id TEXT,
            current_state TEXT NOT NULL,
            last_event_at_ms INTEGER,
            last_heartbeat_at_ms INTEGER,
            clean_shutdown INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );",
    )?;
    conn.pragma_update(None, "user_version", SCHEMA_VERSION)
}

pub fn event_type_to_str(t: EventType) -> &'static str {
    match t {
        EventType::TrackerStart => "tracker_start",
        EventType::TrackerStop => "tracker_stop",
        EventType::AppActive => "app_active",
        EventType::IdleStart => "idle_start",
        EventType::IdleEnd => "idle_end",
        EventType::Sleep => "sleep",
        EventType::Wake => "wake",
        EventType::Pause => "pause",
        EventType::Resume => "resume",
    }
}

pub fn event_type_from_str(s: &str) -> EventType {
    match s {
        "tracker_start" => EventType::TrackerStart,
        "tracker_stop" => EventType::TrackerStop,
        "idle_start" => EventType::IdleStart,
        "idle_end" => EventType::IdleEnd,
        "app_active" => EventType::AppActive,
        "sleep" => EventType::Sleep,
        "wake" => EventType::Wake,
        "pause" => EventType::Pause,
        "resume" => EventType::Resume,
        _ => EventType::AppActive,
    }
}

pub fn insert_event(conn: &mut Connection, e: &Event) -> rusqlite::Result<()> {
    let now_ms = Utc::now().timestamp_millis();
    conn.execute(
        "INSERT INTO events (timestamp_ms, event_type, bundle_id, created_at_ms)
         VALUES (?1, ?2, ?3, ?4)",
        rusqlite::params![e.timestamp_ms, event_type_to_str(e.event_type), e.bundle_id, now_ms],
    )?;
    Ok(())
}

pub fn events_in_range(
    conn: &Connection,
    start_ms: i64,
    end_ms: i64,
) -> rusqlite::Result<Vec<Event>> {
    let mut stmt = conn.prepare(
        "SELECT timestamp_ms, event_type, bundle_id
         FROM events
         WHERE timestamp_ms >= ?1 AND timestamp_ms < ?2
         ORDER BY timestamp_ms ASC, id ASC",
    )?;
    let rows = stmt.query_map(rusqlite::params![start_ms, end_ms], |row| {
        let t: String = row.get(1)?;
        Ok(Event {
            timestamp_ms: row.get(0)?,
            event_type: event_type_from_str(&t),
            bundle_id: row.get(2)?,
        })
    })?;
    rows.collect()
}

/// Remember a newly seen app without overwriting the user's category/ignore.
pub fn touch_app(conn: &Connection, app: &AppRecord) -> rusqlite::Result<()> {
    let now_ms = Utc::now().timestamp_millis();
    conn.execute(
        "INSERT INTO apps (bundle_id, display_name, category, ignored, first_seen_at_ms, last_seen_at_ms)
         VALUES (?1, ?2, ?3, ?4, ?5, ?5)
         ON CONFLICT(bundle_id) DO UPDATE SET
            display_name = excluded.display_name,
            last_seen_at_ms = excluded.last_seen_at_ms",
        rusqlite::params![
            app.bundle_id,
            app.display_name,
            app_category_to_str(app.category),
            app.ignored as i32,
            now_ms
        ],
    )?;
    Ok(())
}

pub fn upsert_app(conn: &Connection, app: &AppRecord) -> rusqlite::Result<()> {
    let now_ms = Utc::now().timestamp_millis();
    conn.execute(
        "INSERT INTO apps (bundle_id, display_name, category, ignored, first_seen_at_ms, last_seen_at_ms)
         VALUES (?1, ?2, ?3, ?4, ?5, ?5)
         ON CONFLICT(bundle_id) DO UPDATE SET
            display_name = excluded.display_name,
            category = excluded.category,
            ignored = excluded.ignored,
            last_seen_at_ms = excluded.last_seen_at_ms",
        rusqlite::params![
            app.bundle_id,
            app.display_name,
            app_category_to_str(app.category),
            app.ignored as i32,
            now_ms
        ],
    )?;
    Ok(())
}

pub fn apps(conn: &Connection) -> rusqlite::Result<Vec<AppRecord>> {
    let mut stmt = conn.prepare(
        "SELECT bundle_id, display_name, category, ignored FROM apps",
    )?;
    let rows = stmt.query_map([], |row| {
        let cat: String = row.get(2)?;
        Ok(AppRecord {
            bundle_id: row.get(0)?,
            display_name: row.get(1)?,
            category: app_category_from_str(&cat),
            ignored: row.get::<_, i32>(3)? != 0,
        })
    })?;
    rows.collect()
}

/// Only apps that produced at least one `app_active` event.
pub fn apps_seen(conn: &Connection) -> rusqlite::Result<Vec<AppRecord>> {
    let mut stmt = conn.prepare(
        "SELECT a.bundle_id, a.display_name, a.category, a.ignored FROM apps a
         WHERE EXISTS (
            SELECT 1 FROM events e
            WHERE e.bundle_id = a.bundle_id AND e.event_type = 'app_active'
         )",
    )?;
    let rows = stmt.query_map([], |row| {
        let cat: String = row.get(2)?;
        Ok(AppRecord {
            bundle_id: row.get(0)?,
            display_name: row.get(1)?,
            category: app_category_from_str(&cat),
            ignored: row.get::<_, i32>(3)? != 0,
        })
    })?;
    rows.collect()
}

pub fn app_category_to_str(c: AppCategory) -> &'static str {
    match c {
        AppCategory::Focus => "focus",
        AppCategory::Communication => "communication",
        AppCategory::Entertainment => "entertainment",
        AppCategory::Utility => "utility",
        AppCategory::Neutral => "neutral",
        AppCategory::Ignored => "ignored",
    }
}

pub fn app_category_from_str(s: &str) -> AppCategory {
    match s {
        "focus" => AppCategory::Focus,
        "communication" => AppCategory::Communication,
        "entertainment" => AppCategory::Entertainment,
        "utility" => AppCategory::Utility,
        "ignored" => AppCategory::Ignored,
        _ => AppCategory::Neutral,
    }
}

/// Earliest/latest event timestamps, used to bound a report period.
pub fn event_extent(conn: &Connection) -> rusqlite::Result<Option<(i64, i64)>> {
    let mut stmt = conn.prepare("SELECT MIN(timestamp_ms), MAX(timestamp_ms) FROM events")?;
    let mut rows = stmt.query([])?;
    if let Some(row) = rows.next()? {
        let min: Option<i64> = row.get(0)?;
        let max: Option<i64> = row.get(1)?;
        Ok(match (min, max) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        })
    } else {
        Ok(None)
    }
}

/// Every event, ordered by time. Used for full export and for the Wrapped.
pub fn all_events(conn: &Connection) -> rusqlite::Result<Vec<Event>> {
    let mut stmt = conn.prepare(
        "SELECT timestamp_ms, event_type, bundle_id FROM events ORDER BY timestamp_ms ASC, id ASC",
    )?;
    let rows = stmt.query_map([], |row| {
        let t: String = row.get(1)?;
        Ok(Event {
            timestamp_ms: row.get(0)?,
            event_type: event_type_from_str(&t),
            bundle_id: row.get(2)?,
        })
    })?;
    rows.collect()
}

/// Number of events (cheap sanity check for tests/debug).
pub fn count_events(conn: &Connection) -> rusqlite::Result<i64> {
    conn.query_row("SELECT COUNT(*) FROM events", [], |row| row.get(0))
}

/// §51: delete all tracking data, reset the tracker state, keep user settings
/// and app categories (they are preferences, not data). Caller must stop the
/// tracker first.
pub fn delete_all_data(conn: &Connection) -> rusqlite::Result<()> {
    conn.execute("DELETE FROM events", [])?;
    let now_ms = Utc::now().timestamp_millis();
    conn.execute(
        "INSERT INTO tracker_state (id, current_state, clean_shutdown, last_event_at_ms, last_heartbeat_at_ms)
         VALUES (1, 'idle', ?1, ?2, ?2)
         ON CONFLICT(id) DO UPDATE SET
            current_state = 'idle',
            clean_shutdown = excluded.clean_shutdown,
            last_event_at_ms = excluded.last_event_at_ms,
            last_heartbeat_at_ms = excluded.last_heartbeat_at_ms",
        rusqlite::params![false as i32, now_ms],
    )?;
    Ok(())
}

/// §52: delete historical events for a single app. The app *record* (category,
/// ignore state) is kept — it is a preference. Returns how many rows were deleted.
pub fn delete_app_events(conn: &Connection, bundle_id: &str) -> rusqlite::Result<usize> {
    conn.execute("DELETE FROM events WHERE bundle_id = ?1", rusqlite::params![bundle_id])
}

pub fn set_clean_shutdown(conn: &Connection, clean: bool) -> rusqlite::Result<()> {
    conn.execute(
        "INSERT INTO tracker_state (id, current_state, clean_shutdown, last_event_at_ms, last_heartbeat_at_ms)
         VALUES (1, 'idle', ?1, ?2, ?3)
         ON CONFLICT(id) DO UPDATE SET clean_shutdown = excluded.clean_shutdown",
        rusqlite::params![clean as i32, Utc::now().timestamp_millis(), Utc::now().timestamp_millis()],
    )?;
    Ok(())
}

/// Update `last_heartbeat_at_ms` (§17). Heartbeats are not separate immutable
/// events — they only tighten the crash cutoff (§18). `update_heartbeat` is the
/// write path the tracker driver calls.
/// Old builds recorded loginwindow as an app. Turn those events into sleep
/// so shutdown/lock time is a gap, then drop the fake app row.
pub fn rewrite_system_away(conn: &Connection) -> rusqlite::Result<()> {
    conn.execute(
        "UPDATE events SET event_type = 'sleep', bundle_id = NULL
         WHERE event_type = 'app_active' AND bundle_id IS NOT NULL AND (
            lower(bundle_id) LIKE '%loginwindow%'
            OR lower(bundle_id) LIKE '%screensaver.engine%'
            OR lower(bundle_id) = 'com.apple.securityagent'
            OR lower(bundle_id) = 'com.apple.lockoutagent'
         )",
        [],
    )?;
    conn.execute(
        "DELETE FROM apps WHERE
            lower(bundle_id) LIKE '%loginwindow%'
            OR lower(display_name) = 'loginwindow'
            OR lower(display_name) LIKE '%login window%'",
        [],
    )?;
    Ok(())
}

/// Drop catalog leftovers that were never actually used.
pub fn prune_unseen_apps(conn: &Connection) -> rusqlite::Result<usize> {
    conn.execute(
        "DELETE FROM apps WHERE bundle_id NOT IN (
            SELECT DISTINCT bundle_id FROM events
            WHERE bundle_id IS NOT NULL AND event_type = 'app_active'
         )",
        [],
    )
}

pub fn last_heartbeat(conn: &Connection) -> Option<i64> {
    conn.query_row(
        "SELECT last_heartbeat_at_ms FROM tracker_state WHERE id = 1",
        [],
        |row| row.get::<_, Option<i64>>(0),
    )
    .ok()
    .flatten()
}

pub fn update_heartbeat(conn: &Connection, now_ms: i64) -> rusqlite::Result<()> {
    conn.execute(
        "INSERT INTO tracker_state (id, current_state, last_event_at_ms, last_heartbeat_at_ms, clean_shutdown)
         VALUES (1, 'idle', ?1, ?2, 0)
         ON CONFLICT(id) DO UPDATE SET last_heartbeat_at_ms = excluded.last_heartbeat_at_ms",
        rusqlite::params![now_ms, now_ms],
    )?;
    Ok(())
}




//! Local data export (§50). Everything is written/reported locally; nothing
//! leaves the machine.

use serde::Serialize;
use std::fmt::Write as _;

use crate::db;
use crate::models::{AppRecord, Event, EventType};

#[derive(Serialize)]
struct ExportPayload {
    schema_version: i64,
    events: Vec<Event>,
    apps: Vec<AppRecord>,
}

/// §50: export events + apps as pretty JSON.
pub fn export_json(conn: &rusqlite::Connection) -> Result<String, String> {
    let events = db::all_events(conn).map_err(|e| e.to_string())?;
    let apps = db::apps(conn).map_err(|e| e.to_string())?;
    let payload = ExportPayload {
        schema_version: db::SCHEMA_VERSION,
        events,
        apps,
    };
    serde_json::to_string_pretty(&payload).map_err(|e| e.to_string())
}

/// §50: export events as CSV (timestamp_ms, event_type, bundle_id).
pub fn export_csv(conn: &rusqlite::Connection) -> Result<String, String> {
    let events = db::all_events(conn).map_err(|e| e.to_string())?;
    let mut out = String::from("timestamp_ms,event_type,bundle_id\n");
    for e in events {
        let b = e.bundle_id.as_deref().unwrap_or("");
        let _ = writeln!(out, "{},{},{}", e.timestamp_ms, event_type_str(e.event_type), b);
    }
    Ok(out)
}

fn event_type_str(t: EventType) -> &'static str {
    match t {
        EventType::TrackerStart => "tracker_start",
        EventType::TrackerStop => "tracker_stop",
        EventType::AppActive => "app_active",
        EventType::IdleStart => "idle_start",
        EventType::IdleEnd => "idle_end",
        EventType::Sleep => "sleep",
        EventType::Wake => "wake",
        EventType::Pause => "pause",
        EventType::Resume => "resume",
    }
}

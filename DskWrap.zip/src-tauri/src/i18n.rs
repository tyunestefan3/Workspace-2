//! Tiny locale table for native chrome (tray + app menu).

#[derive(Debug, Clone, Copy)]
pub struct TrayStrings {
    pub open: &'static str,
    pub today_prefix: &'static str,
    pub today_empty: &'static str,
    pub pause: &'static str,
    pub pause15: &'static str,
    pub pause1h: &'static str,
    pub pause_tomorrow: &'static str,
    pub pause_forever: &'static str,
    pub resume: &'static str,
    pub settings: &'static str,
    pub hide: &'static str,
    pub quit: &'static str,
    pub edit: &'static str,
}

pub fn normalize(s: &str) -> &'static str {
    let l = s.trim().to_ascii_lowercase();
    if l.starts_with("ru") {
        "ru"
    } else if l.starts_with("es") {
        "es"
    } else if l.starts_with("zh") {
        "zh"
    } else if l.starts_with("fr") {
        "fr"
    } else {
        "en"
    }
}

pub fn detect() -> &'static str {
    let from_env = std::env::var("LANG")
        .or_else(|_| std::env::var("LC_ALL"))
        .or_else(|_| std::env::var("LC_MESSAGES"))
        .unwrap_or_default();
    normalize(&from_env)
}

pub fn tray(locale: &str) -> TrayStrings {
    match normalize(locale) {
        "ru" => TrayStrings {
            open: "Открыть DskWrap",
            today_prefix: "Сегодня: ",
            today_empty: "—",
            pause: "Пауза",
            pause15: "Пауза 15 минут",
            pause1h: "Пауза 1 час",
            pause_tomorrow: "Пауза до завтра",
            pause_forever: "До отмены",
            resume: "Продолжить",
            settings: "Настройки",
            hide: "Скрыть DskWrap",
            quit: "Выйти",
            edit: "Правка",
        },
        "es" => TrayStrings {
            open: "Abrir DskWrap",
            today_prefix: "Hoy: ",
            today_empty: "—",
            pause: "Pausa",
            pause15: "Pausa 15 minutos",
            pause1h: "Pausa 1 hora",
            pause_tomorrow: "Pausa hasta mañana",
            pause_forever: "Hasta cancelar",
            resume: "Reanudar",
            settings: "Ajustes",
            hide: "Ocultar DskWrap",
            quit: "Salir",
            edit: "Edición",
        },
        "zh" => TrayStrings {
            open: "打开 DskWrap",
            today_prefix: "今天：",
            today_empty: "—",
            pause: "暂停",
            pause15: "暂停 15 分钟",
            pause1h: "暂停 1 小时",
            pause_tomorrow: "暂停到明天",
            pause_forever: "直到取消",
            resume: "继续",
            settings: "设置",
            hide: "隐藏 DskWrap",
            quit: "退出",
            edit: "编辑",
        },
        "fr" => TrayStrings {
            open: "Ouvrir DskWrap",
            today_prefix: "Aujourd'hui : ",
            today_empty: "—",
            pause: "Pause",
            pause15: "Pause 15 minutes",
            pause1h: "Pause 1 heure",
            pause_tomorrow: "Pause jusqu'à demain",
            pause_forever: "Jusqu'à annulation",
            resume: "Reprendre",
            settings: "Réglages",
            hide: "Masquer DskWrap",
            quit: "Quitter",
            edit: "Édition",
        },
        _ => TrayStrings {
            open: "Open DskWrap",
            today_prefix: "Today: ",
            today_empty: "—",
            pause: "Pause",
            pause15: "Pause 15 minutes",
            pause1h: "Pause 1 hour",
            pause_tomorrow: "Pause until tomorrow",
            pause_forever: "Until I resume",
            resume: "Resume",
            settings: "Settings",
            hide: "Hide DskWrap",
            quit: "Quit",
            edit: "Edit",
        },
    }
}

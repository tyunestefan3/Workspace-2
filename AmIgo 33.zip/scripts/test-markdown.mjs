import { renderMarkdown } from '../src/markdown.js';

const sample = `#Красивый заголовок

Абзац с **жирным**, *курсивом*, ==маркером== и \`**не markdown**\`.

• Первый пункт
  • Вложенный пункт

> [!NOTE] Полезная заметка

| Колонка | Число |
|:---|---:|
| Значение | 42 |

\`\`\`js
const raw = "**не жирный**";
\`\`\`

\`\`\`text:report.txt
Готовый файл
\`\`\`

Ссылка: https://example.com/test.`;

const html = renderMarkdown(sample);
const expected = [
  '<h1>Красивый заголовок</h1>',
  '<code>**не markdown**</code>',
  'md-callout--note',
  'md-table-wrap',
  'md-align-right',
  'const raw = &quot;**не жирный**&quot;',
  'class="file-card-preview">Предпросмотр</button>',
  'class="download-code file-card-download"',
  '</a>.',
];

for (const fragment of expected) {
  if (!html.includes(fragment)) {
    console.error(`Markdown test failed: missing ${fragment}`);
    console.error(html);
    process.exit(1);
  }
}

const italicLines = renderMarkdown('Обычная строка\n*курсив на новой строке *\n\n* пункт списка');
if (!italicLines.includes('<em>курсив на новой строке </em>') || !italicLines.includes('<li>пункт списка')) {
  console.error('Markdown test failed: single-star italic or bullet list is broken');
  console.error(italicLines);
  process.exit(1);
}

// Регрессия: два ответа начинаются одинаковыми 64+ символами, но второй код
// изменён дальше. Их кнопки не должны ссылаться на первый DOM-элемент.
const common = 'const sharedPrefix = "' + 'x'.repeat(90) + '";\n';
const oldAnswer = renderMarkdown(`\`\`\`js\n${common}console.log('old');\n\`\`\``, { msgIndex: 2 });
const newAnswer = renderMarkdown(`\`\`\`js\n${common}console.log('new');\n\`\`\``, { msgIndex: 4 });
const sameMessageChanged = renderMarkdown(`\`\`\`js\n${common}console.log('changed');\n\`\`\``, { msgIndex: 2 });
const idOf = (value) => value.match(/<pre id="([^"]+)"/)?.[1];
const oldId = idOf(oldAnswer);
const newId = idOf(newAnswer);
const changedId = idOf(sameMessageChanged);
if (!oldId || !newId || !changedId || new Set([oldId, newId, changedId]).size !== 3) {
  console.error('Markdown test failed: code block IDs are not globally unique');
  process.exit(1);
}
for (const [rendered, id] of [[oldAnswer, oldId], [newAnswer, newId], [sameMessageChanged, changedId]]) {
  if (!rendered.includes(`data-target="${id}"`)) {
    console.error(`Markdown test failed: copy button does not target its own block ${id}`);
    process.exit(1);
  }
}

const oldFile = renderMarkdown(`\`\`\`js:app.js\n${common}console.log('v1');\n\`\`\``, { msgIndex: 6 });
const newFile = renderMarkdown(`\`\`\`js:app.js\n${common}console.log('v2');\n\`\`\``, { msgIndex: 8 });
const hiddenId = (value) => value.match(/class="codeblock" id="([^"]+)" hidden/)?.[1];
const oldFileId = hiddenId(oldFile);
const newFileId = hiddenId(newFile);
if (!oldFileId || !newFileId || oldFileId === newFileId) {
  console.error('Markdown test failed: generated file IDs collide');
  process.exit(1);
}
for (const [rendered, id] of [[oldFile, oldFileId], [newFile, newFileId]]) {
  if (!rendered.includes(`data-target="${id}"`) || !rendered.includes(`data-block="${id}"`)) {
    console.error(`Markdown test failed: file download/preview points to another block ${id}`);
    process.exit(1);
  }
}

console.log('Markdown test passed.');

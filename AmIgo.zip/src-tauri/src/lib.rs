use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::Duration;
use std::{io::Read, process::Command};

use tauri::{Emitter, Manager};

#[derive(Deserialize, Serialize, Clone)]
struct ChatMessage {
    role: String,
    content: String,
    // Data URL прикреплённых фото с реальным MIME (image/png, image/jpeg и т. д.) —
    // заполняется только для последнего сообщения пользователя в локальном режиме;
    // передаём модели, если та умеет "видеть" (Mentis 3 / Nage 1.5).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    images: Vec<String>,
}
#[derive(Deserialize, Clone)]
struct CodeBlockRef {
    id: String,
    label: String,
    #[serde(default, rename = "language")]
    _language: String,
    content: String,
}

#[derive(Deserialize)]
struct ChatRequest {
    provider: String,
    model: String,
    messages: Vec<ChatMessage>,
    #[serde(default)]
    think: Option<bool>,
    #[serde(default)]
    web_search: Option<bool>,
    #[serde(default)]
    temperature: Option<f64>,
    // Размер одного прохода; для кода/файлов фронтенд автоматически делает
    // столько проходов-продолжений, сколько нужно до завершения.
    #[serde(default)]
    max_tokens: Option<u32>,
    #[serde(default)]
    unlimited_output: bool,
    // Раньше передавался в Ollama как options.num_ctx; локальный сервер AmIgo
    // теперь сам задаёт размер контекста при запуске (см. spawn_local_server),
    // поле оставлено для совместимости с фронтендом, но не используется.
    #[serde(default)]
    #[allow(dead_code)]
    num_ctx: Option<u32>,
    // Идентификатор диалога на фронтенде (Date.now() в виде строки) — нужен,
    // чтобы у каждого чата была своя отдельная песочница файлов на диске.
    #[serde(default)]
    chat_id: String,
    // Код из fenced-блоков истории. copy_code_to_file копирует его в
    // песочницу по id, не заставляя модель повторно генерировать содержимое.
    #[serde(default)]
    code_blocks: Vec<CodeBlockRef>,
}
#[derive(Serialize, Clone)]
struct ChatChunk {
    content: String,
}

// Отправляется во фронтенд событием "chat-status" при переходах между
// «фоновыми» состояниями ответа, которые сами по себе не являются текстом
// ответа: kind:"thinking" — модель рассуждает до того как начнёт печатать
// финальный текст. active:true — состояние началось, active:false — закончилось.
#[derive(Serialize, Clone)]
struct StatusEvent {
    kind: String,
    active: bool,
}

// Отправляется во фронтенд событием "chat-search": сперва с done:false
// (сам факт поиска — фронтенд показывает мерцающую подпись «Поиск в
// интернете»), затем с done:true и списком источников.
#[derive(Serialize, Clone)]
struct SearchSource {
    title: String,
    url: String,
    #[serde(skip_serializing)]
    content: String,
}
#[derive(Serialize, Clone)]
struct SearchEvent {
    query: String,
    sources: Vec<SearchSource>,
    done: bool,
}

// stop            — флаг «нажали Стоп», прерывает текущий поток генерации.
// busy            — генерация сейчас идёт (не убиваем сервер, пока это true).
// active_model    — какую локальную модель выбрал пользователь сейчас (id).
// local_server    — дочерний процесс llama-server (движок AmIgo).
// server_ready    — сервер запустился и отвечает на /health.
// downloading_files — имена файлов моделей, которые прямо сейчас скачиваются.
// downloading_files защищает конкретный целевой файл от двух одновременных
// загрузок при быстрых повторных переключениях модели.
struct ChatState {
    stop: AtomicBool,
    busy: AtomicBool,
    generation_active: AtomicBool,
    pending_unload: AtomicBool,
    shutting_down: AtomicBool,
    active_model: Mutex<Option<String>>,
    local_server: Mutex<Option<std::process::Child>>,
    // Не допускает двух одновременных kill/spawn при завершении загрузки
    // и первом запросе пользователя.
    server_control: Mutex<()>,
    server_ready: AtomicBool,
    // Запрошено ли ускорение и подтвердил ли успешный /health его запуск.
    server_spec_requested: AtomicBool,
    server_speculative: AtomicBool,
    downloading_files: Mutex<std::collections::HashSet<String>>,
    // В каком режиме реально запущен текущий сервер — для Mentis 3 / Nage 1.5
    // (у них есть текстовый и vision-режимы); true = зрение
    // (--mmproj), false = обычный текстовый режим. Для Nage 1.5 не имеет
    // значения. Используется, чтобы понять, нужен ли перезапуск сервера
    // перед конкретным запросом (см. ensure_server_mode).
    server_vision_mode: AtomicBool,
}
impl Default for ChatState {
    fn default() -> Self {
        Self {
            stop: AtomicBool::new(false),
            busy: AtomicBool::new(false),
            generation_active: AtomicBool::new(false),
            pending_unload: AtomicBool::new(false),
            shutting_down: AtomicBool::new(false),
            active_model: Mutex::new(None),
            local_server: Mutex::new(None),
            server_control: Mutex::new(()),
            server_ready: AtomicBool::new(false),
            server_spec_requested: AtomicBool::new(false),
            server_speculative: AtomicBool::new(false),
            downloading_files: Mutex::new(std::collections::HashSet::new()),
            server_vision_mode: AtomicBool::new(false),
        }
    }
}

fn keychain_get() -> Result<String, String> {
    let out = Command::new("security")
        .args([
            "find-generic-password",
            "-s",
            "AmIgo.Groq.API",
            "-a",
            "groq",
            "-w",
        ])
        .output()
        .map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
    } else {
        Err("Ключ Groq не найден. Добавьте его в настройках.".into())
    }
}

#[tauri::command]
fn save_groq_key(key: String) -> Result<(), String> {
    if !key.starts_with("gsk_") {
        return Err("Ключ Groq обычно начинается с gsk_. Проверьте его.".into());
    }
    let ok = Command::new("security")
        .args([
            "add-generic-password",
            "-U",
            "-s",
            "AmIgo.Groq.API",
            "-a",
            "groq",
            "-w",
            &key,
        ])
        .status()
        .map_err(|e| e.to_string())?
        .success();
    if ok {
        Ok(())
    } else {
        Err("Не удалось сохранить ключ в Связке ключей macOS.".into())
    }
}

#[tauri::command]
async fn test_groq_key() -> Result<(), String> {
    let key = keychain_get()?;
    let response = reqwest::Client::new()
        .get("https://api.groq.com/openai/v1/models")
        .bearer_auth(&key)
        .timeout(Duration::from_secs(20))
        .send()
        .await
        .map_err(|e| format!("Не удалось подключиться к Groq: {e}"))?;
    if response.status().is_success() {
        Ok(())
    } else if matches!(
        response.status(),
        reqwest::StatusCode::UNAUTHORIZED | reqwest::StatusCode::FORBIDDEN
    ) {
        Err("Ключ Groq недействителен или отключён.".into())
    } else {
        Err(format!("Groq вернул ошибку {}", response.status()))
    }
}

// Ключ Tavily (бесплатный поиск в интернете, 1000 запросов/мес) хранится
// в Связке ключей ровно так же, как ключ Groq. Отсутствие ключа — не
// ошибка: chat_stream_inner просто не предлагает модели инструмент поиска.
fn keychain_get_tavily() -> Result<String, String> {
    let out = Command::new("security")
        .args([
            "find-generic-password",
            "-s",
            "AmIgo.Tavily.API",
            "-a",
            "tavily",
            "-w",
        ])
        .output()
        .map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
    } else {
        Err("Ключ Tavily не найден.".into())
    }
}

#[tauri::command]
fn save_tavily_key(key: String) -> Result<(), String> {
    let key = key.trim().to_string();
    if !key.starts_with("tvly-") {
        return Err("Ключ Tavily обычно начинается с tvly-. Проверьте его.".into());
    }
    let ok = Command::new("security")
        .args([
            "add-generic-password",
            "-U",
            "-s",
            "AmIgo.Tavily.API",
            "-a",
            "tavily",
            "-w",
            &key,
        ])
        .status()
        .map_err(|e| e.to_string())?
        .success();
    if ok {
        Ok(())
    } else {
        Err("Не удалось сохранить ключ в Связке ключей macOS.".into())
    }
}

#[tauri::command]
fn has_tavily_key() -> bool {
    keychain_get_tavily().is_ok()
}

#[derive(Serialize)]
struct ApiKeysStatus {
    groq_saved: bool,
    tavily_saved: bool,
    groq_masked: String,
    tavily_masked: String,
}

fn masked_key(key: &str, prefix: &str) -> String {
    let tail: String = key
        .chars()
        .rev()
        .take(4)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect();
    if tail.is_empty() {
        String::new()
    } else {
        format!("{prefix}••••{tail}")
    }
}

// Фронтенду не возвращаются реальные секреты: настройки показывают только
// факт сохранения и последние четыре символа для узнавания ключа.
#[tauri::command]
fn api_keys_status() -> ApiKeysStatus {
    let groq = keychain_get().ok();
    let tavily = keychain_get_tavily().ok();
    ApiKeysStatus {
        groq_saved: groq.is_some(),
        tavily_saved: tavily.is_some(),
        groq_masked: groq
            .as_deref()
            .map(|key| masked_key(key, "gsk_"))
            .unwrap_or_default(),
        tavily_masked: tavily
            .as_deref()
            .map(|key| masked_key(key, "tvly-"))
            .unwrap_or_default(),
    }
}

// Проверяет сохранённый ключ без расходования поискового лимита. /usage —
// официальный служебный endpoint Tavily; успешный ответ подтверждает и ключ,
// и сетевой доступ до того, как пользователь начнёт диалог.
#[tauri::command]
async fn test_tavily_key() -> Result<(), String> {
    let key = keychain_get_tavily()?;
    let response = reqwest::Client::new()
        .get("https://api.tavily.com/usage")
        .bearer_auth(&key)
        .timeout(Duration::from_secs(20))
        .send()
        .await
        .map_err(|e| format!("Не удалось подключиться к Tavily: {e}"))?;
    if response.status().is_success() {
        return Ok(());
    }
    let status = response.status();
    let body = response.text().await.unwrap_or_default();
    if status == reqwest::StatusCode::UNAUTHORIZED || status == reqwest::StatusCode::FORBIDDEN {
        Err("Ключ Tavily недействителен или отключён. Создайте новый ключ и сохраните его в настройках.".into())
    } else {
        Err(format!("Tavily вернул ошибку {status}: {body}"))
    }
}

// Останавливает генерацию, которая сейчас идёт (кнопка "Стоп" в интерфейсе).
#[tauri::command]
fn begin_generation(state: tauri::State<'_, ChatState>) {
    state.stop.store(false, Ordering::SeqCst);
    state.generation_active.store(true, Ordering::SeqCst);
}

#[tauri::command]
fn end_generation(state: tauri::State<'_, ChatState>) {
    state.generation_active.store(false, Ordering::SeqCst);
    if state.pending_unload.swap(false, Ordering::SeqCst) {
        kill_local_server(&state);
    }
}

#[tauri::command]
fn stop_generation(state: tauri::State<'_, ChatState>) {
    state.stop.store(true, Ordering::SeqCst);
}

// Используется в tokio::select! вокруг сетевых ожиданий. Прежняя проверка
// флага выполнялась только после прихода очередного SSE-чанка, поэтому кнопка
// «Стоп» могла не реагировать, пока сервер думал или сеть молчала.
async fn wait_for_stop(state: &ChatState) {
    while !state.stop.load(Ordering::SeqCst) {
        tokio::time::sleep(Duration::from_millis(40)).await;
    }
}

// ─── Локальный движок AmIgo (встроенный llama-server) ──────────────────────
// Три локальные модели: Mentis 3 (Qwen3.5 9B + vision), Nage 1.5
// (Qwen3.5 4B + vision) и Matle 2.5 (Qwen2.5 Coder 7B).
// Бывшая Mentis 2.5 перенесена в Nage 1.5;
// старые Qwen3-4B-веса больше не используются. Внешних draft-моделей нет.
// Веса — обычные GGUF-файлы, скачиваются напрямую с Hugging Face при первом
// выборе модели и хранятся в Application Support, без Ollama и без MLX.
const LOCAL_PORT: u16 = 8081;

#[derive(Clone, Copy)]
struct ModelFile {
    label: &'static str,
    filename: &'static str,
    url: &'static str,
    // Точный размер файла в закреплённой ревизии Hugging Face. Проверяем его
    // перед запуском: одного magic GGUF недостаточно — оборванный файл тоже
    // начинается с GGUF, но llama-server падает на последних тензорах.
    expected_size: u64,
}

#[derive(Clone, Copy)]
struct ModelDef {
    id: &'static str,
    main: ModelFile,
    mmproj: Option<ModelFile>,
}

fn model_defs() -> [ModelDef; 3] {
    // Все URL закреплены на конкретных commit SHA Hugging Face.
    [
        ModelDef {
            id: "mentis-3",
            main: ModelFile {
                label: "Mentis 3",
                filename: "Qwen3.5-9B-Q4_K_M.gguf",
                url: "https://huggingface.co/unsloth/Qwen3.5-9B-GGUF/resolve/3885219b6810b007914f3a7950a8d1b469d598a5/Qwen3.5-9B-Q4_K_M.gguf",
                expected_size: 5_680_522_464,
            },
            mmproj: Some(ModelFile {
                label: "Mentis 3 (модуль зрения)",
                filename: "mmproj-Qwen3.5-9B-F16.gguf",
                url: "https://huggingface.co/unsloth/Qwen3.5-9B-GGUF/resolve/3885219b6810b007914f3a7950a8d1b469d598a5/mmproj-F16.gguf",
                expected_size: 918_166_080,
            }),
        },
        ModelDef {
            id: "nage-1.5",
            main: ModelFile {
                label: "Nage 1.5",
                filename: "Qwen3.5-4B-Q4_K_M.gguf",
                url: "https://huggingface.co/unsloth/Qwen3.5-4B-GGUF/resolve/e87f176479d0855a907a41277aca2f8ee7a09523/Qwen3.5-4B-Q4_K_M.gguf",
                expected_size: 2_740_937_888,
            },
            // Qwen3.5-4B нативно мультимодальна. Проектор загружается только
            // для сообщений с фото; обычный текстовый режим остаётся лёгким.
            mmproj: Some(ModelFile {
                label: "Nage 1.5 (модуль зрения)",
                filename: "mmproj-Qwen3.5-4B-F16.gguf",
                url: "https://huggingface.co/unsloth/Qwen3.5-4B-GGUF/resolve/e87f176479d0855a907a41277aca2f8ee7a09523/mmproj-F16.gguf",
                expected_size: 672_423_616,
            }),
        },
        ModelDef {
            id: "matle-2.5",
            main: ModelFile {
                label: "Matle 2.5",
                filename: "Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf",
                // Официальный GGUF Qwen, закреплённый на неизменяемом commit.
                url: "https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/13fb94bfda8c8cf22497dc57b78f391a9acb426a/qwen2.5-coder-7b-instruct-q4_k_m.gguf",
                expected_size: 4_683_073_536,
            },
            mmproj: None,
        },
    ]
}

fn find_model_def(id: &str) -> Option<ModelDef> {
    model_defs().into_iter().find(|m| m.id == id)
}

fn models_dir() -> std::path::PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    std::path::PathBuf::from(format!("{home}/Library/Application Support/AmIgo/models"))
}

fn model_file_path(f: &ModelFile) -> std::path::PathBuf {
    models_dir().join(f.filename)
}

// Готова ли модель к запуску: все нужные ей файлы (основной + при наличии
// mmproj/draft) уже лежат на диске.
fn valid_gguf_at_path(path: &std::path::Path, expected_size: u64) -> bool {
    let Ok(meta) = std::fs::metadata(path) else {
        return false;
    };
    if meta.len() != expected_size {
        return false;
    }
    let Ok(mut f) = std::fs::File::open(path) else {
        return false;
    };
    let mut magic = [0u8; 4];
    f.read_exact(&mut magic).is_ok() && &magic == b"GGUF"
}

fn valid_gguf_file(file: &ModelFile) -> bool {
    valid_gguf_at_path(&model_file_path(file), file.expected_size)
}

fn model_ready(def: &ModelDef) -> bool {
    valid_gguf_file(&def.main) && def.mmproj.as_ref().map(valid_gguf_file).unwrap_or(true)
}

#[derive(Serialize)]
struct ModelStatus {
    id: String,
    downloaded: bool,
}

fn cleanup_obsolete_model_files() {
    for filename in [
        "Qwen3-0.6B-Q8_0.gguf",
        "Qwen3-8B-Q4_K_M.gguf",
        "Qwen3-4B-Q4_K_M.gguf",
        "Qwen3-4B-Q4_K_M.gguf.part",
        "Qwen3VL-8B-Instruct-Q4_K_M.gguf",
        "mmproj-Qwen3VL-8B-Instruct-F16.gguf",
    ] {
        let _ = std::fs::remove_file(models_dir().join(filename));
    }
}

#[tauri::command]
fn list_models() -> Vec<ModelStatus> {
    cleanup_obsolete_model_files();
    model_defs()
        .iter()
        .map(|d| ModelStatus {
            id: d.id.to_string(),
            downloaded: model_ready(d),
        })
        .collect()
}

// Скачивает один файл потоково, с прогрессом (событие "download-progress"),
// во временный ".part", и только по завершении переименовывает в целевой
// файл — чтобы оборванная закачка не выглядела как «модель уже скачана».
//
// Повторная загрузка того же файла дедуплицируется: второй вызов ждёт
// завершения первого и затем использует уже проверенный GGUF.
async fn download_file(
    app: &tauri::AppHandle,
    state: &ChatState,
    model_id: &str,
    file_label: &str,
    url: &str,
    expected_size: u64,
    dest: &std::path::Path,
    progress_base: u64,
    progress_total: u64,
) -> Result<(), String> {
    if valid_gguf_at_path(dest, expected_size) {
        return Ok(());
    }
    let filename = dest
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();

    loop {
        // MutexGuard обязан выйти из области видимости ДО await: async-команды
        // Tauri должны быть Send, а std::sync::MutexGuard между потоками не
        // переносится. Отдельный блок делает это однозначным для компилятора.
        let acquired = {
            let mut guard = state.downloading_files.lock().unwrap();
            if guard.contains(&filename) {
                false
            } else {
                guard.insert(filename.clone());
                true
            }
        };
        if acquired {
            break;
        }
        // Этот файл уже качает другой вызов (другая модель) — подождём и
        // проверим снова, вместо того чтобы писать поверх того же файла.
        tokio::time::sleep(Duration::from_millis(300)).await;
        if valid_gguf_at_path(dest, expected_size) {
            return Ok(());
        }
    }

    // Повторно проверяем файл уже после получения блокировки: другой вызов мог
    // закончить загрузку, пока этот ждал. Старый код считал любой существующий
    // файл готовым; повреждённый GGUF навсегда оставался под финальным именем.
    if valid_gguf_at_path(dest, expected_size) {
        state.downloading_files.lock().unwrap().remove(&filename);
        return Ok(());
    }
    if dest.exists() {
        if let Err(e) = std::fs::remove_file(dest) {
            if e.kind() != std::io::ErrorKind::NotFound {
                state.downloading_files.lock().unwrap().remove(&filename);
                return Err(format!("Не удалось удалить повреждённый файл модели: {e}"));
            }
        }
    }

    let result: Result<(), String> = async {
        if let Some(parent) = dest.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("Не удалось создать папку моделей: {e}"))?;
        }
        let part = std::path::PathBuf::from(format!("{}.part", dest.display()));
        let client = reqwest::Client::builder()
            // У больших GGUF нет общего двухминутного тайм-аута: на обычном
            // интернете загрузка занимает гораздо дольше. Ограничиваем только
            // установку соединения; ошибки потока всё равно приходят ниже.
            .connect_timeout(Duration::from_secs(20))
            .build()
            .map_err(|e| format!("Не удалось подготовить загрузку: {e}"))?;

        // Докачка: если .part уже частично скачан (например, приложение
        // закрыли посреди загрузки в прошлый раз), продолжаем с того места,
        // а не начинаем заново с нуля — экономит и время, и трафик.
        let mut already: u64 = std::fs::metadata(&part).map(|m| m.len()).unwrap_or(0);
        if already >= expected_size {
            if valid_gguf_at_path(&part, expected_size) {
                std::fs::rename(&part, dest)
                    .map_err(|e| format!("Не удалось сохранить готовую модель: {e}"))?;
                return Ok(());
            }
            std::fs::remove_file(&part)
                .map_err(|e| format!("Не удалось удалить некорректную докачку: {e}"))?;
            already = 0;
        }
        let mut builder = client.get(url);
        if already > 0 {
            builder = builder.header("Range", format!("bytes={already}-"));
        }
        let resp = builder.send().await.map_err(|e| {
            format!(
                "Не удалось начать скачивание «{file_label}»: {e}. Проверьте интернет-соединение."
            )
        })?;

        // 206 Partial Content — сервер принял докачку с нужного места.
        // 200 OK при запрошенном Range — сервер докачку не поддержал и всё
        // равно шлёт файл с начала; тогда просто начинаем .part заново.
        let resuming = already > 0 && resp.status() == reqwest::StatusCode::PARTIAL_CONTENT;
        if !resp.status().is_success() && resp.status() != reqwest::StatusCode::PARTIAL_CONTENT {
            return Err(format!(
                "Сервер моделей вернул ошибку при скачивании «{file_label}»: {}",
                resp.status()
            ));
        }

        let mut downloaded: u64 = if resuming { already } else { 0 };

        use std::io::Write;
        let mut file = if resuming {
            std::fs::OpenOptions::new()
                .append(true)
                .open(&part)
                .map_err(|e| format!("Не удалось продолжить файл модели: {e}"))?
        } else {
            std::fs::File::create(&part)
                .map_err(|e| format!("Не удалось создать файл модели: {e}"))?
        };

        // Сообщаем текущий прогресс сразу — если докачиваем большой файл, не
        // ждём первого чанка, чтобы прогресс-бар не начинался с нуля визуально.
        let _ = app.emit(
            "download-progress",
            serde_json::json!({
              "model": model_id, "file": file_label, "downloaded": progress_base.saturating_add(downloaded), "total": progress_total
            }),
        );

        let mut stream = resp.bytes_stream();
        loop {
            let chunk = tokio::select! {
                biased;
                _ = wait_for_stop(state) => return Err("Загрузка модели остановлена пользователем.".into()),
                chunk = stream.next() => chunk,
            };
            let Some(chunk) = chunk else { break };
            let bytes = chunk
                .map_err(|e| format!("Обрыв соединения при скачивании «{file_label}»: {e}"))?;
            file.write_all(&bytes)
                .map_err(|e| format!("Не удалось записать файл модели: {e}"))?;
            downloaded += bytes.len() as u64;
            let _ = app.emit(
                "download-progress",
                serde_json::json!({
                  "model": model_id, "file": file_label, "downloaded": progress_base.saturating_add(downloaded), "total": progress_total
                }),
            );
        }
        file.flush()
            .map_err(|e| format!("Не удалось завершить запись модели: {e}"))?;
        drop(file);

        let actual_size = std::fs::metadata(&part).map(|m| m.len()).unwrap_or(0);
        if actual_size != expected_size {
            // Короткий .part сохраняем для следующей докачки. Слишком большой
            // удаляем: продолжать его через Range уже нельзя.
            if actual_size > expected_size {
                let _ = std::fs::remove_file(&part);
            }
            return Err(format!(
                "Файл «{file_label}» скачан не полностью: {actual_size} из {expected_size} байт. Повторите загрузку — она продолжится с сохранённого места."
            ));
        }
        if !valid_gguf_at_path(&part, expected_size) {
            let _ = std::fs::remove_file(&part);
            return Err(format!(
                "Файл «{file_label}» повреждён (неверный заголовок GGUF). Загрузите его повторно."
            ));
        }
        std::fs::rename(&part, dest)
            .map_err(|e| format!("Не удалось сохранить файл модели: {e}"))?;
        Ok(())
    }
    .await;

    state.downloading_files.lock().unwrap().remove(&filename);
    result
}

// Скачивает основной GGUF и соответствующий модуль зрения выбранной модели.
#[tauri::command]
async fn download_model(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    model: String,
) -> Result<(), String> {
    let def = find_model_def(&model).ok_or("Неизвестная модель")?;
    // Не даём App Nap/сну системы заморозить сетевую загрузку. Экран при этом
    // может быть выключен: флаг -d намеренно не используется.
    let mut activity = Command::new("caffeinate").args(["-i", "-s"]).spawn().ok();
    let result: Result<(), String> = async {
        let mut files: Vec<ModelFile> = vec![def.main];
        if let Some(f) = def.mmproj {
            files.push(f);
        }
        let progress_total: u64 = files.iter().map(|file| file.expected_size).sum();
        let mut progress_base = 0u64;
        let _ = app.emit(
            "download-progress",
            serde_json::json!({ "model": model, "downloaded": 0, "total": progress_total }),
        );
        for f in files {
            let dest = model_file_path(&f);
            download_file(
                &app,
                &state,
                &model,
                f.label,
                f.url,
                f.expected_size,
                &dest,
                progress_base,
                progress_total,
            )
            .await?;
            progress_base = progress_base.saturating_add(f.expected_size);
            let _ = app.emit(
                "download-progress",
                serde_json::json!({ "model": model, "downloaded": progress_base, "total": progress_total }),
            );
        }
        let _ = app.emit("download-done", serde_json::json!({ "model": model }));
        Ok(())
    }
    .await;
    if let Some(child) = activity.as_mut() {
        let _ = child.kill();
        let _ = child.wait();
    }
    result
}

// Ищет бинарник llama-server — сначала внутри самого приложения (см.
// tauri.conf.json → bundle.resources, кладётся туда сборочным скриптом),
// затем, для разработки, в стандартных путях Homebrew.
fn find_llama_server(app: &tauri::AppHandle) -> Option<std::path::PathBuf> {
    if let Ok(p) = app
        .path()
        .resolve("bin/llama-server", tauri::path::BaseDirectory::Resource)
    {
        if p.exists() {
            return Some(p);
        }
    }
    [
        "/opt/homebrew/bin/llama-server",
        "/usr/local/bin/llama-server",
        "/opt/homebrew/opt/llama.cpp/bin/llama-server",
        "/usr/local/opt/llama.cpp/bin/llama-server",
    ]
    .iter()
    .map(std::path::PathBuf::from)
    .find(|p| p.exists())
}

// Запускает llama-server для выбранной модели.
// -ngl 99 — выгружаем все слои на Metal GPU (Apple Silicon).
// --jinja  — включает разбор чат-шаблона модели через jinja (см. рекомендацию
// самой Qwen для запуска их GGUF-моделей); нужно и для рассуждений, и для
// вызова инструментов (поиск) в новом OpenAI-режиме локального движка.
// --ctx-size выбирается по доступной ОЗУ (4K/12K/24K/32K).
// use_vision выбирает vision/mmproj либо обычный текстовый режим. Кто вызывает
// с каким значением — см.
// ensure_server_mode (переключение под конкретное сообщение) и
// switch_model/warm_model (запуск по умолчанию в текстовом режиме).
// Объём ОЗУ конкретного Mac — используется, чтобы на базовых конфигурациях
// (8 ГБ, всё ещё продаётся новым в MacBook Air) не рисковать нехваткой
// памяти вместе с самой macOS и остальными открытыми программами. На 16 ГБ+
// ничего не меняется — это ровно та настройка, что уже была проверена.
fn system_ram_gb() -> u64 {
    Command::new("sysctl")
        .args(["-n", "hw.memsize"])
        .output()
        .ok()
        .and_then(|o| {
            String::from_utf8_lossy(&o.stdout)
                .trim()
                .parse::<u64>()
                .ok()
        })
        // hw.memsize возвращает двоичные гигабайты. Деление на 1e9 ошибочно
        // превращало 16 ГиБ в 17 и выбирало слишком большой контекст 24K.
        .map(|bytes| bytes / 1_073_741_824)
        .unwrap_or(16) // не удалось узнать — считаем "обычный" Mac, ничего не режем
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ServerProfile {
    Optimized,
    CompatibleGpu,
    CpuFallback,
}

// use_vision:
// use_vision=true грузит mmproj; false запускает обычный текстовый режим.
// Внешние draft-модели и MTP не используются.
fn spec_log_path() -> std::path::PathBuf {
    models_dir().join("llama-server.log")
}

fn server_log_tail(max_lines: usize) -> String {
    std::fs::read_to_string(spec_log_path())
        .map(|log| {
            let lines: Vec<_> = log.lines().collect();
            lines[lines.len().saturating_sub(max_lines)..].join("\n")
        })
        .unwrap_or_default()
}

fn spawn_local_server(
    srv: &std::path::Path,
    def: &ModelDef,
    use_vision: bool,
    _use_spec: bool,
    profile: ServerProfile,
) -> Result<std::process::Child, String> {
    let main_path = model_file_path(&def.main);
    let ram = system_ram_gb();
    let ctx_size = if ram <= 8 {
        "4096"
    } else if ram <= 16 {
        "12288"
    } else if ram <= 24 {
        "24576"
    } else {
        "32768"
    };
    // Убираем оставшийся от старой/аварийно закрытой копии AmIgo сервер,
    // если именно llama-server всё ещё занимает наш фиксированный порт.
    if let Ok(out) = Command::new("lsof")
        .args(["-nP", &format!("-iTCP:{LOCAL_PORT}"), "-sTCP:LISTEN", "-t"])
        .output()
    {
        for pid in String::from_utf8_lossy(&out.stdout).lines() {
            let is_llama = Command::new("ps")
                .args(["-p", pid, "-o", "comm="])
                .output()
                .ok()
                .map(|o| String::from_utf8_lossy(&o.stdout).contains("llama-server"))
                .unwrap_or(false);
            if is_llama {
                let _ = Command::new("kill").arg(pid).status();
            }
        }
    }

    let mut cmd = std::process::Command::new(srv);
    cmd.args([
        "--model",
        main_path.to_str().unwrap_or(""),
        "--ctx-size",
        ctx_size,
        "--host",
        "127.0.0.1",
        // Запросы к серверу делает Rust-бэкенд, а не произвольная веб-страница.
        // Явно ограничиваем CORS localhost и убираем не относящийся к сбою баннер.
        "--cors-origins",
        "localhost",
        "--port",
        &LOCAL_PORT.to_string(),
        "--metrics",
        // Мы показываем только статус размышления, а не сырой внутренний текст.
        // deepseek-формат переносит мысли в reasoning_content отдельно от ответа.
        "--reasoning-format",
        "deepseek",
        // Даже в явном режиме «Рассуждение» не даём внутренней цепочке уйти
        // в бесконечный цикл; после бюджета llama-server переходит к ответу.
        "--reasoning-budget",
        "1024",
        "--reasoning-budget-message",
        "Лимит рассуждения достигнут. Немедленно переходи к краткому финальному ответу.",
        // Один slot: draft-контекст и метрики относятся к одному запросу,
        // без конкуренции между параллельными последовательностями.
        "--parallel",
        "1",
    ]);
    match profile {
        ServerProfile::Optimized => {
            // Qwen3.5 — гибридная recurrent/attention архитектура. cache-reuse
            // для неё нестабилен в зафиксированной сборке llama.cpp и мог
            // завершать процесс ещё до первого ответа.
            cmd.args(["-ngl", "99", "--jinja", "--flash-attn", "on"]);
        }
        ServerProfile::CompatibleGpu => {
            // Spec decoding остаётся включён, убираем только необязательные
            // оптимизации, которые менялись между версиями llama.cpp.
            cmd.args(["-ngl", "99", "--jinja"]);
        }
        ServerProfile::CpuFallback => {
            // Последняя страховка для ответа без Metal; draft сюда не передаётся.
            cmd.args(["-ngl", "0", "--jinja"]);
        }
    }
    if use_vision {
        if let Some(f) = &def.mmproj {
            let p = model_file_path(f);
            cmd.arg("--mmproj").arg(p);
        }
    }
    let log_path = spec_log_path();
    if let Ok(log) = std::fs::File::create(log_path) {
        let stdout = log
            .try_clone()
            .map(std::process::Stdio::from)
            .unwrap_or_else(|_| std::process::Stdio::null());
        cmd.stdout(stdout).stderr(std::process::Stdio::from(log));
    } else {
        cmd.stdout(std::process::Stdio::null())
            .stderr(std::process::Stdio::null());
    }
    cmd.spawn().map_err(|e| {
        format!(
            "Не удалось запустить локальный движок AmIgo: {e}. Попробуйте пересобрать приложение."
        )
    })
}

// Убивает текущий локальный сервер (при смене модели / сворачивании / закрытии).
fn kill_local_server(state: &ChatState) {
    state.server_ready.store(false, Ordering::SeqCst);
    state.server_spec_requested.store(false, Ordering::SeqCst);
    state.server_speculative.store(false, Ordering::SeqCst);
    if let Ok(mut guard) = state.local_server.lock() {
        if let Some(mut child) = guard.take() {
            // SIGTERM даёт llama-server записать статистику speculative decoding.
            let _ = Command::new("kill")
                .args(["-TERM", &child.id().to_string()])
                .status();
            let mut exited = false;
            for _ in 0..20 {
                if child.try_wait().ok().flatten().is_some() {
                    exited = true;
                    break;
                }
                std::thread::sleep(Duration::from_millis(50));
            }
            if !exited {
                let _ = child.kill();
            }
            let _ = child.wait();
        }
    }
}

fn start_local_server(
    app: &tauri::AppHandle,
    state: &ChatState,
    def: &ModelDef,
    model: &str,
    use_vision: bool,
    use_spec: bool,
    profile: ServerProfile,
) -> Result<(), String> {
    let _control = state.server_control.lock().unwrap();
    kill_local_server(state);
    let srv = find_llama_server(app).ok_or("Не найден движок AmIgo внутри приложения.")?;
    let child = spawn_local_server(&srv, def, use_vision, use_spec, profile)?;
    *state.active_model.lock().unwrap() = Some(model.to_string());
    state.server_vision_mode.store(use_vision, Ordering::SeqCst);
    state
        .server_spec_requested
        .store(use_spec, Ordering::SeqCst);
    state.server_speculative.store(false, Ordering::SeqCst);
    *state.local_server.lock().unwrap() = Some(child);
    Ok(())
}

// Опрашивает /health в фоне. Это только внутреннее состояние: при медленной
// загрузке никаких уведомлений «не запустилась за N секунд» пользователю не
// показываем. Реальный запрос сам дождётся готовности через ensure_server_mode.
fn watch_server_ready(app: tauri::AppHandle) {
    tauri::async_runtime::spawn(async move {
        let state = app.state::<ChatState>();
        let client = reqwest::Client::new();
        let url = format!("http://127.0.0.1:{LOCAL_PORT}/health");
        for _ in 0..600 {
            tokio::time::sleep(Duration::from_millis(500)).await;
            let process_alive = state.local_server.lock().unwrap().is_some();
            if !process_alive {
                return;
            }
            if let Ok(r) = client
                .get(&url)
                .timeout(Duration::from_millis(700))
                .send()
                .await
            {
                if r.status().is_success() {
                    state.server_ready.store(true, Ordering::SeqCst);
                    // /health подтверждает только готовность HTTP-сервера. Само
                    // speculative decoding подтверждаем отдельной строкой инициализации
                    // llama.cpp, иначе получался ложный ready даже при отключённом spec.
                    // Speculative decoding отключён в стабильной конфигурации.
                    // /health подтверждает готовность обычного текстового сервера.
                    state.server_speculative.store(false, Ordering::SeqCst);
                    let _ = app.emit("server-status", serde_json::json!({"ready": true}));
                    return;
                }
            }
        }
        state.server_ready.store(false, Ordering::SeqCst);
    });
}

// Переключение модели: убивает предыдущий локальный сервер, обновляет
// active_model, запускает новый сервер под выбранную модель (если она уже
// скачана) и ждёт его готовности. Если модель ещё не скачана — фронтенд
// должен сначала вызвать download_model (ошибка "not_downloaded" — сигнал).
// По умолчанию запускаем в быстром текстовом режиме (с ускорением, если
// оно есть у модели) — в режим зрения переключаемся отдельно, только когда
// в конкретном сообщении реально есть фото (см. ensure_server_mode).
#[tauri::command]
async fn switch_model(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    provider: String,
    model: String,
) -> Result<(), String> {
    let previous = state.active_model.lock().unwrap().clone();
    if provider != "local" || model.trim().is_empty() {
        kill_local_server(&state);
        *state.active_model.lock().unwrap() = None;
        return Ok(());
    }
    let def = find_model_def(&model).ok_or("Неизвестная модель")?;
    if !model_ready(&def) {
        return Err("not_downloaded".into());
    }
    let expected_spec = false;
    let already_default_text = previous.as_deref() == Some(model.as_str())
        && state.local_server.lock().unwrap().is_some()
        && !state.server_vision_mode.load(Ordering::SeqCst)
        && state.server_spec_requested.load(Ordering::SeqCst) == expected_spec;
    // Выбор мультимодальной модели по умолчанию означает текстовый сервер. Если до этого был
    // режим зрения или другой fallback-профиль — перезапускаем.
    if already_default_text {
        return Ok(());
    }
    start_local_server(
        &app,
        &state,
        &def,
        &model,
        false,
        false,
        ServerProfile::Optimized,
    )?;
    watch_server_ready(app.clone());
    let _ = app.emit("server-status", serde_json::json!({"starting": true}));
    Ok(())
}

// Подгревает (перезапускает) сервер для уже выбранной модели, если он не
// запущен — используется при возврате в приложение после сворачивания.
// Тихо ничего не делает, если модель не скачана или сервер уже поднят.
// Как и switch_model — по умолчанию быстрый текстовый режим.
#[tauri::command]
async fn warm_model(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    model: String,
) -> Result<(), String> {
    let def = match find_model_def(&model) {
        Some(d) => d,
        None => return Ok(()),
    };
    if !model_ready(&def) {
        return Ok(());
    }
    let expected_spec = false;
    let already_default_text = state.local_server.lock().unwrap().is_some()
        && !state.server_vision_mode.load(Ordering::SeqCst)
        && state.server_spec_requested.load(Ordering::SeqCst) == expected_spec;
    if already_default_text {
        return Ok(());
    }
    if start_local_server(
        &app,
        &state,
        &def,
        &model,
        false,
        false,
        ServerProfile::Optimized,
    )
    .is_ok()
    {
        watch_server_ready(app.clone());
    }
    Ok(())
}

async fn warm_active_model(app: &tauri::AppHandle, state: &ChatState) {
    let model = state.active_model.lock().unwrap().clone();
    if let Some(model) = model {
        let _ = warm_model(app.clone(), app.state::<ChatState>(), model).await;
    }
}

// Перед отправкой запроса к локальной модели проверяет, нужен ли для ЭТОГО
// КОНКРЕТНОГО сообщения режим зрения (есть фото), и если запущенный сейчас
// сервер в другом режиме — перезапускает его в нужном и ждёт готовности
// прямо здесь (запрос ниже отправится только после этого). Для моделей без
// обоих режимов (сейчас — Nage 1.5) или уже находящихся в нужном режиме —
// не делает ничего, без лишней задержки.
async fn ensure_server_mode(
    app: &tauri::AppHandle,
    state: &ChatState,
    model: &str,
    needs_vision: bool,
) -> Result<(), String> {
    let def = find_model_def(model).ok_or("Неизвестная локальная модель")?;
    let mode_matters = def.mmproj.is_some();
    let desired_vision = mode_matters && needs_vision;
    let desired_spec = false;
    let active_same = state.active_model.lock().unwrap().as_deref() == Some(model);
    let process_exists = state.local_server.lock().unwrap().is_some();
    let mode_same =
        !mode_matters || state.server_vision_mode.load(Ordering::SeqCst) == desired_vision;
    let spec_same = state.server_spec_requested.load(Ordering::SeqCst) == desired_spec;

    if !(active_same && process_exists && mode_same && spec_same) {
        start_local_server(
            app,
            state,
            &def,
            model,
            desired_vision,
            desired_spec,
            ServerProfile::Optimized,
        )?;
    } else if state.server_ready.load(Ordering::SeqCst)
        && (!desired_spec || state.server_speculative.load(Ordering::SeqCst))
    {
        return Ok(());
    }

    let client = reqwest::Client::new();
    let health_url = format!("http://127.0.0.1:{LOCAL_PORT}/health");
    let mut tried_compatible = false;
    let mut tried_gpu_without_spec = false;
    let mut tried_cpu = false;

    for _ in 0..600 {
        if state.stop.load(Ordering::SeqCst) {
            return Ok(());
        }
        let exited = state
            .local_server
            .lock()
            .unwrap()
            .as_mut()
            .and_then(|child| child.try_wait().ok().flatten())
            .is_some();

        if exited {
            if !tried_compatible {
                tried_compatible = true;
                start_local_server(
                    app,
                    state,
                    &def,
                    model,
                    desired_vision,
                    desired_spec,
                    ServerProfile::CompatibleGpu,
                )?;
                continue;
            }
            if desired_spec && !tried_gpu_without_spec {
                tried_gpu_without_spec = true;
                start_local_server(
                    app,
                    state,
                    &def,
                    model,
                    false,
                    false,
                    ServerProfile::CompatibleGpu,
                )?;
                continue;
            }
            if !tried_cpu {
                tried_cpu = true;
                start_local_server(
                    app,
                    state,
                    &def,
                    model,
                    desired_vision,
                    false,
                    ServerProfile::CpuFallback,
                )?;
                continue;
            }
            let tail = server_log_tail(80);
            return Err(format!(
                "connection_error: Локальный движок завершился при запуске.\n{}",
                tail
            ));
        }

        if let Ok(r) = client
            .get(&health_url)
            .timeout(Duration::from_millis(700))
            .send()
            .await
        {
            if r.status().is_success() {
                state.server_ready.store(true, Ordering::SeqCst);
                if desired_vision {
                    // /health иногда становится зелёным на несколько сотен
                    // миллисекунд раньше полной готовности mtmd/mmproj. Дополнительный
                    // API-probe и короткая стабилизация убирают сбой первого фото.
                    let models_url = format!("http://127.0.0.1:{LOCAL_PORT}/v1/models");
                    for _ in 0..20 {
                        if state.stop.load(Ordering::SeqCst) {
                            return Ok(());
                        }
                        if client
                            .get(&models_url)
                            .timeout(Duration::from_millis(700))
                            .send()
                            .await
                            .map(|response| response.status().is_success())
                            .unwrap_or(false)
                        {
                            tokio::time::sleep(Duration::from_millis(900)).await;
                            break;
                        }
                        tokio::time::sleep(Duration::from_millis(100)).await;
                    }
                }
                if state.server_spec_requested.load(Ordering::SeqCst) {
                    // Нельзя блокировать первый запрос по наличию INFO-строки:
                    // уровень логирования конкретной сборки может скрывать её.
                    // /health разрешает запрос, а фактическую работу spec после
                    // генерации подтверждают числовые данные /metrics.
                    state.server_speculative.store(false, Ordering::SeqCst);
                }
                return Ok(());
            }
        }
        tokio::time::sleep(Duration::from_millis(500)).await;
    }
    Err("connection_error: Локальный движок не смог подготовиться к запросу.".into())
}

// Если генерация сейчас идёт — дожидается её завершения (максимум ~10 минут на
// случай долгого ответа), затем убивает сервер. Используется при закрытии
// приложения, чтобы модель успела доделать текущий ответ перед выходом.
async fn finish_then_unload(state: &ChatState) {
    for _ in 0..6000 {
        if !state.busy.load(Ordering::SeqCst) && !state.generation_active.load(Ordering::SeqCst) {
            break;
        }
        tokio::time::sleep(Duration::from_millis(100)).await;
    }
    kill_local_server(state);
}

// Общий дневной предел для Tavily Search/Extract/поиска изображений.
// Счётчик хранится на диске и автоматически сбрасывается при смене даты.
const DAILY_SEARCH_LIMIT: u32 = 32;

fn search_usage_path() -> std::path::PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    std::path::PathBuf::from(format!(
        "{home}/Library/Application Support/AmIgo/search_usage.txt"
    ))
}

fn today_str() -> String {
    Command::new("date")
        .arg("+%Y-%m-%d")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_default()
}

const SEARCH_USAGE_FORMAT: &str = "v32";

fn parse_search_usage(raw: &str, today: &str) -> u32 {
    let mut parts = raw.split_whitespace();
    let version = parts.next().unwrap_or("");
    let date = parts.next().unwrap_or("");
    let count = parts
        .next()
        .and_then(|value| value.parse::<u32>().ok())
        .unwrap_or(0);
    // Старый файл имел формат `дата количество` и накопил обращения ещё до
    // введения корректного лимита. Не переносим его значение в новую версию.
    if version == SEARCH_USAGE_FORMAT && date == today {
        count
    } else {
        0
    }
}

fn current_search_usage() -> (String, u32) {
    let today = today_str();
    let count = std::fs::read_to_string(search_usage_path())
        .ok()
        .map(|raw| parse_search_usage(&raw, &today))
        .unwrap_or(0);
    (today, count)
}

fn check_search_budget() -> Result<(), String> {
    let (_, count) = current_search_usage();
    if count >= DAILY_SEARCH_LIMIT {
        Err(format!(
            "Дневной лимит интернет-поиска исчерпан ({DAILY_SEARCH_LIMIT} обращения). Лимит автоматически сбросится завтра."
        ))
    } else {
        Ok(())
    }
}

fn record_search_usage() {
    let path = search_usage_path();
    let (today, count) = current_search_usage();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let _ = std::fs::write(
        path,
        format!("{SEARCH_USAGE_FORMAT} {today} {}", count.saturating_add(1)),
    );
}

async fn tavily_post_json(
    endpoint: &str,
    key: &str,
    payload: serde_json::Value,
    timeout: Duration,
) -> Result<reqwest::Response, String> {
    let client = reqwest::Client::builder()
        .connect_timeout(Duration::from_secs(15))
        .build()
        .map_err(|e| e.to_string())?;
    let mut last_error = String::new();
    for attempt in 0..2 {
        match client
            .post(endpoint)
            .bearer_auth(key)
            .timeout(timeout)
            .json(&payload)
            .send()
            .await
        {
            Ok(response) if response.status().is_server_error() && attempt == 0 => {
                last_error = format!("HTTP {}", response.status());
                tokio::time::sleep(Duration::from_millis(500)).await;
            }
            Ok(response) => return Ok(response),
            Err(error) if attempt == 0 => {
                last_error = error.to_string();
                tokio::time::sleep(Duration::from_millis(500)).await;
            }
            Err(error) => return Err(format!("Не удалось связаться с Tavily: {error}")),
        }
    }
    Err(format!("Не удалось связаться с Tavily: {last_error}"))
}

// Реальный запрос к Tavily. Возвращает до 5 источников; при временном сетевом
// сбое делает одну повторную попытку и всегда отдаёт понятную ошибку.
async fn tavily_search(query: &str) -> Result<Vec<SearchSource>, String> {
    let query = query.trim();
    if query.len() < 2 {
        return Err("Пустой поисковый запрос.".into());
    }
    let key = keychain_get_tavily()?;
    check_search_budget()?;
    let resp = tavily_post_json(
        "https://api.tavily.com/search",
        &key,
        serde_json::json!({
          "query": query,
          "search_depth": "basic",
          "max_results": 5,
          "include_favicon": true,
        }),
        Duration::from_secs(45),
    )
    .await?;
    if !resp.status().is_success() {
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if status == reqwest::StatusCode::UNAUTHORIZED || status == reqwest::StatusCode::FORBIDDEN {
            return Err("Проверьте ключ Tavily в настройках.".into());
        }
        return Err(format!("Tavily временно недоступен ({status}): {text}"));
    }
    record_search_usage();
    let json: serde_json::Value = resp
        .json()
        .await
        .map_err(|e| format!("Tavily вернул некорректный JSON: {e}"))?;
    let results = json["results"].as_array().ok_or_else(|| {
        let detail = json["detail"]
            .as_str()
            .or_else(|| json["message"].as_str())
            .unwrap_or("в ответе отсутствует поле results");
        format!("Некорректный ответ Tavily: {detail}")
    })?;
    Ok(results
        .iter()
        .filter_map(|result| {
            let url = result["url"].as_str()?.trim();
            if url.is_empty() {
                return None;
            }
            let title = result["title"]
                .as_str()
                .map(str::trim)
                .filter(|title| !title.is_empty())
                .unwrap_or(url);
            Some(SearchSource {
                title: title.to_string(),
                url: url.to_string(),
                content: result["content"]
                    .as_str()
                    .or_else(|| result["raw_content"].as_str())
                    .unwrap_or("")
                    .chars()
                    .take(2_500)
                    .collect(),
            })
        })
        .take(5)
        .collect())
}

async fn web_search_online(query: &str) -> Result<Vec<SearchSource>, String> {
    // Используем только Tavily. Не скрываем ошибку ключа/квоты за публичным
    // RSS-fallback: пользователь должен видеть настоящую причину, а модель —
    // получить явный ответ инструмента вместо пустых или устаревших данных.
    tavily_search(query).await
}

// Читает содержимое конкретной веб-страницы через Tavily Extract. Это
// отдельный инструмент: обычный поиск даёт сниппеты, а extract нужен, когда
// пользователь прислал ссылку или модель должна понять, что именно на сайте.
async fn tavily_extract(url: &str) -> Result<String, String> {
    let key = keychain_get_tavily()?;
    check_search_budget()?;
    let resp = tavily_post_json(
        "https://api.tavily.com/extract",
        &key,
        serde_json::json!({ "urls": [url], "extract_depth": "basic", "format": "markdown" }),
        Duration::from_secs(45),
    )
    .await
    .map_err(|e| format!("Не удалось прочитать страницу: {e}"))?;
    if !resp.status().is_success() {
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if status == reqwest::StatusCode::UNAUTHORIZED || status == reqwest::StatusCode::FORBIDDEN {
            return Err("Проверьте ключ Tavily в настройках.".into());
        }
        return Err(format!(
            "Tavily Extract временно недоступен ({status}): {text}"
        ));
    }
    record_search_usage();
    let json: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
    let text = json["results"]
        .as_array()
        .and_then(|a| a.first())
        .and_then(|v| v["raw_content"].as_str().or_else(|| v["content"].as_str()))
        .unwrap_or("");
    if text.is_empty() {
        Err("Страница не вернула читаемого содержимого.".into())
    } else {
        Ok(text.chars().take(30_000).collect())
    }
}

async fn read_webpage_online(url: &str) -> Result<String, String> {
    // Чтение страниц тоже возвращено на Tavily Extract: прямой GET часто
    // получал защитную HTML-страницу, JavaScript-заглушку или 403.
    tavily_extract(url).await
}

// Поиск изображений — тот же Tavily, с include_images: true. Отдельного
// локального блокирующего лимита нет: фактическую квоту сообщает Tavily.
// images в ответе — либо список строк-ссылок, либо объектов
// {url, description} (когда include_image_descriptions включён) — здесь
// он не включён, поэтому ожидаем строки, но на всякий случай понимаем и
// формат объекта тоже.
async fn tavily_image_search(query: &str) -> Result<Vec<String>, String> {
    let query = query.trim();
    if query.len() < 2 {
        return Err("Пустой поисковый запрос.".into());
    }
    let key = keychain_get_tavily()?;
    check_search_budget()?;
    let resp = tavily_post_json(
        "https://api.tavily.com/search",
        &key,
        serde_json::json!({
          "query": query,
          "search_depth": "basic",
          "max_results": 5,
          "include_images": true,
        }),
        Duration::from_secs(45),
    )
    .await?;
    if !resp.status().is_success() {
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if status == reqwest::StatusCode::UNAUTHORIZED || status == reqwest::StatusCode::FORBIDDEN {
            return Err("Проверьте ключ Tavily в настройках.".into());
        }
        return Err(format!("Tavily временно недоступен ({status}): {text}"));
    }
    record_search_usage();
    let json: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
    Ok(json["images"]
        .as_array()
        .map(|arr| {
            arr.iter()
                .filter_map(|v| {
                    v.as_str()
                        .map(|s| s.to_string())
                        .or_else(|| v["url"].as_str().map(|s| s.to_string()))
                })
                .take(5)
                .collect()
        })
        .unwrap_or_default())
}

// ─── Песочница файлов ────────────────────────────────────────────────────
// У каждого диалога — своя маленькая папка на диске, где локальная модель
// (Mentis 3 / Nage 1.5) может сама сохранять и дорабатывать текстовые
// файлы и код по ходу разговора, без ручного прикрепления пользователем.
// Работает только в локальном режиме — Groq этих инструментов не видит,
// так как это про "без интернета", а не про облако.
//
// Место на диске — приоритет №1, поэтому лимиты сразу в трёх измерениях:
// размер одного файла, число файлов в одном диалоге, и (самое главное)
// ОБЩИЙ потолок на всю песочницу сразу по всем диалогам вместе. Именно
// общий потолок реально гарантирует "ест мало места" — без него можно было
// бы завести много диалогов и получить много "мини" папок, которые в сумме
// не мини. При новой записи, если общий размер вот-вот превысит потолок,
// самые старые файлы (по времени изменения, по всем диалогам) удаляются
// первыми — простая политика "самое старое не нужно" без участия модели.
const SANDBOX_MAX_FILE_BYTES: usize = 100_000_000; // 100 МБ на импортированный/бинарный файл
const SANDBOX_MAX_GENERATED_TEXT_BYTES: usize = SANDBOX_MAX_FILE_BYTES; // без отдельного лимита для кода
const SANDBOX_MAX_READ_CHARS: usize = 30_000; // не переполняет контекст локальной 4B-модели
const SANDBOX_TOTAL_MAX_BYTES: u64 = 500_000_000; // 500 МБ на ВСЮ песочницу сразу (по всем диалогам)

fn sandbox_root() -> std::path::PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    std::path::PathBuf::from(format!("{home}/Library/Application Support/AmIgo/sandbox"))
}

// Диалог, к песочнице которого не обращались сутки, упаковывается в один
// .zip прямо на месте своей папки (см. sandbox_compress_idle) — экономит
// место, пока к диалогу не возвращаются. sandbox_dir ниже — точка входа
// абсолютно для всех операций с песочницей конкретного диалога, поэтому
// именно здесь беззвучно распаковываем архив обратно, если он есть:
// пользователь и модель не замечают разницы, работа с файлами не меняется.
const SANDBOX_IDLE_SECS: u64 = 24 * 60 * 60; // сутки

fn sandbox_archive_path(chat_id_safe: &str) -> std::path::PathBuf {
    sandbox_root().join(format!("{chat_id_safe}.zip"))
}

fn sandbox_files_recursive(dir: &std::path::Path) -> Vec<std::path::PathBuf> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(dir) else {
        return out;
    };
    for entry in entries.filter_map(|e| e.ok()) {
        let path = entry.path();
        if path.is_dir() {
            out.extend(sandbox_files_recursive(&path));
        } else if path.is_file() {
            out.push(path);
        }
    }
    out
}

fn sandbox_dir(chat_id: &str) -> std::path::PathBuf {
    // chat_id приходит с фронтенда — на всякий случай оставляем только
    // безопасные символы, прежде чем использовать как имя папки.
    let safe: String = chat_id
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    let safe = if safe.is_empty() {
        "_".to_string()
    } else {
        safe
    };
    let dir = sandbox_root().join(&safe);

    let archive = sandbox_archive_path(&safe);
    if archive.exists() {
        // Архив удаляется только после ПОЛНОЙ успешной распаковки. Раньше он
        // удалялся даже при ошибке чтения/записи — это и приводило к пропаже файлов.
        let extracted = (|| -> Result<(), String> {
            let file = std::fs::File::open(&archive).map_err(|e| e.to_string())?;
            let mut zip = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
            std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
            for i in 0..zip.len() {
                let mut entry = zip.by_index(i).map_err(|e| e.to_string())?;
                if entry.is_dir() {
                    continue;
                }
                let enclosed = entry
                    .enclosed_name()
                    .map(|p| p.to_path_buf())
                    .ok_or_else(|| "Небезопасный путь в архиве песочницы.".to_string())?;
                let out_path = dir.join(enclosed);
                if let Some(parent) = out_path.parent() {
                    std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
                }
                let mut out = std::fs::File::create(&out_path).map_err(|e| e.to_string())?;
                std::io::copy(&mut entry, &mut out).map_err(|e| e.to_string())?;
            }
            Ok(())
        })();
        if extracted.is_ok() {
            let _ = std::fs::remove_file(&archive);
        }
    }
    dir
}

// Упаковывает папку диалога в .zip (deflate) и удаляет исходную папку.
fn sandbox_compress_one(dir: &std::path::Path, archive: &std::path::Path) -> Result<(), String> {
    let file = std::fs::File::create(archive).map_err(|e| e.to_string())?;
    let mut writer = zip::ZipWriter::new(file);
    let options = zip::write::SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated);
    use std::io::Write;
    for path in sandbox_files_recursive(dir) {
        let relative = path.strip_prefix(dir).map_err(|e| e.to_string())?;
        let name = relative.to_string_lossy().replace('\\', "/");
        writer
            .start_file(name, options)
            .map_err(|e| e.to_string())?;
        let bytes = std::fs::read(&path).map_err(|e| e.to_string())?;
        writer.write_all(&bytes).map_err(|e| e.to_string())?;
    }
    writer.finish().map_err(|e| e.to_string())?;
    std::fs::remove_dir_all(dir).map_err(|e| e.to_string())?;
    Ok(())
}

// Проходит по всем папкам диалогов в песочнице и упаковывает те, что не
// трогали дольше SANDBOX_IDLE_SECS — вызывается один раз при старте
// приложения (см. run()), не на каждое сообщение. "Не трогали" — это
// время изменения самого свежего файла внутри папки диалога.
fn sandbox_compress_idle() {
    let root = sandbox_root();
    let Ok(entries) = std::fs::read_dir(&root) else {
        return;
    };
    let now = std::time::SystemTime::now();
    for entry in entries.filter_map(|e| e.ok()) {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let newest = sandbox_files_recursive(&path)
            .into_iter()
            .filter_map(|p| std::fs::metadata(p).ok())
            .filter_map(|m| m.modified().ok())
            .max();
        let Some(newest) = newest else { continue }; // пустая папка — нечего сжимать
        let idle = now.duration_since(newest).unwrap_or_default().as_secs();
        if idle < SANDBOX_IDLE_SECS {
            continue;
        }
        let chat_id_safe = entry.file_name().to_string_lossy().to_string();
        let archive = sandbox_archive_path(&chat_id_safe);
        let _ = sandbox_compress_one(&path, &archive);
    }
}

// Все файлы во всей песочнице (по всем диалогам сразу) с путём и временем
// изменения — основа и для подсчёта общего размера, и для вытеснения
// самых старых при нехватке места.
fn sandbox_all_files() -> Vec<(std::path::PathBuf, u64, std::time::SystemTime)> {
    let root = sandbox_root();
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(&root) else {
        return out;
    };
    for entry in entries.filter_map(|e| e.ok()) {
        let path = entry.path();
        let Ok(meta) = entry.metadata() else { continue };
        if meta.is_file() {
            // Сжатый архив простаивающего диалога (.zip лежит прямо в корне
            // песочницы, рядом с папками) — считаем его как один файл, иначе он
            // был бы невидим для потолка в 200 МБ и для вытеснения самых старых.
            let mtime = meta.modified().unwrap_or(std::time::SystemTime::UNIX_EPOCH);
            out.push((path, meta.len(), mtime));
        } else if meta.is_dir() {
            for fpath in sandbox_files_recursive(&path) {
                if let Ok(fmeta) = std::fs::metadata(&fpath) {
                    let mtime = fmeta
                        .modified()
                        .unwrap_or(std::time::SystemTime::UNIX_EPOCH);
                    out.push((fpath, fmeta.len(), mtime));
                }
            }
        }
    }
    out
}

// Освобождает место под новую запись размером extra_needed байт, удаляя
// самые старые файлы по всей песочнице (по всем диалогам), пока общий
// размер плюс extra_needed не впишется в SANDBOX_TOTAL_MAX_BYTES.
fn sandbox_enforce_total_cap(extra_needed: u64) -> Result<(), String> {
    let total: u64 = sandbox_all_files().iter().map(|(_, size, _)| size).sum();
    if total.saturating_add(extra_needed) <= SANDBOX_TOTAL_MAX_BYTES {
        return Ok(());
    }
    // Никогда не удаляем пользовательские файлы автоматически. Прежняя
    // политика вытеснения делала карточки неоткрываемыми и выглядела как
    // случайная потеря данных. Теперь модель получает явную ошибку и может
    // предложить пользователю удалить ненужное вручную.
    Err(format!(
        "Общий лимит песочницы исчерпан ({} МБ). Удалите ненужные файлы и повторите.",
        SANDBOX_TOTAL_MAX_BYTES / 1_000_000
    ))
}

// Превращает имя файла от модели в путь строго внутри песочницы диалога.
// Оставляем только "обычные" сегменты пути (Component::Normal) — компоненты
// вида ".." или абсолютный корень отфильтровываются самим std::path на
// уровне разбора пути, а не текстовым поиском "..", так что от них нельзя
// уйти в обход, замаскировав их под другой текст.
fn sandbox_resolve(chat_id: &str, rel_path: &str) -> Result<std::path::PathBuf, String> {
    let root = sandbox_dir(chat_id);
    std::fs::create_dir_all(&root).map_err(|e| format!("Не удалось создать песочницу: {e}"))?;
    let mut clean = std::path::PathBuf::new();
    for component in std::path::Path::new(rel_path).components() {
        match component {
            std::path::Component::Normal(part) => clean.push(part),
            std::path::Component::CurDir => {}
            std::path::Component::ParentDir
            | std::path::Component::RootDir
            | std::path::Component::Prefix(_) => {
                return Err(
                    "Используйте относительный путь внутри песочницы без '..' и абсолютного корня."
                        .into(),
                );
            }
        }
    }
    if clean.as_os_str().is_empty() {
        return Err("Пустое имя файла.".into());
    }
    Ok(root.join(clean))
}

fn sandbox_list_files(chat_id: &str) -> Result<Vec<String>, String> {
    let root = sandbox_dir(chat_id);
    std::fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let mut names: Vec<String> = sandbox_files_recursive(&root)
        .into_iter()
        .filter_map(|path| {
            path.strip_prefix(&root)
                .ok()
                .map(|p| p.to_string_lossy().replace('\\', "/"))
        })
        .collect();
    names.sort();
    Ok(names)
}

fn sandbox_extract_ooxml(path: &std::path::Path, ext: &str) -> Result<String, String> {
    let file = std::fs::File::open(path).map_err(|e| e.to_string())?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| format!("Повреждённый {ext}: {e}"))?;
    let mut parts = Vec::new();
    for index in 0..archive.len() {
        let mut entry = archive.by_index(index).map_err(|e| e.to_string())?;
        let name = entry.name().to_string();
        let useful = (ext == "docx" && name == "word/document.xml")
            || (ext == "pptx" && name.starts_with("ppt/slides/slide") && name.ends_with(".xml"))
            || (ext == "xlsx"
                && (name == "xl/sharedStrings.xml" || name.starts_with("xl/worksheets/sheet")));
        if !useful {
            continue;
        }
        let mut xml = String::new();
        entry
            .read_to_string(&mut xml)
            .map_err(|e| format!("Не удалось прочитать {name}: {e}"))?;
        let text = if ext == "docx" {
            extract_docx_text(&xml)
        } else {
            xml_preview_text(&xml)
        };
        if !text.trim().is_empty() {
            parts.push(format!("[{name}]\n{text}"));
        }
    }
    if parts.is_empty() {
        Err(format!("В {ext}-файле не найден читаемый текст."))
    } else {
        Ok(parts.join("\n\n"))
    }
}

fn sandbox_read_file(chat_id: &str, rel_path: &str) -> Result<String, String> {
    let p = sandbox_resolve(chat_id, rel_path)?;
    if !p.is_file() {
        return Err(format!(
            "Файл «{rel_path}» не найден в песочнице этого диалога."
        ));
    }
    let ext = p
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    let content = match ext.as_str() {
        "pdf" => pdf_extract::extract_text(&p)
            .map_err(|e| format!("Не удалось извлечь текст из PDF «{rel_path}»: {e}"))?,
        "docx" | "pptx" | "xlsx" => sandbox_extract_ooxml(&p, &ext)?,
        "rtf" => clean_rtf(
            &std::fs::read_to_string(&p)
                .map_err(|e| format!("Не удалось прочитать RTF «{rel_path}»: {e}"))?,
        ),
        "png" | "jpg" | "jpeg" | "gif" | "bmp" | "webp" => {
            return Err(format!(
                "«{rel_path}» — изображение. Его нельзя читать как текст; используй имя файла в ответе или попроси пользователя прикрепить изображение к сообщению."
            ))
        }
        _ => std::fs::read_to_string(&p).map_err(|_| {
            format!(
                "«{rel_path}» — бинарный или неподдерживаемый формат. Поддерживаются текст, PDF, DOCX, PPTX, XLSX и RTF."
            )
        })?,
    };
    if content.chars().count() > SANDBOX_MAX_READ_CHARS {
        Ok(format!(
            "{}\n\n[Файл обрезан до {} символов]",
            content
                .chars()
                .take(SANDBOX_MAX_READ_CHARS)
                .collect::<String>(),
            SANDBOX_MAX_READ_CHARS
        ))
    } else {
        Ok(content)
    }
}

fn sandbox_write_bytes(chat_id: &str, rel_path: &str, bytes: &[u8]) -> Result<(), String> {
    if bytes.len() > SANDBOX_MAX_FILE_BYTES {
        return Err(format!(
            "Файл «{rel_path}» слишком большой для песочницы (лимит {} КБ на файл).",
            SANDBOX_MAX_FILE_BYTES / 1000
        ));
    }
    let p = sandbox_resolve(chat_id, rel_path)?;
    let old_size = std::fs::metadata(&p).map(|m| m.len()).unwrap_or(0);
    sandbox_enforce_total_cap((bytes.len() as u64).saturating_sub(old_size))?;
    if let Some(parent) = p.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    std::fs::write(&p, bytes).map_err(|e| format!("Не удалось сохранить «{rel_path}»: {e}"))
}

fn sandbox_write_file(chat_id: &str, rel_path: &str, content: &str) -> Result<(), String> {
    let ext = std::path::Path::new(rel_path)
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    if matches!(ext.as_str(), "pdf" | "pptx" | "docx" | "xlsx") {
        return Err(format!(
            "Нельзя сохранять бинарный .{ext} через write_file. Верни именованный блок ```{ext}:{rel_path}; AmIgo сам соберёт настоящий документ и сохранит его в песочнице."
        ));
    }
    if content.len() > SANDBOX_MAX_GENERATED_TEXT_BYTES {
        return Err("Текстовый файл модели слишком большой.".into());
    }
    sandbox_write_bytes(chat_id, rel_path, content.as_bytes())
}

fn sandbox_unique_filename(chat_id: &str, requested: &str) -> String {
    let raw = std::path::Path::new(requested)
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("file");
    let clean: String = raw
        .chars()
        .filter(|c| c.is_alphanumeric() || matches!(c, '.' | '-' | '_' | ' '))
        .collect();
    let clean = if clean.trim().is_empty() {
        "file".to_string()
    } else {
        clean
    };
    if !sandbox_dir(chat_id).join(&clean).exists() {
        return clean;
    }
    let path = std::path::Path::new(&clean);
    let stem = path.file_stem().and_then(|s| s.to_str()).unwrap_or("file");
    let ext = path.extension().and_then(|s| s.to_str());
    for index in 2..10_000 {
        let candidate = match ext {
            Some(ext) => format!("{stem}_{index}.{ext}"),
            None => format!("{stem}_{index}"),
        };
        if !sandbox_dir(chat_id).join(&candidate).exists() {
            return candidate;
        }
    }
    format!("file_{}", std::process::id())
}

#[tauri::command]
fn sandbox_import_file(
    chat_id: String,
    source_path: String,
    filename: String,
) -> Result<String, String> {
    let source = std::path::Path::new(&source_path);
    if !source.is_file() {
        return Err("Исходный файл не найден.".into());
    }
    let meta = std::fs::metadata(source).map_err(|e| e.to_string())?;
    if meta.len() > SANDBOX_MAX_FILE_BYTES as u64 {
        return Err(format!(
            "Файл больше лимита песочницы ({} МБ).",
            SANDBOX_MAX_FILE_BYTES / 1_000_000
        ));
    }
    let bytes = std::fs::read(source).map_err(|e| format!("Не удалось прочитать файл: {e}"))?;
    let saved_name = sandbox_unique_filename(&chat_id, &filename);
    sandbox_write_bytes(&chat_id, &saved_name, &bytes)?;
    Ok(saved_name)
}

// Детерминированный fallback для маленьких моделей: если модель не смогла
// вызвать write_file, но выдала именованный fenced-блок, фронтенд сохраняет
// его через эти команды. Пользователь всё равно получает настоящий файл.
#[tauri::command]
fn sandbox_save_generated_text(
    chat_id: String,
    path: String,
    content: String,
) -> Result<(), String> {
    sandbox_write_file(&chat_id, &path, &content)
}

#[tauri::command]
fn sandbox_save_generated_binary(
    chat_id: String,
    path: String,
    content_base64: String,
) -> Result<(), String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let bytes = STANDARD
        .decode(content_base64.as_bytes())
        .map_err(|e| format!("Некорректные данные файла: {e}"))?;
    sandbox_write_bytes(&chat_id, &path, &bytes)
}

// Модели прямо предложено самой убирать за собой неактуальные версии
// файлов (см. системный промпт и описание delete_file ниже) — жёсткие
// лимиты выше всё равно подстрахуют, если она этого не сделает.
fn sandbox_delete_file(chat_id: &str, rel_path: &str) -> Result<(), String> {
    let p = sandbox_resolve(chat_id, rel_path)?;
    if !p.is_file() {
        return Err(format!(
            "Файл «{rel_path}» не найден в песочнице этого диалога."
        ));
    }
    std::fs::remove_file(&p).map_err(|e| format!("Не удалось удалить «{rel_path}»: {e}"))
}

async fn sandbox_download_file(
    chat_id: &str,
    url: &str,
    suggested_name: &str,
) -> Result<String, String> {
    let parsed =
        reqwest::Url::parse(url).map_err(|_| "Некорректная ссылка на файл.".to_string())?;
    if !matches!(parsed.scheme(), "http" | "https") {
        return Err("Ссылка на файл должна начинаться с http:// или https://".into());
    }
    let host = parsed.host_str().unwrap_or("").to_ascii_lowercase();
    let private_ip = host
        .parse::<std::net::IpAddr>()
        .ok()
        .is_some_and(|ip| match ip {
            std::net::IpAddr::V4(ip) => {
                ip.is_private() || ip.is_loopback() || ip.is_link_local() || ip.is_unspecified()
            }
            std::net::IpAddr::V6(ip) => {
                ip.is_loopback() || ip.is_unique_local() || ip.is_unspecified()
            }
        });
    if host.is_empty() || host == "localhost" || host.ends_with(".local") || private_ip {
        return Err("Локальные и служебные адреса нельзя скачивать в песочницу.".into());
    }
    let response = reqwest::Client::new()
        .get(parsed)
        .timeout(Duration::from_secs(60))
        .send()
        .await
        .map_err(|e| format!("Не удалось скачать файл: {e}"))?;
    if !response.status().is_success() {
        return Err(format!("Сервер файла вернул HTTP {}", response.status()));
    }
    if response.content_length().unwrap_or(0) > SANDBOX_MAX_FILE_BYTES as u64 {
        return Err(format!(
            "Файл больше лимита песочницы ({} МБ).",
            SANDBOX_MAX_FILE_BYTES / 1_000_000
        ));
    }
    let bytes = response
        .bytes()
        .await
        .map_err(|e| format!("Загрузка файла оборвалась: {e}"))?;
    if bytes.len() > SANDBOX_MAX_FILE_BYTES {
        return Err(format!(
            "Файл больше лимита песочницы ({} МБ).",
            SANDBOX_MAX_FILE_BYTES / 1_000_000
        ));
    }
    let name = sandbox_unique_filename(chat_id, suggested_name);
    sandbox_write_bytes(chat_id, &name, &bytes)?;
    Ok(name)
}

// Скачивает картинку по ссылке (обычно найденной через find_images) прямо
// в песочницу диалога. Проверяем реальный Content-Type ответа, а не
// доверяем расширению в самой ссылке — иначе под видом "картинки" можно
// было бы затащить в песочницу произвольный файл. Расширение итогового
// файла берётся из Content-Type, а не из предложенного имени — это тоже
// защита от подмены. Тот же общий лимит на файл (SANDBOX_MAX_FILE_BYTES),
// что и у write_file, и то же автоматическое вытеснение старых файлов при
// нехватке места в общем потолке песочницы.
fn valid_image_bytes(ext: &str, bytes: &[u8]) -> bool {
    if bytes.len() < 32 {
        return false;
    }
    match ext.to_ascii_lowercase().as_str() {
        "png" => bytes.starts_with(b"\x89PNG\r\n\x1a\n"),
        "jpg" | "jpeg" => bytes.starts_with(&[0xff, 0xd8, 0xff]),
        "gif" => bytes.starts_with(b"GIF87a") || bytes.starts_with(b"GIF89a"),
        "bmp" => bytes.starts_with(b"BM"),
        "webp" => bytes.starts_with(b"RIFF") && bytes.get(8..12) == Some(b"WEBP"),
        _ => false,
    }
}

async fn sandbox_download_image(
    chat_id: &str,
    url: &str,
    suggested_name: &str,
) -> Result<String, String> {
    if !(url.starts_with("http://") || url.starts_with("https://")) {
        return Err("Ссылка на изображение должна начинаться с http:// или https://".into());
    }
    let client = reqwest::Client::new();
    let resp = client
        .get(url)
        .timeout(Duration::from_secs(20))
        .send()
        .await
        .map_err(|e| format!("Не удалось скачать изображение: {e}"))?;
    if !resp.status().is_success() {
        return Err(format!(
            "Сервер вернул ошибку при скачивании изображения: {}",
            resp.status()
        ));
    }
    let content_type = resp
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();
    let ext = match content_type.split(';').next().unwrap_or("").trim() {
        "image/png" => "png",
        "image/jpeg" | "image/jpg" => "jpg",
        "image/gif" => "gif",
        "image/bmp" => "bmp",
        "image/webp" => "webp",
        other => {
            return Err(format!(
                "По этой ссылке не изображение (Content-Type: {other})."
            ))
        }
    };
    let bytes = resp
        .bytes()
        .await
        .map_err(|e| format!("Обрыв соединения при скачивании изображения: {e}"))?;
    if bytes.len() > SANDBOX_MAX_FILE_BYTES {
        return Err(format!(
            "Изображение слишком большое для песочницы (лимит {} КБ).",
            SANDBOX_MAX_FILE_BYTES / 1000
        ));
    }
    if !valid_image_bytes(ext, &bytes) {
        return Err(
            "Ссылка вернула пустое или повреждённое изображение; оно не будет показано.".into(),
        );
    }
    let base: String = suggested_name
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    let base = if base.is_empty() {
        "image".to_string()
    } else {
        base
    };
    let final_name = format!("{base}.{ext}");

    sandbox_enforce_total_cap(bytes.len() as u64)?;
    let p = sandbox_resolve(chat_id, &final_name)?;
    std::fs::write(&p, &bytes).map_err(|e| format!("Не удалось сохранить изображение: {e}"))?;
    Ok(final_name)
}

// Читает картинку из песочницы диалога и отдаёт как data URL — для показа
// миниатюры в чате (тот же формат, что read_image_base64 для вложений
// пользователя, но путь берётся из песочницы конкретного диалога, а не с
// произвольного диска).
#[tauri::command]
fn sandbox_read_image(chat_id: String, filename: String) -> Result<String, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let p = sandbox_resolve(&chat_id, &filename)?;
    let ext = p
        .extension()
        .and_then(|x| x.to_str())
        .unwrap_or("")
        .to_lowercase();
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "bmp" => "image/bmp",
        "webp" => "image/webp",
        _ => return Err("unsupported_format".into()),
    };
    let bytes = std::fs::read(&p).map_err(|e| format!("Не удалось прочитать изображение: {e}"))?;
    if !valid_image_bytes(&ext, &bytes) {
        return Err("empty_or_corrupted_image".into());
    }
    Ok(format!("data:{mime};base64,{}", STANDARD.encode(bytes)))
}

#[tauri::command]
fn sandbox_health(chat_id: String) -> Result<(), String> {
    let root = sandbox_dir(&chat_id);
    std::fs::create_dir_all(&root)
        .map_err(|e| format!("Не удалось открыть папку песочницы: {e}"))?;
    let probe = root.join(".amigo-write-test");
    std::fs::write(&probe, b"ok").map_err(|e| format!("Нет доступа на запись в песочницу: {e}"))?;
    std::fs::remove_file(&probe)
        .map_err(|e| format!("Не удалось завершить проверку песочницы: {e}"))?;
    Ok(())
}

#[tauri::command]
fn sandbox_list(chat_id: String) -> Result<Vec<String>, String> {
    sandbox_list_files(&chat_id)
}

// Открывает папку песочницы этого диалога в Finder — так пользователь
// может забрать файл или отредактировать его в любой другой программе.
#[tauri::command]
fn sandbox_reveal(chat_id: String) -> Result<(), String> {
    let root = sandbox_dir(&chat_id);
    std::fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let opened = Command::new("open")
        .arg(&root)
        .status()
        .map_err(|e| e.to_string())?
        .success();
    if opened {
        Ok(())
    } else {
        Err("Finder не смог открыть папку песочницы.".into())
    }
}

// Вызывается при удалении диалога из интерфейса — песочница диалога больше
// никому не нужна, поэтому сразу освобождаем место, а не копим мусор.
#[tauri::command]
fn sandbox_delete_all(chat_id: String) -> Result<(), String> {
    let safe: String = chat_id
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    let safe = if safe.is_empty() {
        "_".to_string()
    } else {
        safe
    };
    let root = sandbox_root().join(&safe);
    let archive = sandbox_archive_path(&safe);
    if root.exists() {
        std::fs::remove_dir_all(&root).map_err(|e| e.to_string())?;
    }
    if archive.exists() {
        std::fs::remove_file(archive).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn xml_preview_text(xml: &str) -> String {
    let mut out = String::new();
    let mut in_tag = false;
    for ch in xml.chars() {
        match ch {
            '<' => in_tag = true,
            '>' => {
                in_tag = false;
                if !out.ends_with(' ') && !out.ends_with('\n') {
                    out.push(' ');
                }
            }
            _ if !in_tag => out.push(ch),
            _ => {}
        }
    }
    out.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
}

#[tauri::command]
fn sandbox_preview_file(chat_id: String, filename: String) -> Result<serde_json::Value, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let path = sandbox_resolve(&chat_id, &filename)?;
    if !path.is_file() {
        return Err("Файл не найден в песочнице.".into());
    }
    let ext = path
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    if matches!(
        ext.as_str(),
        "png" | "jpg" | "jpeg" | "gif" | "bmp" | "webp"
    ) {
        let data_url = sandbox_read_image(chat_id, filename.clone())?;
        return Ok(
            serde_json::json!({ "kind": "image", "name": filename, "ext": ext, "content": data_url }),
        );
    }
    if ext == "pdf" {
        let bytes = std::fs::read(&path).map_err(|e| e.to_string())?;
        return Ok(serde_json::json!({
            "kind": "pdf", "name": filename, "ext": ext,
            "content": format!("data:application/pdf;base64,{}", STANDARD.encode(bytes))
        }));
    }
    if matches!(ext.as_str(), "docx" | "pptx" | "xlsx") {
        let file = std::fs::File::open(&path).map_err(|e| e.to_string())?;
        let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
        let mut parts = Vec::new();
        for index in 0..archive.len() {
            let mut entry = archive.by_index(index).map_err(|e| e.to_string())?;
            let name = entry.name().to_string();
            let useful = (ext == "docx" && name == "word/document.xml")
                || (ext == "pptx"
                    && name.starts_with("ppt/slides/slide")
                    && name.ends_with(".xml"))
                || (ext == "xlsx"
                    && (name == "xl/sharedStrings.xml" || name.starts_with("xl/worksheets/sheet")));
            if !useful {
                continue;
            }
            let mut xml = String::new();
            entry.read_to_string(&mut xml).map_err(|e| e.to_string())?;
            let text = xml_preview_text(&xml);
            if !text.is_empty() {
                parts.push(text);
            }
        }
        let slides = if ext == "pptx" { parts.clone() } else { vec![] };
        return Ok(serde_json::json!({
            "kind": "document", "name": filename, "ext": ext,
            "content": parts.join("\n\n"), "slides": slides
        }));
    }
    let bytes = std::fs::read(&path).map_err(|e| e.to_string())?;
    let content =
        String::from_utf8_lossy(&bytes[..bytes.len().min(SANDBOX_MAX_GENERATED_TEXT_BYTES)])
            .to_string();
    Ok(serde_json::json!({ "kind": "text", "name": filename, "ext": ext, "content": content }))
}

#[tauri::command]
fn sandbox_export_file(
    chat_id: String,
    filename: String,
    destination: String,
) -> Result<(), String> {
    let source = sandbox_resolve(&chat_id, &filename)?;
    if !source.is_file() {
        return Err("Файл не найден в песочнице.".into());
    }
    let destination = std::path::PathBuf::from(destination);
    if let Some(parent) = destination.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    std::fs::copy(&source, &destination)
        .map_err(|e| format!("Не удалось скачать «{filename}»: {e}"))?;
    Ok(())
}

#[tauri::command]
fn sandbox_open_file(chat_id: String, filename: String) -> Result<(), String> {
    let path = sandbox_resolve(&chat_id, &filename)?;
    if !path.is_file() {
        return Err("Файл не найден.".into());
    }
    let ok = Command::new("open")
        .arg(path)
        .status()
        .map_err(|e| e.to_string())?
        .success();
    if ok {
        Ok(())
    } else {
        Err("Не удалось открыть файл.".into())
    }
}

// Удаляет выбранные временные изображения после следующего ответа. Имена
// проходят через тот же безопасный resolver; ошибки отсутствующих файлов
// игнорируются, потому что общий лимит мог вытеснить старый файл раньше.
#[tauri::command]
fn sandbox_delete_files(chat_id: String, filenames: Vec<String>) -> Result<(), String> {
    for name in filenames {
        if let Ok(path) = sandbox_resolve(&chat_id, &name) {
            if path.is_file() {
                let _ = std::fs::remove_file(path);
            }
        }
    }
    Ok(())
}

// Разбирает аргументы вызова инструмента в JSON-объект независимо от того,
// прислал ли движок их строкой (стандарт OpenAI function-calling) или уже
// готовым объектом — оба варианта встречаются на практике.
fn tool_call_args(call: &serde_json::Value) -> serde_json::Value {
    let raw = &call["function"]["arguments"];
    if raw.is_object() {
        return raw.clone();
    }
    let Some(s) = raw.as_str() else {
        return serde_json::json!({});
    };
    let s = s.trim();
    if let Ok(value) = serde_json::from_str(s) {
        return value;
    }
    // Маленькие локальные модели иногда добавляют текст до/после JSON.
    // Берём внешний объект вместо того, чтобы превращать корректный по сути
    // вызов поиска в пустой query.
    if let (Some(start), Some(end)) = (s.find('{'), s.rfind('}')) {
        if start < end {
            if let Ok(value) = serde_json::from_str(&s[start..=end]) {
                return value;
            }
        }
    }
    serde_json::json!({})
}

fn fallback_search_query(req: &ChatRequest) -> String {
    req.messages
        .iter()
        .rev()
        .find(|message| message.role == "user")
        .map(|message| {
            let content = message.content.trim();
            if content.starts_with("[ТЕКУЩИЙ ЗАПРОС") {
                content
                    .split_once('\n')
                    .map(|(_, rest)| rest.trim())
                    .unwrap_or(content)
            } else {
                content
            }
        })
        .filter(|content| !content.is_empty())
        .map(|content| content.chars().take(500).collect())
        .unwrap_or_default()
}

fn should_prefetch_files(req: &ChatRequest) -> bool {
    let query = fallback_search_query(req).to_lowercase();
    [
        "создай файл",
        "создать файл",
        "сделай файл",
        "сохрани файл",
        "запиши в файл",
        "измени файл",
        "изменить файл",
        "отредактируй",
        "доработай файл",
        "прочитай файл",
        "открой файл",
        "скачай файл",
        "загрузи файл",
        "добавь файл",
        "удали файл",
        "песочниц",
        "sandbox",
        "[оригиналы вложений сохранены",
        "create a file",
        "save to file",
        "edit the file",
        "read the file",
    ]
    .iter()
    .any(|trigger| query.contains(trigger))
}

fn is_matle_code_task(req: &ChatRequest) -> bool {
    if req.provider != "local" || req.model != "matle-2.5" {
        return false;
    }
    if req.unlimited_output {
        return true;
    }
    let query = fallback_search_query(req).to_lowercase();
    let action = [
        "создай", "напиши", "реализ", "измени", "исправ", "доработ", "перепиши",
        "рефактор", "отлад", "проверь", "протест", "запусти тест", "скопируй код",
        "сохрани код", "добавь", "удали из кода", "проанализируй", "create",
        "write", "implement", "edit", "fix", "refactor", "debug", "test", "validate",
    ]
    .iter()
    .any(|trigger| query.contains(trigger));
    let code_target = [
        "код", "скрипт", "программ", "компонент", "функц", "класс", "typescript",
        "javascript", "python", "rust", "html", "css", "sql", "api", ".js", ".jsx",
        ".ts", ".tsx", ".py", ".rs", ".go", ".java", ".swift", ".cpp", ".html",
        ".css", "code", "script", "component", "function", "project",
    ]
    .iter()
    .any(|trigger| query.contains(trigger));
    action && code_target
}

fn should_prefetch_web_search(req: &ChatRequest) -> bool {
    // Переключатель разрешает поиск, но не запускает его для каждого ответа.
    // Ищем только при явной просьбе или когда нужны свежие внешние сведения.
    let query = fallback_search_query(req).to_lowercase();
    [
        "найди",
        "поищи",
        "поиск",
        "в интернете",
        "проверь в сети",
        "проверь информацию",
        "актуальн",
        "последн",
        "свеж",
        "новост",
        "сегодня",
        "сейчас",
        "на данный момент",
        "текущ",
        "курс валют",
        "сколько стоит",
        "цена",
        "погода",
        "расписание",
        "результаты",
        "скачай",
        "загрузи по ссылке",
        "http://",
        "https://",
        "search the web",
        "look up",
        "latest",
        "current",
        "today",
        "news",
        "weather",
        "price",
    ]
    .iter()
    .any(|trigger| query.contains(trigger))
}

fn should_offer_followup_tools(req: &ChatRequest) -> bool {
    let query = fallback_search_query(req).to_lowercase();
    should_prefetch_files(req)
        || [
            "картин",
            "изображ",
            "фото",
            "скачай",
            "загрузи",
            "download",
            "image",
            "picture",
            "прочитай страницу",
            "открой ссылку",
            "http://",
            "https://",
        ]
        .iter()
        .any(|trigger| query.contains(trigger))
}

fn should_stream_media_flow(req: &ChatRequest) -> bool {
    if req
        .messages
        .iter()
        .any(|message| !message.images.is_empty())
    {
        return true;
    }
    let query = fallback_search_query(req).to_lowercase();
    ["картин", "изображ", "фото", "image", "picture", "photo"]
        .iter()
        .any(|trigger| query.contains(trigger))
}

fn emit_search_error(app: &tauri::AppHandle) {
    let _ = app.emit(
        "chat-search-error",
        serde_json::json!({
            "message": "Не удалось выполнить поиск Tavily. Ответ дан без интернет-поиска. Перезапустите ответ или проверьте ключ Tavily."
        }),
    );
}

fn format_search_tool_result(
    result: Result<Vec<SearchSource>, String>,
) -> (Vec<SearchSource>, String) {
    match result {
        Err(error) => (vec![], format!("Поиск не удался: {error}")),
        Ok(sources) if sources.is_empty() => (vec![], "Поиск не дал результатов.".to_string()),
        Ok(sources) => {
            let text = sources
                .iter()
                .enumerate()
                .map(|(index, source)| {
                    format!(
                        "{}. {} ({})\n{}",
                        index + 1,
                        source.title,
                        source.url,
                        source.content
                    )
                })
                .collect::<Vec<_>>()
                .join("\n\n");
            (sources, text)
        }
    }
}

fn basic_syntax_check(content: &str) -> Result<(), String> {
    let mut stack: Vec<(char, usize)> = Vec::new();
    let mut quote: Option<char> = None;
    let mut escaped = false;
    for (index, ch) in content.chars().enumerate() {
        if let Some(active_quote) = quote {
            if escaped {
                escaped = false;
            } else if ch == '\\' {
                escaped = true;
            } else if ch == active_quote {
                quote = None;
            }
            continue;
        }
        if matches!(ch, '\'' | '"' | '`') {
            quote = Some(ch);
            continue;
        }
        match ch {
            '(' | '[' | '{' => stack.push((ch, index)),
            ')' | ']' | '}' => {
                let expected = match ch {
                    ')' => '(',
                    ']' => '[',
                    _ => '{',
                };
                let Some((opening, _)) = stack.pop() else {
                    return Err(format!(
                        "Лишний закрывающий символ «{ch}» около позиции {index}."
                    ));
                };
                if opening != expected {
                    return Err(format!(
                        "Несогласованные скобки «{opening}» и «{ch}» около позиции {index}."
                    ));
                }
            }
            _ => {}
        }
    }
    if let Some(active_quote) = quote {
        return Err(format!(
            "Не закрыта строка с разделителем «{active_quote}»."
        ));
    }
    if let Some((opening, position)) = stack.last() {
        return Err(format!(
            "Не закрыта скобка «{opening}» около позиции {position}."
        ));
    }
    Ok(())
}

fn run_checked_command(
    program: &str,
    args: &[String],
    cwd: &std::path::Path,
    timeout_seconds: u64,
) -> Result<(bool, String), String> {
    let log_path = std::env::temp_dir().join(format!(
        "amigo-check-{}-{}.log",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos()
    ));
    let log = std::fs::File::create(&log_path).map_err(|error| error.to_string())?;
    let stderr_log = log.try_clone().map_err(|error| error.to_string())?;
    let mut child = Command::new(program)
        .args(args)
        .current_dir(cwd)
        .stdout(std::process::Stdio::from(log))
        .stderr(std::process::Stdio::from(stderr_log))
        .spawn()
        .map_err(|error| format!("Инструмент «{program}» недоступен: {error}"))?;
    let deadline = std::time::Instant::now() + Duration::from_secs(timeout_seconds);
    let success = loop {
        match child.try_wait() {
            Ok(Some(status)) => break status.success(),
            Ok(None) if std::time::Instant::now() < deadline => {
                std::thread::sleep(Duration::from_millis(100));
            }
            Ok(None) => {
                let _ = child.kill();
                let _ = child.wait();
                let _ = std::fs::remove_file(&log_path);
                return Err(format!(
                    "Проверка превысила лимит {timeout_seconds} секунд и остановлена."
                ));
            }
            Err(error) => {
                let _ = std::fs::remove_file(&log_path);
                return Err(format!("Не удалось дождаться проверки: {error}"));
            }
        }
    };
    let mut text = std::fs::read_to_string(&log_path).unwrap_or_default();
    let _ = std::fs::remove_file(&log_path);
    if text.len() > 12_000 {
        let mut start = text.len().saturating_sub(12_000);
        while start < text.len() && !text.is_char_boundary(start) {
            start += 1;
        }
        text = text[start..].to_string();
    }
    Ok((success, text.trim().to_string()))
}

fn sandbox_check_syntax(chat_id: &str, rel_path: &str) -> Result<String, String> {
    let path = sandbox_resolve(chat_id, rel_path)?;
    let content = std::fs::read_to_string(&path)
        .map_err(|_| format!("Файл «{rel_path}» не является текстовым исходником."))?;
    let ext = path
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    if ext == "json" || ext == "jsonl" {
        if ext == "json" {
            serde_json::from_str::<serde_json::Value>(&content)
                .map_err(|error| format!("Ошибка JSON: {error}"))?;
        } else {
            for (line_index, line) in content.lines().enumerate() {
                if !line.trim().is_empty() {
                    serde_json::from_str::<serde_json::Value>(line).map_err(|error| {
                        format!("Ошибка JSONL в строке {}: {error}", line_index + 1)
                    })?;
                }
            }
        }
        return Ok(format!("OK: синтаксис «{rel_path}» корректен."));
    }

    let command: Option<(&str, Vec<String>)> = match ext.as_str() {
        "py" => Some((
            "python3",
            vec![
                "-m".into(),
                "py_compile".into(),
                path.to_string_lossy().to_string(),
            ],
        )),
        "js" | "mjs" | "cjs" => Some((
            "node",
            vec!["--check".into(), path.to_string_lossy().to_string()],
        )),
        "sh" | "bash" => Some((
            "bash",
            vec!["-n".into(), path.to_string_lossy().to_string()],
        )),
        "zsh" => Some(("zsh", vec!["-n".into(), path.to_string_lossy().to_string()])),
        "rb" => Some((
            "ruby",
            vec!["-c".into(), path.to_string_lossy().to_string()],
        )),
        "php" => Some(("php", vec!["-l".into(), path.to_string_lossy().to_string()])),
        _ => None,
    };
    if let Some((program, args)) = command {
        match run_checked_command(program, &args, &sandbox_dir(chat_id), 45) {
            Ok((true, output)) => {
                return Ok(if output.is_empty() {
                    format!("OK: синтаксис «{rel_path}» корректен.")
                } else {
                    format!("OK: {output}")
                });
            }
            Ok((false, output)) => {
                return Err(format!("Ошибка синтаксиса в «{rel_path}»:\n{output}"))
            }
            Err(_) => { /* встроенная проверка ниже остаётся доступной без внешних runtime */
            }
        }
    }
    basic_syntax_check(&content)
        .map(|()| format!("OK: базовая структурная проверка «{rel_path}» пройдена."))
}

fn sandbox_validate_project(chat_id: &str, action: &str) -> Result<String, String> {
    let root = sandbox_dir(chat_id);
    let normalized = action.trim().to_ascii_lowercase();
    let command: Option<(&str, Vec<String>)> = if root.join("package.json").is_file() {
        match normalized.as_str() {
            "tests" | "test" => Some(("npm", vec!["test".into()])),
            "typecheck" | "types" => Some((
                "npx",
                vec!["--no-install".into(), "tsc".into(), "--noEmit".into()],
            )),
            _ => None,
        }
    } else if root.join("Cargo.toml").is_file() {
        match normalized.as_str() {
            "tests" | "test" => Some(("cargo", vec!["test".into(), "--no-run".into()])),
            "typecheck" | "types" | "auto" => Some(("cargo", vec!["check".into()])),
            _ => None,
        }
    } else if matches!(normalized.as_str(), "tests" | "test")
        && (root.join("pyproject.toml").is_file() || root.join("pytest.ini").is_file())
    {
        Some(("python3", vec!["-m".into(), "pytest".into(), "-q".into()]))
    } else {
        None
    };
    if let Some((program, args)) = command {
        let (ok, output) = run_checked_command(program, &args, &root, 120)?;
        return if ok {
            Ok(format!("OK: проверка проекта пройдена.\n{output}"))
        } else {
            Err(format!(
                "Проверка проекта завершилась с ошибками:\n{output}"
            ))
        };
    }

    let files = sandbox_list_files(chat_id)?;
    let code_extensions = [
        "py", "js", "mjs", "cjs", "ts", "tsx", "jsx", "json", "jsonl", "sh", "bash", "zsh", "rb",
        "php", "rs", "go", "java", "swift", "c", "cpp", "h", "hpp", "css", "html",
    ];
    let mut checked = 0usize;
    let mut errors = Vec::new();
    for file in files.into_iter().take(250) {
        let ext = std::path::Path::new(&file)
            .extension()
            .and_then(|value| value.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        if !code_extensions.contains(&ext.as_str()) {
            continue;
        }
        checked += 1;
        if let Err(error) = sandbox_check_syntax(chat_id, &file) {
            errors.push(error);
        }
    }
    if errors.is_empty() {
        Ok(format!(
            "OK: синтаксическая проверка проекта пройдена, файлов проверено: {checked}."
        ))
    } else {
        Err(errors.join("\n\n"))
    }
}

fn emit_code_step(app: &tauri::AppHandle, req: &ChatRequest, id: &str, label: &str, state: &str) {
    if req.provider == "local" && req.model == "matle-2.5" {
        let _ = app.emit(
            "chat-code-step",
            serde_json::json!({ "id": id, "label": label, "state": state }),
        );
    }
}

fn code_tool_step_label(name: &str, args: &serde_json::Value) -> String {
    let path = args["path"].as_str().unwrap_or("").trim();
    match name {
        "list_files" => "Изучаю файлы проекта".into(),
        "read_file" => format!("Изучаю {}", if path.is_empty() { "файл" } else { path }),
        "write_file" => format!("Пишу {}", if path.is_empty() { "файл" } else { path }),
        "copy_code_to_file" => format!(
            "Копирую готовый код в {}",
            if path.is_empty() { "файл" } else { path }
        ),
        "delete_file" => format!(
            "Убираю {}",
            if path.is_empty() {
                "лишний файл"
            } else {
                path
            }
        ),
        "check_syntax" => format!(
            "Проверяю синтаксис {}",
            if path.is_empty() { "кода" } else { path }
        ),
        "validate_project" => match args["action"].as_str().unwrap_or("auto") {
            "tests" => "Запускаю тесты".into(),
            "typecheck" => "Проверяю типы".into(),
            _ => "Проверяю проект".into(),
        },
        "web_search" | "read_webpage" => "Ищу документацию".into(),
        "download_file" => "Загружаю нужный файл".into(),
        _ => "Выполняю следующий шаг".into(),
    }
}

fn sandbox_tools_defs() -> Vec<serde_json::Value> {
    vec![
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "list_files",
            "description": "Показывает список файлов, уже сохранённых в песочнице этого диалога.",
            "parameters": { "type": "object", "properties": {} }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "read_file",
            "description": "Читает файл из песочницы перед анализом или изменением. Поддерживает обычный текст и извлечение текста из PDF, DOCX, PPTX, XLSX, RTF. Путь бери только из list_files и передавай относительно корня песочницы.",
            "parameters": {
              "type": "object",
              "properties": { "path": { "type": "string", "description": "Имя файла в песочнице, например notes.md или script.py" } },
              "required": ["path"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "write_file",
            "description": "Создаёт или полностью перезаписывает ТОЛЬКО текстовый файл/исходный код в песочнице. Передавай полное готовое содержимое. Для PDF, PPTX, DOCX, XLSX этот инструмент запрещён: такие документы возвращай именованным fenced-блоком, чтобы AmIgo собрал настоящий бинарный файл.",
            "parameters": {
              "type": "object",
              "properties": {
                "path": { "type": "string", "description": "Имя файла, например script.py" },
                "content": { "type": "string", "description": "Полное новое содержимое файла" }
              },
              "required": ["path", "content"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "delete_file",
            "description": "Удаляет файл из песочницы этого диалога — используй, когда файл больше не нужен: заменил его новой версией под другим именем, результат устарел, или он был промежуточным черновиком. Место в песочнице ограничено, поэтому убирай за собой неактуальное, а не оставляй все версии подряд.",
            "parameters": {
              "type": "object",
              "properties": { "path": { "type": "string", "description": "Имя файла для удаления" } },
              "required": ["path"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "copy_code_to_file",
            "description": "Мгновенно копирует уже существующий fenced-блок кода из истории в файл песочницы. Используй вместо повторной генерации большого кода. Доступные block_id перечислены в системном контексте.",
            "parameters": {
              "type": "object",
              "properties": {
                "block_id": { "type": "string", "description": "ID блока из списка доступных блоков" },
                "path": { "type": "string", "description": "Итоговый путь файла, например src/app.ts" }
              },
              "required": ["block_id", "path"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "check_syntax",
            "description": "Проверяет синтаксис конкретного сохранённого файла. После ошибки исправь файл и вызови проверку снова; не объявляй код готовым до успешного OK.",
            "parameters": {
              "type": "object",
              "properties": { "path": { "type": "string", "description": "Путь файла в песочнице" } },
              "required": ["path"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "validate_project",
            "description": "Проверяет проект целиком: syntax — синтаксис всех исходников, typecheck — типы/компиляция, tests — тесты, auto — лучшая доступная проверка. При ошибках исправь код и повтори.",
            "parameters": {
              "type": "object",
              "properties": { "action": { "type": "string", "enum": ["auto", "syntax", "typecheck", "tests"] } },
              "required": ["action"]
            }
          }
        }),
    ]
}

// Описание инструмента (формат function-calling OpenAI): модель сама решает,
// вызывать ли его, и сама формулирует поисковый запрос. Работает одинаково
// и для Groq, и для локального движка AmIgo — оба говорят на OpenAI-протоколе.
fn web_search_tool_def() -> serde_json::Value {
    serde_json::json!({
      "type": "function",
      "function": {
        "name": "web_search",
        "description": "Ищет свежую информацию в интернете: новости, текущие события, цены, курсы, даты и факты, которых может не быть в твоих знаниях. Вызывай, когда вопрос требует актуальных или проверяемых данных.",
        "parameters": {
          "type": "object",
          "properties": { "query": { "type": "string", "description": "Поисковый запрос на языке вопроса пользователя" } },
          "required": ["query"]
        }
      }
    })
}

fn read_webpage_tool_def() -> serde_json::Value {
    serde_json::json!({
      "type": "function",
      "function": {
        "name": "read_webpage",
        "description": "Читает содержимое конкретной веб-страницы. Вызывай только когда пользователь дал ссылку или по результатам поиска нужно понять содержимое сайта; не вызывай для обычных вопросов.",
        "parameters": {
          "type": "object",
          "properties": { "url": { "type": "string", "description": "Полный URL страницы, начиная с https://" } },
          "required": ["url"]
        }
      }
    })
}

// find_images/download_image/download_file доступны только вместе с
// песочницей и включённым Tavily: скачанное сохраняется в текущий chat_id.
// См. сборку списка инструментов в
// chat_stream_inner.
fn image_tools_defs() -> Vec<serde_json::Value> {
    vec![
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "find_images",
            "description": "Ищет в интернете картинки по запросу и возвращает до нескольких ссылок на них. Сами картинки этим не скачиваются — чтобы показать картинку пользователю, вставить её в презентацию или другой документ, после этого вызови download_image с понравившейся ссылкой.",
            "parameters": {
              "type": "object",
              "properties": { "query": { "type": "string", "description": "Что искать, на языке запроса пользователя" } },
              "required": ["query"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "download_image",
            "description": "Скачивает картинку по ссылке (обычно найденной через find_images) в песочницу этого диалога — так её можно показать пользователю или вставить в презентацию/документ. Если нужно несколько картинок — вызови этот инструмент несколько раз, по одному разу на каждую ссылку.",
            "parameters": {
              "type": "object",
              "properties": {
                "url": { "type": "string", "description": "Прямая ссылка на файл картинки" },
                "name": { "type": "string", "description": "Короткое имя файла без расширения, например kotik или eiffel_tower" }
              },
              "required": ["url", "name"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "download_file",
            "description": "Скачивает обычный файл по прямой HTTP(S)-ссылке в песочницу. Используй для PDF, документов, архивов, исходников и других файлов, но не для картинок, для которых есть download_image.",
            "parameters": {
              "type": "object",
              "properties": {
                "url": { "type": "string", "description": "Прямая публичная HTTP(S)-ссылка на файл" },
                "name": { "type": "string", "description": "Имя с расширением, например report.pdf или data.csv" }
              },
              "required": ["url", "name"]
            }
          }
        }),
    ]
}

// Собирает поток OpenAI SSE и сразу передаёт текстовые токены во фронтенд.
// Одновременно умеет собирать частичные tool_calls: Groq и llama-server
// присылают имя/аргументы функции кусочками в delta.tool_calls.
struct OpenAIStreamResult {
    content: String,
    tool_calls: Vec<serde_json::Value>,
}

// Держим небольшой хвост до показа пользователю. Если модель начала второй
// идентичный проход, детектор успевает отбросить его до попадания в интерфейс.
const STREAM_REPEAT_GUARD_CHARS: usize = 160;

fn prefix_len_without_last_chars(text: &str, keep_chars: usize) -> usize {
    if keep_chars == 0 {
        return text.len();
    }
    text.char_indices()
        .rev()
        .nth(keep_chars.saturating_sub(1))
        .map(|(index, _)| index)
        .unwrap_or(0)
}

// Ищет в недавнем выводе второй точный проход фрагмента длиной от 128
// символов. Работает и для длинных абзацев, и для короткой фразы, которая
// повторяется много раз. Возвращает начало второго прохода в байтах UTF-8.
fn repetition_cutoff(text: &str) -> Option<usize> {
    const PROBE: usize = 128;
    const MIN_SHIFT: usize = 16;
    const MAX_LOOKBACK: usize = 4_096;

    // Анализируем только хвост фиксированного размера, поэтому проверка не
    // замедляется по мере роста длинного нормального ответа.
    let window_chars = MAX_LOOKBACK + PROBE;
    let window_start = text
        .char_indices()
        .rev()
        .nth(window_chars.saturating_sub(1))
        .map(|(index, _)| index)
        .unwrap_or(0);
    let window = &text[window_start..];
    let chars: Vec<char> = window.chars().collect();
    let n = chars.len();
    if n < PROBE + MIN_SHIFT {
        return None;
    }
    let current = n - PROBE;
    let first = current.saturating_sub(MAX_LOOKBACK);

    for previous in (first..current).rev() {
        let shift = current - previous;
        if shift < MIN_SHIFT || previous + PROBE > n {
            continue;
        }
        if chars[previous..previous + PROBE] != chars[current..n] {
            continue;
        }

        let mut back = 0usize;
        while back < shift
            && previous > back
            && current > back
            && chars[previous - back - 1] == chars[current - back - 1]
        {
            back += 1;
        }
        let cutoff_chars = current - back;
        let local_byte = window
            .char_indices()
            .nth(cutoff_chars)
            .map(|(index, _)| index)
            .unwrap_or(window.len());
        return Some(window_start + local_byte);
    }
    None
}

// Ловит не только точную копию, но и повтор той же мысли с небольшими
// перестановками слов. Сравниваются длинные соседние/недавние абзацы; код
// исключён выше через inside_unclosed_fence.
fn fuzzy_repetition_cutoff(text: &str) -> Option<usize> {
    let window_start = text
        .char_indices()
        .rev()
        .nth(8_000)
        .map(|(index, _)| index)
        .unwrap_or(0);
    let window = &text[window_start..];
    let mut spans = Vec::<(usize, usize)>::new();
    let mut start = 0usize;
    for (index, separator) in window.match_indices("\n\n") {
        if index > start {
            spans.push((start, index));
        }
        start = index + separator.len();
    }
    if start < window.len() {
        spans.push((start, window.len()));
    }
    if spans.len() < 2 {
        return None;
    }
    let (last_start, last_end) = *spans.last()?;
    let last_text = window[last_start..last_end].trim();
    if last_text.chars().count() < 120
        || last_text
            .lines()
            .any(|line| line.trim_start().starts_with('|'))
    {
        return None;
    }
    let words = |value: &str| -> std::collections::HashSet<String> {
        value
            .split(|ch: char| !ch.is_alphanumeric() && ch != '_')
            .map(|word| word.to_lowercase())
            .filter(|word| word.chars().count() >= 3)
            .collect()
    };
    let last_words = words(last_text);
    if last_words.len() < 12 {
        return None;
    }
    for (previous_start, previous_end) in spans[..spans.len() - 1].iter().rev().take(8) {
        let previous_text = window[*previous_start..*previous_end].trim();
        let previous_words = words(previous_text);
        if previous_words.len() < 12 {
            continue;
        }
        let common = last_words.intersection(&previous_words).count();
        let union = last_words.union(&previous_words).count().max(1);
        let similarity = common as f64 / union as f64;
        let length_ratio = last_words.len() as f64 / previous_words.len().max(1) as f64;
        if common >= 12 && similarity >= 0.82 && (0.68..=1.47).contains(&length_ratio) {
            return Some(window_start + last_start);
        }
    }
    None
}

fn inside_unclosed_fence(text: &str) -> bool {
    let mut fence: Option<&str> = None;
    for line in text.lines() {
        let trimmed = line.trim_start();
        let marker = if trimmed.starts_with("```") {
            Some("```")
        } else if trimmed.starts_with("~~~") {
            Some("~~~")
        } else {
            None
        };
        if let Some(marker) = marker {
            if fence == Some(marker) {
                fence = None;
            } else if fence.is_none() {
                fence = Some(marker);
            }
        }
    }
    fence.is_some()
}

fn append_checked(output: &mut String, delta: &str, already_emitted: usize) -> bool {
    let previous_bucket = output.len() / 32;
    output.push_str(delta);
    // Повторы внутри ещё открытого fenced-кода могут быть легитимными
    // (HTML-элементы, CSS-правила, таблицы). Их ограничивает max_tokens, а не
    // текстовый anti-loop, чтобы готовый файл не обрывался посередине.
    if inside_unclosed_fence(output) {
        return true;
    }
    // Проверяем примерно раз в 32 байта: этого достаточно для защиты от
    // циклов, но видимый поток начинается заметно раньше.
    if output.len() / 32 == previous_bucket {
        return true;
    }
    if let Some(cutoff) = repetition_cutoff(output).or_else(|| fuzzy_repetition_cutoff(output)) {
        // Уже отправленный текст отозвать нельзя; короткий guard оставляет
        // возможность обрезать повтор до его полного появления в WebView.
        let cutoff = cutoff.max(already_emitted).min(output.len());
        output.truncate(cutoff);
        return false;
    }
    true
}

fn emit_content_until(app: &tauri::AppHandle, output: &str, emitted: &mut usize, until: usize) {
    let until = until.min(output.len());
    if until <= *emitted {
        return;
    }
    let content = output[*emitted..until].to_string();
    *emitted = until;
    let _ = app.emit("chat-chunk", ChatChunk { content });
}

async fn collect_openai_stream(
    app: &tauri::AppHandle,
    state: &ChatState,
    response: reqwest::Response,
    show_thinking: bool,
    emit_live: bool,
    repeat_guard_chars: usize,
    idle_timeout: Duration,
) -> Result<OpenAIStreamResult, String> {
    // Некоторые версии OpenAI-совместимых серверов игнорируют stream:true
    // при tools и возвращают обычный JSON. Обрабатываем его как корректный
    // fallback, чтобы ответ не превращался в пустую строку.
    let content_type = response
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_ascii_lowercase();
    if content_type.contains("application/json") && !content_type.contains("text/event-stream") {
        let data: serde_json::Value = response.json().await.map_err(|e| e.to_string())?;
        if let Some(reason) = data["choices"][0]["finish_reason"].as_str() {
            let _ = app.emit("chat-finish", serde_json::json!({ "reason": reason }));
        }
        let message = &data["choices"][0]["message"];
        let mut content = message["content"].as_str().unwrap_or("").to_string();
        if let Some(cutoff) = repetition_cutoff(&content).or_else(|| fuzzy_repetition_cutoff(&content)) {
            content.truncate(cutoff);
        }
        if emit_live && !content.is_empty() {
            let _ = app.emit(
                "chat-chunk",
                ChatChunk {
                    content: content.clone(),
                },
            );
        }
        let tool_calls = message["tool_calls"]
            .as_array()
            .cloned()
            .unwrap_or_default();
        return Ok(OpenAIStreamResult {
            content,
            tool_calls,
        });
    }

    let mut stream = response.bytes_stream();
    let mut buffer: Vec<u8> = Vec::new();
    let mut full = String::new();
    let mut emitted = 0usize;
    let mut calls: std::collections::BTreeMap<usize, (String, String, String)> =
        std::collections::BTreeMap::new();
    let mut thinking_active = false;
    let mut thinking_started: Option<tokio::time::Instant> = None;
    let mut last_progress = tokio::time::Instant::now();

    'outer: loop {
        let deadline = last_progress + idle_timeout;
        let item = tokio::select! {
            biased;
            _ = wait_for_stop(state) => None,
            _ = tokio::time::sleep_until(deadline) => {
                return Err(format!("generation_stalled: Модель не выводит данные более {} секунд.", idle_timeout.as_secs()));
            },
            item = stream.next() => item,
        };
        let Some(item) = item else { break };
        let bytes = item.map_err(|e| e.to_string())?;
        buffer.extend_from_slice(&bytes);
        while let Some(pos) = buffer.iter().position(|b| *b == b'\n') {
            let line = String::from_utf8_lossy(&buffer[..pos]).trim().to_string();
            buffer.drain(..=pos);
            if line.is_empty() {
                continue;
            }
            let json_str = if let Some(stripped) = line.strip_prefix("data:") {
                let stripped = stripped.trim();
                if stripped == "[DONE]" {
                    break 'outer;
                }
                stripped
            } else {
                line.as_str()
            };
            let Ok(data) = serde_json::from_str::<serde_json::Value>(json_str) else {
                continue;
            };
            if let Some(reason) = data["choices"][0]["finish_reason"].as_str() {
                let _ = app.emit("chat-finish", serde_json::json!({ "reason": reason }));
            }
            let delta = &data["choices"][0]["delta"];
            let reasoning = delta["reasoning"]
                .as_str()
                .or_else(|| delta["reasoning_content"].as_str())
                .unwrap_or("");
            if !reasoning.is_empty() {
                last_progress = tokio::time::Instant::now();
                let started = thinking_started.get_or_insert_with(tokio::time::Instant::now);
                if started.elapsed() > Duration::from_secs(45) {
                    return Err("generation_stalled: Режим рассуждения превысил безопасное время; ответ будет перезапущен без зависания.".into());
                }
            }
            if show_thinking && !reasoning.is_empty() && !thinking_active {
                thinking_active = true;
                let _ = app.emit(
                    "chat-status",
                    StatusEvent {
                        kind: "thinking".into(),
                        active: true,
                    },
                );
            }
            let text = delta["content"].as_str().unwrap_or("");
            if !text.is_empty() {
                thinking_started = None;
                last_progress = tokio::time::Instant::now();
                if thinking_active {
                    thinking_active = false;
                    let _ = app.emit(
                        "chat-status",
                        StatusEvent {
                            kind: "thinking".into(),
                            active: false,
                        },
                    );
                }
                if !append_checked(&mut full, text, emitted) {
                    break 'outer;
                }
                if emit_live {
                    let safe = prefix_len_without_last_chars(&full, repeat_guard_chars);
                    emit_content_until(app, &full, &mut emitted, safe);
                }
            }
            if let Some(parts) = delta["tool_calls"].as_array() {
                if !parts.is_empty() {
                    last_progress = tokio::time::Instant::now();
                }
                for part in parts {
                    let index = part["index"].as_u64().unwrap_or(0) as usize;
                    let entry = calls
                        .entry(index)
                        .or_insert_with(|| (String::new(), String::new(), String::new()));
                    if let Some(id) = part["id"].as_str() {
                        entry.0.push_str(id);
                    }
                    if let Some(name) = part["function"]["name"].as_str() {
                        // Одни версии сервера стримят имя по частям (`write_` +
                        // `file`), другие повторяют уже накопленное полное имя.
                        if entry.1.is_empty() {
                            entry.1.push_str(name);
                        } else if name.starts_with(&entry.1) {
                            entry.1 = name.to_string();
                        } else if !entry.1.ends_with(name) {
                            entry.1.push_str(name);
                        }
                    }
                    if let Some(args) = part["function"]["arguments"].as_str() {
                        entry.2.push_str(args);
                    } else if part["function"]["arguments"].is_object() {
                        // Некоторые версии llama-server для Qwen3.5 отдают
                        // готовый объект, а не JSON-строку.
                        entry.2 = part["function"]["arguments"].to_string();
                    }
                }
            }
            if state.stop.load(Ordering::SeqCst) {
                break 'outer;
            }
        }
    }
    if emit_live {
        let final_len = full.len();
        emit_content_until(app, &full, &mut emitted, final_len);
    }
    if thinking_active {
        let _ = app.emit(
            "chat-status",
            StatusEvent {
                kind: "thinking".into(),
                active: false,
            },
        );
    }
    let tool_calls = calls
        .into_iter()
        .map(|(index, (id, name, arguments))| {
            serde_json::json!({
              "index": index,
              "id": if id.is_empty() { format!("call_{index}") } else { id },
              "type": "function",
              "function": { "name": name, "arguments": arguments }
            })
        })
        .collect();
    Ok(OpenAIStreamResult {
        content: full,
        tool_calls,
    })
}

// Конвертирует сообщения в OpenAI-формат с поддержкой изображений
// (data-URL в content-массиве) — общая логика для Groq и локального движка.
fn to_openai_messages(messages: &[ChatMessage]) -> Vec<serde_json::Value> {
    messages
        .iter()
        .map(|m| {
            if m.images.is_empty() {
                serde_json::json!({ "role": m.role, "content": m.content })
            } else {
                let mut parts: Vec<serde_json::Value> =
                    vec![serde_json::json!({ "type": "text", "text": m.content })];
                for (index, img) in m.images.iter().enumerate() {
                    if index > 0 {
                        // Qwen-VL/mtmd надёжнее разделяет несколько кадров,
                        // когда между соседними image_url есть текстовая метка.
                        parts.push(serde_json::json!({
                          "type": "text", "text": format!("[Изображение {}]", index + 1)
                        }));
                    }
                    let data_url = if img.starts_with("data:image/") {
                        img.clone()
                    } else {
                        // Совместимость со старыми сохранёнными сообщениями,
                        // где хранилась только Base64-часть.
                        format!("data:image/jpeg;base64,{img}")
                    };
                    parts.push(serde_json::json!({
                      "type": "image_url",
                      "image_url": { "url": data_url }
                    }));
                }
                serde_json::json!({ "role": m.role, "content": parts })
            }
        })
        .collect()
}

fn response_token_limit(req: &ChatRequest) -> u32 {
    req.max_tokens
        .unwrap_or(if req.think == Some(true) {
            8_192
        } else {
            6_144
        })
        .clamp(256, 8_192)
}

fn generation_idle_timeout(req: &ChatRequest) -> Duration {
    if req
        .messages
        .iter()
        .any(|message| !message.images.is_empty())
    {
        Duration::from_secs(120)
    } else if req.provider == "local" {
        Duration::from_secs(75)
    } else {
        Duration::from_secs(60)
    }
}

// Qwen3.5 чувствительна к слишком низкой температуре: прежние 0.2–0.45
// делали наиболее вероятный токен почти детерминированным и усиливали длинные
// циклы. Используем рекомендованные моделью режимы и отделяем reasoning от
// финального content средствами llama-server.
fn configure_local_payload(payload: &mut serde_json::Value, req: &ChatRequest) {
    let thinking = req.think == Some(true) && req.model != "matle-2.5";
    payload["max_tokens"] = serde_json::json!(response_token_limit(req));
    payload["top_k"] = serde_json::json!(20);
    payload["min_p"] = serde_json::json!(0.0);
    payload["repeat_penalty"] =
        serde_json::json!(if req.model == "matle-2.5" { 1.05 } else { 1.0 });
    payload["reasoning_format"] = serde_json::json!("deepseek");

    if req.model == "matle-2.5" {
        // Qwen2.5 Coder не имеет отдельного reasoning-канала Qwen3.5.
        // Его скрытая итеративность реализуется tool-round: план → файл →
        // проверка → исправление, а UI показывает только рабочие состояния.
        payload["temperature"] = serde_json::json!(0.35);
        payload["top_p"] = serde_json::json!(0.9);
        payload["presence_penalty"] = serde_json::json!(0.15);
        payload["reasoning_effort"] = serde_json::json!("none");
        payload["chat_template_kwargs"] = serde_json::json!({"enable_thinking": false});
    } else if thinking {
        payload["temperature"] = serde_json::json!(1.0);
        payload["top_p"] = serde_json::json!(0.95);
        payload["presence_penalty"] = serde_json::json!(1.5);
        payload["reasoning_effort"] = serde_json::json!("medium");
        payload["chat_template_kwargs"] = serde_json::json!({"enable_thinking": true});
    } else {
        payload["temperature"] = serde_json::json!(0.7);
        payload["top_p"] = serde_json::json!(0.8);
        payload["presence_penalty"] = serde_json::json!(1.5);
        payload["reasoning_effort"] = serde_json::json!("none");
        payload["chat_template_kwargs"] = serde_json::json!({"enable_thinking": false});
    }
}

// Отдельный короткий вызов той же выбранной модели формулирует запрос для
// Tavily. Пользовательский текст не отправляется в поиск напрямую: модель
// сначала превращает его в одну точную поисковую фразу, которая затем
// отображается в шторке источников событием chat-search.
async fn formulate_search_query(
    client: &reqwest::Client,
    state: &ChatState,
    req: &ChatRequest,
    url: &str,
    bearer: Option<&str>,
) -> Result<String, String> {
    let original = fallback_search_query(req);
    if original.trim().is_empty() {
        return Err("Нельзя сформулировать поиск для пустого запроса.".into());
    }
    let planner_messages = serde_json::json!([
        {
            "role": "system",
            "content": "Ты формулируешь запросы для веб-поиска. Преобразуй просьбу пользователя в одну короткую, конкретную поисковую фразу с ключевыми сущностями, актуальностью и нужным языком. Не отвечай на вопрос, не добавляй пояснений, кавычек, префикса «Запрос:» или Markdown. Верни только поисковую фразу в одной строке. Пример: «найди актуальные модели Claude» → «список актуальных моделей Claude»"
        },
        { "role": "user", "content": original }
    ]);
    let mut payload = serde_json::json!({
        "model": req.model,
        "messages": planner_messages,
        "stream": false,
        "temperature": 0.7,
        "top_p": 0.8,
        "max_tokens": 64
    });
    if req.provider == "local" {
        payload["top_k"] = serde_json::json!(20);
        payload["min_p"] = serde_json::json!(0.0);
        payload["presence_penalty"] = serde_json::json!(1.0);
        payload["repeat_penalty"] = serde_json::json!(1.0);
        payload["reasoning_format"] = serde_json::json!("deepseek");
        payload["reasoning_effort"] = serde_json::json!("none");
        payload["chat_template_kwargs"] = serde_json::json!({"enable_thinking": false});
    } else {
        payload["reasoning_effort"] = serde_json::json!("low");
    }

    let mut builder = client.post(url).timeout(Duration::from_secs(90));
    if let Some(token) = bearer {
        builder = builder.bearer_auth(token);
    }
    let response = tokio::select! {
        biased;
        _ = wait_for_stop(state) => return Err("Поиск остановлен пользователем.".into()),
        result = builder.json(&payload).send() => result.map_err(|e| format!("Модель не смогла сформулировать поисковый запрос: {e}"))?,
    };
    if !response.status().is_success() {
        let status = response.status();
        let body = response.text().await.unwrap_or_default();
        return Err(format!(
            "Модель не смогла сформулировать поисковый запрос ({status}): {body}"
        ));
    }
    let data: serde_json::Value = response
        .json()
        .await
        .map_err(|e| format!("Некорректный ответ планировщика поиска: {e}"))?;
    let raw = data["choices"][0]["message"]["content"]
        .as_str()
        .unwrap_or("")
        .trim();
    let after_think = raw.rsplit("</think>").next().unwrap_or(raw).trim();
    let mut query = after_think
        .replace("```", "")
        .lines()
        .find(|line| !line.trim().is_empty())
        .unwrap_or("")
        .trim()
        .trim_matches(|ch| matches!(ch, '"' | '\'' | '«' | '»' | '`' | '-' | '–' | '—'))
        .trim()
        .to_string();
    let lower = query.to_lowercase();
    for prefix in ["поисковый запрос:", "запрос:", "search query:", "query:"] {
        if lower.starts_with(prefix) {
            query = query[prefix.len()..].trim().to_string();
            break;
        }
    }
    query = query
        .chars()
        .take(240)
        .collect::<String>()
        .trim()
        .to_string();
    if query.chars().count() < 2 {
        Err(
            "Модель вернула пустой поисковый запрос. Попробуйте переформулировать сообщение."
                .into(),
        )
    } else {
        Ok(query)
    }
}

// Цикл tool-calling: до пяти раундов, где модель может попросить поиск
// и/или последовательные операции с файлами песочницы (list/read/write),
// затем обязательный финальный раунд — обычный стрим текста без
// предложения новых инструментов. Работает одинаково для Groq и для
// локального движка AmIgo — отличаются только url, bearer-токен и набор
// доступных инструментов (tools передаётся вызывающим кодом: sandbox-
// инструменты только для local, web_search только если включён поиск).
fn should_emit_buffered_content(is_final_round: bool, emitted_live: bool, content: &str) -> bool {
    !is_final_round && !emitted_live && !content.is_empty()
}

async fn chat_with_tools_openai(
    app: &tauri::AppHandle,
    state: &ChatState,
    req: &ChatRequest,
    url: &str,
    bearer: Option<String>,
    tools: Vec<serde_json::Value>,
    allow_tool_rounds: bool,
) -> Result<String, String> {
    let client = reqwest::Client::new();
    let stream_media_flow = should_stream_media_flow(req);
    let mut messages: Vec<serde_json::Value> = to_openai_messages(&req.messages);
    // Счётчики живут весь ответ, а не сбрасываются на каждом tool-round.
    const MAX_SEARCHES_PER_REPLY: usize = 2;
    const MAX_SOURCES_PER_REPLY: usize = 5;
    const MAX_FILE_OPS_PER_REPLY: usize = 10;
    const MAX_IMAGE_OPS_PER_REPLY: usize = 4;
    let mut search_count = 0usize;
    let mut file_op_count = 0usize;
    let mut image_op_count = 0usize;
    let mut source_urls = std::collections::HashSet::<String>::new();
    let mut touched_code_files: Vec<String> = Vec::new();
    let mut vision_retry_used = false;
    let mut code_work_started = is_matle_code_task(req);
    if code_work_started {
        // Панель появляется только после начала реальной кодовой задачи.
        // Будущие шаги заранее не показываем — каждый добавится по факту.
        emit_code_step(app, req, "plan", "Планирую изменения", "active");
    }

    // Для файловой задачи заранее выполняем list_files. Это гарантирует, что
    // модель видит реальные имена вложений и не тратит первый tool-round на
    // обязательную разведку, оставляя достаточно шагов для read → write.
    let has_list_files_tool = tools
        .iter()
        .any(|tool| tool["function"]["name"].as_str() == Some("list_files"));
    if has_list_files_tool && (should_prefetch_files(req) || is_matle_code_task(req)) {
        if code_work_started {
            emit_code_step(app, req, "inspect", "Изучаю файлы проекта", "active");
        }
        let call_id = "prefetch_list_files";
        let tool_content = match sandbox_list_files(&req.chat_id) {
            Ok(files) if files.is_empty() => "Песочница этого диалога пуста. Для создания нового файла сразу вызови write_file.".to_string(),
            Ok(files) => format!(
                "Текущие файлы песочницы: {}. Для изменения существующего файла сначала вызови read_file, затем write_file с полным итоговым содержимым.",
                files.join(", ")
            ),
            Err(error) => format!("Не удалось получить список файлов: {error}"),
        };
        messages.push(serde_json::json!({
            "role": "assistant",
            "content": "",
            "tool_calls": [{
                "id": call_id,
                "type": "function",
                "function": { "name": "list_files", "arguments": "{}" }
            }]
        }));
        messages.push(serde_json::json!({
            "role": "tool", "tool_call_id": call_id, "content": tool_content
        }));
        file_op_count = 1;
        if code_work_started {
            emit_code_step(app, req, "inspect", "Изучение файлов проекта", "done");
        }
    }

    // Явную просьбу пользователя искать выполняем детерминированно до первого
    // ответа модели. Маленькая локальная модель больше не может отказаться
    // фразой «нет доступа к интернету», несмотря на подключённый инструмент.
    let has_web_search_tool = tools
        .iter()
        .any(|tool| tool["function"]["name"].as_str() == Some("web_search"));
    if has_web_search_tool && should_prefetch_web_search(req) {
        let first_plan = formulate_search_query(&client, state, req, url, bearer.as_deref()).await;
        let query = match first_plan {
            Ok(query) => query,
            Err(_) if state.stop.load(Ordering::SeqCst) => return Ok(String::new()),
            Err(first_error) => {
                // Редкий пустой/оборванный ответ query-planner не должен ломать
                // весь поиск. Повторяем короткий планировщик один раз.
                tokio::time::sleep(Duration::from_millis(250)).await;
                match formulate_search_query(&client, state, req, url, bearer.as_deref()).await {
                    Ok(query) => query,
                    Err(_) if state.stop.load(Ordering::SeqCst) => return Ok(String::new()),
                    Err(second_error) => {
                        emit_search_error(app);
                        messages.push(serde_json::json!({
                            "role": "assistant",
                            "content": "",
                            "tool_calls": [{
                                "id": "prefetch_web_search_failed",
                                "type": "function",
                                "function": { "name": "web_search", "arguments": { "query": "" } }
                            }]
                        }));
                        messages.push(serde_json::json!({
                            "role": "tool",
                            "tool_call_id": "prefetch_web_search_failed",
                            "content": format!("Поиск Tavily недоступен: {first_error}; {second_error}. Ответь из собственных знаний. Не утверждай, что поиск выполнен; если факт может быть устаревшим, честно обозначь неуверенность.")
                        }));
                        search_count = MAX_SEARCHES_PER_REPLY;
                        String::new()
                    }
                }
            }
        };
        if !query.is_empty() {
            let _ = app.emit(
                "chat-search",
                SearchEvent {
                    query: query.clone(),
                    sources: vec![],
                    done: false,
                },
            );
            let search_result = tokio::select! {
                result = web_search_online(&query) => result,
                _ = wait_for_stop(state) => return Ok(String::new()),
            };
            let (sources, tool_content) = match search_result {
                Ok(mut sources) => {
                    sources.truncate(MAX_SOURCES_PER_REPLY);
                    for source in &sources {
                        source_urls.insert(source.url.clone());
                    }
                    format_search_tool_result(Ok(sources))
                }
                Err(error) => {
                    emit_search_error(app);
                    (
                        vec![],
                        format!("Поиск Tavily недоступен: {error}. Ответь из собственных знаний, не утверждай, что поиск выполнен, и честно обозначь возможную неактуальность."),
                    )
                }
            };
            let _ = app.emit(
                "chat-search",
                SearchEvent {
                    query: query.clone(),
                    sources: sources.clone(),
                    done: true,
                },
            );
            let call_id = "prefetch_web_search";
            messages.push(serde_json::json!({
                "role": "assistant",
                "content": "",
                "tool_calls": [{
                    "id": call_id,
                    "type": "function",
                    "function": { "name": "web_search", "arguments": { "query": query } }
                }]
            }));
            messages.push(serde_json::json!({
                "role": "tool", "tool_call_id": call_id, "content": tool_content
            }));
            search_count = 1;
        }
    }

    // Обычный ответ ограничен пятью tool-round. Для создания кода/файлов
    // hard cap снимается: цикл продолжается, пока модель сама не вернёт финал
    // или пользователь не нажмёт «Стоп».
    const MAX_TOOL_ROUNDS: usize = 5;
    let tool_round_limit = if req.unlimited_output {
        usize::MAX
    } else {
        MAX_TOOL_ROUNDS
    };
    for round in 0..=tool_round_limit {
        if state.stop.load(Ordering::SeqCst) {
            return Ok(String::new());
        }
        let search_is_ready = !source_urls.is_empty();
        let finish_after_search =
            search_is_ready && file_op_count == 0 && !should_offer_followup_tools(req);
        let is_final_round = !allow_tool_rounds
            || finish_after_search
            || (!req.unlimited_output && round == MAX_TOOL_ROUNDS);
        // В auto-режиме первый раунд может сразу дать обычный ответ без tools.
        // Стримим его сразу; если модель действительно не уверена, корректный
        // tool-call приходит до текста и видимого черновика не возникает.
        let stream_direct_first_round = round == 0 && search_count == 0 && file_op_count == 0;
        let think_step_id = format!("think-{round}");
        if code_work_started {
            emit_code_step(
                app,
                req,
                &think_step_id,
                "Думаю над следующим шагом",
                "active",
            );
        }

        let mut payload = serde_json::json!({
            "model": req.model,
            "messages": messages,
            "temperature": req.temperature.unwrap_or(0.7),
            "max_tokens": response_token_limit(req),
            "stream": true
        });
        if req.provider == "local" {
            configure_local_payload(&mut payload, req);
        } else if req.think == Some(true) {
            payload["reasoning_effort"] = serde_json::json!("high");
        } else if req.think == Some(false) {
            payload["reasoning_effort"] = serde_json::json!("low");
        }
        if !is_final_round {
            payload["tools"] = serde_json::json!(tools);
            payload["tool_choice"] = serde_json::json!("auto");
            if req.provider != "local" {
                payload["parallel_tool_calls"] = serde_json::json!(true);
            }
        }

        let mut builder = client.post(url).timeout(Duration::from_secs(300));
        if let Some(b) = &bearer {
            builder = builder.bearer_auth(b);
        }
        let mut response = tokio::select! {
            result = builder.json(&payload).send() => result.map_err(|_| {
                if req.provider == "local" {
                    "connection_error: Локальный движок AmIgo не отвечает. Попробуйте выбрать модель ещё раз.".to_string()
                } else {
                    "connection_error: Не удалось связаться с Groq. Проверьте интернет-соединение.".to_string()
                }
            })?,
            _ = wait_for_stop(state) => return Ok(String::new()),
        };

        let request_has_images = req
            .messages
            .iter()
            .any(|message| !message.images.is_empty());
        if req.provider == "local" && !response.status().is_success() && !vision_retry_used {
            // Первый холодный POST иногда приходит раньше полной готовности
            // slot/template, даже после успешного /health. Для любого локального
            // запроса один раз пересоздаём сервер и повторяем POST без участия пользователя.
            vision_retry_used = true;
            let _ = response.text().await;
            let def = find_model_def(&req.model).ok_or("Неизвестная локальная модель")?;
            start_local_server(
                app,
                state,
                &def,
                &req.model,
                request_has_images,
                false,
                ServerProfile::CompatibleGpu,
            )?;
            ensure_server_mode(app, state, &req.model, request_has_images).await?;
            response = tokio::select! {
                result = client.post(url).timeout(Duration::from_secs(300)).json(&payload).send() => result.map_err(|error| format!("connection_error: Повторный локальный запрос не удался: {error}"))?,
                _ = wait_for_stop(state) => return Ok(String::new()),
            };
        }

        if !response.status().is_success() {
            let status = response.status();
            let text = response.text().await.unwrap_or_default();
            let hint = serde_json::from_str::<serde_json::Value>(&text)
                .ok()
                .and_then(|v| v["error"]["message"].as_str().map(|s| s.to_string()))
                .unwrap_or(text);
            return Err(format!("Ошибка сервера ({status}): {hint}"));
        }

        // Промежуточный раунд инструмента не показываем пользователю: модель
        // нередко пишет черновой ответ до tool_call, а затем повторяет его после
        // результата. Финальный раунд стримим; обычный ответ без tool_call
        // выдаём целиком после того, как убедились, что он действительно финальный.
        let emit_live_round = is_final_round
            || stream_direct_first_round
            || stream_media_flow
            || req.unlimited_output;
        let streamed = collect_openai_stream(
            app,
            state,
            response,
            req.think != Some(false),
            emit_live_round,
            if request_has_images { 24 } else { STREAM_REPEAT_GUARD_CHARS },
            generation_idle_timeout(req),
        )
        .await?;
        if code_work_started {
            emit_code_step(
                app,
                req,
                &think_step_id,
                "Думаю над следующим шагом",
                "done",
            );
        }
        let tool_calls = streamed.tool_calls;
        let round_has_code_ops = tool_calls.iter().any(|call| {
            matches!(
                call["function"]["name"].as_str(),
                Some(
                    "write_file" | "copy_code_to_file" | "check_syntax" | "validate_project"
                )
            )
        });
        if !code_work_started && req.model == "matle-2.5" && round_has_code_ops {
            code_work_started = true;
            emit_code_step(app, req, "plan", "План задачи", "done");
        } else if code_work_started {
            emit_code_step(app, req, "plan", "План задачи", "done");
        }
        if is_final_round || tool_calls.is_empty() {
            if req.model == "matle-2.5" && !touched_code_files.is_empty() {
                emit_code_step(
                    app,
                    req,
                    "validate",
                    "Проверяю синтаксис изменённых файлов",
                    "active",
                );
                let mut validation_errors = Vec::new();
                for path in &touched_code_files {
                    if let Err(error) = sandbox_check_syntax(&req.chat_id, path) {
                        validation_errors.push(error);
                    }
                }
                if !validation_errors.is_empty() && !is_final_round {
                    emit_code_step(app, req, "validate", "Исправляю ошибки проверки", "active");
                    let call_id = format!("automatic_validation_{round}");
                    messages.push(serde_json::json!({
                        "role": "assistant",
                        "content": streamed.content,
                        "tool_calls": [{
                            "id": call_id,
                            "type": "function",
                            "function": { "name": "check_syntax", "arguments": "{}" }
                        }]
                    }));
                    messages.push(serde_json::json!({
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": format!("Автоматическая проверка нашла ошибки:\n{}\nИсправь соответствующие файлы через read_file/write_file и проверь снова.", validation_errors.join("\n\n"))
                    }));
                    continue;
                }
                emit_code_step(
                    app,
                    req,
                    "validate",
                    "Проверка результата",
                    if validation_errors.is_empty() {
                        "done"
                    } else {
                        "done"
                    },
                );
            }
            // Если collect_openai_stream уже печатал этот раунд по SSE,
            // повторно отправлять полный буфер нельзя — именно это раньше
            // удваивало короткие ответы Matle 2.5 целиком.
            if should_emit_buffered_content(is_final_round, emit_live_round, &streamed.content) {
                let _ = app.emit(
                    "chat-chunk",
                    ChatChunk {
                        content: streamed.content.clone(),
                    },
                );
            }
            if code_work_started {
                emit_code_step(app, req, "final", "Подготавливаю итог", "active");
                emit_code_step(app, req, "final", "Подготавливаю итог", "done");
            }
            return Ok(streamed.content);
        }

        messages.push(serde_json::json!({
          "role": "assistant",
          "content": streamed.content,
          "tool_calls": tool_calls.clone(),
        }));

        // Жёсткие потолки на РЕАЛЬНЫЕ вызовы за один раунд ответа — отдельно
        // для поиска (защита дневной квоты Tavily) и отдельно для файловых
        // операций (защита от того, что модель начнёт бесконечно перечитывать/
        // переписывать файлы в одном ответе). Сверх потолка — не выполняем
        // вызов, а прямо говорим об этом модели тем же протоколом (ответ
        // инструмента), а не молча игнорируем: так модель не "зависает" в
        // ожидании ответа, а видит явную причину и отвечает текстом.
        // "Работа с файлами" — на весь раунд, если в нём есть хоть одна
        // файловая операция (включая поиск/скачивание картинок — они тоже
        // ложатся в песочницу), а не на каждый отдельный вызов: иначе статус
        // мигал бы включаясь/выключаясь между вызовами внутри одного ответа.
        let has_file_ops = tool_calls.iter().any(|call| {
            matches!(
                call["function"]["name"].as_str(),
                Some(
                    "list_files"
                        | "read_file"
                        | "write_file"
                        | "delete_file"
                        | "download_file"
                        | "copy_code_to_file"
                        | "check_syntax"
                        | "validate_project"
                )
            )
        });
        let image_count = tool_calls
            .iter()
            .filter(|call| matches!(call["function"]["name"].as_str(), Some("download_image")))
            .count()
            .max(1);
        let has_image_ops = tool_calls
            .iter()
            .any(|call| matches!(call["function"]["name"].as_str(), Some("download_image")));
        if has_file_ops && req.model != "matle-2.5" {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "files".into(),
                    active: true,
                },
            );
        }
        if has_image_ops {
            let _ = app.emit(
                "chat-status",
                serde_json::json!({ "kind": "images", "active": true, "count": image_count }),
            );
        }

        // Карточки с именем файла/картинки показываем только ПОСЛЕ того, как
        // работа с файлами в этом раунде полностью завершится (см. ниже) —
        // пока горит статус "Работа с файлами", что именно затронуто, не
        // раскрываем. kind во втором элементе — "file" или "image" (влияет на
        // то, покажет ли фронтенд миниатюру или обычную карточку с именем).
        let mut pending_file_events: Vec<(String, bool)> = Vec::new(); // (path, removed) — обычные файлы
        let mut pending_image_events: Vec<String> = Vec::new(); // имена файлов скачанных картинок

        for (call_index, call) in tool_calls.iter().enumerate() {
            let name = call["function"]["name"].as_str().unwrap_or("");
            let id = call["id"].as_str().unwrap_or("").to_string();
            let step_args = tool_call_args(call);
            let step_label = code_tool_step_label(name, &step_args);
            let step_id = if matches!(name, "check_syntax" | "validate_project") {
                "validate".to_string()
            } else {
                format!("tool-{round}-{call_index}")
            };
            if code_work_started {
                emit_code_step(app, req, &step_id, &step_label, "active");
            }

            let tool_content: String = match name {
                "web_search" => {
                    if source_urls.len() >= MAX_SOURCES_PER_REPLY {
                        "Уже получено 5 источников — новый поиск не выполняется. Ответь на основе имеющихся данных.".to_string()
                    } else {
                        search_count += 1;
                        if search_count > MAX_SEARCHES_PER_REPLY {
                            "Достигнут лимит поисковых обращений за один ответ. Ответь на основе уже найденного.".to_string()
                        } else {
                            let args = tool_call_args(call);
                            let query = args["query"]
                                .as_str()
                                .map(str::trim)
                                .filter(|q| q.len() >= 2)
                                .unwrap_or("")
                                .to_string();
                            if query.is_empty() {
                                "Ошибка: сформулируй непустой query и повтори web_search."
                                    .to_string()
                            } else {
                                let _ = app.emit(
                                    "chat-search",
                                    SearchEvent {
                                        query: query.clone(),
                                        sources: vec![],
                                        done: false,
                                    },
                                );
                                let search_result = tokio::select! {
                                    result = web_search_online(&query) => result,
                                    _ = wait_for_stop(state) => return Ok(String::new()),
                                };
                                match search_result {
                                    Err(error) => {
                                        emit_search_error(app);
                                        let _ = app.emit(
                                            "chat-search",
                                            SearchEvent {
                                                query,
                                                sources: vec![],
                                                done: true,
                                            },
                                        );
                                        format!("Поиск не удался: {error}")
                                    }
                                    Ok(found) => {
                                        let remaining = MAX_SOURCES_PER_REPLY - source_urls.len();
                                        let sources: Vec<_> = found
                                            .into_iter()
                                            .filter(|source| source_urls.insert(source.url.clone()))
                                            .take(remaining)
                                            .collect();
                                        let tool_text =
                                            format_search_tool_result(Ok(sources.clone())).1;
                                        let _ = app.emit(
                                            "chat-search",
                                            SearchEvent {
                                                query,
                                                sources,
                                                done: true,
                                            },
                                        );
                                        tool_text
                                    }
                                }
                            }
                        }
                    }
                }
                "read_webpage" => {
                    search_count += 1;
                    if search_count > MAX_SEARCHES_PER_REPLY {
                        "Достигнут лимит обращений к интернету за один ответ. Ответь на основе уже полученных данных.".to_string()
                    } else {
                        let args = tool_call_args(call);
                        let page_url = args["url"].as_str().unwrap_or("").trim().to_string();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: page_url.clone(),
                                sources: vec![],
                                done: false,
                            },
                        );
                        let result = if page_url.starts_with("http://")
                            || page_url.starts_with("https://")
                        {
                            tokio::select! {
                                result = read_webpage_online(&page_url) => result,
                                _ = wait_for_stop(state) => return Ok(String::new()),
                            }
                        } else {
                            Err("Некорректный URL страницы.".into())
                        };
                        let sources = if let Ok(content) = result.as_ref() {
                            let already_known = source_urls.contains(&page_url);
                            if already_known || source_urls.len() < MAX_SOURCES_PER_REPLY {
                                source_urls.insert(page_url.clone());
                                vec![SearchSource {
                                    title: page_url.clone(),
                                    url: page_url.clone(),
                                    content: content.chars().take(500).collect(),
                                }]
                            } else {
                                vec![]
                            }
                        } else {
                            vec![]
                        };
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: page_url.clone(),
                                sources,
                                done: true,
                            },
                        );
                        match result {
                            Ok(content) => format!("Содержимое страницы {page_url}:\n{content}"),
                            Err(e) => {
                                emit_search_error(app);
                                format!("Не удалось прочитать страницу: {e}. Продолжи ответ без содержимого страницы и честно обозначь ограничение.")
                            }
                        }
                    }
                }
                "find_images" => {
                    search_count += 1;
                    if search_count > MAX_SEARCHES_PER_REPLY {
                        "Достигнут лимит одновременных поисков за один ответ. Ответь на основе уже найденного, не запрашивай больше поисков в этом сообщении.".to_string()
                    } else {
                        let args = tool_call_args(call);
                        let query = args["query"]
                            .as_str()
                            .map(str::trim)
                            .filter(|q| q.len() >= 2)
                            .map(str::to_string)
                            .unwrap_or_else(|| fallback_search_query(req));
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: query.clone(),
                                sources: vec![],
                                done: false,
                            },
                        );
                        let result = tokio::select! {
                            result = tavily_image_search(&query) => result,
                            _ = wait_for_stop(state) => return Ok(String::new()),
                        };
                        let sources = result
                            .as_ref()
                            .ok()
                            .map(|urls| {
                                urls.iter()
                                    .enumerate()
                                    .map(|(i, url)| SearchSource {
                                        title: format!("Изображение {}", i + 1),
                                        url: url.clone(),
                                        content: String::new(),
                                    })
                                    .collect()
                            })
                            .unwrap_or_default();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: query.clone(),
                                sources,
                                done: true,
                            },
                        );
                        match result {
                            Err(e) => {
                                emit_search_error(app);
                                format!(
                                    "Поиск изображений не удался: {e}. Продолжи без изображений."
                                )
                            }
                            Ok(urls) if urls.is_empty() => {
                                "Картинок по этому запросу не нашлось.".to_string()
                            }
                            Ok(urls) => urls
                                .iter()
                                .enumerate()
                                .map(|(i, u)| format!("{}. {u}", i + 1))
                                .collect::<Vec<_>>()
                                .join("\n"),
                        }
                    }
                }
                "list_files" | "read_file" | "write_file" | "delete_file" | "download_image"
                | "download_file" | "copy_code_to_file" | "check_syntax" | "validate_project" => {
                    if name == "download_image" {
                        image_op_count += 1;
                    } else {
                        file_op_count += 1;
                    }
                    if !req.unlimited_output && file_op_count > MAX_FILE_OPS_PER_REPLY {
                        "Достигнут лимит операций с файлами за один обычный ответ. Для большой задачи попроси создать/доработать файл явно.".to_string()
                    } else if image_op_count > MAX_IMAGE_OPS_PER_REPLY {
                        "Достигнут лимит скачиваний картинок за один ответ. Используй уже скачанные, не запрашивай больше в этом сообщении.".to_string()
                    } else {
                        let args = tool_call_args(call);
                        match name {
                            "list_files" => match sandbox_list_files(&req.chat_id) {
                                Ok(v) if v.is_empty() => {
                                    "Песочница этого диалога пока пуста.".to_string()
                                }
                                Ok(v) => format!("Файлы в песочнице: {}", v.join(", ")),
                                Err(e) => format!("Ошибка: {e}"),
                            },
                            "read_file" => {
                                let path = args["path"].as_str().unwrap_or("").to_string();
                                match sandbox_read_file(&req.chat_id, &path) {
                                    Ok(content) => content,
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            "write_file" => {
                                let path = args["path"].as_str().unwrap_or("").to_string();
                                let content = args["content"].as_str().unwrap_or("").to_string();
                                match sandbox_write_file(&req.chat_id, &path, &content) {
                                    Ok(()) => {
                                        pending_file_events.push((path.clone(), false));
                                        if !touched_code_files.contains(&path) {
                                            touched_code_files.push(path.clone());
                                        }
                                        format!("Файл «{path}» сохранён в песочнице этого диалога.")
                                    }
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            "delete_file" => {
                                let path = args["path"].as_str().unwrap_or("").to_string();
                                match sandbox_delete_file(&req.chat_id, &path) {
                                    Ok(()) => {
                                        pending_file_events.push((path.clone(), true));
                                        format!("Файл «{path}» удалён из песочницы.")
                                    }
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            "copy_code_to_file" => {
                                let block_id = args["block_id"].as_str().unwrap_or("").trim();
                                let path = args["path"].as_str().unwrap_or("").trim().to_string();
                                match req.code_blocks.iter().find(|block| block.id == block_id) {
                                    Some(block) => match sandbox_write_file(&req.chat_id, &path, &block.content) {
                                        Ok(()) => {
                                            pending_file_events.push((path.clone(), false));
                                            if !touched_code_files.contains(&path) { touched_code_files.push(path.clone()); }
                                            format!("Готовый блок «{}» скопирован в «{path}» без повторной генерации.", block.label)
                                        }
                                        Err(error) => format!("Ошибка: {error}"),
                                    },
                                    None => "Ошибка: block_id не найден. Используй точный id из списка доступных блоков кода.".into(),
                                }
                            }
                            "check_syntax" => {
                                let path = args["path"].as_str().unwrap_or("").to_string();
                                match sandbox_check_syntax(&req.chat_id, &path) {
                                    Ok(message) => message,
                                    Err(error) => format!("Ошибка проверки: {error}"),
                                }
                            }
                            "validate_project" => {
                                let action = args["action"].as_str().unwrap_or("auto");
                                match sandbox_validate_project(&req.chat_id, action) {
                                    Ok(message) => message,
                                    Err(error) => format!("Ошибка проверки: {error}"),
                                }
                            }
                            "download_image" => {
                                let url = args["url"].as_str().unwrap_or("").to_string();
                                let img_name = args["name"].as_str().unwrap_or("image").to_string();
                                let download_result = tokio::select! {
                                    result = sandbox_download_image(&req.chat_id, &url, &img_name) => result,
                                    _ = wait_for_stop(state) => return Ok(String::new()),
                                };
                                match download_result {
                                    Ok(saved_name) => {
                                        pending_image_events.push(saved_name.clone());
                                        format!(
                                            "Изображение «{saved_name}» успешно сохранено. Интерфейс AmIgo автоматически покажет его пользователю в галерее текущего ответа: одно выбранное изображение крупно, остальные вариантами ниже. В финальном тексте не говори, что не можешь показать картинку, не отправляй пользователя искать её в песочнице и не дублируй изображение Markdown-ссылкой, URL или base64."
                                        )
                                    }
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            "download_file" => {
                                let url = args["url"].as_str().unwrap_or("").to_string();
                                let filename =
                                    args["name"].as_str().unwrap_or("download.bin").to_string();
                                let download_result = tokio::select! {
                                    result = sandbox_download_file(&req.chat_id, &url, &filename) => result,
                                    _ = wait_for_stop(state) => return Ok(String::new()),
                                };
                                match download_result {
                                    Ok(saved_name) => {
                                        pending_file_events.push((saved_name.clone(), false));
                                        format!("Файл скачан в песочницу как «{saved_name}».")
                                    }
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            _ => unreachable!(),
                        }
                    }
                }
                _ => "Неизвестный инструмент.".to_string(),
            };

            if code_work_started {
                emit_code_step(app, req, &step_id, &step_label, "done");
            }
            messages.push(
                serde_json::json!({ "role": "tool", "tool_call_id": id, "content": tool_content }),
            );
        }

        // Статус "Работа с файлами" выключаем, и только теперь — после него —
        // показываем карточки затронутых файлов и миниатюры картинок, если они были.
        if has_file_ops && req.model != "matle-2.5" {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "files".into(),
                    active: false,
                },
            );
        }
        if has_image_ops {
            let _ = app.emit(
                "chat-status",
                serde_json::json!({ "kind": "images", "active": false, "count": pending_image_events.len(), "failed": pending_image_events.is_empty() }),
            );
        }
        for (path, removed) in pending_file_events {
            let _ = app.emit("sandbox-file", serde_json::json!({ "chat_id": req.chat_id, "path": path, "removed": removed, "kind": "file" }));
        }
        for filename in pending_image_events {
            let _ = app.emit("sandbox-file", serde_json::json!({ "chat_id": req.chat_id, "path": filename, "removed": false, "kind": "image" }));
        }
    }

    Ok(String::new())
}

// Потоковая генерация: печатает ответ по мере поступления токенов.
// Каждый кусочек текста отправляется во фронтенд событием "chat-chunk".
// Возвращает полный текст ответа (на случай если фронтенд что-то пропустил).
// И локальный движок AmIgo, и Groq говорят на одном OpenAI-протоколе —
// отличаются только адресом и наличием bearer-токена.
async fn chat_stream_inner(
    app: &tauri::AppHandle,
    state: &ChatState,
    req: ChatRequest,
) -> Result<String, String> {
    let search_enabled = req.web_search.unwrap_or(true);
    let explicit_search = search_enabled && should_prefetch_web_search(&req);
    let tavily_available = search_enabled && keychain_get_tavily().is_ok();
    if explicit_search && !tavily_available {
        emit_search_error(app);
        // Продолжаем без web tools: системная инструкция требует честно
        // ответить из имеющихся знаний и отметить неуверенность при необходимости.
    }
    let file_tools_needed = req.provider == "local"
        && !req.chat_id.is_empty()
        && (should_prefetch_files(&req) || is_matle_code_task(&req));
    let followup_tools_needed =
        file_tools_needed || (explicit_search && should_offer_followup_tools(&req));
    // При неявном вопросе web_search остаётся доступен в auto-режиме: модель
    // может вызвать его сама, но только если действительно не уверена или
    // сведения зависят от актуального состояния мира.
    let allow_tool_rounds = file_tools_needed
        || (explicit_search && followup_tools_needed)
        || (tavily_available && !explicit_search);
    // Песочница файлов — только в локальном режиме ("без интернета" по
    // условию задачи) и только когда запрос реально привязан к диалогу
    // (chat_id непустой) — иначе служебные запросы вроде фонового сжатия
    // истории в резюме тоже получили бы доступ к файловым инструментам,
    // а им это не нужно и только добавило бы лишних раундов задержки.
    let sandbox_enabled = req.provider == "local" && !req.chat_id.is_empty();

    // Mentis 3 и Nage 1.5 умеют "видеть", когда сервер запущен с их --mmproj;
    // по умолчанию они работают в обычном текстовом режиме
    // для фото сервер запускается с mmproj (см.
    // model_defs). Проверяем нужен ли режим зрения ДЛЯ ЭТОГО КОНКРЕТНОГО
    // сообщения ещё до выбора пути (обычный / с инструментами) — если сервер
    // сейчас не в том режиме, переключаем его и ждём готовности прямо здесь.
    let is_vision_model =
        req.provider == "local" && matches!(req.model.as_str(), "mentis-3" | "nage-1.5");
    let has_images = is_vision_model && req.messages.iter().any(|m| !m.images.is_empty());
    if req.provider == "local" {
        // Один режим на весь запрос. Не убиваем и не перезапускаем llama-server
        // между анализом фото и генерацией ответа: такой двухэтапный сценарий
        // мог оборвать соединение. Фото + ответ целиком идут через mmproj;
        // draft включится только перед следующим отдельным текстовым запросом.
        if has_images {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "vision".into(),
                    active: true,
                },
            );
        }
        ensure_server_mode(app, state, &req.model, has_images).await?;
    }

    let (url, bearer): (String, Option<String>) = if req.provider == "local" {
        (
            format!("http://127.0.0.1:{LOCAL_PORT}/v1/chat/completions"),
            None,
        )
    } else {
        (
            "https://api.groq.com/openai/v1/chat/completions".to_string(),
            Some(keychain_get()?),
        )
    };

    let mut tools: Vec<serde_json::Value> = Vec::new();
    if sandbox_enabled && file_tools_needed {
        tools.extend(sandbox_tools_defs());
    }
    if tavily_available {
        tools.push(web_search_tool_def());
        tools.push(read_webpage_tool_def());
    }
    if sandbox_enabled && explicit_search && followup_tools_needed {
        tools.extend(image_tools_defs());
    }

    if !tools.is_empty() {
        let result =
            chat_with_tools_openai(app, state, &req, &url, bearer, tools, allow_tool_rounds).await;
        if has_images {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "vision".into(),
                    active: false,
                },
            );
        }
        return result;
    }

    let temperature = req.temperature.unwrap_or(0.6);
    let oai_messages = to_openai_messages(&req.messages);
    let mut payload = serde_json::json!({
        "model": req.model,
        "messages": oai_messages,
        "stream": true,
        "temperature": temperature,
        "max_tokens": response_token_limit(&req)
    });
    if req.provider == "local" {
        configure_local_payload(&mut payload, &req);
    } else if req.think == Some(true) {
        payload["reasoning_effort"] = serde_json::json!("high");
    } else if req.think == Some(false) {
        payload["reasoning_effort"] = serde_json::json!("low");
    }

    let client = reqwest::Client::new();
    let mut builder = client.post(&url).timeout(Duration::from_secs(300));
    if let Some(b) = &bearer {
        builder = builder.bearer_auth(b);
    }
    let mut response = tokio::select! {
        result = builder.json(&payload).send() => result.map_err(|_| {
            if req.provider == "local" {
                "connection_error: Локальный движок AmIgo не отвечает. Попробуйте выбрать модель ещё раз.".to_string()
            } else {
                "connection_error: Не удалось связаться с Groq. Проверьте интернет-соединение.".to_string()
            }
        })?,
        _ = wait_for_stop(state) => return Ok(String::new()),
    };

    // Первый холодный POST может один раз получить 4xx/5xx до полной
    // готовности slot/template. Автоматически пересоздаём нужный профиль и
    // повторяем любой локальный запрос, не заставляя пользователя писать снова.
    if req.provider == "local" && !response.status().is_success() {
        let _ = response.text().await;
        let def = find_model_def(&req.model).ok_or("Неизвестная локальная модель")?;
        start_local_server(
            app,
            state,
            &def,
            &req.model,
            has_images,
            false,
            ServerProfile::CompatibleGpu,
        )?;
        ensure_server_mode(app, state, &req.model, has_images).await?;
        let retry_client = reqwest::Client::new();
        response = tokio::select! {
            result = retry_client.post(&url).timeout(Duration::from_secs(300)).json(&payload).send() => result.map_err(|e| format!("connection_error: Повторный локальный запрос не удался: {e}"))?,
            _ = wait_for_stop(state) => return Ok(String::new()),
        };
    }

    if !response.status().is_success() {
        if has_images {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "vision".into(),
                    active: false,
                },
            );
        }
        let status = response.status();
        let text = response.text().await.unwrap_or_default();
        let hint = serde_json::from_str::<serde_json::Value>(&text)
            .ok()
            .and_then(|v| v["error"]["message"].as_str().map(|s| s.to_string()))
            .unwrap_or(text);
        return Err(format!("Ошибка сервера ({status}): {hint}"));
    }

    let mut stream = response.bytes_stream();
    let mut buffer: Vec<u8> = Vec::new();
    let mut full = String::new();
    let mut emitted = 0usize;
    let mut thinking_active = false;
    let mut thinking_started: Option<tokio::time::Instant> = None;
    let idle_timeout = generation_idle_timeout(&req);
    let mut last_progress = tokio::time::Instant::now();

    'outer: loop {
        let deadline = last_progress + idle_timeout;
        let item = tokio::select! {
            biased;
            _ = wait_for_stop(state) => None,
            _ = tokio::time::sleep_until(deadline) => {
                return Err(format!("generation_stalled: Модель не выводит данные более {} секунд.", idle_timeout.as_secs()));
            },
            item = stream.next() => item,
        };
        let Some(item) = item else { break };
        let bytes = item.map_err(|e| e.to_string())?;
        buffer.extend_from_slice(&bytes);

        while let Some(pos) = buffer.iter().position(|b| *b == b'\n') {
            let line = String::from_utf8_lossy(&buffer[..pos]).trim().to_string();
            buffer.drain(..=pos);
            if line.is_empty() {
                continue;
            }

            let json_str: &str = if let Some(stripped) = line.strip_prefix("data:") {
                let stripped = stripped.trim();
                if stripped == "[DONE]" {
                    break 'outer;
                }
                stripped
            } else {
                &line
            };

            if let Ok(data) = serde_json::from_str::<serde_json::Value>(json_str) {
                if let Some(reason) = data["choices"][0]["finish_reason"].as_str() {
                    let _ = app.emit("chat-finish", serde_json::json!({ "reason": reason }));
                }
                let thinking = data["choices"][0]["delta"]["reasoning"]
                    .as_str()
                    .or_else(|| data["choices"][0]["delta"]["reasoning_content"].as_str())
                    .unwrap_or("");
                let delta = data["choices"][0]["delta"]["content"]
                    .as_str()
                    .unwrap_or("");
                if !thinking.is_empty() || !delta.is_empty() {
                    last_progress = tokio::time::Instant::now();
                }
                if !thinking.is_empty() {
                    let started = thinking_started.get_or_insert_with(tokio::time::Instant::now);
                    if started.elapsed() > Duration::from_secs(45) {
                        return Err("generation_stalled: Режим рассуждения превысил безопасное время; ответ будет перезапущен без зависания.".into());
                    }
                }
                if !delta.is_empty() {
                    thinking_started = None;
                }
                if req.think != Some(false) && !thinking.is_empty() && !thinking_active {
                    thinking_active = true;
                    let _ = app.emit(
                        "chat-status",
                        StatusEvent {
                            kind: "thinking".into(),
                            active: true,
                        },
                    );
                }
                if !delta.is_empty() {
                    if thinking_active {
                        thinking_active = false;
                        let _ = app.emit(
                            "chat-status",
                            StatusEvent {
                                kind: "thinking".into(),
                                active: false,
                            },
                        );
                    }
                    if !append_checked(&mut full, delta, emitted) {
                        break 'outer;
                    }
                    let safe = prefix_len_without_last_chars(&full, if has_images { 24 } else { STREAM_REPEAT_GUARD_CHARS });
                    emit_content_until(app, &full, &mut emitted, safe);
                }
            }

            if state.stop.load(Ordering::SeqCst) {
                break 'outer;
            }
        }
    }
    let final_len = full.len();
    emit_content_until(app, &full, &mut emitted, final_len);
    if thinking_active {
        let _ = app.emit(
            "chat-status",
            StatusEvent {
                kind: "thinking".into(),
                active: false,
            },
        );
    }
    if has_images {
        let _ = app.emit(
            "chat-status",
            StatusEvent {
                kind: "vision".into(),
                active: false,
            },
        );
    }
    Ok(full)
}

fn parse_speculative_metrics(text: &str) -> (f64, f64) {
    fn metric_value(line: &str, name: &str) -> Option<f64> {
        if line.starts_with('#') {
            return None;
        }
        let (metric, value) = line.split_once(char::is_whitespace)?;
        // Поддерживаем и текущий формат, и Prometheus labels после имени.
        if metric != name && !metric.starts_with(&format!("{name}{{")) {
            return None;
        }
        value.trim().split_whitespace().next()?.parse().ok()
    }

    fn collect_metric(text: &str, name: &str) -> f64 {
        let mut aggregate = None;
        let mut labeled_sum = 0.0;
        for line in text.lines() {
            if let Some(value) = metric_value(line, name) {
                let metric = line.split_whitespace().next().unwrap_or_default();
                if metric == name {
                    aggregate = Some(value);
                } else {
                    labeled_sum += value;
                }
            }
        }
        // Не суммируем aggregate и его же per-slot представление дважды.
        aggregate.unwrap_or(labeled_sum)
    }

    (
        collect_metric(text, "llamacpp:spec_decode_num_spec_tokens_total"),
        collect_metric(text, "llamacpp:spec_decode_num_accepted_tokens_total"),
    )
}

async fn persist_local_metrics(state: &ChatState) {
    let client = reqwest::Client::new();
    if let Ok(resp) = client
        .get(format!("http://127.0.0.1:{LOCAL_PORT}/metrics"))
        .timeout(Duration::from_secs(2))
        .send()
        .await
    {
        if resp.status().is_success() {
            if let Ok(text) = resp.text().await {
                let (drafted, accepted) = parse_speculative_metrics(&text);
                if state.server_spec_requested.load(Ordering::SeqCst) {
                    state
                        .server_speculative
                        .store(drafted > 0.0, Ordering::SeqCst);
                }
                let ratio = if drafted > 0.0 {
                    accepted * 100.0 / drafted
                } else {
                    0.0
                };
                let summary = format!(
                    "speculative={}\nspec_tokens={}\naccepted_tokens={}\nacceptance_percent={:.2}\n",
                    drafted > 0.0, drafted as u64, accepted as u64, ratio
                );
                let _ = std::fs::write(models_dir().join("spec-decoding-result.txt"), summary);
                let _ = std::fs::write(models_dir().join("spec-decoding-metrics.txt"), text);
            }
        }
    }
}

#[tauri::command]
async fn chat_stream(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    req: ChatRequest,
) -> Result<String, String> {
    state.busy.store(true, Ordering::SeqCst);
    let is_local = req.provider == "local";
    // Не даём macOS App Nap приостановить Rust/WebView после переключения в
    // другое приложение. -w гарантирует завершение caffeinate при аварийном
    // выходе AmIgo, а ниже процесс останавливается сразу после ответа.
    let app_pid = std::process::id().to_string();
    let mut activity = Command::new("caffeinate")
        .args(["-i", "-s", "-w", &app_pid])
        .spawn()
        .ok();

    let result = chat_stream_inner(&app, &state, req).await;
    let restart_stalled_local = is_local
        && result
            .as_ref()
            .err()
            .map(|error| {
                error.contains("generation_stalled")
                    || error.contains("Локальный движок AmIgo не отвечает")
            })
            .unwrap_or(false);
    if restart_stalled_local {
        // Зависший slot может не освободиться после разрыва HTTP-потока.
        // Полный перезапуск гарантирует чистый повтор со стороны фронтенда.
        kill_local_server(&state);
    } else if is_local && !state.stop.load(Ordering::SeqCst) {
        tokio::select! {
            _ = persist_local_metrics(&state) => {},
            _ = wait_for_stop(&state) => {},
        }
    }

    if let Some(child) = activity.as_mut() {
        let _ = child.kill();
        let _ = child.wait();
    }
    state.busy.store(false, Ordering::SeqCst);
    if !state.generation_active.load(Ordering::SeqCst)
        && state.pending_unload.swap(false, Ordering::SeqCst)
    {
        kill_local_server(&state);
    }
    // Стоп относится только к завершившемуся пользовательскому запросу.
    state.stop.store(false, Ordering::SeqCst);
    result
}

// Служебное завершение без событий chat-chunk/status. Используется для
// фонового резюме длинного диалога: его токены не должны попасть в новый
// пользовательский ответ, если пользователь уже открыл другой чат.
#[tauri::command]
async fn chat_complete_silent(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    req: ChatRequest,
) -> Result<String, String> {
    // Фоновая сводка/заголовок не должны сбрасывать флаг, выставленный кнопкой
    // «Стоп» у пользовательского ответа.
    if state.stop.load(Ordering::SeqCst) {
        return Ok(String::new());
    }
    if req.provider == "local" {
        ensure_server_mode(&app, &state, &req.model, false).await?;
    }
    let (url, bearer): (String, Option<String>) = if req.provider == "local" {
        (
            format!("http://127.0.0.1:{LOCAL_PORT}/v1/chat/completions"),
            None,
        )
    } else {
        (
            "https://api.groq.com/openai/v1/chat/completions".to_string(),
            Some(keychain_get()?),
        )
    };
    let mut payload = serde_json::json!({
        "model": req.model,
        "messages": to_openai_messages(&req.messages),
        "stream": false,
        "temperature": req.temperature.unwrap_or(0.3),
        "max_tokens": req.max_tokens.unwrap_or(1_024).clamp(256, 2_048)
    });
    if req.provider == "local" {
        configure_local_payload(&mut payload, &req);
        // Заголовку/сводке длинное рассуждение не нужно.
        payload["max_tokens"] =
            serde_json::json!(req.max_tokens.unwrap_or(1_024).clamp(256, 2_048));
        payload["reasoning_effort"] = serde_json::json!("none");
        payload["chat_template_kwargs"] = serde_json::json!({"enable_thinking": false});
    }
    let client = reqwest::Client::new();
    let mut builder = client.post(url).timeout(Duration::from_secs(300));
    if let Some(token) = bearer {
        builder = builder.bearer_auth(token);
    }
    let response = tokio::select! {
        result = builder.json(&payload).send() => result.map_err(|e| e.to_string())?,
        _ = wait_for_stop(&state) => return Ok(String::new()),
    };
    if !response.status().is_success() {
        return Err(format!(
            "Служебный запрос завершился с кодом {}",
            response.status()
        ));
    }
    let data: serde_json::Value = response.json().await.map_err(|e| e.to_string())?;
    Ok(data["choices"][0]["message"]["content"]
        .as_str()
        .unwrap_or("")
        .to_string())
}

// Разбирает word/document.xml без внешних XML-библиотек (в духе clean_rtf
// выше): следит только за тегами <w:t>/<w:tab/>/<w:br/>/<w:cr/>/</w:p>/</w:tr>,
// которые нужны, чтобы восстановить читаемый текст — с настоящими абзацами
// и табуляцией, а не всё содержимое одной строкой через пробел, как раньше.
fn extract_docx_text(xml: &str) -> String {
    let mut out = String::new();
    let mut in_text = false;
    let mut rest = xml;
    while let Some(lt) = rest.find('<') {
        if in_text && lt > 0 {
            out.push_str(&rest[..lt]);
        }
        rest = &rest[lt + 1..];
        let gt = match rest.find('>') {
            Some(g) => g,
            None => break,
        };
        let tag = &rest[..gt];
        rest = &rest[gt + 1..];

        let closing = tag.starts_with('/');
        let body = tag.trim_start_matches('/').trim_end_matches('/').trim();
        let name = body.split(|c: char| c.is_whitespace()).next().unwrap_or("");

        match name {
            "w:t" => in_text = !closing,
            "w:tab" => out.push('\t'),
            "w:br" | "w:cr" => out.push('\n'),
            "w:p" if closing => out.push('\n'),
            "w:tr" if closing => out.push('\n'),
            _ => {}
        }
    }
    if in_text {
        out.push_str(rest);
    }

    let decoded = out
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'");

    // Схлопывает больше одной подряд пустой строки в одну (пустые <w:p>
    // между абзацами иначе дают много лишних переносов).
    let mut cleaned = String::new();
    let mut blank_run = 0;
    for line in decoded.lines() {
        let line = line.trim_end();
        if line.trim().is_empty() {
            blank_run += 1;
            if blank_run <= 1 {
                cleaned.push('\n');
            }
        } else {
            blank_run = 0;
            cleaned.push_str(line);
            cleaned.push('\n');
        }
    }
    cleaned.trim().to_string()
}

// Очень упрощённый разбор RTF: вырезает управляющие слова/группы фигурных
// скобок, оставляя читаемый текст. Не претендует на полную точность (это
// не полноценный RTF-парсер), но для заметок и писем этого достаточно.
fn clean_rtf(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    let mut depth = 0i32;
    while let Some(c) = chars.next() {
        match c {
            '{' => depth += 1,
            '}' => depth -= 1,
            '\\' => {
                let mut word = String::new();
                while let Some(&n) = chars.peek() {
                    if n.is_ascii_alphabetic() {
                        word.push(n);
                        chars.next();
                    } else {
                        break;
                    }
                }
                while let Some(&n) = chars.peek() {
                    if n.is_ascii_digit() || n == '-' {
                        chars.next();
                    } else {
                        break;
                    }
                }
                if chars.peek() == Some(&' ') {
                    chars.next();
                }
                if word == "par" || word == "line" {
                    out.push('\n');
                } else if word == "tab" {
                    out.push('\t');
                }
            }
            _ if depth <= 1 => out.push(c),
            _ => {}
        }
    }
    out
}

// Расширения, которые читаем как обычный текст без специальной обработки —
// исходный код на любом популярном языке, конфиги, разметка, логи и т.п.
const PLAIN_TEXT_EXTS: &[&str] = &[
    "txt", "md", "markdown", "csv", "tsv", "json", "jsonl", "yaml", "yml", "toml", "ini", "cfg",
    "conf", "env", "xml", "svg", "html", "htm", "css", "scss", "less", "log", "rst", "tex", "js",
    "jsx", "ts", "tsx", "mjs", "cjs", "py", "rb", "rs", "go", "java", "kt", "kts", "swift", "c",
    "h", "cpp", "cc", "hpp", "cs", "php", "sql", "sh", "bash", "zsh", "ps1", "lua", "pl", "r",
    "scala", "dart", "vue", "svelte",
];

#[tauri::command]
fn extract_document(path: String) -> Result<String, String> {
    let p = std::path::Path::new(&path);
    let ext = p
        .extension()
        .and_then(|x| x.to_str())
        .unwrap_or("")
        .to_lowercase();
    if PLAIN_TEXT_EXTS.contains(&ext.as_str()) {
        return std::fs::read_to_string(p).map_err(|e| format!("Не удалось прочитать файл: {e}"));
    }
    if ext == "pdf" {
        return pdf_extract::extract_text(p).map_err(|e| format!("Не удалось прочитать PDF: {e}"));
    }
    if ext == "docx" {
        let f = std::fs::File::open(p).map_err(|e| format!("Не удалось прочитать файл: {e}"))?;
        let mut z = zip::ZipArchive::new(f).map_err(|e| e.to_string())?;
        let mut x = String::new();
        z.by_name("word/document.xml")
            .map_err(|e| e.to_string())?
            .read_to_string(&mut x)
            .map_err(|e| e.to_string())?;
        return Ok(extract_docx_text(&x));
    }
    if ext == "rtf" {
        let raw =
            std::fs::read_to_string(p).map_err(|e| format!("Не удалось прочитать файл: {e}"))?;
        return Ok(clean_rtf(&raw));
    }
    Err("unsupported_format".into())
}

#[tauri::command]
fn prepare_image_attachment(
    chat_id: String,
    source_path: String,
    suggested_name: String,
) -> Result<serde_json::Value, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let source = std::path::Path::new(&source_path);
    if !source.is_file() {
        return Err("Изображение не найдено.".into());
    }
    let stem = std::path::Path::new(&suggested_name)
        .file_stem()
        .and_then(|value| value.to_str())
        .unwrap_or("image");
    let clean_stem: String = stem
        .chars()
        .filter(|ch| ch.is_alphanumeric() || matches!(ch, '-' | '_' | ' '))
        .collect();
    let requested = format!(
        "{}.png",
        if clean_stem.trim().is_empty() {
            "image"
        } else {
            clean_stem.trim()
        }
    );
    let saved_name = sandbox_unique_filename(&chat_id, &requested);
    let temp_name = format!(
        "amigo-image-{}-{}.png",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos()
    );
    let temp_path = std::env::temp_dir().join(temp_name);
    let output = Command::new("/usr/bin/sips")
        .args(["-s", "format", "png"])
        .arg(source)
        .arg("--out")
        .arg(&temp_path)
        .output()
        .map_err(|error| format!("Не удалось запустить конвертацию изображения: {error}"))?;
    if !output.status.success() {
        let detail = String::from_utf8_lossy(&output.stderr);
        let _ = std::fs::remove_file(&temp_path);
        return Err(format!(
            "macOS не смогла преобразовать изображение в PNG: {}",
            detail.trim()
        ));
    }
    let bytes = std::fs::read(&temp_path)
        .map_err(|error| format!("Не удалось прочитать подготовленное изображение: {error}"))?;
    let _ = std::fs::remove_file(&temp_path);
    if !valid_image_bytes("png", &bytes) {
        return Err("После конвертации получено пустое или повреждённое изображение.".into());
    }
    sandbox_write_bytes(&chat_id, &saved_name, &bytes)?;
    Ok(serde_json::json!({
        "filename": saved_name,
        "data_url": format!("data:image/png;base64,{}", STANDARD.encode(bytes)),
    }))
}

const WHISPER_MODEL_NAME: &str = "ggml-base-q5_1.bin";
const WHISPER_MODEL_SIZE: u64 = 59_707_625;
const WHISPER_MODEL_URL: &str = "https://huggingface.co/ggerganov/whisper.cpp/resolve/5359861c739e955e79d9a303bcbc70fb988958b1/ggml-base-q5_1.bin";

async fn ensure_whisper_model() -> Result<std::path::PathBuf, String> {
    use std::io::Write;
    let path = models_dir().join(WHISPER_MODEL_NAME);
    if std::fs::metadata(&path).map(|meta| meta.len()).unwrap_or(0) == WHISPER_MODEL_SIZE {
        return Ok(path);
    }
    std::fs::create_dir_all(models_dir()).map_err(|error| error.to_string())?;
    let part = std::path::PathBuf::from(format!("{}.part", path.display()));
    let mut already = std::fs::metadata(&part).map(|meta| meta.len()).unwrap_or(0);
    if already > WHISPER_MODEL_SIZE {
        let _ = std::fs::remove_file(&part);
        already = 0;
    }
    let client = reqwest::Client::builder()
        .connect_timeout(Duration::from_secs(20))
        .build()
        .map_err(|error| error.to_string())?;
    let mut request = client.get(WHISPER_MODEL_URL);
    if already > 0 {
        request = request.header("Range", format!("bytes={already}-"));
    }
    let response = request.send().await.map_err(|error| {
        format!("Не удалось загрузить локальный модуль распознавания речи: {error}")
    })?;
    let resume = already > 0 && response.status() == reqwest::StatusCode::PARTIAL_CONTENT;
    if !response.status().is_success() && response.status() != reqwest::StatusCode::PARTIAL_CONTENT
    {
        return Err(format!(
            "Сервер модуля распознавания речи вернул {}",
            response.status()
        ));
    }
    let mut file = if resume {
        std::fs::OpenOptions::new()
            .append(true)
            .open(&part)
            .map_err(|error| error.to_string())?
    } else {
        already = 0;
        std::fs::File::create(&part).map_err(|error| error.to_string())?
    };
    let mut downloaded = already;
    let mut stream = response.bytes_stream();
    while let Some(chunk) = stream.next().await {
        let bytes = chunk.map_err(|error| format!("Загрузка модуля речи оборвалась: {error}"))?;
        file.write_all(&bytes).map_err(|error| error.to_string())?;
        downloaded += bytes.len() as u64;
        if downloaded > WHISPER_MODEL_SIZE {
            let _ = std::fs::remove_file(&part);
            return Err("Некорректный размер локального модуля распознавания речи.".into());
        }
    }
    file.flush().map_err(|error| error.to_string())?;
    drop(file);
    if std::fs::metadata(&part).map(|meta| meta.len()).unwrap_or(0) != WHISPER_MODEL_SIZE {
        return Err("Локальный модуль распознавания речи загружен не полностью; повторите — загрузка продолжится.".into());
    }
    std::fs::rename(&part, &path).map_err(|error| error.to_string())?;
    Ok(path)
}

fn find_whisper_cli(app: &tauri::AppHandle) -> Option<std::path::PathBuf> {
    app.path()
        .resolve("bin/whisper-cpp", tauri::path::BaseDirectory::Resource)
        .ok()
        .filter(|path| path.is_file())
}

#[tauri::command]
async fn transcribe_audio(app: tauri::AppHandle, source_path: String) -> Result<String, String> {
    let source = std::path::PathBuf::from(&source_path);
    if !source.is_file() {
        return Err("Аудиофайл не найден.".into());
    }
    let whisper = find_whisper_cli(&app).ok_or(
        "В приложении отсутствует локальный модуль распознавания аудио. Пересоберите AmIgo.",
    )?;
    let model = ensure_whisper_model().await?;
    let nonce = format!(
        "{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos()
    );
    let wav = std::env::temp_dir().join(format!("amigo-audio-{nonce}.wav"));
    let output_prefix = std::env::temp_dir().join(format!("amigo-transcript-{nonce}"));
    let converted = Command::new("/usr/bin/afconvert")
        .args(["-f", "WAVE", "-d", "LEI16@16000", "-c", "1"])
        .arg(&source)
        .arg(&wav)
        .output()
        .map_err(|error| format!("Не удалось подготовить аудио: {error}"))?;
    if !converted.status.success() {
        let detail = String::from_utf8_lossy(&converted.stderr);
        let _ = std::fs::remove_file(&wav);
        return Err(format!(
            "Формат аудио не удалось преобразовать: {}",
            detail.trim()
        ));
    }
    let mut activity = Command::new("caffeinate").args(["-i", "-s"]).spawn().ok();
    let output = Command::new(&whisper)
        .arg("-m")
        .arg(&model)
        .arg("-f")
        .arg(&wav)
        .args(["-l", "auto", "-otxt", "-nt", "-of"])
        .arg(&output_prefix)
        .output()
        .map_err(|error| format!("Локальное распознавание аудио не запустилось: {error}"))?;
    if let Some(child) = activity.as_mut() {
        let _ = child.kill();
        let _ = child.wait();
    }
    let _ = std::fs::remove_file(&wav);
    let txt_path = std::path::PathBuf::from(format!("{}.txt", output_prefix.display()));
    let transcript = std::fs::read_to_string(&txt_path)
        .unwrap_or_else(|_| String::from_utf8_lossy(&output.stdout).to_string());
    let _ = std::fs::remove_file(&txt_path);
    if !output.status.success() {
        let detail = String::from_utf8_lossy(&output.stderr);
        return Err(format!(
            "Локальное распознавание аудио завершилось с ошибкой: {}",
            detail.trim()
        ));
    }
    let clean = transcript
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect::<Vec<_>>()
        .join("\n");
    if clean.is_empty() {
        Err("В аудио не удалось распознать речь.".into())
    } else {
        Ok(clean)
    }
}

// Читает картинку с диска и возвращает data URL (data:image/...;base64,...) —
// используется для миниатюры карточки вложения во фронтенде. Base64-часть
// без префикса отдельно уходит модели через поле images в ChatMessage.
#[tauri::command]
fn read_image_base64(path: String) -> Result<String, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let p = std::path::Path::new(&path);
    let ext = p
        .extension()
        .and_then(|x| x.to_str())
        .unwrap_or("")
        .to_lowercase();
    // Локальный движок AmIgo (llama.cpp/mtmd) декодирует изображения через
    // stb_image, который умеет JPEG/PNG/BMP/GIF (и ещё пару редких форматов),
    // но НЕ умеет WebP и TIFF — попытка их скормить модели заканчивается
    // ошибкой decode уже внутри движка, что выглядит как необъяснимый сбой.
    // Поэтому отсекаем нечитаемые форматы здесь же, с понятной причиной.
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "bmp" => "image/bmp",
        // HEIC/HEIF, WebP, TIFF и прочие форматы без декодера в движке — явный
        // код ошибки, чтобы фронтенд показал понятный тост, а не сырое сообщение.
        _ => return Err("unsupported_format".into()),
    };
    let bytes = std::fs::read(p).map_err(|e| format!("Не удалось прочитать изображение: {e}"))?;
    if !valid_image_bytes(&ext, &bytes) {
        return Err("empty_or_corrupted_image".into());
    }
    Ok(format!("data:{mime};base64,{}", STANDARD.encode(bytes)))
}

// Обе Qwen3.5-модели мультимодальны и получают свой mmproj; Nage 1.5
// остаётся текстовой. Список фиксирован, поэтому сеть для проверки не нужна.
#[tauri::command]
fn model_supports_vision(model: String) -> bool {
    matches!(model.as_str(), "mentis-3" | "nage-1.5")
}

// Сохраняет текст (например, код или документ из ответа модели) в файл,
// путь к которому пользователь выбрал через системный диалог "Сохранить как".
#[tauri::command]
fn save_file(path: String, content: String) -> Result<(), String> {
    std::fs::write(&path, content).map_err(|e| format!("Не удалось сохранить файл: {e}"))
}

// Сохраняет бинарный файл (PDF, PPTX, DOCX, XLSX и т.п.), который фронтенд
// собрал в памяти из лёгкого текстового описания модели (см. src/fileGenerators.js)
// и передал сюда как base64-строку. save_file для этого не подходит, потому
// что пишет содержимое как UTF-8 текст и испортил бы бинарный формат.
#[tauri::command]
fn save_binary_file(path: String, content_base64: String) -> Result<(), String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let bytes = STANDARD
        .decode(content_base64.as_bytes())
        .map_err(|e| format!("Некорректные данные файла: {e}"))?;
    std::fs::write(&path, bytes).map_err(|e| format!("Не удалось сохранить файл: {e}"))
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let app = tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .manage(ChatState::default())
        .invoke_handler(tauri::generate_handler![
            chat_stream,
            chat_complete_silent,
            begin_generation,
            end_generation,
            stop_generation,
            save_groq_key,
            test_groq_key,
            extract_document,
            save_file,
            save_binary_file,
            switch_model,
            list_models,
            download_model,
            warm_model,
            read_image_base64,
            prepare_image_attachment,
            transcribe_audio,
            model_supports_vision,
            save_tavily_key,
            has_tavily_key,
            api_keys_status,
            test_tavily_key,
            sandbox_health,
            sandbox_list,
            sandbox_reveal,
            sandbox_delete_all,
            sandbox_read_image,
            sandbox_delete_files,
            sandbox_preview_file,
            sandbox_open_file,
            sandbox_export_file,
            sandbox_import_file,
            sandbox_save_generated_text,
            sandbox_save_generated_binary
        ])
        .setup(|_app| {
            // Песочница больше не сжимается в фоне: фоновая упаковка могла
            // пересечься с чтением/записью и оставить карточку без файла.
            // Старые уже созданные архивы безопасно распакуются при обращении.
            Ok(())
        })
        // Автоматическое управление локальным сервером: греем при возврате в
        // приложение, останавливаем при сворачивании/переключении на другое
        // приложение и при закрытии (⌘Q) — модель на диске остаётся, освобождается
        // только ОЗУ (сервер — обычный дочерний процесс, его можно просто убить).
        .on_window_event(|window, event| match event {
            tauri::WindowEvent::CloseRequested { api, .. } => {
                api.prevent_close();
                let app = window.app_handle().clone();
                let state = app.state::<ChatState>();
                if state.shutting_down.swap(true, Ordering::SeqCst) {
                    return;
                }
                drop(state);
                tauri::async_runtime::spawn(async move {
                    let state = app.state::<ChatState>();
                    finish_then_unload(&state).await;
                    app.exit(0);
                });
            }
            tauri::WindowEvent::Focused(focused) => {
                let focused = *focused;
                let app = window.app_handle().clone();
                tauri::async_runtime::spawn(async move {
                    let state = app.state::<ChatState>();
                    if state.shutting_down.load(Ordering::SeqCst) {
                        return;
                    }
                    if focused {
                        // Возврат отменяет отложенную выгрузку, если генерация ещё идёт.
                        state.pending_unload.store(false, Ordering::SeqCst);
                        warm_active_model(&app, &state).await;
                    } else if state.busy.load(Ordering::SeqCst)
                        || state.generation_active.load(Ordering::SeqCst)
                    {
                        // Сначала закончить весь ответ, включая автопродолжения,
                        // создание документов и опросов, затем освободить память.
                        state.pending_unload.store(true, Ordering::SeqCst);
                    } else {
                        kill_local_server(&state);
                    }
                });
            }
            _ => {}
        })
        .build(tauri::generate_context!())
        .expect("Ошибка сборки AmIgo");

    // Cmd+Q на macOS приходит как RunEvent::ExitRequested и может обходить
    // WindowEvent::CloseRequested. Перехватываем его отдельно и разрешаем
    // реальный выход только после завершения всей generation session.
    app.run(|app_handle, event| {
        if let tauri::RunEvent::ExitRequested { api, code, .. } = event {
            let state = app_handle.state::<ChatState>();
            if state.shutting_down.load(Ordering::SeqCst) {
                return;
            }
            let has_server = state
                .local_server
                .lock()
                .map(|server| server.is_some())
                .unwrap_or(false);
            let must_wait = state.busy.load(Ordering::SeqCst)
                || state.generation_active.load(Ordering::SeqCst)
                || has_server;
            if !must_wait {
                return;
            }
            api.prevent_exit();
            if state.shutting_down.swap(true, Ordering::SeqCst) {
                return;
            }
            drop(state);
            let app = app_handle.clone();
            tauri::async_runtime::spawn(async move {
                let state = app.state::<ChatState>();
                finish_then_unload(&state).await;
                app.exit(code.unwrap_or(0));
            });
        }
    });
}

#[cfg(test)]
mod tests {
    use super::{
        masked_key, model_defs, parse_search_usage, parse_speculative_metrics, repetition_cutoff,
        is_matle_code_task, should_emit_buffered_content, should_offer_followup_tools,
        should_prefetch_files,
        should_prefetch_web_search, to_openai_messages, tool_call_args, ChatMessage, ChatRequest,
    };

    fn request_with_text(text: &str) -> ChatRequest {
        ChatRequest {
            provider: "local".into(),
            model: "nage-1.5".into(),
            messages: vec![ChatMessage {
                role: "user".into(),
                content: text.into(),
                images: vec![],
            }],
            think: Some(false),
            web_search: Some(true),
            temperature: Some(0.7),
            max_tokens: Some(1024),
            unlimited_output: false,
            num_ctx: Some(4096),
            chat_id: "test-chat".into(),
            code_blocks: vec![],
        }
    }


    #[test]
    fn matle_code_panel_appears_only_for_actionable_code_work() {
        let mut explain = request_with_text("Объясни, что такое код");
        explain.model = "matle-2.5".into();
        assert!(!is_matle_code_task(&explain));

        let mut implement = request_with_text("Напиши компонент на TypeScript");
        implement.model = "matle-2.5".into();
        assert!(is_matle_code_task(&implement));

        let mut unrelated = request_with_text("Расскажи о погоде");
        unrelated.model = "matle-2.5".into();
        assert!(!is_matle_code_task(&unrelated));
    }

    #[test]
    fn text_stream_keeps_enough_tail_to_hide_a_repeated_start() {
        assert!(STREAM_REPEAT_GUARD_CHARS >= 128);
    }

    #[test]
    fn streamed_tool_round_is_not_emitted_twice() {
        assert!(!should_emit_buffered_content(false, true, "готовый ответ"));
        assert!(should_emit_buffered_content(false, false, "готовый ответ"));
        assert!(!should_emit_buffered_content(true, true, "готовый ответ"));
    }

    #[test]
    fn old_search_counter_does_not_block_new_daily_limit() {
        assert_eq!(parse_search_usage("2026-08-17 99", "2026-08-17"), 0);
        assert_eq!(parse_search_usage("v32 2026-08-17 12", "2026-08-17"), 12);
        assert_eq!(parse_search_usage("v32 2026-08-16 31", "2026-08-17"), 0);
    }

    #[test]
    fn api_keys_are_only_exposed_as_masks() {
        assert_eq!(masked_key("gsk_secret_1234", "gsk_"), "gsk_••••1234");
        assert_eq!(masked_key("tvly-secret-abcd", "tvly-"), "tvly-••••abcd");
    }

    #[test]
    fn image_payload_keeps_real_mime_type() {
        let messages = to_openai_messages(&[ChatMessage {
            role: "user".into(),
            content: "Что на изображении?".into(),
            images: vec!["data:image/png;base64,iVBORw0KGgo=".into()],
        }]);
        assert_eq!(
            messages[0]["content"][1]["image_url"]["url"],
            "data:image/png;base64,iVBORw0KGgo="
        );
    }

    #[test]
    fn local_models_use_new_independent_weights() {
        let defs = model_defs();
        assert_eq!(defs.len(), 3);
        assert_eq!(defs[0].id, "mentis-3");
        assert_eq!(defs[0].main.filename, "Qwen3.5-9B-Q4_K_M.gguf");
        assert_eq!(defs[1].id, "nage-1.5");
        assert_eq!(defs[1].main.filename, "Qwen3.5-4B-Q4_K_M.gguf");
        assert_eq!(defs[2].id, "matle-2.5");
        assert_eq!(
            defs[2].main.filename,
            "Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf"
        );
        assert!(defs[2].mmproj.is_none());
        assert_eq!(
            defs[1]
                .mmproj
                .expect("Nage 1.5 должна поддерживать фото")
                .filename,
            "mmproj-Qwen3.5-4B-F16.gguf"
        );
        assert!(defs.iter().all(|def| !def.main.filename.contains("0.6B")));
    }

    #[test]
    fn cuts_second_long_repetition_before_it_reaches_ui() {
        let intro = "Краткий ответ.\n\n";
        let block = "Это достаточно длинный повторяющийся абзац, который модель по ошибке начинает писать второй раз. Он содержит больше ста двадцати восьми символов и позволяет надёжно обнаружить цикл без реакции на обычные короткие совпадения.\n";
        let text = format!("{intro}{block}{block}");
        let cutoff = repetition_cutoff(&text).expect("повтор должен быть обнаружен");
        let expected = intro.len() + block.len();
        // Детектор может также убрать один общий перевод строки перед повтором.
        assert!(cutoff >= expected.saturating_sub(4) && cutoff <= expected);
    }

    #[test]
    fn keeps_normal_non_repeating_answer() {
        let text = "Радж Капур был индийским актёром, режиссёром и продюсером. Он родился в 1924 году и стал одной из ключевых фигур хинди-кинематографа. Его известные фильмы включают «Бродягу» и «Господина 420».";
        assert_eq!(repetition_cutoff(text), None);
    }

    #[test]
    fn search_runs_only_for_explicit_or_fresh_queries() {
        assert!(!should_prefetch_web_search(&request_with_text("Привет!")));
        assert!(!should_prefetch_web_search(&request_with_text(
            "Объясни теорию относительности"
        )));
        assert!(should_prefetch_web_search(&request_with_text(
            "Найди актуальные модели Claude"
        )));
        assert!(should_prefetch_web_search(&request_with_text(
            "Какая погода сегодня?"
        )));
        assert!(!should_offer_followup_tools(&request_with_text(
            "Найди актуальные модели Claude"
        )));
        assert!(should_offer_followup_tools(&request_with_text(
            "Найди и скачай изображения новых моделей Claude"
        )));
    }

    #[test]
    fn file_tasks_receive_sandbox_listing_before_model_reply() {
        assert!(should_prefetch_files(&request_with_text(
            "Создай файл report.md и сохрани результат"
        )));
        assert!(should_prefetch_files(&request_with_text(
            "Прочитай файл из песочницы"
        )));
        assert!(!should_prefetch_files(&request_with_text(
            "Объясни теорию относительности"
        )));
    }

    #[test]
    fn parses_speculative_metrics_with_and_without_labels() {
        let metrics = r#"
# HELP llamacpp:spec_decode_num_spec_tokens_total Speculative drafts
llamacpp:spec_decode_num_spec_tokens_total 12
llamacpp:spec_decode_num_spec_tokens_total{slot="0"} 3
llamacpp:spec_decode_num_accepted_tokens_total 9
llamacpp:spec_decode_num_accepted_tokens_total{slot="0"} 2
"#;
        // Нелэйбленный aggregate имеет приоритет: per-slot не считаем второй раз.
        assert_eq!(parse_speculative_metrics(metrics), (12.0, 9.0));
    }

    #[test]
    fn sums_labeled_metrics_when_aggregate_is_absent() {
        let metrics = r#"
llamacpp:spec_decode_num_spec_tokens_total{slot="0"} 3
llamacpp:spec_decode_num_spec_tokens_total{slot="1"} 4
llamacpp:spec_decode_num_accepted_tokens_total{slot="0"} 2
llamacpp:spec_decode_num_accepted_tokens_total{slot="1"} 3
"#;
        assert_eq!(parse_speculative_metrics(metrics), (7.0, 5.0));
    }

    #[test]
    fn parses_local_tool_arguments_with_surrounding_text() {
        let call = serde_json::json!({
            "function": {
                "arguments": "Вызову поиск: {\"query\":\"новости сегодня\"}"
            }
        });
        assert_eq!(tool_call_args(&call)["query"], "новости сегодня");
    }

    #[test]
    fn accepts_object_tool_arguments() {
        let call = serde_json::json!({
            "function": { "arguments": { "query": "курс евро" } }
        });
        assert_eq!(tool_call_args(&call)["query"], "курс евро");
    }

    #[test]
    fn ignores_unrelated_or_malformed_metrics() {
        let metrics =
            "llamacpp:tokens_predicted_total 42\nllamacpp:spec_decode_num_spec_tokens_total nope\n";
        assert_eq!(parse_speculative_metrics(metrics), (0.0, 0.0));
    }
}

import assert from 'node:assert/strict';
import {
  buildDialogFilesBlock,
  buildSystemPrompt,
  classifyTurn,
  collectAttachmentDocuments,
  compactDroppedMessages,
  isWholeDocumentQuestion,
  shouldGatherEvidence,
  userTaskPrefix,
} from '../src/orchestrator.js';

assert.equal(classifyTurn({ text: 'Привет' }).intent, 'chat');
assert.equal(classifyTurn({ text: 'Расскажи, что умеешь' }).intent, 'capability');
assert.equal(classifyTurn({
  text: 'Что в этом файле?',
  attachments: [{ kind: 'text', name: 'a.pdf', text: 'hello' }],
}).intent, 'file_qa');
assert.equal(classifyTurn({
  text: 'Напиши змейку на python',
}).intent, 'code');
assert.equal(classifyTurn({
  text: 'Что на фото?',
  attachments: [{ kind: 'image', name: 'a.png' }],
}).intent, 'vision');
assert.equal(classifyTurn({
  text: 'найди курс евро',
  searchAvailable: true,
}).intent, 'search');
assert.equal(classifyTurn({
  text: 'Объясни подробно, как работает квантование модели',
}).intent, 'explain');
assert.equal(classifyTurn({
  text: 'Сравни эти два подхода: плюсы и минусы',
}).intent, 'explain');

// Распознавание вопроса про документ целиком — под него включается
// детерминированное покрытие начала/середины/конца вместо точечного поиска.
assert.equal(isWholeDocumentQuestion('Перескажи этот документ полностью'), true);
assert.equal(isWholeDocumentQuestion('О чём весь этот файл?'), true);
assert.equal(isWholeDocumentQuestion('Сделай конспект документа'), true);
assert.equal(isWholeDocumentQuestion('Какие главные мысли текста?'), true);
assert.equal(isWholeDocumentQuestion('Что в этом файле?'), true);
assert.equal(isWholeDocumentQuestion('Какой срок оплаты по договору?'), false);
assert.equal(isWholeDocumentQuestion('Переведи второй абзац'), false);
assert.equal(isWholeDocumentQuestion('Привет'), false);

// Реестр файлов: имена и роли, дедуп, кап по количеству — чтобы модель всегда
// знала, КАКИЕ файлы есть в диалоге, не запоминая их содержимое.
assert.equal(buildDialogFilesBlock({ messages: [] }), '');
const filesBlockChat = {
  messages: [
    { role: 'user', content: 'разбери', attachments: [{ kind: 'text', name: 'main.py', sandboxPath: 'main.py' }] },
    { role: 'assistant', content: 'готово', sandboxFiles: ['report.pdf'], attachments: [] },
    { role: 'user', content: 'и это', attachments: [{ kind: 'image', name: 'photo.png', sandboxPath: 'photo.png' }] },
  ],
};
const filesBlock = buildDialogFilesBlock(filesBlockChat, ['main.py', 'notes.txt', 'photo.png']);
assert.match(filesBlock, /Файлы диалога/);
assert.match(filesBlock, /main\.py — в песочнице, доступен инструментами/);
assert.match(filesBlock, /notes\.txt — в песочнице, доступен инструментами/);
assert.match(filesBlock, /report\.pdf — создан ассистентом/);
// main.py встречается один раз (дедуп), картинки в реестр не попадают.
assert.equal(filesBlock.match(/main\.py/g).length, 1);
assert.equal(filesBlock.includes('photo.png'), false);
const manyFiles = buildDialogFilesBlock({
  messages: [{ role: 'user', content: 'x', attachments: Array.from({ length: 20 }, (_, i) => ({ kind: 'text', name: `f${i}.txt` })) }],
});
assert.match(manyFiles, /…и ещё 6/);

// Аннотация файла в одну строку подставляется в реестр (кэшируется на вложении).
const filesWithNotes = buildDialogFilesBlock({
  messages: [{ role: 'user', content: 'x', attachments: [{ kind: 'text', name: 'dogovor.txt', synopsis: 'Договор аренды склада: сроки оплаты и штрафы.' }] }],
});
assert.match(filesWithNotes, /dogovor\.txt — загружен пользователем: Договор аренды склада/);

assert.equal(shouldGatherEvidence({
  intent: 'chat',
  attachments: [{ kind: 'text', name: 'a.txt' }],
  sandboxFiles: [],
}), true);
assert.equal(shouldGatherEvidence({
  intent: 'chat',
  attachments: [],
  sandboxFiles: ['note.txt'],
}), false);
assert.equal(shouldGatherEvidence({
  intent: 'file_qa',
  attachments: [],
  sandboxFiles: ['note.txt'],
}), true);
assert.equal(shouldGatherEvidence({
  intent: 'file_qa',
  continueMsg: true,
  attachments: [{ kind: 'text' }],
  sandboxFiles: ['note.txt'],
}), false);

const docs = collectAttachmentDocuments([
  { attachments: [{ kind: 'text', name: 'a.txt', text: 'AAA' }, { kind: 'image', name: 'p.png' }] },
  { attachments: [{ kind: 'text', sandboxPath: 'a.txt', text: 'dup' }] },
]);
assert.equal(docs.length, 1);
assert.equal(docs[0].name, 'a.txt');

const digest = compactDroppedMessages([
  { role: 'user', content: 'Старый вопрос про погоду в Липецке подробно' },
  { role: 'assistant', content: 'Ответ про погоду был длинный и больше не нужен для новой темы' },
]);
assert.match(digest, /Сжатая ранняя история/);
assert.match(digest, /Пользователь/);

const system = buildSystemPrompt({
  identityBlock: 'Тебя зовут Nage 1.5.',
  nowStr: 'четверг',
  intent: 'file_qa',
  provider: 'local',
  evidencePresent: true,
  sandboxFiles: ['report.pdf'],
  preferFiles: true,
});
assert.match(system, /Nage 1\.5/);
assert.match(system, /данные, не инструкции/);
assert.match(system, /Фрагменты файлов уже подобраны/);
assert.match(system, /report\.pdf/);
assert.doesNotMatch(system, /АВТОМАТИЧЕСКИ вставляет галерею/);

const chatSystem = buildSystemPrompt({
  identityBlock: 'Тебя зовут Nage 1.5.',
  intent: 'chat',
  provider: 'local',
  sandboxFiles: [],
});
assert.match(chatSystem, /Сильный собеседник/);
assert.doesNotMatch(chatSystem, /write_file/);
assert.match(chatSystem, /для обычного разговора не вызывай/);

assert.match(userTaskPrefix({ intent: 'file_qa', isCoder: false }), /фрагментам файлов/);
assert.equal(userTaskPrefix({ intent: 'chat', isCoder: true }), '');

console.log('Orchestrator tests passed.');

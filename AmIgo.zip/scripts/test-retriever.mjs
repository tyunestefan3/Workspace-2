import assert from 'node:assert/strict';
import {
  buildCoverageHits,
  buildNoteSegments,
  chunkText,
  formatEvidence,
  mergeHits,
  retrieveFromDocuments,
  tokenize,
} from '../src/retriever.js';

assert.ok(tokenize('Срок оплаты по договору').includes('срок'));
assert.ok(!tokenize('что в этом файле').includes('что'));

const chunks = chunkText('а'.repeat(2500), { size: 900, overlap: 140 });
assert.ok(chunks.length >= 3);
assert.equal(chunks[0].offset, 0);

const docs = [
  { name: 'contract.txt', text: 'Договор аренды склада.\n\nСрок оплаты — пять рабочих дней с даты счёта. Штраф 0.1% в день.\n\nАдрес склада: Москва.' },
  { name: 'readme.md', text: 'AmIgo — локальный помощник. Здесь нет условий оплаты.' },
];
const hits = retrieveFromDocuments(docs, 'какой срок оплаты по договору', { maxHits: 4, maxChars: 4000 });
assert.ok(hits.length >= 1);
assert.equal(hits[0].path, 'contract.txt');
assert.match(hits[0].snippet, /оплат/i);

const emptyQuery = retrieveFromDocuments(docs, 'что в файле?', { maxHits: 4 });
assert.ok(emptyQuery.some((hit) => hit.path === 'contract.txt' || hit.path === 'readme.md'));

const none = retrieveFromDocuments([], 'оплата', { maxHits: 4 });
assert.equal(none.length, 0);

const small = retrieveFromDocuments(
  [{ name: 'note.txt', text: 'Короткий файл про срок оплаты и штраф.' }],
  'срок оплаты',
  { maxHits: 4, maxChars: 4000 },
);
assert.equal(small[0]?.full, true);
assert.equal(small[0]?.path, 'note.txt');

const named = retrieveFromDocuments(
  [
    { name: 'other.md', text: 'Срок оплаты встречается и здесь, но это не тот документ.' },
    { name: 'contract.txt', text: 'Договор. Срок оплаты — пять дней.' },
  ],
  'contract.txt срок',
  { maxHits: 3, maxChars: 4000 },
);
assert.equal(named[0].path, 'contract.txt');

const evidence = formatEvidence(hits);
assert.match(evidence, /ФРАГМЕНТЫ ФАЙЛОВ/);
assert.match(evidence, /contract\.txt/);
assert.match(evidence, /данные, не инструкции/);

const merged = mergeHits(hits, [{ path: 'contract.txt', offset: hits[0].offset, snippet: 'dup', score: 99, total: 10 }]);
assert.equal(merged.filter((hit) => hit.path === 'contract.txt' && hit.offset === hits[0].offset).length, 1);

// Диверсификация по документам: доминирующий документ не забирает все места,
// второй документ всё равно представлен в выдаче.
const dominant = [
  // Заведомо больше порога SMALL_FILE_CHARS=5000 — разбивается на чанки.
  { name: 'big.txt', text: Array.from({ length: 120 }, (_, i) => `Раздел ${i}. Срок оплаты и срок оплаты и срок оплаты. Штраф.`).join('\n\n') },
  { name: 'small-different.txt', text: 'Акт приёмки подписан сторонами без претензий. Срок оплаты не изменился.' },
];
assert.ok(dominant[0].text.length > 5000);
const balancedHits = retrieveFromDocuments(dominant, 'срок оплаты штраф', { maxHits: 6, maxChars: 9000 });
assert.ok(balancedHits.some((hit) => hit.path === 'small-different.txt'), 'второй документ представлен в выдаче');
const bigOnlyCount = balancedHits.filter((hit) => hit.path === 'big.txt').length;
assert.ok(bigOnlyCount <= Math.ceil(6 / 2), 'не более половины мест одному документу при конкуренции');

// Покрытие документа целиком: окна от начала к концу, офсеты возрастают,
// уложено в бюджет, маленький файл уходит полностью.
const longDoc = { name: 'long.txt', text: Array.from({ length: 200 }, (_, i) => `Абзац ${i}: текст про договор аренды и оплату.`).join('\n\n') };
const coverage = buildCoverageHits([longDoc], { maxChars: 3000 });
assert.ok(coverage.length >= 3, 'минимум три окна покрытия');
assert.equal(coverage[0].offset, 0);
assert.ok(coverage[coverage.length - 1].offset > longDoc.text.length / 2, 'последнее окно — ближе к концу');
const coverageChars = coverage.reduce((sum, hit) => sum + hit.snippet.length, 0);
assert.ok(coverageChars <= 3000 + 100, 'покрытие укладывается в бюджет символов');
const ascending = coverage.every((hit, index, arr) => index === 0 || hit.offset > arr[index - 1].offset);
assert.ok(ascending, 'офсеты окон возрастают');
const smallCoverage = buildCoverageHits([{ name: 'tiny.txt', text: 'коротко' }], { maxChars: 3000 });
assert.equal(smallCoverage.length, 1);
assert.equal(smallCoverage[0].full, true);

// Сегментация для LLM-заметок: непрерывно покрывает весь текст без пропусков.
const noteSegs = buildNoteSegments('x'.repeat(50000), { maxSegments: 8, segmentChars: 6000 });
assert.equal(noteSegs.length, 8);
assert.equal(noteSegs[0].offset, 0);
assert.equal(noteSegs.map((s) => s.text).join('').length, 50000, 'сегменты в сумме — весь документ');
const noteSmall = buildNoteSegments('короткий текст', {});
assert.equal(noteSmall.length, 1);
assert.equal(noteSmall[0].offset, 0);
assert.equal(buildNoteSegments('', {}).length, 0);

console.log('Retriever tests passed.');

#!/bin/zsh
# Собирает AmIgo.app + AmIgo.dmg для Apple Silicon.
# Запускать отдельными строками, без \ в конце:
#   export PATH="$(dirname "$(rustup which cargo)"):$HOME/.cargo/bin:$PATH"
#   cd ~/Documents/AmIgo
#   zsh scripts/build-amigo.command
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -f "$HOME/.cargo/env" ]]; then
  source "$HOME/.cargo/env"
fi
export PATH="$HOME/.cargo/bin:/opt/homebrew/opt/rustup/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

if ! command -v node >/dev/null; then
  echo "Node.js не найден. Выполните:"
  echo "  brew install node"
  exit 1
fi

if ! xcode-select -p >/dev/null 2>&1; then
  echo "Нет Xcode Command Line Tools. Выполните:"
  echo "  xcode-select --install"
  exit 1
fi

if ! command -v git >/dev/null; then
  echo "Git не найден. Выполните: xcode-select --install"
  exit 1
fi

if ! command -v cmake >/dev/null; then
  echo "CMake не найден. Выполните:"
  echo "  brew install cmake"
  exit 1
fi

if ! command -v rustup >/dev/null; then
  echo "Нужен rustup (не brew rust). Выполните:"
  echo "  brew uninstall rust"
  echo "  brew install rustup"
  echo "  rustup default stable"
  echo "  source \"\$HOME/.cargo/env\""
  echo "Затем снова:"
  echo "  export PATH=\"\$(dirname \"\$(rustup which cargo)\"):\$HOME/.cargo/bin:\$PATH\""
  echo "  cd ~/Documents/AmIgo"
  echo "  zsh scripts/build-amigo.command"
  exit 1
fi

# Homebrew rustup даёт команду rustup, но не всегда кладёт cargo в PATH.
if ! command -v cargo >/dev/null || ! command -v rustc >/dev/null; then
  rustup default stable >/dev/null || true
  if [[ -f "$HOME/.cargo/env" ]]; then
    source "$HOME/.cargo/env"
  fi
  CARGO_REAL="$(rustup which cargo 2>/dev/null || true)"
  RUSTC_REAL="$(rustup which rustc 2>/dev/null || true)"
  if [[ -n "${CARGO_REAL:-}" && -x "$CARGO_REAL" ]]; then
    export PATH="$(dirname "$CARGO_REAL"):$HOME/.cargo/bin:$PATH"
  fi
  if [[ -n "${RUSTC_REAL:-}" && -x "$RUSTC_REAL" ]]; then
    export PATH="$(dirname "$RUSTC_REAL"):$PATH"
  fi
fi

if ! command -v cargo >/dev/null; then
  echo "cargo не в PATH. Homebrew rustup так устроен. Ищу toolchain…"
  rustup default stable
  CARGO_REAL="$(rustup which cargo)"
  if [[ ! -x "$CARGO_REAL" ]]; then
    echo "rustup which cargo не сработал. Пришлите вывод:"
    echo "  which rustup"
    echo "  rustup show"
    echo "  rustup which cargo"
    echo "  ls \"\$HOME/.cargo/bin\""
    echo "  ls \"\$HOME/.rustup/toolchains\""
    exit 1
  fi
  mkdir -p "$HOME/.cargo/bin"
  export PATH="$(dirname "$CARGO_REAL"):$HOME/.cargo/bin:$PATH"
fi

if ! command -v cargo >/dev/null; then
  echo "cargo всё ещё не найден. Пришлите вывод:"
  echo "  which rustup; rustup show; rustup which cargo"
  exit 1
fi

if command -v brew >/dev/null && brew list rust >/dev/null 2>&1; then
  echo "Снимаю Homebrew-пакет rust — он ломает сборку через rustup."
  brew uninstall rust || true
  hash -r
fi

ARCH="$(uname -m)"
if [[ "$ARCH" != "arm64" ]]; then
  echo "AmIgo собирается только для Apple Silicon (arm64)."
  exit 1
fi

echo "cargo: $(command -v cargo)"
echo "rustc host: $(rustc -vV | awk -F': ' '/^host:/{print $2}')"

echo "Ставлю цель Apple Silicon…"
rustup target add aarch64-apple-darwin

export MACOSX_DEPLOYMENT_TARGET="${MACOSX_DEPLOYMENT_TARGET:-12.0}"

# Пин llama.cpp: ядра GGUF/Metal. HTTP-порт приложения — наш (amigo-engine).
LLAMA_CPP_TAG="b11295"
CACHE_DIR="$HOME/Library/Caches/AmIgo"
LLAMA_SRC="$CACHE_DIR/llama.cpp-$LLAMA_CPP_TAG"
LLAMA_BUILD="$LLAMA_SRC/build"
mkdir -p "$CACHE_DIR"

if [[ ! -d "$LLAMA_SRC/.git" ]]; then
  rm -rf "$LLAMA_SRC"
  echo "Скачиваю llama.cpp $LLAMA_CPP_TAG…"
  git clone --depth 1 --branch "$LLAMA_CPP_TAG" https://github.com/ggml-org/llama.cpp.git "$LLAMA_SRC"
fi

echo "Собираю amigo-engine (llama.cpp Metal)…"
cmake -S "$LLAMA_SRC" -B "$LLAMA_BUILD" \
  -DCMAKE_BUILD_TYPE=Release \
  -DGGML_METAL=ON \
  -DGGML_METAL_EMBED_LIBRARY=ON \
  -DGGML_NATIVE=OFF \
  -DBUILD_SHARED_LIBS=OFF \
  -DLLAMA_CURL=OFF \
  -DLLAMA_BUILD_TESTS=OFF \
  -DLLAMA_BUILD_EXAMPLES=OFF \
  -DLLAMA_BUILD_SERVER=ON
NCPU="$(sysctl -n hw.ncpu 2>/dev/null || echo 4)"
cmake --build "$LLAMA_BUILD" --config Release -j"$NCPU" --target llama-server

ENGINE_SRC=""
if [[ -x "$LLAMA_BUILD/bin/llama-server" ]]; then
  ENGINE_SRC="$LLAMA_BUILD/bin/llama-server"
elif [[ -x "$LLAMA_BUILD/llama-server" ]]; then
  ENGINE_SRC="$LLAMA_BUILD/llama-server"
fi
[[ -n "$ENGINE_SRC" ]] || { echo "Не собран llama-server / amigo-engine"; exit 1; }

WHISPER_WHEEL="whisper_cpp_cli-0.0.3-py3-none-macosx_11_0_arm64.whl"
WHISPER_SHA="6c9cb1d10770da5b7f92c54c2ace29142694b5b392c274db1d95ce1d2f6223d2"
WHISPER_URL="https://files.pythonhosted.org/packages/fd/eb/4d1a96d887b62fdddc58e3e0c9c94f673b54cd9fc025329340f9c4d052bc/whisper_cpp_cli-0.0.3-py3-none-macosx_11_0_arm64.whl"

WHISPER_ARCHIVE="$CACHE_DIR/$WHISPER_WHEEL"
valid_whisper_archive() {
  [[ -f "$WHISPER_ARCHIVE" ]] || return 1
  [[ "$(shasum -a 256 "$WHISPER_ARCHIVE" | awk '{print $1}')" == "$WHISPER_SHA" ]]
}
if ! valid_whisper_archive; then
  rm -f "$WHISPER_ARCHIVE"
  echo "Скачиваю проверенный локальный модуль распознавания аудио ($ARCH)…"
  curl -L --fail --retry 3 --connect-timeout 20 "$WHISPER_URL" -o "$WHISPER_ARCHIVE"
fi
if ! valid_whisper_archive; then
  echo "Контрольная сумма модуля распознавания аудио не совпала."
  exit 1
fi

BIN_DIR="src-tauri/bin"
rm -rf "$BIN_DIR"
mkdir -p "$BIN_DIR"
cp "$ENGINE_SRC" "$BIN_DIR/amigo-engine"
chmod 755 "$BIN_DIR/amigo-engine"
ENGINE_DIR="$(dirname "$ENGINE_SRC")"
setopt NULL_GLOB
for lib in "$ENGINE_DIR"/*.dylib; do
  [[ -f "$lib" ]] || continue
  cp "$lib" "$BIN_DIR/"
done
unsetopt NULL_GLOB
if command -v install_name_tool >/dev/null; then
  install_name_tool -add_rpath "@executable_path" "$BIN_DIR/amigo-engine" >/dev/null 2>&1 || true
fi
codesign --force --sign - "$BIN_DIR/amigo-engine" >/dev/null 2>&1 || true
for lib in "$BIN_DIR"/*.dylib(N); do
  codesign --force --sign - "$lib" >/dev/null 2>&1 || true
done

unzip -p "$WHISPER_ARCHIVE" 'whisper_cpp_cli-0.0.3.data/scripts/whisper-cpp' > "$BIN_DIR/whisper-cpp"
chmod 755 "$BIN_DIR/whisper-cpp"
codesign --force --sign - "$BIN_DIR/whisper-cpp" >/dev/null 2>&1 || true

echo "Движок AmIgo: amigo-engine (llama.cpp $LLAMA_CPP_TAG, Metal) + whisper-cpp ($ARCH)"

npm install
zsh scripts/make-macos-icon.command

DMG_DIR="src-tauri/target/release/bundle/dmg"
mkdir -p "$DMG_DIR"
rm -f "$DMG_DIR"/*.dmg(N)

npm run tauri build -- --target aarch64-apple-darwin

APP_DIR="src-tauri/target/aarch64-apple-darwin/release/bundle/macos/AmIgo.app"
DMG_DIR="src-tauri/target/aarch64-apple-darwin/release/bundle/dmg"
if [[ ! -d "$APP_DIR" ]]; then
  APP_DIR="src-tauri/target/release/bundle/macos/AmIgo.app"
  DMG_DIR="src-tauri/target/release/bundle/dmg"
fi
mkdir -p "$DMG_DIR"

DMG_FILES=("$DMG_DIR"/*.dmg(N))
if (( ${#DMG_FILES[@]} > 0 )); then
  mv -f "$DMG_FILES[1]" "$DMG_DIR/AmIgo.dmg"
fi

FINAL_DMG="$DMG_DIR/AmIgo.dmg"
[[ -d "$APP_DIR" ]] || { echo "AmIgo.app не найден после сборки"; exit 1; }
[[ -s "$FINAL_DMG" ]] || { echo "AmIgo.dmg не создан"; exit 1; }
[[ -x "$APP_DIR/Contents/Resources/bin/whisper-cpp" ]] || {
  echo "В AmIgo.app отсутствует встроенный модуль распознавания аудио"
  exit 1
}
[[ -x "$APP_DIR/Contents/Resources/bin/amigo-engine" ]] || {
  echo "В AmIgo.app отсутствует встроенный движок amigo-engine"
  exit 1
}
ICON_FILES=("$APP_DIR/Contents/Resources"/*.icns(N))
(( ${#ICON_FILES[@]} > 0 )) || { echo "В AmIgo.app отсутствует иконка .icns"; exit 1; }
APP_EXECUTABLES=("$APP_DIR/Contents/MacOS"/*(N*))
(( ${#APP_EXECUTABLES[@]} > 0 )) || { echo "В AmIgo.app отсутствует исполняемый файл"; exit 1; }

echo "Проверка DMG пройдена: приложение, иконка, amigo-engine и whisper-cpp внутри."
echo "Сборка завершена. Приложение: $APP_DIR"
echo "Образ для отправки: $FINAL_DMG"
open "$DMG_DIR" || true

import { renderMarkdown } from '../src/markdown.js';

const sample = `#Красивый заголовок

Абзац с **жирным**, *курсивом*, ==маркером== и \`**не markdown**\`.

• Первый пункт
  • Вложенный пункт

> [!NOTE] Полезная заметка

| Колонка | Число |
|:---|---:|
| Значение | 42 |

\`\`\`js
const raw = "**не жирный**";
\`\`\`

\`\`\`text:report.txt
Готовый файл
\`\`\`

Ссылка: https://example.com/test.`;

const html = renderMarkdown(sample);
const expected = [
  '<h1>Красивый заголовок</h1>',
  '<code>**не markdown**</code>',
  'md-callout--note',
  'md-table-wrap',
  'md-align-right',
  'const raw = &quot;**не жирный**&quot;',
  'class="file-card-preview">Предпросмотр</button>',
  'class="download-code file-card-download"',
  '</a>.',
];

for (const fragment of expected) {
  if (!html.includes(fragment)) {
    console.error(`Markdown test failed: missing ${fragment}`);
    console.error(html);
    process.exit(1);
  }
}

const italicLines = renderMarkdown('Обычная строка\n*курсив на новой строке *\n\n* пункт списка');
if (!italicLines.includes('<em>курсив на новой строке </em>') || !italicLines.includes('<li>пункт списка')) {
  console.error('Markdown test failed: single-star italic or bullet list is broken');
  console.error(italicLines);
  process.exit(1);
}

const questionCard = renderMarkdown(`\`\`\`question
[{"question":"**Какой** формат?","multiple":false,"options":["\`PDF\`","*DOCX*"]}]
\`\`\``, { msgIndex: 12 });
if (!questionCard.includes('Какой формат?') || !questionCard.includes('PDF') || !questionCard.includes('DOCX') || questionCard.includes('**Какой**') || !questionCard.includes('question-dismiss')) {
  console.error('Markdown test failed: question card content or close button is broken');
  console.error(questionCard);
  process.exit(1);
}
const duplicateQuestionCard = renderMarkdown(`\`\`\`question
[
  {"question":"Какой формат нужен?","multiple":false,"options":["PDF","PDF"]},
  {"question":"Какой формат вам нужен?","multiple":false,"options":["PDF"]}
]
\`\`\``, { msgIndex: 15 });
if ((duplicateQuestionCard.match(/class="question-card"/g) || []).length !== 1
  || !duplicateQuestionCard.includes('1/1')
  || (duplicateQuestionCard.match(/data-value="PDF"/g) || []).length !== 1) {
  console.error('Markdown test failed: duplicate questions/options were not removed');
  console.error(duplicateQuestionCard);
  process.exit(1);
}

const answeredQuestion = renderMarkdown(`\`\`\`question
[{"question":"Какой формат?","multiple":false,"options":["PDF"]}]
\`\`\``, { msgIndex: 16, answers: { 0: { status: 'answered', text: 'PDF' } } });
if (!answeredQuestion.includes('question-receipt') || !answeredQuestion.includes('Ответ получен') || answeredQuestion.includes('question-card')) {
  console.error('Markdown test failed: answered question did not become a receipt');
  process.exit(1);
}
const skippedQuestion = renderMarkdown(`\`\`\`question
[{"question":"Какой формат?","multiple":false,"options":["PDF"]}]
\`\`\``, { msgIndex: 17, answers: { 0: { status: 'skipped' } } });
if (!skippedQuestion.includes('Вопрос пропущен') || skippedQuestion.includes('question-card')) {
  console.error('Markdown test failed: skipped question did not become a receipt');
  process.exit(1);
}
// Квитанции не зависят от модели: Mentis/Nage/Groq тоже должны их видеть.
const groqReceipt = renderMarkdown(`\`\`\`question
[{"question":"Какой тон?","multiple":false,"options":["Короткий"]}]
\`\`\``, { msgIndex: 42, answers: { 0: { status: 'answered', text: 'Короткий' } } });
if (!groqReceipt.includes('Ответ получен') || groqReceipt.includes('question-card')) {
  console.error('Markdown test failed: receipt is not shown for a non-Matle answer');
  process.exit(1);
}
if (groqReceipt.includes('class="thinking"') || answeredQuestion.includes('class="thinking"') || skippedQuestion.includes('class="thinking"')) {
  console.error('Markdown test failed: receipt still shows the typing animation');
  process.exit(1);
}

const hiddenQuestion = renderMarkdown(`\`\`\`question\n[{"question":"Скрыть меня?","multiple":false,"options":[]}]\n\`\`\``, { msgIndex: 13, hideQuestions: true });
if (hiddenQuestion.includes('question-card') || hiddenQuestion.includes('Скрыть меня?')) {
  console.error('Markdown test failed: dismissed question is still visible');
  process.exit(1);
}
const sandboxLink = renderMarkdown('Открой [готовый файл](sandbox:src/app.ts).');
if (!sandboxLink.includes('class="sandbox-file-link"') || !sandboxLink.includes('data-sandbox-open="src/app.ts"')) {
  console.error('Markdown test failed: sandbox file link is not clickable');
  process.exit(1);
}
const alternateNamedFence = renderMarkdown(`\`\`\`typescript filename=UserProfile.tsx\nexport const UserProfile = () => null;\n\`\`\``, { msgIndex: 14 });
if (!alternateNamedFence.includes('file-card') || !alternateNamedFence.includes('UserProfile')) {
  console.error('Markdown test failed: alternate named fence did not become a file card');
  process.exit(1);
}

const matleCodeOnly = renderMarkdown(`Готовый результат ниже.

\`\`\`typescript
export const answer: number = 42;
\`\`\``, { msgIndex: 18, hideCodeBlocks: true });
if (matleCodeOnly.includes('class="codeblock"') || matleCodeOnly.includes('export const answer') || !matleCodeOnly.includes('Готовый результат')) {
  console.error('Markdown test failed: Matle code block is visible in code-only-files mode');
  process.exit(1);
}
const matleNamedFile = renderMarkdown(`\`\`\`typescript:answer.ts
export const answer: number = 42;
\`\`\``, { msgIndex: 19, hideCodeBlocks: true });
if (!matleNamedFile.includes('class="file-card"') || matleNamedFile.includes('<pre')) {
  console.error('Markdown test failed: named Matle file did not remain a file card');
  process.exit(1);
}

// Регрессия: два ответа начинаются одинаковыми 64+ символами, но второй код
// изменён дальше. Их кнопки не должны ссылаться на первый DOM-элемент.
const common = 'const sharedPrefix = "' + 'x'.repeat(90) + '";\n';
const oldAnswer = renderMarkdown(`\`\`\`js\n${common}console.log('old');\n\`\`\``, { msgIndex: 2 });
const newAnswer = renderMarkdown(`\`\`\`js\n${common}console.log('new');\n\`\`\``, { msgIndex: 4 });
const sameMessageChanged = renderMarkdown(`\`\`\`js\n${common}console.log('changed');\n\`\`\``, { msgIndex: 2 });
const idOf = (value) => value.match(/<pre id="([^"]+)"/)?.[1];
const oldId = idOf(oldAnswer);
const newId = idOf(newAnswer);
const changedId = idOf(sameMessageChanged);
if (!oldId || !newId || !changedId || new Set([oldId, newId, changedId]).size !== 3) {
  console.error('Markdown test failed: code block IDs are not globally unique');
  process.exit(1);
}
for (const [rendered, id] of [[oldAnswer, oldId], [newAnswer, newId], [sameMessageChanged, changedId]]) {
  if (!rendered.includes(`data-target="${id}"`)) {
    console.error(`Markdown test failed: copy button does not target its own block ${id}`);
    process.exit(1);
  }
}

const oldFile = renderMarkdown(`\`\`\`js:app.js\n${common}console.log('v1');\n\`\`\``, { msgIndex: 6 });
const newFile = renderMarkdown(`\`\`\`js:app.js\n${common}console.log('v2');\n\`\`\``, { msgIndex: 8 });
const hiddenId = (value) => value.match(/class="codeblock" id="([^"]+)" hidden/)?.[1];
const oldFileId = hiddenId(oldFile);
const newFileId = hiddenId(newFile);
if (!oldFileId || !newFileId || oldFileId === newFileId) {
  console.error('Markdown test failed: generated file IDs collide');
  process.exit(1);
}
for (const [rendered, id] of [[oldFile, oldFileId], [newFile, newFileId]]) {
  if (!rendered.includes(`data-target="${id}"`) || !rendered.includes(`data-block="${id}"`)) {
    console.error(`Markdown test failed: file download/preview points to another block ${id}`);
    process.exit(1);
  }
}

console.log('Markdown test passed.');

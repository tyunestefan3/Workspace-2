import assert from 'node:assert/strict';
import {
  areUserQuestionsEquivalent,
  CONTINUE_RE,
  cleanContinuationStart,
  collapseRepeatedWholeResponse,
  continuationLooksRestarted,
  convertPlainQuestionsToSurvey,
  hideStreamingQuestionDraft,
  isBriefAcknowledgment,
  isConciseCapabilityQuestion,
  isStreamingFileDraft,
  isUnlimitedCreationTask,
  requestedDocumentExt,
  extractRequestedDocumentText,
  looksLikeFileNarration,
  wantsDocumentExport,
  isUnusedChat,
  hasUnclosedFence,
  looksLikeIncompleteCode,
  shouldAutoContinueReply,
  sourceLooksIncomplete,
  looksLikeOsControlSurvey,
  looksLikeToolCallPayload,
  nextChatId,
  removeRepeatedProse,
  shouldStartNewTopic,
  stripConstraintNarration,
  stripEchoedUserPrompt,
  stripLeakedToolCalls,
  stripPendingBlocks,
} from '../src/chatLogic.js';

const empty = { id: 1, title: 'Новый диалог', messages: [], pendingAttachments: [], draft: '' };
assert.equal(isUnusedChat(empty), true);
assert.equal(isUnusedChat({ ...empty, draft: 'черновик' }), false);
assert.equal(isUnusedChat({ ...empty, pendingAttachments: [{ name: 'a.txt' }] }), false);
assert.equal(isUnusedChat({ ...empty, messages: [{ role: 'user', content: 'Привет' }] }), false);
assert.equal(nextChatId([{ id: 20 }, { id: 30 }], 10), 31);
assert.equal(isConciseCapabilityQuestion('Расскажи, что умеешь'), true);
assert.equal(isConciseCapabilityQuestion('А что еще', 'Расскажи, что умеешь'), true);
assert.equal(isConciseCapabilityQuestion('А что еще', 'Привет'), false);
assert.equal(isStreamingFileDraft('```json\n{"question":"Какое время?","options":["12:00"]}\n```'), false);
assert.equal(isStreamingFileDraft('```python:app.py\nprint(1)\n'), true);
assert.equal(isBriefAcknowledgment('Понял, спасибо'), true);
assert.equal(isBriefAcknowledgment('расскажи про Apple подробно'), false);
assert.equal(looksLikeOsControlSurvey(
  'Я — AmIgo, ваш ассистент на Mac. Помогаю с работой в системе. Чем заняться прямо сейчас?',
  ['Найти файлы или папки', 'Запустить приложение', 'Очистить корзину'],
), true);
assert.equal(looksLikeOsControlSurvey('Какой формат нужен?', ['PDF', 'DOCX']), false);
assert.equal(
  convertPlainQuestionsToSurvey(
    'В файле нет слов песни.\n\nХочешь, я попробую найти текст в интернете и сохранить его в файл?\nОтветь — что делать?',
  ).includes('```question'),
  false,
);
assert.equal(isUnlimitedCreationTask('Создай большой HTML-файл калькулятора', []), true);
assert.equal(isUnlimitedCreationTask('Напиши код на Python для анализа данных', []), true);
assert.equal(isUnlimitedCreationTask('Напиши змейку на python', []), true);
assert.equal(isUnlimitedCreationTask('Сделай телеграм бота', []), true);
assert.equal(isUnlimitedCreationTask('Объясни, что такое Python', []), false);
assert.equal(hasUnclosedFence('```python\nprint(1)\n'), true);
assert.equal(hasUnclosedFence('```python\nprint(1)\n```'), false);
assert.equal(sourceLooksIncomplete('def greet(name):\n    print(f"hi {name}")\n    return name'), false);
assert.equal(sourceLooksIncomplete('def greet(name):\n    print(f"hi {name}"\n    return'), true);
assert.equal(sourceLooksIncomplete('function main() {\n  const x = 1;\n  if (x'), true);
assert.equal(looksLikeIncompleteCode('Вот игра:\n```python\nimport pygame\ndef run():\n    while True:\n        pass\n```'), false);
assert.equal(looksLikeIncompleteCode('Вот игра:\n```python\nimport pygame\ndef run():\n    while True:\n'), true);
assert.equal(looksLikeIncompleteCode('```js\nfunction add(a, b) {\n  return a + b;\n}\n```'), false);
assert.equal(looksLikeIncompleteCode('```js\nfunction add(a, b) {\n  return a +\n```'), true);
assert.equal(shouldAutoContinueReply('```py\nprint(1)\n```', 'length'), true);
assert.equal(shouldAutoContinueReply('Готово.', 'stop'), false);
assert.equal(isUnlimitedCreationTask('Исправь этот файл', [{ sandboxPath: 'app.js' }]), true);
assert.equal(isUnlimitedCreationTask('Объедини эти файлы в один', []), true);
assert.equal(isUnlimitedCreationTask('перепиши', [{ sandboxPath: 'notes.md' }]), true);
assert.equal(isUnlimitedCreationTask('Что на этих фото?', [{ sandboxPath: 'a.png', kind: 'image' }, { sandboxPath: 'b.png', kind: 'image' }]), false);
assert.equal(isUnlimitedCreationTask('Прочитай эти файлы', [{ sandboxPath: 'a.pdf', kind: 'text' }, { sandboxPath: 'b.txt', kind: 'text' }]), true);
assert.equal(isUnlimitedCreationTask('Что в этом файле?', [{ sandboxPath: 'report.pdf', kind: 'text' }]), true);
assert.equal(wantsDocumentExport('Хорошо а оформи жто в pdf'), true);
assert.equal(isUnlimitedCreationTask('Хорошо а оформи это в pdf', []), true);
assert.equal(wantsDocumentExport('Что такое pdf'), false);
assert.equal(requestedDocumentExt('Или просто тестовый документ с текстом «Привет, это PDF»? — да'), 'pdf');
assert.equal(requestedDocumentExt('Расскажи, что такое PDF'), '');
assert.equal(extractRequestedDocumentText('а сделай PDF документ с содержанием: привет, это PDF'), 'привет, это PDF');
assert.equal(looksLikeFileNarration('Я уже создал файл test_document.pdf в песочнице'), true);
assert.equal(looksLikeToolCallPayload('{\n"name": \'list_files".\n"arguments": {}\n}'), true);
assert.equal(looksLikeToolCallPayload('{"title":"data","items":[1,2,3]}'), false);
assert.equal(stripLeakedToolCalls('Готово.\n```json\n{"name":"list_files","arguments":{}}\n```\n'), 'Готово.');
assert.equal(
  stripEchoedUserPrompt('Напиши калькулятор на python\n\nСейчас сохраню файл и проверю синтаксис.', 'Напиши калькулятор на python'),
  'Сейчас сохраню файл и проверю синтаксис.',
);
assert.equal(
  stripEchoedUserPrompt('[Задача] объяснить\n[Сделай] сначала суть, потом сжатое почему; без учебника\n\nГравитация притягивает массы.', 'Объясни гравитацию кратко'),
  'Гравитация притягивает массы.',
);
assert.equal(stripEchoedUserPrompt('Сделаю калькулятор и сразу проверю его.', 'Напиши калькулятор на python'), 'Сделаю калькулятор и сразу проверю его.');
const streamingWithClosedFile = 'План готов.\n```python:app.py\nprint(1)\n```\nДальше пояснение про запуск.';
assert.match(stripPendingBlocks(streamingWithClosedFile), /План готов\.\s+Дальше пояснение про запуск\./);
const streamingOpenFile = 'План готов.\n```python:app.py\nprint(1)\n';
assert.equal(stripPendingBlocks(streamingOpenFile), 'План готов.');
assert.match(stripPendingBlocks('Смотри:\n```\n**жирный**\nсписок\n'), /жирный/);
const constrained = 'Суть: Apple делает Mac.\n\nПочему так:\n1. Экосистема: Я не имею доступа к интернету для получения актуальных новостей.';
assert.match(stripConstraintNarration(constrained), /Apple делает Mac/);
assert.doesNotMatch(stripConstraintNarration(constrained), /не имею доступа/);
const leakedOs = 'Ключевые элементы проекта:\n1. Геймификация обучения.\n\nОсобенности:\n- Я не управляю компьютером напрямую, не вижу диск системы и не имею доступа к Finder или настройкам macOS — всё ограничено чатом, вложениями и песочницей.';
const cleanedOs = stripConstraintNarration(leakedOs);
assert.match(cleanedOs, /Геймификация обучения/);
assert.doesNotMatch(cleanedOs, /не управляю компьютером|Finder|Особенности/);
const pdfRefusal = 'Я не могу создать PDF-файл напрямую в чате, так как инструмент write_file работает только с текстовыми файлами.\n\nОднако я могу оформить изложение в виде структурированного текстового файла (например, в формате Markdown).\n\nВот описание модели.';
const cleanedPdf = stripConstraintNarration(pdfRefusal);
assert.match(cleanedPdf, /Вот описание модели/);
assert.doesNotMatch(cleanedPdf, /write_file|не могу создать PDF|структурированного текстового файла/i);

const chat = {
  messages: [{
    role: 'user',
    content: 'Объясни устройство локальной модели и параметры генерации ответа подробно',
  }],
};
assert.equal(shouldStartNewTopic(chat, 'Теперь новая тема: расскажи о выращивании орхидей'), true);
assert.equal(shouldStartNewTopic(chat, 'А как это работает подробнее?'), false);
assert.equal(
  shouldStartNewTopic(chat, 'Подготовь подробный маршрут путешествия по северной Италии с музеями ресторанами поездами гостиницами бюджетом'),
  true
);

const singleSurvey = convertPlainQuestionsToSurvey('Какой формат документа вам нужен?');
assert.match(singleSurvey, /```question/);
assert.match(singleSurvey, /Какой формат документа вам нужен\?/);

const multiSurvey = convertPlainQuestionsToSurvey(`Чтобы подготовить результат, уточните:
1. Какой формат нужен?
- PDF
- DOCX
2. Для какой аудитории готовим документ?`);
assert.match(multiSurvey, /```question/);
assert.match(multiSurvey, /"PDF"/);
assert.match(multiSurvey, /Для какой аудитории/);

const explanatory = 'Почему это важно?\nПотому что это влияет на итоговый результат.';
assert.equal(convertPlainQuestionsToSurvey(explanatory), explanatory);
const codeQuestion = '```js\nconst value = ready ? 1 : 0;\n```';
assert.equal(convertPlainQuestionsToSurvey(codeQuestion), codeQuestion);

for (const command of ['продолжай', 'Продолжи, пожалуйста', 'continue', '/continue', 'go on please', 'дальше']) {
  assert.equal(CONTINUE_RE.test(command), true, command);
}

const existing = 'Первый абзац.\n\nВторой абзац уже начат и должен продолжаться отсюда.';
const repeated = 'Второй абзац уже начат и должен продолжаться отсюда.\nНовая часть ответа.';
assert.equal(cleanContinuationStart(existing, repeated), '\nНовая часть ответа.');
assert.equal(cleanContinuationStart(existing, 'Продолжение: Новая часть.'), 'Новая часть.');
const nagePartial = `# Мои возможности как твой помощник Nage 1.5

Я — твоя локальная рабочая станция.

## Работа с файлами

* **Создание:** Пишу код (Python, JS,`;
const nageRestart = `\`\`\`markdown
# Мои возможности как твой помощник Nage 1.5

Я — твоя локальная рабочая станция.

## Работа с файлами

* **Создание:** Пишу код (Python, JS, Go, Rust и др.).
\`\`\``;
assert.equal(continuationLooksRestarted(nagePartial, nageRestart), true);
assert.equal(cleanContinuationStart(nagePartial, nageRestart), ' Go, Rust и др.).');
assert.equal(cleanContinuationStart(nagePartial, nageRestart.slice(0, 90)), '');

const duplicated = `Я помогаю с кодом и файлами. Дай конкретную задачу — я сразу начну работу.Я помогаю с кодом и файлами. Дай конкретную задачу — я сразу начну работу.`;
assert.equal(collapseRepeatedWholeResponse(duplicated), 'Я помогаю с кодом и файлами. Дай конкретную задачу — я сразу начну работу.');
const restartedLong = `# Возможности Nage 1.5

Я локальный помощник и сейчас перечислю основные возможности для работы.

Короткий обрыв.# Возможности Nage 1.5

Я локальный помощник и сейчас перечислю основные возможности для работы.

Это полная новая версия ответа без повторного начала и с нормальным завершением.`;
assert.equal(collapseRepeatedWholeResponse(restartedLong), `# Возможности Nage 1.5

Я локальный помощник и сейчас перечислю основные возможности для работы.

Это полная новая версия ответа без повторного начала и с нормальным завершением.`);
assert.equal(collapseRepeatedWholeResponse('Первый абзац.\n\nВторой непохожий абзац.'), 'Первый абзац.\n\nВторой непохожий абзац.');
assert.equal(isConciseCapabilityQuestion('Расскажи, что умеешь'), true);
assert.equal(isConciseCapabilityQuestion('Расскажи подробно обо всех своих возможностях'), false);
assert.equal(areUserQuestionsEquivalent('Какой формат нужен?', 'Какой формат вам нужен?'), true);
assert.equal(areUserQuestionsEquivalent('Какой формат файла нужен?', 'Какой у проекта бюджет?'), false);
assert.equal(removeRepeatedProse('Первый полезный абзац с достаточно большим количеством слов для проверки повтора.\n\nПервый полезный абзац с достаточно большим количеством слов для проверки повтора.'), 'Первый полезный абзац с достаточно большим количеством слов для проверки повтора.');
const fencedRepeat = '```js\nconst a = 1;\nconst a = 1;\n```';
assert.equal(removeRepeatedProse(fencedRepeat), fencedRepeat);
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю результат.\nКакой формат'), 'Сначала подготовлю результат.');
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю результат.\nКакой формат нужен?'), 'Сначала подготовлю результат.');
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю результат. Какой формат'), 'Сначала подготовлю результат.');
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю подробный результат'), 'Сначала подготовлю подробный результат');

console.log('Chat logic tests passed.');

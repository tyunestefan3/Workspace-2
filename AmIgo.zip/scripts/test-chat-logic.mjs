import assert from 'node:assert/strict';
import {
  areUserQuestionsEquivalent,
  CONTINUE_RE,
  cleanContinuationStart,
  collapseRepeatedWholeResponse,
  continuationLooksRestarted,
  convertPlainQuestionsToSurvey,
  hideStreamingQuestionDraft,
  isConciseCapabilityQuestion,
  isUnlimitedCreationTask,
  isUnusedChat,
  nextChatId,
  removeRepeatedProse,
  shouldStartNewTopic,
} from '../src/chatLogic.js';

const empty = { id: 1, title: 'Новый диалог', messages: [], pendingAttachments: [], draft: '' };
assert.equal(isUnusedChat(empty), true);
assert.equal(isUnusedChat({ ...empty, draft: 'черновик' }), false);
assert.equal(isUnusedChat({ ...empty, pendingAttachments: [{ name: 'a.txt' }] }), false);
assert.equal(isUnusedChat({ ...empty, messages: [{ role: 'user', content: 'Привет' }] }), false);
assert.equal(nextChatId([{ id: 20 }, { id: 30 }], 10), 31);
assert.equal(isUnlimitedCreationTask('Создай большой HTML-файл калькулятора', []), true);
assert.equal(isUnlimitedCreationTask('Напиши код на Python для анализа данных', []), true);
assert.equal(isUnlimitedCreationTask('Объясни, что такое Python', []), false);
assert.equal(isUnlimitedCreationTask('Исправь этот файл', [{ sandboxPath: 'app.js' }]), true);

const chat = {
  messages: [{
    role: 'user',
    content: 'Объясни устройство локальной модели и параметры генерации ответа подробно',
  }],
};
assert.equal(shouldStartNewTopic(chat, 'Теперь новая тема: расскажи о выращивании орхидей'), true);
assert.equal(shouldStartNewTopic(chat, 'А как это работает подробнее?'), false);
assert.equal(
  shouldStartNewTopic(chat, 'Подготовь подробный маршрут путешествия по северной Италии с музеями ресторанами поездами гостиницами бюджетом'),
  true
);

const singleSurvey = convertPlainQuestionsToSurvey('Какой формат документа вам нужен?');
assert.match(singleSurvey, /```question/);
assert.match(singleSurvey, /Какой формат документа вам нужен\?/);

const multiSurvey = convertPlainQuestionsToSurvey(`Чтобы подготовить результат, уточните:
1. Какой формат нужен?
- PDF
- DOCX
2. Для какой аудитории готовим документ?`);
assert.match(multiSurvey, /```question/);
assert.match(multiSurvey, /"PDF"/);
assert.match(multiSurvey, /Для какой аудитории/);

const explanatory = 'Почему это важно?\nПотому что это влияет на итоговый результат.';
assert.equal(convertPlainQuestionsToSurvey(explanatory), explanatory);
const codeQuestion = '```js\nconst value = ready ? 1 : 0;\n```';
assert.equal(convertPlainQuestionsToSurvey(codeQuestion), codeQuestion);

for (const command of ['продолжай', 'Продолжи, пожалуйста', 'continue', '/continue', 'go on please', 'дальше']) {
  assert.equal(CONTINUE_RE.test(command), true, command);
}

const existing = 'Первый абзац.\n\nВторой абзац уже начат и должен продолжаться отсюда.';
const repeated = 'Второй абзац уже начат и должен продолжаться отсюда.\nНовая часть ответа.';
assert.equal(cleanContinuationStart(existing, repeated), '\nНовая часть ответа.');
assert.equal(cleanContinuationStart(existing, 'Продолжение: Новая часть.'), 'Новая часть.');
const nagePartial = `# Мои возможности как твой помощник Nage 1.5

Я — твоя локальная рабочая станция.

## Работа с файлами

* **Создание:** Пишу код (Python, JS,`;
const nageRestart = `\`\`\`markdown
# Мои возможности как твой помощник Nage 1.5

Я — твоя локальная рабочая станция.

## Работа с файлами

* **Создание:** Пишу код (Python, JS, Go, Rust и др.).
\`\`\``;
assert.equal(continuationLooksRestarted(nagePartial, nageRestart), true);
assert.equal(cleanContinuationStart(nagePartial, nageRestart), ' Go, Rust и др.).');
assert.equal(cleanContinuationStart(nagePartial, nageRestart.slice(0, 90)), '');

const duplicated = `Я помогаю с кодом и файлами. Дай конкретную задачу — я сразу начну работу.Я помогаю с кодом и файлами. Дай конкретную задачу — я сразу начну работу.`;
assert.equal(collapseRepeatedWholeResponse(duplicated), 'Я помогаю с кодом и файлами. Дай конкретную задачу — я сразу начну работу.');
const restartedLong = `# Возможности Nage 1.5

Я локальный помощник и сейчас перечислю основные возможности для работы.

Короткий обрыв.# Возможности Nage 1.5

Я локальный помощник и сейчас перечислю основные возможности для работы.

Это полная новая версия ответа без повторного начала и с нормальным завершением.`;
assert.equal(collapseRepeatedWholeResponse(restartedLong), `# Возможности Nage 1.5

Я локальный помощник и сейчас перечислю основные возможности для работы.

Это полная новая версия ответа без повторного начала и с нормальным завершением.`);
assert.equal(collapseRepeatedWholeResponse('Первый абзац.\n\nВторой непохожий абзац.'), 'Первый абзац.\n\nВторой непохожий абзац.');
assert.equal(isConciseCapabilityQuestion('Расскажи, что умеешь'), true);
assert.equal(isConciseCapabilityQuestion('Расскажи подробно обо всех своих возможностях'), false);
assert.equal(areUserQuestionsEquivalent('Какой формат нужен?', 'Какой формат вам нужен?'), true);
assert.equal(areUserQuestionsEquivalent('Какой формат файла нужен?', 'Какой у проекта бюджет?'), false);
assert.equal(removeRepeatedProse('Первый полезный абзац с достаточно большим количеством слов для проверки повтора.\n\nПервый полезный абзац с достаточно большим количеством слов для проверки повтора.'), 'Первый полезный абзац с достаточно большим количеством слов для проверки повтора.');
const fencedRepeat = '```js\nconst a = 1;\nconst a = 1;\n```';
assert.equal(removeRepeatedProse(fencedRepeat), fencedRepeat);
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю результат.\nКакой формат'), 'Сначала подготовлю результат.');
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю результат.\nКакой формат нужен?'), 'Сначала подготовлю результат.');
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю результат. Какой формат'), 'Сначала подготовлю результат.');
assert.equal(hideStreamingQuestionDraft('Сначала подготовлю подробный результат'), 'Сначала подготовлю подробный результат');

console.log('Chat logic tests passed.');

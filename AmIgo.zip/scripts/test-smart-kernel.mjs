import assert from 'node:assert/strict';
import {
  expandSearchQuery,
  extractDurableFacts,
  looksLikeGroundingFailure,
  mentionedFilenames,
  samplerForIntent,
} from '../src/smartKernel.js';

const expanded = expandSearchQuery('Какой срок оплаты по «договору аренды» в report.pdf? 0.1%');
assert.match(expanded, /договору аренды/);
assert.match(expanded, /report\.pdf/i);
assert.match(expanded, /0\.1%/);
assert.ok(!expanded.includes('какой') || tokenizeSafe(expanded));

function tokenizeSafe() { return true; }

assert.deepEqual(
  mentionedFilenames('посмотри bot.py пожалуйста', ['bot.py', 'readme.md']),
  ['bot.py'],
);

const facts = extractDurableFacts([
  { role: 'user', content: 'Меня зовут Иван. Я живу в Казани.' },
  { role: 'assistant', content: 'Привет!' },
  { role: 'user', content: 'Я предпочитаю краткие ответы. Я пишу на Python. Проект называется AmIgo.' },
  { role: 'user', content: 'Отвечай на английском' },
]);
assert.ok(facts.some((line) => /Иван/.test(line)));
assert.ok(facts.some((line) => /Казани/.test(line)));
assert.ok(facts.some((line) => /краткие/.test(line)));
assert.ok(facts.some((line) => /Python/.test(line)));
assert.ok(facts.some((line) => /AmIgo/.test(line)));
assert.ok(facts.some((line) => /английск/i.test(line)));

const workFacts = extractDurableFacts([
  { role: 'user', content: 'Я работаю как дизайнер интерфейсов. Я пишу на Python.' },
]);
assert.ok(workFacts.includes('Работа: дизайнер интерфейсов'));
assert.ok(!workFacts.some((line) => /^Работа: на Python/.test(line)));
assert.ok(workFacts.some((line) => /^Стек: Python/.test(line)));

assert.equal(looksLikeGroundingFailure('У меня нет доступа к этому файлу, прикрепите его снова.'), true);
assert.equal(looksLikeGroundingFailure('Во фрагменте договора срок оплаты — пять дней.'), false);

assert.equal(samplerForIntent('file_qa', { temperature: 0.7 }).temperature, 0.6);
assert.equal(samplerForIntent('explain', { temperature: 0.7 }).temperature, 0.7);
assert.equal(samplerForIntent('capability', { temperature: 0.7 }).max_tokens, 900);

console.log('Smart kernel tests passed.');

import assert from 'node:assert/strict';
import {
  clipToTokens,
  contextBudget,
  estimateTokens,
  packPrompt,
  packTurn,
  selectRecentMessages,
  splitBudget,
} from '../src/contextBuilder.js';

assert.equal(estimateTokens(''), 0);
assert.ok(estimateTokens('абвгдеёжзийклмнопрст') >= 8);
assert.ok(contextBudget({ numCtx: 12_288, hasImages: false, reserveOutput: 4_096 }) < 12_288);
assert.ok(contextBudget({ numCtx: 12_288, hasImages: true, imageCount: 3, reserveOutput: 2_048 })
  < contextBudget({ numCtx: 12_288, hasImages: false, reserveOutput: 2_048 }));

const clipped = clipToTokens('я'.repeat(5_000), 40);
assert.ok(clipped.includes('обрезано по бюджету токенов'));
assert.ok(estimateTokens(clipped) <= 48);

const { system: sysB, history: histB } = splitBudget(10_000);
assert.equal(sysB + histB, 10_000);

const history = [
  { role: 'user', content: 'старый вопрос про погоду' },
  { role: 'assistant', content: 'я'.repeat(8_000) },
  { role: 'user', content: 'новый вопрос про файл' },
];
const selected = selectRecentMessages(history, 1_200, { lastUserMax: 400, otherMax: 200 });
assert.equal(selected.kept.at(-1)?.content.includes('новый вопрос про файл') || selected.kept.some((m) => m.content.includes('новый вопрос')), true);
assert.ok(selected.kept.some((m) => m.role === 'user' && m.content.includes('новый вопрос')));
assert.ok(selected.dropped >= 0);

const packed = packPrompt({
  system: 'я'.repeat(20_000),
  messages: history,
  budget: 3_000,
  lastUserMax: 400,
  otherMax: 200,
});
assert.ok(estimateTokens(packed.system) < 3_000);
assert.ok(packed.messages.some((m) => m.content.includes('новый вопрос')));
assert.ok(packed.used <= packed.budget + 40);

const packedTurn = packTurn({
  system: 'я'.repeat(8_000),
  evidence: 'фрагмент договора про срок оплаты '.repeat(400),
  messages: history,
  budget: 3_000,
  lastUserMax: 400,
  otherMax: 200,
});
assert.ok(packedTurn.evidence.includes('срок оплаты') || packedTurn.evidence.includes('обрезано'));
assert.ok(packedTurn.messages.some((m) => m.content.includes('новый вопрос')));
assert.ok(packedTurn.used <= packedTurn.budget + 80);

console.log('Context builder tests passed.');

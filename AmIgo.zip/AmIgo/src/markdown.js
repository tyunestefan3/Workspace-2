// Markdown-рендер без внешних зависимостей — с расчётом на то, что модель
// может быть "нестандартной" и использовать не только базовый синтаксис.
// Понимает: блоки кода ``` и ~~~, инлайн-код `code`, **жирный**, ~~зачёркнутый~~,
// *курсив*, ***жирный курсив***, [ссылки](url) и голые http-ссылки,
// ![картинки](url), экранирование \*, \_ и т.п., заголовки #...###### и
// заголовки через подчёркивание (Заголовок\n===/---), списки - / * / 1. /
// чекбоксы - [ ] с произвольной вложенностью по отступам, таблицы, цитаты >,
// горизонтальные линии ---, и правильно склеивает многострочные абзацы
// (перенос строки внутри абзаца — <br>, а не отдельный параграф).

export function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (x) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[x]));
}


// Делает незавершённую markdown-разметку потокового ответа визуально
// стабильной. Модель присылает токены частями: сначала может прийти "**",
// а закрывающие "**" — через несколько секунд. Без этого пользователь
// временно видит служебные звёздочки. Здесь мы только для текущего кадра
// виртуально закрываем начатое выделение; исходный текст сообщения не меняется.
// Содержимое fenced code blocks не трогаем, чтобы звёздочки в коде оставались кодом.
export function stabilizeStreamingMarkdown(src) {
  const balanceInline = (segment) => {
    const stack = [];
    let inCode = false;
    const isWord = (c) => !!c && /[\p{L}\p{N}]/u.test(c);
    const tokens = ['***', '___', '**', '__', '~~', '*', '_', '`'];

    for (let i = 0; i < segment.length;) {
      if (segment[i] === '\\') { i += Math.min(2, segment.length - i); continue; }
      let token = null;
      for (const t of tokens) {
        if (segment.startsWith(t, i)) { token = t; break; }
      }
      if (!token) { i++; continue; }

      if (inCode && token !== '`') { i += token.length; continue; }
      const top = stack[stack.length - 1];
      const next = segment[i + token.length] || '';
      // Оператор умножения/степени с пробелом после него — обычный текст,
      // а не начало курсива или жирного выделения.
      if (token !== '`' && top?.token !== token && next && /\s/.test(next)) {
        i += token.length; continue;
      }
      if ((token === '*' || token === '_')) {
        const lineStart = segment.lastIndexOf('\n', i - 1) + 1;
        const beforeOnLine = segment.slice(lineStart, i);
        if (token === '*' && /^\s*$/.test(beforeOnLine) && /\s/.test(next)) { i++; continue; }
        if (token === '_' && isWord(segment[i - 1]) && isWord(next)) { i++; continue; }
      }


      if (top?.token === token) stack.pop();
      else stack.push({ token, pos: i });
      if (token === '`') inCode = !inCode;
      i += token.length;
    }

    if (!stack.length) return segment;
    const removeAt = [];
    const closers = [];
    for (let i = stack.length - 1; i >= 0; i--) {
      const item = stack[i];
      // Один только что пришедший маркер в конце не показываем до появления
      // первого символа содержимого. Остальные виртуально закрываем.
      if (item.pos + item.token.length === segment.length) removeAt.push(item);
      else closers.push(item.token);
    }
    let out = segment;
    for (const item of removeAt.sort((a, b) => b.pos - a.pos)) {
      out = out.slice(0, item.pos) + out.slice(item.pos + item.token.length);
    }
    return out + closers.join('');
  };

  let out = '';
  let cursor = 0;
  const opener = /(```|~~~)[^\n]*\n/g;
  while (cursor < (src || '').length) {
    opener.lastIndex = cursor;
    const open = opener.exec(src);
    if (!open) { out += balanceInline(src.slice(cursor)); break; }
    out += balanceInline(src.slice(cursor, open.index));
    const fence = open[1];
    const bodyStart = opener.lastIndex;
    const closeRe = new RegExp(`\\n${fence.replace(/~/g, '\\~')}\\s*(?=\\n|$)`, 'g');
    closeRe.lastIndex = bodyStart;
    const close = closeRe.exec(src);
    if (!close) { out += src.slice(open.index); break; }
    const end = closeRe.lastIndex;
    out += src.slice(open.index, end);
    cursor = end;
  }
  return out;
}

const COPY_ICON =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
const DOWNLOAD_ICON =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';
const CHEVRON_ICON =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';
const FILE_ICON =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
const PENCIL_ICON =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
const ARROW_RIGHT_ICON =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>';

const LIST_TAG = { ul: 'ul', ol: 'ol', task: 'ul' };
function stableId(lang, filename, code, position) {
  // Детерминированный id блока — не меняется при повторном рендере того же
  // сообщения. Это важно для кнопок "Копировать"/"Скачать" — они ищут элемент
  // по id, который должен быть тем же самым, что был задан при создании кнопки.
  let h = position * 2654435761;
  const s = (lang || '') + (filename || '') + (code || '').slice(0, 64);
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 0x9e3779b9) >>> 0;
  return `code-${h.toString(36)}`;
}

// Расширения "настоящих" документов (не просто кода) — для них особенно
// важно осмысленное имя файла, потому что пользователь такой файл обычно
// сохраняет и открывает в другом приложении, а не просто читает как код.
const DOC_EXT = { pdf: 'pdf', pptx: 'pptx', ppt: 'pptx', docx: 'docx', doc: 'docx', xlsx: 'xlsx', xls: 'xlsx' };

// Превращает произвольный текст (обычно первый заголовок/строку содержимого)
// в безопасное имя файла: убирает markdown-символы, недопустимые для файловой
// системы символы, схлопывает пробелы в "_" и обрезает длину.
function slugifyFilename(text) {
  const cleaned = (text || '')
    .replace(/^#+\s*/, '')
    .replace(/[*_`]/g, '')
    .replace(/[\\/:*?"<>|]/g, '')
    .trim()
    .replace(/\s+/g, '_');
  return cleaned.slice(0, 60);
}

// Если модель не указала имя файла через ```lang:filename для одного из
// форматов документов (pdf/pptx/docx/xlsx), подбираем его сами — из первого
// заголовка (# ...) или первой непустой строки содержимого блока — вместо
// безликого "amigo-code.pdf".
function deriveFilename(lang, filename, code) {
  if (filename) return filename;
  const ext = DOC_EXT[(lang || '').toLowerCase()];
  if (!ext) return filename;
  const firstLine = (code || '').split('\n').find((l) => l.trim().length > 0) || '';
  const base = slugifyFilename(firstLine) || 'документ';
  return `${base}.${ext}`;
}

// Достаёт из текста ответа все валидные ```question блоки как обычные
// объекты — используется и для сборки итоговой сводки ответов пользователя
// после прохождения опроса (main.js), и (через ту же логику ниже) для самой
// отрисовки. Порядок и qid (0,1,2…) всегда совпадают с порядком блоков в тексте.
function parseQuestionPayload(raw, qid) {
  let parsed = null;
  try { parsed = JSON.parse(raw); } catch { parsed = null; }

  let question = parsed && typeof parsed.question === 'string' ? parsed.question.trim() : '';
  let multiple = !!parsed?.multiple;
  let options = Array.isArray(parsed?.options) ? parsed.options : (Array.isArray(parsed?.choices) ? parsed.choices : []);

  // Модели иногда присылают почти-JSON (например, забывают запятую). Даже
  // такой ```question никогда не должен превращаться в сырой блок кода:
  // вытаскиваем вопрос и варианты безопасным ограниченным fallback-парсером.
  if (!question) {
    const q = String(raw || '').match(/["']question["']\s*:\s*"((?:\\.|[^"\\])*)"/i);
    if (q) {
      try { question = JSON.parse(`"${q[1]}"`).trim(); } catch { question = q[1].trim(); }
    }
    multiple = /["']multiple["']\s*:\s*true/i.test(String(raw || ''));
    const optionsBody = String(raw || '').match(/["']options["']\s*:\s*\[([\s\S]*?)\]/i)?.[1] || '';
    options = Array.from(optionsBody.matchAll(/"((?:\\.|[^"\\])*)"/g)).map((m) => {
      try { return JSON.parse(`"${m[1]}"`); } catch { return m[1]; }
    });
  }

  if (!question) return null;
  return {
    qid,
    question: question.slice(0, 500),
    multiple,
    // Пустой массив — нормальный вопрос со свободным текстовым ответом.
    options: options.map((o) => String(o).trim()).filter(Boolean).slice(0, 8),
  };
}

function questionPayloads(raw, startQid = 0) {
  let parsed = null;
  try { parsed = JSON.parse(raw); } catch { parsed = null; }
  const values = Array.isArray(parsed) ? parsed : [parsed];
  const out = [];
  for (const value of values) {
    if (!value || typeof value !== 'object') continue;
    const q = parseQuestionPayload(JSON.stringify(value), startQid + out.length);
    if (q) out.push(q);
  }
  // Для специально помеченного, но слегка сломанного JSON — fallback.
  if (!out.length) {
    const q = parseQuestionPayload(raw, startQid);
    if (q) out.push(q);
  }
  return out;
}

function isQuestionCodeBlock(lang, filename, code) {
  if ((lang || '').toLowerCase() === 'question') return true;
  if ((filename || '').trim()) return false; // настоящий именованный JSON-файл
  let parsed = null;
  try { parsed = JSON.parse(code); } catch { return false; }
  const values = Array.isArray(parsed) ? parsed : [parsed];
  return values.some((v) => v && typeof v === 'object'
    && typeof v.question === 'string'
    && (Object.prototype.hasOwnProperty.call(v, 'options')
      || Object.prototype.hasOwnProperty.call(v, 'multiple')));
}

function normalizeLooseQuestionJson(src) {
  const input = String(src || '');
  let out = '';
  let i = 0;
  let fence = null;
  while (i < input.length) {
    if (!fence && (input.startsWith('```', i) || input.startsWith('~~~', i))) {
      fence = input.slice(i, i + 3); out += fence; i += 3; continue;
    }
    if (fence && input.startsWith(fence, i)) {
      out += fence; i += 3; fence = null; continue;
    }
    if (fence || (input[i] !== '{' && input[i] !== '[')) {
      out += input[i++]; continue;
    }

    const start = i;
    const opening = input[i];
    const stack = [opening === '{' ? '}' : ']'];
    let inString = false;
    let escaped = false;
    i++;
    for (; i < input.length && stack.length; i++) {
      const c = input[i];
      if (inString) {
        if (escaped) escaped = false;
        else if (c === '\\') escaped = true;
        else if (c === '"') inString = false;
        continue;
      }
      if (c === '"') { inString = true; continue; }
      if (c === '{') stack.push('}');
      else if (c === '[') stack.push(']');
      else if (c === stack[stack.length - 1]) stack.pop();
    }
    if (stack.length) { out += input.slice(start); break; }
    const candidate = input.slice(start, i);
    if (isQuestionCodeBlock('json', '', candidate)) {
      out += `\n\`\`\`question\n${candidate}\n\`\`\`\n`;
    } else {
      out += candidate;
    }
  }
  return out;
}

export function parseQuestionBlocks(src) {
  src = normalizeLooseQuestionJson(src);
  const out = [];
  // Распознаём не только ```question, но и ```json/обычный fenced-блок,
  // если внутри находится именно схема опроса. Модели часто игнорируют имя
  // языка, но пользователь всё равно должен увидеть карточку, а не JSON.
  const re = /(```|~~~)([\w+-]*)(?::([^\n`]+))?\s*\n([\s\S]*?)(?:\1|$)/gi;
  let m;
  while ((m = re.exec(src || ''))) {
    const [, , lang, filename, code] = m;
    if (!isQuestionCodeBlock(lang, filename, code)) continue;
    const questions = questionPayloads(code, out.length);
    out.push(...questions);
  }
  return out;
}

// Один шаг опроса — интерактивная карточка: прогресс "N/всего" сверху слева,
// вопрос, варианты (круглая отметка — только один, квадратная — можно
// несколько), и просто строка для своего ответа внизу списка (обычное поле
// ввода, без подписи и без отдельного клика чтобы её раскрыть). Футер с двумя
// кнопками никогда не наезжает сам на себя — «Пропустить →» строго по центру,
// «Ответить» строго в правом углу (grid с тремя колонками, а не flex — так
// работает при любой ширине текста). Ни один вариант не отправляется по клику
// сам по себе — только по «Ответить». Когда пройден весь опрос, карточка
// целиком исчезает — за это отвечает main.js (сюда эта функция просто не
// вызывается повторно для отвеченных шагов).
function questionStepHtml(qb, stepIndex, total, msgIndex) {
  const qText = escapeHtml(qb.question);
  const markShape = qb.multiple ? 'square' : 'circle';
  const optionsHtml = qb.options
    .map(
      (opt) => `
      <button type="button" class="question-option" data-value="${escapeHtml(opt)}">
        <span class="question-mark question-mark--${markShape}"></span>
        <span class="question-option-text">${escapeHtml(opt)}</span>
      </button>`
    )
    .join('');

  return `<div class="question-card" data-multiple="${qb.multiple ? 1 : 0}" data-msg-index="${msgIndex}" data-qid="${qb.qid}" data-total="${total}">
    <div class="question-progress">${stepIndex + 1}/${total}</div>
    <div class="question-title">${qText}</div>
    ${optionsHtml ? `<div class="question-options">${optionsHtml}</div>` : ''}
    <div class="question-custom-row">
      <span class="icon question-custom-icon" style="width:14px;height:14px">${PENCIL_ICON}</span>
      <input type="text" class="question-custom-input" placeholder="${qb.options.length ? 'Свой вариант…' : 'Введите ответ…'}" maxlength="300">
    </div>
    <div class="question-footer">
      <button type="button" class="question-skip">Пропустить<span class="icon" style="width:13px;height:13px">${ARROW_RIGHT_ICON}</span></button>
      <button type="button" class="question-submit" disabled>Ответить</button>
    </div>
  </div>`;
}

export function renderMarkdown(src, opts = {}) {
  src = normalizeLooseQuestionJson(src);
  const { msgIndex = 0, answers = {} } = opts;
  const questionBlocks = parseQuestionBlocks(src);
  const blocks = [];

  // 1. Прячем блоки кода (``` или ~~~), чтобы остальные правила их не трогали.
  // Модель может указать после языка имя файла через двоеточие —
  // ```python:bot.py — тогда блок кода оформляется как готовый файл
  // (заголовок с именем, кнопка "скачать как ...", карточка файла внизу ответа).
  // Особый язык ```question — не файл и не код, а JSON-описание одного вопроса
  // опроса (см. parseQuestionBlocks/questionStepHtml выше); если JSON невалиден
  // или не похож на вопрос, тихо откатываемся к обычному блоку кода.
  let text = src.replace(/(```|~~~)([\w+-]*)(?::([^\n`]+))?\n([\s\S]*?)\1/g, (_, _fence, lang, filename, code) => {
    const idx = blocks.length;
    const cleanLang = (lang || '').trim();
    if (isQuestionCodeBlock(cleanLang, filename, code)) {
      // Опрос может прийти как question, json или блок без языка. Схема
      // распознаётся по содержимому и никогда не показывается сырым JSON.
      blocks.push({ isQuestion: true, validQuestion: questionPayloads(code).length > 0, id: stableId('question', '', code, blocks.length) });
      return `\u0000BLOCK${idx}\u0000`;
    }
    blocks.push({ lang: cleanLang, filename: deriveFilename(cleanLang, (filename || '').trim(), code), code, id: stableId(cleanLang, filename, code, blocks.length) });
    return `\u0000BLOCK${idx}\u0000`;
  });

  // 1б. Блок кода, который модель ещё дописывает (закрывающих ``` пока не
  // было) — раньше он до прихода закрывающей строки показывался сырым
  // текстом с открывающими ```, и только потом «выскакивал» готовым блоком.
  // Первый .replace выше уже убрал все ПОЛНОСТЬЮ закрытые блоки, так что
  // любая оставшаяся тройная кавычка — это заведомо ещё не закрытый блок;
  // оформляем его как обычный блок кода сразу, по мере поступления текста.
  text = text.replace(/(```|~~~)([\w+-]*)(?::([^\n`]+))?\n([\s\S]*)$/, (_, _fence, lang, filename, code) => {
    const idx = blocks.length;
    const cleanLang = (lang || '').trim();
    if (isQuestionCodeBlock(cleanLang, filename, code)) {
      blocks.push({ isQuestion: true, validQuestion: questionPayloads(code).length > 0, id: stableId('question', '', code, blocks.length) });
      return `\u0000BLOCK${idx}\u0000`;
    }
    blocks.push({ lang: cleanLang, filename: deriveFilename(cleanLang, (filename || '').trim(), code), code, id: stableId(cleanLang, filename, code, blocks.length) });
    return `\u0000BLOCK${idx}\u0000`;
  });

  // 2. Экранируем HTML в оставшемся тексте (защита от инъекций).
  text = escapeHtml(text);

  // 3. Экранированные спецсимволы (\* \_ \` и т.п.) прячем, чтобы дальнейшие
  // правила их не интерпретировали, и вернём как обычный символ в самом конце.
  text = text.replace(/\\([\\`*_{}[\]()#+.!>~-])/g, (_, c) => `\u0001${c.charCodeAt(0)}\u0001`);

  // 4. Инлайн-разметка на всём тексте разом.
  text = text.replace(/`([^`\n]+)`/g, (_, c) => `<code>${c}</code>`);
  text = text.replace(/\*\*\*([^*]+)\*\*\*/g, '<strong><em>$1</em></strong>');
  text = text.replace(/___([^_]+)___/g, '<strong><em>$1</em></strong>');
  text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  text = text.replace(/__([^_]+)__/g, '<strong>$1</strong>');
  text = text.replace(/~~([^~]+)~~/g, '<del>$1</del>');
  text = text.replace(/(^|[ \t(])\*([^*\s][^*\n]*?)\*(?!\*)/g, '$1<em>$2</em>');
  text = text.replace(/(^|[ \t(])_([^_\s][^_\n]*?)_(?!_)/g, '$1<em>$2</em>');

  // Картинки и ссылки: сперва ![alt](url), затем [текст](url) — прячем их,
  // чтобы не задвоить автоссылкой, затем голые http(s)-адреса, затем
  // возвращаем спрятанные ссылки/картинки на место.
  const linkBlocks = [];
  text = text.replace(/!\[([^\]]*)\]\((https?:\/\/[^\s)]+)\)/g, (_, alt, url) => {
    const idx = linkBlocks.length;
    linkBlocks.push(`<img src="${url}" alt="${alt}" loading="lazy" class="md-img">`);
    return `\u0002LINK${idx}\u0002`;
  });
  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, label, url) => {
    const idx = linkBlocks.length;
    linkBlocks.push(`<a href="${url}" target="_blank" rel="noopener">${label}</a>`);
    return `\u0002LINK${idx}\u0002`;
  });
  text = text.replace(/https?:\/\/[^\s<>()]+/g, (m) => `<a href="${m}" target="_blank" rel="noopener">${m}</a>`);
  text = text.replace(/\u0002LINK(\d+)\u0002/g, (_, i) => linkBlocks[Number(i)]);

  text = text.replace(/^(#{1,6})\s+(.*)$/gm, (_, hashes, content) => `<h${hashes.length}>${content}</h${hashes.length}>`);

  // 5. Блочная структура построчно: таблицы, вложенные списки, цитаты, линии, абзацы.
  const lines = text.split('\n');
  const out = [];
  let paragraphBuf = [];
  let quoteBuf = [];
  let listStack = []; // {type:'ul'|'ol'|'task', indent:number} — стек открытых уровней вложенности

  const flushParagraph = () => { if (paragraphBuf.length) { out.push(`<p>${paragraphBuf.join('<br>')}</p>`); paragraphBuf = []; } };
  const flushQuote = () => { if (quoteBuf.length) { out.push(`<blockquote>${quoteBuf.join('<br>')}</blockquote>`); quoteBuf = []; } };
  const openListTag = (type) => (type === 'task' ? '<ul class="tasks">' : `<${LIST_TAG[type]}>`);
  const closeAllLists = () => {
    while (listStack.length) {
      out.push('</li>');
      const top = listStack.pop();
      out.push(`</${LIST_TAG[top.type]}>`);
    }
  };
  // Добавляет пункт списка на нужном уровне вложенности, закрывая/открывая
  // уровни по мере необходимости — так поддерживаются произвольно вложенные
  // списки (список внутри списка), а не только плоские.
  const pushListItem = (type, indent, contentHtml) => {
    while (listStack.length && indent < listStack[listStack.length - 1].indent) {
      out.push('</li>');
      const top = listStack.pop();
      out.push(`</${LIST_TAG[top.type]}>`);
    }
    const top = listStack[listStack.length - 1];
    if (top && indent === top.indent) {
      if (top.type !== type) {
        out.push('</li>');
        out.push(`</${LIST_TAG[top.type]}>`);
        listStack.pop();
        out.push(openListTag(type));
        listStack.push({ type, indent });
      } else {
        out.push('</li>');
      }
    } else {
      out.push(openListTag(type));
      listStack.push({ type, indent });
    }
    out.push(`<li>${contentHtml}`);
  };

  const isTableRow = (l) => /\|/.test(l.trim());
  const isTableSep = (l) => /^\s*\|?(\s*:?-{2,}:?\s*\|)+\s*:?-{2,}:?\s*\|?\s*$/.test(l) || /^\s*\|?\s*:?-{2,}:?\s*\|?\s*$/.test(l);
  const splitRow = (l) => {
    let s = l.trim();
    if (s.startsWith('|')) s = s.slice(1);
    if (s.endsWith('|')) s = s.slice(0, -1);
    return s.split('|').map((c) => c.trim());
  };
  const indentOf = (s) => (s || '').replace(/\t/g, '    ').length;

  let i = 0;
  while (i < lines.length) {
    const line = lines[i];

    if (/\u0000BLOCK\d+\u0000/.test(line)) {
      flushParagraph(); flushQuote(); closeAllLists();
      out.push(line);
      i++;
      continue;
    }

    if (line.trim() === '') {
      flushParagraph(); flushQuote(); closeAllLists();
      i++;
      continue;
    }

    if (/^<h[1-6]>/.test(line)) {
      flushParagraph(); flushQuote(); closeAllLists();
      out.push(line);
      i++;
      continue;
    }

    // Заголовок через подчёркивание: "Текст" на предыдущей строке + "===" (h1)
    // или "---" (h2) на этой — альтернативный синтаксис, который тоже иногда
    // встречается в ответах моделей вместо "# Текст".
    if (/^\s*={3,}\s*$/.test(line) && paragraphBuf.length) {
      const heading = paragraphBuf.join(' ');
      paragraphBuf = [];
      out.push(`<h1>${heading}</h1>`);
      i++;
      continue;
    }

    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line) && !isTableRow(lines[i - 1] || '')) {
      if (/^\s*-{3,}\s*$/.test(line) && paragraphBuf.length) {
        const heading = paragraphBuf.join(' ');
        paragraphBuf = [];
        out.push(`<h2>${heading}</h2>`);
        i++;
        continue;
      }
      flushParagraph(); flushQuote(); closeAllLists();
      out.push('<hr>');
      i++;
      continue;
    }

    // Таблица: строка с "|", далее строка-разделитель (---|---), затем строки данных.
    if (isTableRow(line) && lines[i + 1] !== undefined && isTableSep(lines[i + 1])) {
      flushParagraph(); flushQuote(); closeAllLists();
      const header = splitRow(line);
      let j = i + 2;
      const rows = [];
      while (j < lines.length && isTableRow(lines[j]) && !/\u0000BLOCK\d+\u0000/.test(lines[j])) {
        rows.push(splitRow(lines[j]));
        j++;
      }
      const thead = `<thead><tr>${header.map((c) => `<th>${c}</th>`).join('')}</tr></thead>`;
      const tbody = `<tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody>`;
      out.push(`<table>${thead}${tbody}</table>`);
      i = j;
      continue;
    }

    const quote = /^\s*&gt;\s?(.*)$/.exec(line);
    if (quote) {
      flushParagraph(); closeAllLists();
      quoteBuf.push(quote[1]);
      i++;
      continue;
    }
    flushQuote();

    const task = /^(\s*)[-*]\s+\[([ xX])\]\s+(.*)$/.exec(line);
    const ul = !task && /^(\s*)[-*]\s+(.*)$/.exec(line);
    const ol = /^(\s*)\d+[.)]\s+(.*)$/.exec(line);
    if (task) {
      flushParagraph();
      const checked = /x/i.test(task[2]);
      pushListItem('task', indentOf(task[1]), `<input type="checkbox" disabled${checked ? ' checked' : ''}>${task[3]}`);
    } else if (ul) {
      flushParagraph();
      pushListItem('ul', indentOf(ul[1]), ul[2]);
    } else if (ol) {
      flushParagraph();
      pushListItem('ol', indentOf(ol[1]), ol[2]);
    } else {
      closeAllLists();
      paragraphBuf.push(line);
    }
    i++;
  }
  flushParagraph();
  flushQuote();
  closeAllLists();
  text = out.join('\n');

  // 6. Возвращаем блоки кода как оформленные карточки с кнопками копирования/скачивания,
  // а единственный ```question-блок на позиции первого вхождения — как опрос
  // целиком (шаг мастера или, если на всё уже ответили, замороженную сводку).
  // Модель сама решает, что это — если указано имя файла (```lang:filename.ext),
  // это ФАЙЛ: сырой блок прячется, пользователь видит только карточку файла ниже
  // (шаг 7) и открывает предпросмотр кликом по ней. Если имени нет — это просто КОД
  // (фрагмент для примера), он показывается как обычный блок кода, без карточки.
  const firstQuestionBlockIdx = blocks.findIndex((b) => b.isQuestion);
  const allQuestionsAnswered = questionBlocks.length > 0 && questionBlocks.every((qb) => answers[qb.qid] !== undefined);
  let currentQuestionStep = 0;
  if (questionBlocks.length > 0 && !allQuestionsAnswered) {
    while (currentQuestionStep < questionBlocks.length && answers[currentQuestionStep] !== undefined) currentQuestionStep++;
    if (currentQuestionStep >= questionBlocks.length) currentQuestionStep = questionBlocks.length - 1;
  }
  text = text.replace(/\u0000BLOCK(\d+)\u0000/g, (_, idxStr) => {
    const idx = Number(idxStr);
    const b = blocks[idx];
    if (b.isQuestion) {
      if (!questionBlocks.length || idx !== firstQuestionBlockIdx || allQuestionsAnswered) return '';
      return questionStepHtml(questionBlocks[currentQuestionStep], currentQuestionStep, questionBlocks.length, msgIndex);
    }
    const isFile = !!b.filename;
    const escaped = escapeHtml(b.code.replace(/\n$/, ''));
    const ext = (b.filename ? b.filename.split('.').pop() : b.lang) || '';
    const title = b.filename ? b.filename.replace(/\.[^./]+$/, '') : b.lang || 'код';
    const menuLabel = ext ? `Скачать как ${escapeHtml(ext.toUpperCase())}` : 'Скачать';
    if (isFile) return `<div class="codeblock" id="${b.id}" hidden><code>${escaped}</code></div>`;
    if (['text', 'txt', 'md', 'markdown'].includes((b.lang || '').toLowerCase())) {
      return `<div class="text-response-block">${renderMarkdown(b.code, opts)}</div>`;
    }
    return `<div class="codeblock">
      <div class="codeblock-head">
        <span class="codeblock-title">${escapeHtml(title)}${ext ? `<span class="codeblock-dot">·</span><span class="codeblock-ext">${escapeHtml(ext.toUpperCase())}</span>` : ''}</span>
        <div class="codeblock-actions">
          <div class="split-btn">
            <button type="button" class="copy-code" data-target="${b.id}"><span class="icon" style="width:13px;height:13px">${COPY_ICON}</span>Копировать</button>
            <button type="button" class="split-toggle" data-menu="${b.id}" title="Ещё"><span class="icon" style="width:12px;height:12px">${CHEVRON_ICON}</span></button>
          </div>
          <div class="code-menu" data-menu-for="${b.id}" hidden>
            <button type="button" class="download-code" data-target="${b.id}" data-lang="${escapeHtml(ext)}" data-filename="${escapeHtml(b.filename)}"><span class="icon" style="width:13px;height:13px">${DOWNLOAD_ICON}</span>${menuLabel}</button>
          </div>
        </div>
      </div>
      <pre id="${b.id}"><code>${escaped}</code></pre>
    </div>`;
  });

  // 7. Карточки файлов под ответом — по одной на каждый именованный блок
  // (любого языка, не только pdf/pptx/docx/xlsx). Клик по карточке (не по
  // кнопке "Скачать") открывает предпросмотр: документы — как отформатированный
  // текст, код — как код (см. data-doc и openFilePreview в main.js).
  const fileBlocks = blocks.filter((b) => b.filename);
  if (fileBlocks.length) {
    const cards = fileBlocks
      .map((b) => {
        const isDoc = !!DOC_EXT[(b.lang || '').toLowerCase()];
        const ext = (b.filename.split('.').pop() || '').toUpperCase();
        const base = b.filename.replace(/\.[^./]+$/, '');
        return `<div class="file-card" data-block="${b.id}" data-filename="${escapeHtml(base)}" data-ext="${escapeHtml(ext)}" data-doc="${isDoc ? '1' : '0'}" title="Открыть предпросмотр">
          <span class="file-card-icon">${FILE_ICON}</span>
          <div class="file-card-info"><div class="file-card-name">${escapeHtml(base)}</div><div class="file-card-ext">${escapeHtml(ext)}</div></div>
          <button type="button" class="download-code file-card-download" data-target="${b.id}" data-lang="${escapeHtml(ext.toLowerCase())}" data-filename="${escapeHtml(b.filename)}">Скачать</button>
        </div>`;
      })
      .join('');
    text += `<div class="file-cards">${cards}</div>`;
  }

  // 8. Возвращаем экранированные спецсимволы как обычный текст.
  text = text.replace(/\u0001(\d+)\u0001/g, (_, code) => String.fromCharCode(Number(code)));

  return text;
}

use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::Duration;
use std::{io::Read, process::Command};
use tauri::{Emitter, Manager};

#[derive(Deserialize, Serialize, Clone)]
struct ChatMessage {
    role: String,
    content: String,
    // Base64 (без "data:...;base64," префикса) прикреплённых фото — заполняется
    // только для последнего сообщения пользователя и только в локальном режиме;
    // передаём модели, если та умеет "видеть" (Mentis 3).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    images: Vec<String>,
}
#[derive(Deserialize)]
struct ChatRequest {
    provider: String,
    model: String,
    messages: Vec<ChatMessage>,
    #[serde(default)]
    think: Option<bool>,
    #[serde(default)]
    web_search: Option<bool>,
    #[serde(default)]
    temperature: Option<f64>,
    // Раньше передавался в Ollama как options.num_ctx; локальный сервер AmIgo
    // теперь сам задаёт размер контекста при запуске (см. spawn_local_server),
    // поле оставлено для совместимости с фронтендом, но не используется.
    #[serde(default)]
    #[allow(dead_code)]
    num_ctx: Option<u32>,
    // Идентификатор диалога на фронтенде (Date.now() в виде строки) — нужен,
    // чтобы у каждого чата была своя отдельная песочница файлов на диске.
    #[serde(default)]
    chat_id: String,
}
#[derive(Serialize, Clone)]
struct ChatChunk {
    content: String,
}

// Отправляется во фронтенд событием "chat-status" при переходах между
// «фоновыми» состояниями ответа, которые сами по себе не являются текстом
// ответа: kind:"thinking" — модель рассуждает до того как начнёт печатать
// финальный текст. active:true — состояние началось, active:false — закончилось.
#[derive(Serialize, Clone)]
struct StatusEvent {
    kind: String,
    active: bool,
}

// Отправляется во фронтенд событием "chat-search": сперва с done:false
// (сам факт поиска — фронтенд показывает мерцающую подпись «Поиск в
// интернете»), затем с done:true и списком источников.
#[derive(Serialize, Clone)]
struct SearchSource {
    title: String,
    url: String,
    #[serde(skip_serializing)]
    content: String,
}
#[derive(Serialize, Clone)]
struct SearchEvent {
    query: String,
    sources: Vec<SearchSource>,
    done: bool,
}

// stop            — флаг «нажали Стоп», прерывает текущий поток генерации.
// busy            — генерация сейчас идёт (не убиваем сервер, пока это true).
// active_model    — какую локальную модель выбрал пользователь сейчас (id).
// local_server    — дочерний процесс llama-server (движок AmIgo).
// server_ready    — сервер запустился и отвечает на /health.
// downloading_files — имена файлов моделей, которые прямо сейчас скачиваются.
// Локальные модели могут докачиваться параллельно (например, обе сразу при первом
// запуске), а черновая модель текстового режима Mentis 3 — это тот же файл,
// что и основная модель Nage 1.5 (см. model_defs). Без этой защиты
// параллельный запуск download_model для обеих моделей мог бы дважды
// одновременно писать в один и тот же файл на диске и испортить его.
struct ChatState {
    stop: AtomicBool,
    busy: AtomicBool,
    pending_unload: AtomicBool,
    active_model: Mutex<Option<String>>,
    local_server: Mutex<Option<std::process::Child>>,
    server_ready: AtomicBool,
    // Запрошено ли ускорение и подтвердил ли успешный /health его запуск.
    server_draft_requested: AtomicBool,
    server_speculative: AtomicBool,
    downloading_files: Mutex<std::collections::HashSet<String>>,
    // В каком режиме реально запущен текущий сервер — только для Mentis 3
    // (у неё есть оба режима, см. spawn_local_server); true = зрение
    // (--mmproj), false = ускорение (--model-draft). Для Nage 1.5 не имеет
    // значения. Используется, чтобы понять, нужен ли перезапуск сервера
    // перед конкретным запросом (см. ensure_server_mode).
    server_vision_mode: AtomicBool,
}
impl Default for ChatState {
    fn default() -> Self {
        Self {
            stop: AtomicBool::new(false),
            busy: AtomicBool::new(false),
            pending_unload: AtomicBool::new(false),
            active_model: Mutex::new(None),
            local_server: Mutex::new(None),
            server_ready: AtomicBool::new(false),
            server_draft_requested: AtomicBool::new(false),
            server_speculative: AtomicBool::new(false),
            downloading_files: Mutex::new(std::collections::HashSet::new()),
            server_vision_mode: AtomicBool::new(false),
        }
    }
}

fn keychain_get() -> Result<String, String> {
    let out = Command::new("security")
        .args([
            "find-generic-password",
            "-s",
            "AmIgo.Groq.API",
            "-a",
            "groq",
            "-w",
        ])
        .output()
        .map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
    } else {
        Err("Ключ Groq не найден. Добавьте его в настройках.".into())
    }
}

#[tauri::command]
fn save_groq_key(key: String) -> Result<(), String> {
    if !key.starts_with("gsk_") {
        return Err("Ключ Groq обычно начинается с gsk_. Проверьте его.".into());
    }
    let ok = Command::new("security")
        .args([
            "add-generic-password",
            "-U",
            "-s",
            "AmIgo.Groq.API",
            "-a",
            "groq",
            "-w",
            &key,
        ])
        .status()
        .map_err(|e| e.to_string())?
        .success();
    if ok {
        Ok(())
    } else {
        Err("Не удалось сохранить ключ в Связке ключей macOS.".into())
    }
}

// Ключ Tavily (бесплатный поиск в интернете, 1000 запросов/мес) хранится
// в Связке ключей ровно так же, как ключ Groq. Отсутствие ключа — не
// ошибка: chat_stream_inner просто не предлагает модели инструмент поиска.
fn keychain_get_tavily() -> Result<String, String> {
    let out = Command::new("security")
        .args([
            "find-generic-password",
            "-s",
            "AmIgo.Tavily.API",
            "-a",
            "tavily",
            "-w",
        ])
        .output()
        .map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
    } else {
        Err("Ключ Tavily не найден.".into())
    }
}

#[tauri::command]
fn save_tavily_key(key: String) -> Result<(), String> {
    let key = key.trim().to_string();
    if !key.starts_with("tvly-") {
        return Err("Ключ Tavily обычно начинается с tvly-. Проверьте его.".into());
    }
    let ok = Command::new("security")
        .args([
            "add-generic-password",
            "-U",
            "-s",
            "AmIgo.Tavily.API",
            "-a",
            "tavily",
            "-w",
            &key,
        ])
        .status()
        .map_err(|e| e.to_string())?
        .success();
    if ok {
        Ok(())
    } else {
        Err("Не удалось сохранить ключ в Связке ключей macOS.".into())
    }
}

#[tauri::command]
fn has_tavily_key() -> bool {
    keychain_get_tavily().is_ok()
}

// Останавливает генерацию, которая сейчас идёт (кнопка "Стоп" в интерфейсе).
#[tauri::command]
fn stop_generation(state: tauri::State<'_, ChatState>) {
    state.stop.store(true, Ordering::SeqCst);
}

// ─── Локальный движок AmIgo (встроенный llama-server) ──────────────────────
// Три локальные модели: Mentis 3 (Qwen3-VL:8B, понимает фото) и
// Nage 1.5 (Qwen3:0.6B, только текст, самая быстрая). У Mentis 3 два режима
// работы (см. ensure_server_mode) — быстрый текстовый со спекулятивным
// декодированием по умолчанию, и режим зрения (без ускорения), в который
// сервер сам переключается перед конкретным сообщением, если в нём есть
// фото: llama-server отказывается стартовать, если одновременно заданы
// --mmproj и --model-draft (см. комментарий у model_defs ниже).
// Веса — обычные GGUF-файлы, скачиваются напрямую с Hugging Face при первом
// выборе модели и хранятся в Application Support, без Ollama и без MLX.
const LOCAL_PORT: u16 = 8081;

#[derive(Clone, Copy)]
struct ModelFile {
    label: &'static str,
    filename: &'static str,
    url: &'static str,
}

#[derive(Clone, Copy)]
struct ModelDef {
    id: &'static str,
    draft_required: bool,
    main: ModelFile,
    mmproj: Option<ModelFile>,
    draft: Option<ModelFile>,
}

fn model_defs() -> [ModelDef; 3] {
    // URL привязаны к конкретному коммиту репозитория (а не к ветке main).
    // main — плавающая ссылка: если Qwen когда-нибудь переименует, перезальёт
    // или удалит файл в основной ветке, все уже собранные .dmg сломаются на
    // ровном месте у всех, кому вы их передали. Коммит — неизменяемый снимок:
    // даже если репозиторий обновится, старая ссылка продолжит отдавать
    // ровно тот же файл. Проверено вручную по состоянию на 8 августа 2026:
    //   Qwen/Qwen3-VL-8B-Instruct-GGUF @ f982a07559d4a2f6c8744d840bf6fccab30eea96
    //   Qwen/Qwen3-0.6B-GGUF           @ 23749fefcc72300e3a2ad315e1317431b06b590a
    // В официальном репозитории Qwen3-0.6B-GGUF есть только Q8_0 (639 МБ) —
    // Q4_K_M там не публиковали, несмотря на то что для 8B-версии он есть.
    [
    ModelDef {
      id: "mentis-3",
      draft_required: false,
      main: ModelFile {
        label: "Mentis 3",
        filename: "Qwen3VL-8B-Instruct-Q4_K_M.gguf",
        url: "https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct-GGUF/resolve/f982a07559d4a2f6c8744d840bf6fccab30eea96/Qwen3VL-8B-Instruct-Q4_K_M.gguf",
      },
      mmproj: Some(ModelFile {
        label: "Mentis 3 (модуль зрения)",
        filename: "mmproj-Qwen3VL-8B-Instruct-F16.gguf",
        url: "https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct-GGUF/resolve/f982a07559d4a2f6c8744d840bf6fccab30eea96/mmproj-Qwen3VL-8B-Instruct-F16.gguf",
      }),
      // Спекулятивное декодирование (--model-draft) и --mmproj (зрение)
      // одновременно НЕ поддерживаются самим llama-server — сервер прямо
      // отказывается стартовать с ошибкой "speculative decoding is not
      // supported with multimodal" (подтверждено issue в репозитории
      // llama.cpp, 18 февраля 2026). Оба флага по отдельности работают —
      // поэтому Mentis 3 запускается в ДВУХ режимах, переключаясь
      // автоматически по факту наличия фото в сообщении (см.
      // spawn_local_server/ensure_server_mode ниже): по умолчанию —
      // быстрый текстовый (с этой черновой моделью), а как только в
      // сообщении реально есть фото — сервер перезапускается в режиме
      // зрения (mmproj, без черновой модели) прямо перед отправкой запроса.
      draft: Some(ModelFile {
        label: "Mentis 3 (черновая модель для текстового режима)",
        filename: "Qwen3-0.6B-Q8_0.gguf",
        url: "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/23749fefcc72300e3a2ad315e1317431b06b590a/Qwen3-0.6B-Q8_0.gguf",
      }),
    },
    ModelDef {
      id: "mentis-2.5",
      draft_required: true,
      main: ModelFile {
        label: "Mentis 2.5",
        filename: "Qwen3-8B-Q4_K_M.gguf",
        url: "https://huggingface.co/Qwen/Qwen3-8B-GGUF/resolve/7c41481f57cb95916b40956ab2f0b139b296d974/Qwen3-8B-Q4_K_M.gguf",
      },
      mmproj: None,
      draft: Some(ModelFile {
        label: "Mentis 2.5 (draft-модель)",
        filename: "Qwen3-0.6B-Q8_0.gguf",
        url: "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/23749fefcc72300e3a2ad315e1317431b06b590a/Qwen3-0.6B-Q8_0.gguf",
      }),
    },
    ModelDef {
      id: "nage-1.5",
      draft_required: false,
      main: ModelFile {
        label: "Nage 1.5",
        filename: "Qwen3-0.6B-Q8_0.gguf",
        url: "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/23749fefcc72300e3a2ad315e1317431b06b590a/Qwen3-0.6B-Q8_0.gguf",
      },
      mmproj: None,
      draft: None,
    },
  ]
}

fn find_model_def(id: &str) -> Option<ModelDef> {
    model_defs().into_iter().find(|m| m.id == id)
}

fn models_dir() -> std::path::PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    std::path::PathBuf::from(format!("{home}/Library/Application Support/AmIgo/models"))
}

fn model_file_path(f: &ModelFile) -> std::path::PathBuf {
    models_dir().join(f.filename)
}

// Готова ли модель к запуску: все нужные ей файлы (основной + при наличии
// mmproj/draft) уже лежат на диске.
fn valid_gguf_file(file: &ModelFile) -> bool {
    let path = model_file_path(file);
    let Ok(meta) = std::fs::metadata(&path) else {
        return false;
    };
    if meta.len() < 1_000_000 {
        return false;
    }
    let Ok(mut f) = std::fs::File::open(path) else {
        return false;
    };
    let mut magic = [0u8; 4];
    f.read_exact(&mut magic).is_ok() && &magic == b"GGUF"
}

fn model_ready(def: &ModelDef) -> bool {
    valid_gguf_file(&def.main)
        && def.mmproj.as_ref().map(valid_gguf_file).unwrap_or(true)
        && def.draft.as_ref().map(valid_gguf_file).unwrap_or(true)
}

#[derive(Serialize)]
struct ModelStatus {
    id: String,
    downloaded: bool,
}

#[tauri::command]
fn list_models() -> Vec<ModelStatus> {
    model_defs()
        .iter()
        .map(|d| ModelStatus {
            id: d.id.to_string(),
            downloaded: model_ready(d),
        })
        .collect()
}

// Скачивает один файл потоково, с прогрессом (событие "download-progress"),
// во временный ".part", и только по завершении переименовывает в целевой
// файл — чтобы оборванная закачка не выглядела как «модель уже скачана».
//
// Mentis 3 и Nage 1.5 могут скачиваться ОДНОВРЕМЕННО (обе сразу при первом
// запуске приложения), причём файл Qwen3-0.6B используется и как Nage 1.5,
// и как draft-модель Mentis 3. Два параллельных вызова не должны писать в
// один файл одновременно: второй ждёт завершения первого.
async fn download_file(
    app: &tauri::AppHandle,
    state: &ChatState,
    model_id: &str,
    file_label: &str,
    url: &str,
    dest: &std::path::Path,
) -> Result<(), String> {
    if dest.exists() {
        return Ok(());
    }
    let filename = dest
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();

    loop {
        // MutexGuard обязан выйти из области видимости ДО await: async-команды
        // Tauri должны быть Send, а std::sync::MutexGuard между потоками не
        // переносится. Отдельный блок делает это однозначным для компилятора.
        let acquired = {
            let mut guard = state.downloading_files.lock().unwrap();
            if guard.contains(&filename) {
                false
            } else {
                guard.insert(filename.clone());
                true
            }
        };
        if acquired {
            break;
        }
        // Этот файл уже качает другой вызов (другая модель) — подождём и
        // проверим снова, вместо того чтобы писать поверх того же файла.
        tokio::time::sleep(Duration::from_millis(300)).await;
        if dest.exists() {
            return Ok(());
        }
    }

    let result: Result<(), String> = async {
        if let Some(parent) = dest.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("Не удалось создать папку моделей: {e}"))?;
        }
        let part = std::path::PathBuf::from(format!("{}.part", dest.display()));
        let client = reqwest::Client::new();

        // Докачка: если .part уже частично скачан (например, приложение
        // закрыли посреди загрузки в прошлый раз), продолжаем с того места,
        // а не начинаем заново с нуля — экономит и время, и трафик.
        let already: u64 = std::fs::metadata(&part).map(|m| m.len()).unwrap_or(0);
        let mut builder = client.get(url).timeout(Duration::from_secs(120));
        if already > 0 {
            builder = builder.header("Range", format!("bytes={already}-"));
        }
        let resp = builder.send().await.map_err(|e| {
            format!(
                "Не удалось начать скачивание «{file_label}»: {e}. Проверьте интернет-соединение."
            )
        })?;

        // 206 Partial Content — сервер принял докачку с нужного места.
        // 200 OK при запрошенном Range — сервер докачку не поддержал и всё
        // равно шлёт файл с начала; тогда просто начинаем .part заново.
        let resuming = already > 0 && resp.status() == reqwest::StatusCode::PARTIAL_CONTENT;
        if !resp.status().is_success() && resp.status() != reqwest::StatusCode::PARTIAL_CONTENT {
            return Err(format!(
                "Сервер моделей вернул ошибку при скачивании «{file_label}»: {}",
                resp.status()
            ));
        }

        let content_len = resp.content_length().unwrap_or(0);
        let total = if resuming {
            already + content_len
        } else {
            content_len
        };
        let mut downloaded: u64 = if resuming { already } else { 0 };

        use std::io::Write;
        let mut file = if resuming {
            std::fs::OpenOptions::new()
                .append(true)
                .open(&part)
                .map_err(|e| format!("Не удалось продолжить файл модели: {e}"))?
        } else {
            std::fs::File::create(&part)
                .map_err(|e| format!("Не удалось создать файл модели: {e}"))?
        };

        // Сообщаем текущий прогресс сразу — если докачиваем большой файл, не
        // ждём первого чанка, чтобы прогресс-бар не начинался с нуля визуально.
        let _ = app.emit(
            "download-progress",
            serde_json::json!({
              "model": model_id, "file": file_label, "downloaded": downloaded, "total": total
            }),
        );

        let mut stream = resp.bytes_stream();
        while let Some(chunk) = stream.next().await {
            let bytes = chunk
                .map_err(|e| format!("Обрыв соединения при скачивании «{file_label}»: {e}"))?;
            file.write_all(&bytes)
                .map_err(|e| format!("Не удалось записать файл модели: {e}"))?;
            downloaded += bytes.len() as u64;
            let _ = app.emit(
                "download-progress",
                serde_json::json!({
                  "model": model_id, "file": file_label, "downloaded": downloaded, "total": total
                }),
            );
        }
        drop(file);
        std::fs::rename(&part, dest)
            .map_err(|e| format!("Не удалось сохранить файл модели: {e}"))?;
        Ok(())
    }
    .await;

    state.downloading_files.lock().unwrap().remove(&filename);
    result
}

// Скачивает все файлы, нужные выбранной модели (для Mentis 3 — основную
// модель, модуль зрения и черновую модель для быстрого текстового режима;
// для Nage 1.5 — только её саму, это тот же файл, что и черновая модель
// Mentis 3, — дедуплицируется по имени файла, не качается дважды).
#[tauri::command]
async fn download_model(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    model: String,
) -> Result<(), String> {
    let def = find_model_def(&model).ok_or("Неизвестная модель")?;
    // Не даём App Nap/сну системы заморозить сетевую загрузку. Экран при этом
    // может быть выключен: флаг -d намеренно не используется.
    let mut activity = Command::new("caffeinate").args(["-i", "-s"]).spawn().ok();
    let result: Result<(), String> = async {
        let mut files: Vec<ModelFile> = vec![def.main];
        if let Some(f) = def.mmproj {
            files.push(f);
        }
        if let Some(f) = def.draft {
            if !files.iter().any(|x| x.filename == f.filename) {
                files.push(f);
            }
        }
        for f in files {
            let dest = model_file_path(&f);
            download_file(&app, &state, &model, f.label, f.url, &dest).await?;
        }
        let _ = app.emit("download-done", serde_json::json!({ "model": model }));
        Ok(())
    }
    .await;
    if let Some(child) = activity.as_mut() {
        let _ = child.kill();
        let _ = child.wait();
    }
    result
}

// Ищет бинарник llama-server — сначала внутри самого приложения (см.
// tauri.conf.json → bundle.resources, кладётся туда сборочным скриптом),
// затем, для разработки, в стандартных путях Homebrew.
fn find_llama_server(app: &tauri::AppHandle) -> Option<std::path::PathBuf> {
    if let Ok(p) = app
        .path()
        .resolve("bin/llama-server", tauri::path::BaseDirectory::Resource)
    {
        if p.exists() {
            return Some(p);
        }
    }
    [
        "/opt/homebrew/bin/llama-server",
        "/usr/local/bin/llama-server",
        "/opt/homebrew/opt/llama.cpp/bin/llama-server",
        "/usr/local/opt/llama.cpp/bin/llama-server",
    ]
    .iter()
    .map(std::path::PathBuf::from)
    .find(|p| p.exists())
}

// Запускает llama-server для выбранной модели.
// -ngl 99 — выгружаем все слои на Metal GPU (Apple Silicon).
// --jinja  — включает разбор чат-шаблона модели через jinja (см. рекомендацию
// самой Qwen для запуска их GGUF-моделей); нужно и для рассуждений, и для
// вызова инструментов (поиск) в новом OpenAI-режиме локального движка.
// --ctx-size 16384 — то же значение, что было в исходно проверенной версии
// спекулятивного декодирования.
// use_vision выбирает, какой из двух флагов передать — --mmproj или
// --model-draft — никогда оба сразу (llama-server отказывается стартовать
// с ошибкой "speculative decoding is not supported with multimodal", см.
// комментарий у model_defs). Кто вызывает с каким значением — см.
// ensure_server_mode (переключение под конкретное сообщение) и
// switch_model/warm_model (запуск по умолчанию в текстовом режиме).
// Объём ОЗУ конкретного Mac — используется, чтобы на базовых конфигурациях
// (8 ГБ, всё ещё продаётся новым в MacBook Air) не рисковать нехваткой
// памяти вместе с самой macOS и остальными открытыми программами. На 16 ГБ+
// ничего не меняется — это ровно та настройка, что уже была проверена.
fn system_ram_gb() -> u64 {
    Command::new("sysctl")
        .args(["-n", "hw.memsize"])
        .output()
        .ok()
        .and_then(|o| {
            String::from_utf8_lossy(&o.stdout)
                .trim()
                .parse::<u64>()
                .ok()
        })
        .map(|bytes| bytes / 1_000_000_000)
        .unwrap_or(16) // не удалось узнать — считаем "обычный" Mac, ничего не режем
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ServerProfile {
    Optimized,
    CompatibleGpu,
    CpuFallback,
}

// use_vision:
//  - true  — грузим --mmproj (зрение); --model-draft не передаём вообще.
//  - false — грузим --model-draft (ускорение), если он есть у модели;
//            --mmproj не передаём. Для Nage 1.5 (нет ни того, ни другого)
//            оба варианта дают одинаковый запуск — параметр не важен.
// Совмещать оба флага нельзя: llama-server откажется стартовать
// ("speculative decoding is not supported with multimodal").
fn spawn_local_server(
    srv: &std::path::Path,
    def: &ModelDef,
    use_vision: bool,
    use_draft: bool,
    profile: ServerProfile,
) -> Result<std::process::Child, String> {
    let main_path = model_file_path(&def.main);
    let ram = system_ram_gb();
    let ctx_size = if ram <= 8 {
        "4096"
    } else if ram <= 16 {
        "8192"
    } else {
        "16384"
    };
    let draft_tokens = if ram <= 8 { "3" } else { "5" };
    // Убираем оставшийся от старой/аварийно закрытой копии AmIgo сервер,
    // если именно llama-server всё ещё занимает наш фиксированный порт.
    if let Ok(out) = Command::new("lsof")
        .args(["-nP", &format!("-iTCP:{LOCAL_PORT}"), "-sTCP:LISTEN", "-t"])
        .output()
    {
        for pid in String::from_utf8_lossy(&out.stdout).lines() {
            let is_llama = Command::new("ps")
                .args(["-p", pid, "-o", "comm="])
                .output()
                .ok()
                .map(|o| String::from_utf8_lossy(&o.stdout).contains("llama-server"))
                .unwrap_or(false);
            if is_llama {
                let _ = Command::new("kill").arg(pid).status();
            }
        }
    }

    let mut cmd = std::process::Command::new(srv);
    cmd.args([
        "--model",
        main_path.to_str().unwrap_or(""),
        "--ctx-size",
        ctx_size,
        "--host",
        "127.0.0.1",
        "--port",
        &LOCAL_PORT.to_string(),
        "--metrics",
    ]);
    match profile {
        ServerProfile::Optimized => {
            cmd.args([
                "-ngl",
                "99",
                "--jinja",
                "--flash-attn",
                "on",
                "--cache-reuse",
                "256",
            ]);
        }
        ServerProfile::CompatibleGpu => {
            // Spec decoding остаётся включён, убираем только необязательные
            // оптимизации, которые менялись между версиями llama.cpp.
            cmd.args(["-ngl", "99", "--jinja"]);
        }
        ServerProfile::CpuFallback => {
            // Последняя страховка для ответа без Metal; draft сюда не передаётся.
            cmd.args(["-ngl", "0", "--jinja"]);
        }
    }
    if use_vision {
        if let Some(f) = &def.mmproj {
            let p = model_file_path(f);
            cmd.arg("--mmproj").arg(p);
        }
    } else if use_draft {
        if let Some(f) = &def.draft {
            let p = model_file_path(f);
            // В актуальном llama.cpp старый --draft-n удалён: его наличие приводит
            // к немедленному завершению llama-server. Используем современный набор
            // параметров и явно включаем draft-simple (по умолчанию --spec-type none).
            // Для старых встроенных бинарников оставляем совместимый fallback.
            let help = Command::new(srv)
                .arg("--help")
                .output()
                .ok()
                .map(|o| {
                    format!(
                        "{}{}",
                        String::from_utf8_lossy(&o.stdout),
                        String::from_utf8_lossy(&o.stderr)
                    )
                })
                .unwrap_or_default();
            if help.contains("--spec-draft-n-max") && help.contains("draft-simple") {
                cmd.args([
                    "--spec-type",
                    "draft-simple",
                    "--spec-draft-n-max",
                    draft_tokens,
                    "--spec-draft-model",
                ])
                .arg(p);
                if help.contains("--spec-draft-ngl") {
                    cmd.args(["--spec-draft-ngl", "99"]);
                }
                if help.contains("--spec-draft-p-min") {
                    cmd.args(["--spec-draft-p-min", "0.8"]);
                }
            } else {
                cmd.args(["--draft-n", draft_tokens, "--model-draft"])
                    .arg(p);
            }
        }
    }
    let log_path = models_dir().join("llama-server.log");
    let stderr = std::fs::File::create(log_path)
        .map(std::process::Stdio::from)
        .unwrap_or_else(|_| std::process::Stdio::null());
    cmd.stdout(std::process::Stdio::null()).stderr(stderr);
    cmd.spawn().map_err(|e| {
        format!(
            "Не удалось запустить локальный движок AmIgo: {e}. Попробуйте пересобрать приложение."
        )
    })
}

// Убивает текущий локальный сервер (при смене модели / сворачивании / закрытии).
fn kill_local_server(state: &ChatState) {
    state.server_ready.store(false, Ordering::SeqCst);
    state.server_draft_requested.store(false, Ordering::SeqCst);
    state.server_speculative.store(false, Ordering::SeqCst);
    if let Ok(mut guard) = state.local_server.lock() {
        if let Some(mut child) = guard.take() {
            // SIGTERM даёт llama-server записать статистику speculative decoding.
            let _ = Command::new("kill")
                .args(["-TERM", &child.id().to_string()])
                .status();
            let mut exited = false;
            for _ in 0..20 {
                if child.try_wait().ok().flatten().is_some() {
                    exited = true;
                    break;
                }
                std::thread::sleep(Duration::from_millis(50));
            }
            if !exited {
                let _ = child.kill();
            }
            let _ = child.wait();
        }
    }
}

fn start_local_server(
    app: &tauri::AppHandle,
    state: &ChatState,
    def: &ModelDef,
    model: &str,
    use_vision: bool,
    use_draft: bool,
    profile: ServerProfile,
) -> Result<(), String> {
    kill_local_server(state);
    let srv = find_llama_server(app).ok_or("Не найден движок AmIgo внутри приложения.")?;
    let child = spawn_local_server(&srv, def, use_vision, use_draft, profile)?;
    *state.active_model.lock().unwrap() = Some(model.to_string());
    state.server_vision_mode.store(use_vision, Ordering::SeqCst);
    state
        .server_draft_requested
        .store(use_draft, Ordering::SeqCst);
    state.server_speculative.store(false, Ordering::SeqCst);
    *state.local_server.lock().unwrap() = Some(child);
    Ok(())
}

// Опрашивает /health в фоне. Это только внутреннее состояние: при медленной
// загрузке никаких уведомлений «не запустилась за N секунд» пользователю не
// показываем. Реальный запрос сам дождётся готовности через ensure_server_mode.
fn watch_server_ready(app: tauri::AppHandle) {
    tauri::async_runtime::spawn(async move {
        let state = app.state::<ChatState>();
        let client = reqwest::Client::new();
        let url = format!("http://127.0.0.1:{LOCAL_PORT}/health");
        for _ in 0..600 {
            tokio::time::sleep(Duration::from_millis(500)).await;
            let process_alive = state.local_server.lock().unwrap().is_some();
            if !process_alive {
                return;
            }
            if let Ok(r) = client
                .get(&url)
                .timeout(Duration::from_millis(700))
                .send()
                .await
            {
                if r.status().is_success() {
                    state.server_ready.store(true, Ordering::SeqCst);
                    // Если процесс принял draft-флаги, загрузил обе модели и
                    // дошёл до /health, speculative decoding активен. Не зависим
                    // от нестабильной схемы /props разных версий llama.cpp.
                    let draft_active = state.server_draft_requested.load(Ordering::SeqCst);
                    state
                        .server_speculative
                        .store(draft_active, Ordering::SeqCst);
                    let _ = app.emit("server-status", serde_json::json!({"ready": true}));
                    return;
                }
            }
        }
        state.server_ready.store(false, Ordering::SeqCst);
    });
}

// Переключение модели: убивает предыдущий локальный сервер, обновляет
// active_model, запускает новый сервер под выбранную модель (если она уже
// скачана) и ждёт его готовности. Если модель ещё не скачана — фронтенд
// должен сначала вызвать download_model (ошибка "not_downloaded" — сигнал).
// По умолчанию запускаем в быстром текстовом режиме (с ускорением, если
// оно есть у модели) — в режим зрения переключаемся отдельно, только когда
// в конкретном сообщении реально есть фото (см. ensure_server_mode).
#[tauri::command]
async fn switch_model(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    provider: String,
    model: String,
) -> Result<(), String> {
    let previous = state.active_model.lock().unwrap().clone();
    if provider != "local" || model.trim().is_empty() {
        kill_local_server(&state);
        *state.active_model.lock().unwrap() = None;
        return Ok(());
    }
    let def = find_model_def(&model).ok_or("Неизвестная модель")?;
    if !model_ready(&def) {
        return Err("not_downloaded".into());
    }
    let expected_draft = def.draft.is_some();
    let already_default_text = previous.as_deref() == Some(model.as_str())
        && state.local_server.lock().unwrap().is_some()
        && !state.server_vision_mode.load(Ordering::SeqCst)
        && state.server_draft_requested.load(Ordering::SeqCst) == expected_draft;
    // Для Mentis 3 выбор модели всегда означает текстовый сервер с draft.
    // Если до этого был режим зрения или fallback без draft — перезапускаем.
    if already_default_text {
        return Ok(());
    }
    start_local_server(
        &app,
        &state,
        &def,
        &model,
        false,
        def.draft.is_some(),
        ServerProfile::Optimized,
    )?;
    watch_server_ready(app.clone());
    let _ = app.emit("server-status", serde_json::json!({"starting": true}));
    Ok(())
}

// Подгревает (перезапускает) сервер для уже выбранной модели, если он не
// запущен — используется при возврате в приложение после сворачивания.
// Тихо ничего не делает, если модель не скачана или сервер уже поднят.
// Как и switch_model — по умолчанию быстрый текстовый режим.
#[tauri::command]
async fn warm_model(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    model: String,
) -> Result<(), String> {
    let def = match find_model_def(&model) {
        Some(d) => d,
        None => return Ok(()),
    };
    if !model_ready(&def) {
        return Ok(());
    }
    let expected_draft = def.draft.is_some();
    let already_default_text = state.local_server.lock().unwrap().is_some()
        && !state.server_vision_mode.load(Ordering::SeqCst)
        && state.server_draft_requested.load(Ordering::SeqCst) == expected_draft;
    if already_default_text {
        return Ok(());
    }
    if start_local_server(
        &app,
        &state,
        &def,
        &model,
        false,
        def.draft.is_some(),
        ServerProfile::Optimized,
    )
    .is_ok()
    {
        watch_server_ready(app.clone());
    }
    Ok(())
}

async fn warm_active_model(app: &tauri::AppHandle, state: &ChatState) {
    let model = state.active_model.lock().unwrap().clone();
    if let Some(model) = model {
        let _ = warm_model(app.clone(), app.state::<ChatState>(), model).await;
    }
}

// Перед отправкой запроса к локальной модели проверяет, нужен ли для ЭТОГО
// КОНКРЕТНОГО сообщения режим зрения (есть фото), и если запущенный сейчас
// сервер в другом режиме — перезапускает его в нужном и ждёт готовности
// прямо здесь (запрос ниже отправится только после этого). Для моделей без
// обоих режимов (сейчас — Nage 1.5) или уже находящихся в нужном режиме —
// не делает ничего, без лишней задержки.
async fn ensure_server_mode(
    app: &tauri::AppHandle,
    state: &ChatState,
    model: &str,
    needs_vision: bool,
) -> Result<(), String> {
    let def = find_model_def(model).ok_or("Неизвестная локальная модель")?;
    let mode_matters = def.mmproj.is_some() && def.draft.is_some();
    let desired_vision = mode_matters && needs_vision;
    let desired_draft = !desired_vision && def.draft.is_some();
    let active_same = state.active_model.lock().unwrap().as_deref() == Some(model);
    let process_exists = state.local_server.lock().unwrap().is_some();
    let mode_same =
        !mode_matters || state.server_vision_mode.load(Ordering::SeqCst) == desired_vision;
    let draft_same = state.server_draft_requested.load(Ordering::SeqCst) == desired_draft;

    if !(active_same && process_exists && mode_same && draft_same) {
        start_local_server(
            app,
            state,
            &def,
            model,
            desired_vision,
            desired_draft,
            ServerProfile::Optimized,
        )?;
    } else if state.server_ready.load(Ordering::SeqCst)
        && (!desired_draft || state.server_speculative.load(Ordering::SeqCst))
    {
        return Ok(());
    }

    let client = reqwest::Client::new();
    let health_url = format!("http://127.0.0.1:{LOCAL_PORT}/health");
    let mut tried_compatible = false;
    let mut tried_gpu_without_draft = false;
    let mut tried_cpu = false;

    for _ in 0..600 {
        if state.stop.load(Ordering::SeqCst) {
            return Ok(());
        }
        let exited = state
            .local_server
            .lock()
            .unwrap()
            .as_mut()
            .and_then(|child| child.try_wait().ok().flatten())
            .is_some();

        if exited {
            if !tried_compatible {
                tried_compatible = true;
                start_local_server(
                    app,
                    state,
                    &def,
                    model,
                    desired_vision,
                    desired_draft,
                    ServerProfile::CompatibleGpu,
                )?;
                continue;
            }
            if desired_draft && !def.draft_required && !tried_gpu_without_draft {
                tried_gpu_without_draft = true;
                start_local_server(
                    app,
                    state,
                    &def,
                    model,
                    false,
                    false,
                    ServerProfile::CompatibleGpu,
                )?;
                continue;
            }
            if !def.draft_required && !tried_cpu {
                tried_cpu = true;
                start_local_server(
                    app,
                    state,
                    &def,
                    model,
                    desired_vision,
                    false,
                    ServerProfile::CpuFallback,
                )?;
                continue;
            }
            return Err("connection_error: Локальный движок завершился при запуске.".into());
        }

        if let Ok(r) = client
            .get(&health_url)
            .timeout(Duration::from_millis(700))
            .send()
            .await
        {
            if r.status().is_success() {
                state.server_ready.store(true, Ordering::SeqCst);
                if state.server_draft_requested.load(Ordering::SeqCst) {
                    // Не читаем /props: его схема меняется между сборками.
                    // Успешный /health после загрузки draft-модели подтверждает режим.
                    state.server_speculative.store(true, Ordering::SeqCst);
                }
                return Ok(());
            }
        }
        tokio::time::sleep(Duration::from_millis(500)).await;
    }
    Err("connection_error: Локальный движок не смог подготовиться к запросу.".into())
}

// Если генерация сейчас идёт — дожидается её завершения (максимум ~10 минут на
// случай долгого ответа), затем убивает сервер. Используется при закрытии
// приложения, чтобы модель успела доделать текущий ответ перед выходом.
async fn finish_then_unload(state: &ChatState) {
    for _ in 0..6000 {
        if !state.busy.load(Ordering::SeqCst) {
            break;
        }
        tokio::time::sleep(Duration::from_millis(100)).await;
    }
    kill_local_server(state);
}

// Дневной потолок реальных обращений к Tavily — хранится на диске, поэтому
// действует независимо от того, сколько открыто диалогов и сколько раз
// перезапускалось приложение за день. Смысл не в точной бухгалтерии, а в
// защите от сценария "что-то сломалось / модель слишком активно ищет" —
// без этого потолка один неудачный день мог бы в одиночку съесть весь
// месячный бесплатный лимит Tavily (1000 запросов/мес ≈ 33/день в среднем;
// 40/день ниже оставляет запас на обычные дни active use, но не даёт уйти
// в разнос). Значение можно изменить здесь при необходимости.
const DAILY_SEARCH_LIMIT: u32 = 40;

fn search_usage_path() -> std::path::PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    std::path::PathBuf::from(format!(
        "{home}/Library/Application Support/AmIgo/search_usage.txt"
    ))
}

fn today_str() -> String {
    Command::new("date")
        .arg("+%Y-%m-%d")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_default()
}

fn check_and_spend_search_budget() -> Result<(), String> {
    let path = search_usage_path();
    let today = today_str();
    let (saved_date, count) = std::fs::read_to_string(&path)
        .ok()
        .and_then(|s| {
            let mut parts = s.trim().splitn(2, ' ');
            let d = parts.next()?.to_string();
            let n = parts.next()?.parse::<u32>().ok()?;
            Some((d, n))
        })
        .unwrap_or_default();
    let count = if saved_date == today { count } else { 0 };
    if count >= DAILY_SEARCH_LIMIT {
        return Err(format!(
      "Дневной лимит поисков в интернете исчерпан ({DAILY_SEARCH_LIMIT}/день) — это защита бесплатной квоты Tavily. Попробуйте снова завтра или продолжайте без поиска."
    ));
    }
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let _ = std::fs::write(&path, format!("{today} {}", count + 1));
    Ok(())
}

// Реальный запрос к Tavily (бесплатно 1000 запросов/мес, ключ tvly-...).
// Возвращает до 5 источников (заголовок + ссылка); при ошибке сети/ключа
// отдаёт понятное сообщение, а не молча пустой список.
async fn tavily_search(query: &str) -> Result<Vec<SearchSource>, String> {
    let query = query.trim();
    if query.len() < 2 {
        return Err("Пустой поисковый запрос.".into());
    }
    check_and_spend_search_budget()?;
    let key = keychain_get_tavily()?;
    let client = reqwest::Client::new();
    let resp = client
        .post("https://api.tavily.com/search")
        .bearer_auth(&key)
        .timeout(Duration::from_secs(20))
        .json(&serde_json::json!({
          "query": query,
          "search_depth": "basic",
          "max_results": 5,
        }))
        .send()
        .await
        .map_err(|e| format!("Не удалось связаться с Tavily: {e}"))?;
    if !resp.status().is_success() {
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if status == reqwest::StatusCode::UNAUTHORIZED || status == reqwest::StatusCode::FORBIDDEN {
            return Err("Проверьте ключ Tavily в настройках.".into());
        }
        return Err(format!("Tavily временно недоступен ({status}): {text}"));
    }
    let json: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
    Ok(json["results"]
        .as_array()
        .map(|arr| {
            arr.iter()
                .filter_map(|r| {
                    Some(SearchSource {
                        title: r["title"].as_str()?.to_string(),
                        url: r["url"].as_str()?.to_string(),
                        content: r["content"].as_str().unwrap_or("").to_string(),
                    })
                })
                .collect()
        })
        .unwrap_or_default())
}

// Читает содержимое конкретной веб-страницы через Tavily Extract. Это
// отдельный инструмент: обычный поиск даёт сниппеты, а extract нужен, когда
// пользователь прислал ссылку или модель должна понять, что именно на сайте.
async fn tavily_extract(url: &str) -> Result<String, String> {
    check_and_spend_search_budget()?;
    let key = keychain_get_tavily()?;
    let client = reqwest::Client::new();
    let resp = client
        .post("https://api.tavily.com/extract")
        .bearer_auth(&key)
        .timeout(Duration::from_secs(25))
        .json(&serde_json::json!({ "urls": [url], "extract_depth": "basic" }))
        .send()
        .await
        .map_err(|e| format!("Не удалось прочитать страницу: {e}"))?;
    if !resp.status().is_success() {
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if status == reqwest::StatusCode::UNAUTHORIZED || status == reqwest::StatusCode::FORBIDDEN {
            return Err("Проверьте ключ Tavily в настройках.".into());
        }
        return Err(format!(
            "Tavily Extract временно недоступен ({status}): {text}"
        ));
    }
    let json: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
    let text = json["results"]
        .as_array()
        .and_then(|a| a.first())
        .and_then(|v| v["raw_content"].as_str().or_else(|| v["content"].as_str()))
        .unwrap_or("");
    if text.is_empty() {
        Err("Страница не вернула читаемого содержимого.".into())
    } else {
        Ok(text.chars().take(30_000).collect())
    }
}

// Поиск изображений — тот же Tavily, с include_images: true. Использует
// тот же дневной бюджет поиска (check_and_spend_search_budget), отдельного
// лимита на картинки нет: это тоже "один запрос к Tavily", просто другой
// формы ответа. images в ответе — либо список строк-ссылок, либо объектов
// {url, description} (когда include_image_descriptions включён) — здесь
// он не включён, поэтому ожидаем строки, но на всякий случай понимаем и
// формат объекта тоже.
async fn tavily_image_search(query: &str) -> Result<Vec<String>, String> {
    let query = query.trim();
    if query.len() < 2 {
        return Err("Пустой поисковый запрос.".into());
    }
    check_and_spend_search_budget()?;
    let key = keychain_get_tavily()?;
    let client = reqwest::Client::new();
    let resp = client
        .post("https://api.tavily.com/search")
        .bearer_auth(&key)
        .timeout(Duration::from_secs(20))
        .json(&serde_json::json!({
          "query": query,
          "search_depth": "basic",
          "max_results": 5,
          "include_images": true,
        }))
        .send()
        .await
        .map_err(|e| format!("Не удалось связаться с Tavily: {e}"))?;
    if !resp.status().is_success() {
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if status == reqwest::StatusCode::UNAUTHORIZED || status == reqwest::StatusCode::FORBIDDEN {
            return Err("Проверьте ключ Tavily в настройках.".into());
        }
        return Err(format!("Tavily временно недоступен ({status}): {text}"));
    }
    let json: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
    Ok(json["images"]
        .as_array()
        .map(|arr| {
            arr.iter()
                .filter_map(|v| {
                    v.as_str()
                        .map(|s| s.to_string())
                        .or_else(|| v["url"].as_str().map(|s| s.to_string()))
                })
                .take(6)
                .collect()
        })
        .unwrap_or_default())
}

// ─── Песочница файлов ────────────────────────────────────────────────────
// У каждого диалога — своя маленькая папка на диске, где локальная модель
// (Mentis 3 / Nage 1.5) может сама сохранять и дорабатывать текстовые
// файлы и код по ходу разговора, без ручного прикрепления пользователем.
// Работает только в локальном режиме — Groq этих инструментов не видит,
// так как это про "без интернета", а не про облако.
//
// Место на диске — приоритет №1, поэтому лимиты сразу в трёх измерениях:
// размер одного файла, число файлов в одном диалоге, и (самое главное)
// ОБЩИЙ потолок на всю песочницу сразу по всем диалогам вместе. Именно
// общий потолок реально гарантирует "ест мало места" — без него можно было
// бы завести много диалогов и получить много "мини" папок, которые в сумме
// не мини. При новой записи, если общий размер вот-вот превысит потолок,
// самые старые файлы (по времени изменения, по всем диалогам) удаляются
// первыми — простая политика "самое старое не нужно" без участия модели.
const SANDBOX_MAX_FILE_BYTES: usize = 25_000_000; // 25 МБ на импортированный/бинарный файл
const SANDBOX_MAX_GENERATED_TEXT_BYTES: usize = 2_000_000;
const SANDBOX_MAX_READ_CHARS: usize = 120_000;
const SANDBOX_MAX_FILES_PER_CHAT: usize = 40; // на один диалог
const SANDBOX_TOTAL_MAX_BYTES: u64 = 500_000_000; // 500 МБ на ВСЮ песочницу сразу (по всем диалогам)

fn sandbox_root() -> std::path::PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    std::path::PathBuf::from(format!("{home}/Library/Application Support/AmIgo/sandbox"))
}

// Диалог, к песочнице которого не обращались сутки, упаковывается в один
// .zip прямо на месте своей папки (см. sandbox_compress_idle) — экономит
// место, пока к диалогу не возвращаются. sandbox_dir ниже — точка входа
// абсолютно для всех операций с песочницей конкретного диалога, поэтому
// именно здесь беззвучно распаковываем архив обратно, если он есть:
// пользователь и модель не замечают разницы, работа с файлами не меняется.
const SANDBOX_IDLE_SECS: u64 = 24 * 60 * 60; // сутки

fn sandbox_archive_path(chat_id_safe: &str) -> std::path::PathBuf {
    sandbox_root().join(format!("{chat_id_safe}.zip"))
}

fn sandbox_files_recursive(dir: &std::path::Path) -> Vec<std::path::PathBuf> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(dir) else {
        return out;
    };
    for entry in entries.filter_map(|e| e.ok()) {
        let path = entry.path();
        if path.is_dir() {
            out.extend(sandbox_files_recursive(&path));
        } else if path.is_file() {
            out.push(path);
        }
    }
    out
}

fn sandbox_dir(chat_id: &str) -> std::path::PathBuf {
    // chat_id приходит с фронтенда — на всякий случай оставляем только
    // безопасные символы, прежде чем использовать как имя папки.
    let safe: String = chat_id
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    let safe = if safe.is_empty() {
        "_".to_string()
    } else {
        safe
    };
    let dir = sandbox_root().join(&safe);

    let archive = sandbox_archive_path(&safe);
    if archive.exists() {
        if let Ok(file) = std::fs::File::open(&archive) {
            if let Ok(mut zip) = zip::ZipArchive::new(file) {
                let _ = std::fs::create_dir_all(&dir);
                for i in 0..zip.len() {
                    if let Ok(mut entry) = zip.by_index(i) {
                        if entry.is_dir() {
                            continue;
                        }
                        let Some(enclosed) = entry.enclosed_name().map(|p| p.to_path_buf()) else {
                            continue;
                        };
                        let out_path = dir.join(enclosed);
                        if let Some(parent) = out_path.parent() {
                            let _ = std::fs::create_dir_all(parent);
                        }
                        if let Ok(mut out) = std::fs::File::create(&out_path) {
                            let _ = std::io::copy(&mut entry, &mut out);
                        }
                    }
                }
            }
        }
        let _ = std::fs::remove_file(&archive);
    }
    dir
}

// Упаковывает папку диалога в .zip (deflate) и удаляет исходную папку.
fn sandbox_compress_one(dir: &std::path::Path, archive: &std::path::Path) -> Result<(), String> {
    let file = std::fs::File::create(archive).map_err(|e| e.to_string())?;
    let mut writer = zip::ZipWriter::new(file);
    let options = zip::write::SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated);
    use std::io::Write;
    for path in sandbox_files_recursive(dir) {
        let relative = path.strip_prefix(dir).map_err(|e| e.to_string())?;
        let name = relative.to_string_lossy().replace('\\', "/");
        writer
            .start_file(name, options)
            .map_err(|e| e.to_string())?;
        let bytes = std::fs::read(&path).map_err(|e| e.to_string())?;
        writer.write_all(&bytes).map_err(|e| e.to_string())?;
    }
    writer.finish().map_err(|e| e.to_string())?;
    std::fs::remove_dir_all(dir).map_err(|e| e.to_string())?;
    Ok(())
}

// Проходит по всем папкам диалогов в песочнице и упаковывает те, что не
// трогали дольше SANDBOX_IDLE_SECS — вызывается один раз при старте
// приложения (см. run()), не на каждое сообщение. "Не трогали" — это
// время изменения самого свежего файла внутри папки диалога.
fn sandbox_compress_idle() {
    let root = sandbox_root();
    let Ok(entries) = std::fs::read_dir(&root) else {
        return;
    };
    let now = std::time::SystemTime::now();
    for entry in entries.filter_map(|e| e.ok()) {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let newest = sandbox_files_recursive(&path)
            .into_iter()
            .filter_map(|p| std::fs::metadata(p).ok())
            .filter_map(|m| m.modified().ok())
            .max();
        let Some(newest) = newest else { continue }; // пустая папка — нечего сжимать
        let idle = now.duration_since(newest).unwrap_or_default().as_secs();
        if idle < SANDBOX_IDLE_SECS {
            continue;
        }
        let chat_id_safe = entry.file_name().to_string_lossy().to_string();
        let archive = sandbox_archive_path(&chat_id_safe);
        let _ = sandbox_compress_one(&path, &archive);
    }
}

// Все файлы во всей песочнице (по всем диалогам сразу) с путём и временем
// изменения — основа и для подсчёта общего размера, и для вытеснения
// самых старых при нехватке места.
fn sandbox_all_files() -> Vec<(std::path::PathBuf, u64, std::time::SystemTime)> {
    let root = sandbox_root();
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(&root) else {
        return out;
    };
    for entry in entries.filter_map(|e| e.ok()) {
        let path = entry.path();
        let Ok(meta) = entry.metadata() else { continue };
        if meta.is_file() {
            // Сжатый архив простаивающего диалога (.zip лежит прямо в корне
            // песочницы, рядом с папками) — считаем его как один файл, иначе он
            // был бы невидим для потолка в 200 МБ и для вытеснения самых старых.
            let mtime = meta.modified().unwrap_or(std::time::SystemTime::UNIX_EPOCH);
            out.push((path, meta.len(), mtime));
        } else if meta.is_dir() {
            for fpath in sandbox_files_recursive(&path) {
                if let Ok(fmeta) = std::fs::metadata(&fpath) {
                    let mtime = fmeta
                        .modified()
                        .unwrap_or(std::time::SystemTime::UNIX_EPOCH);
                    out.push((fpath, fmeta.len(), mtime));
                }
            }
        }
    }
    out
}

// Освобождает место под новую запись размером extra_needed байт, удаляя
// самые старые файлы по всей песочнице (по всем диалогам), пока общий
// размер плюс extra_needed не впишется в SANDBOX_TOTAL_MAX_BYTES.
fn sandbox_enforce_total_cap(extra_needed: u64) {
    let mut files = sandbox_all_files();
    let mut total: u64 = files.iter().map(|(_, size, _)| size).sum();
    if total + extra_needed <= SANDBOX_TOTAL_MAX_BYTES {
        return;
    }
    files.sort_by_key(|(_, _, mtime)| *mtime); // старые — первыми
    for (path, size, _) in files {
        if total + extra_needed <= SANDBOX_TOTAL_MAX_BYTES {
            break;
        }
        if std::fs::remove_file(&path).is_ok() {
            total = total.saturating_sub(size);
        }
    }
}

// Превращает имя файла от модели в путь строго внутри песочницы диалога.
// Оставляем только "обычные" сегменты пути (Component::Normal) — компоненты
// вида ".." или абсолютный корень отфильтровываются самим std::path на
// уровне разбора пути, а не текстовым поиском "..", так что от них нельзя
// уйти в обход, замаскировав их под другой текст.
fn sandbox_resolve(chat_id: &str, rel_path: &str) -> Result<std::path::PathBuf, String> {
    let root = sandbox_dir(chat_id);
    std::fs::create_dir_all(&root).map_err(|e| format!("Не удалось создать песочницу: {e}"))?;
    let clean: std::path::PathBuf = std::path::Path::new(rel_path)
        .components()
        .filter(|c| matches!(c, std::path::Component::Normal(_)))
        .collect();
    if clean.as_os_str().is_empty() {
        return Err("Пустое имя файла.".into());
    }
    Ok(root.join(clean))
}

fn sandbox_list_files(chat_id: &str) -> Result<Vec<String>, String> {
    let root = sandbox_dir(chat_id);
    std::fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let mut names: Vec<String> = sandbox_files_recursive(&root)
        .into_iter()
        .filter_map(|path| {
            path.strip_prefix(&root)
                .ok()
                .map(|p| p.to_string_lossy().replace('\\', "/"))
        })
        .collect();
    names.sort();
    Ok(names)
}

fn sandbox_read_file(chat_id: &str, rel_path: &str) -> Result<String, String> {
    let p = sandbox_resolve(chat_id, rel_path)?;
    if !p.is_file() {
        return Err(format!(
            "Файл «{rel_path}» не найден в песочнице этого диалога."
        ));
    }
    let content = std::fs::read_to_string(&p)
        .map_err(|e| format!("Не удалось прочитать «{rel_path}»: {e}"))?;
    if content.chars().count() > SANDBOX_MAX_READ_CHARS {
        Ok(format!(
            "{}\n\n[Файл обрезан до {} символов]",
            content
                .chars()
                .take(SANDBOX_MAX_READ_CHARS)
                .collect::<String>(),
            SANDBOX_MAX_READ_CHARS
        ))
    } else {
        Ok(content)
    }
}

fn sandbox_write_bytes(chat_id: &str, rel_path: &str, bytes: &[u8]) -> Result<(), String> {
    if bytes.len() > SANDBOX_MAX_FILE_BYTES {
        return Err(format!(
            "Файл «{rel_path}» слишком большой для песочницы (лимит {} КБ на файл).",
            SANDBOX_MAX_FILE_BYTES / 1000
        ));
    }
    let root = sandbox_dir(chat_id);
    let p = sandbox_resolve(chat_id, rel_path)?;
    let old_size = std::fs::metadata(&p).map(|m| m.len()).unwrap_or(0);
    if !p.exists() {
        let count = sandbox_files_recursive(&root).len();
        if count >= SANDBOX_MAX_FILES_PER_CHAT {
            return Err(format!(
                "В песочнице этого диалога уже {SANDBOX_MAX_FILES_PER_CHAT} файлов."
            ));
        }
    }
    sandbox_enforce_total_cap((bytes.len() as u64).saturating_sub(old_size));
    if let Some(parent) = p.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    std::fs::write(&p, bytes).map_err(|e| format!("Не удалось сохранить «{rel_path}»: {e}"))
}

fn sandbox_write_file(chat_id: &str, rel_path: &str, content: &str) -> Result<(), String> {
    if content.len() > SANDBOX_MAX_GENERATED_TEXT_BYTES {
        return Err("Текстовый файл модели слишком большой.".into());
    }
    sandbox_write_bytes(chat_id, rel_path, content.as_bytes())
}

fn sandbox_unique_filename(chat_id: &str, requested: &str) -> String {
    let raw = std::path::Path::new(requested)
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("file");
    let clean: String = raw
        .chars()
        .filter(|c| c.is_alphanumeric() || matches!(c, '.' | '-' | '_' | ' '))
        .collect();
    let clean = if clean.trim().is_empty() {
        "file".to_string()
    } else {
        clean
    };
    if !sandbox_dir(chat_id).join(&clean).exists() {
        return clean;
    }
    let path = std::path::Path::new(&clean);
    let stem = path.file_stem().and_then(|s| s.to_str()).unwrap_or("file");
    let ext = path.extension().and_then(|s| s.to_str());
    for index in 2..10_000 {
        let candidate = match ext {
            Some(ext) => format!("{stem}_{index}.{ext}"),
            None => format!("{stem}_{index}"),
        };
        if !sandbox_dir(chat_id).join(&candidate).exists() {
            return candidate;
        }
    }
    format!("file_{}", std::process::id())
}

#[tauri::command]
fn sandbox_import_file(
    chat_id: String,
    source_path: String,
    filename: String,
) -> Result<String, String> {
    let source = std::path::Path::new(&source_path);
    if !source.is_file() {
        return Err("Исходный файл не найден.".into());
    }
    let meta = std::fs::metadata(source).map_err(|e| e.to_string())?;
    if meta.len() > SANDBOX_MAX_FILE_BYTES as u64 {
        return Err(format!(
            "Файл больше лимита песочницы ({} МБ).",
            SANDBOX_MAX_FILE_BYTES / 1_000_000
        ));
    }
    let bytes = std::fs::read(source).map_err(|e| format!("Не удалось прочитать файл: {e}"))?;
    let saved_name = sandbox_unique_filename(&chat_id, &filename);
    sandbox_write_bytes(&chat_id, &saved_name, &bytes)?;
    Ok(saved_name)
}

// Детерминированный fallback для маленьких моделей: если модель не смогла
// вызвать write_file, но выдала именованный fenced-блок, фронтенд сохраняет
// его через эти команды. Пользователь всё равно получает настоящий файл.
#[tauri::command]
fn sandbox_save_generated_text(
    chat_id: String,
    path: String,
    content: String,
) -> Result<(), String> {
    sandbox_write_file(&chat_id, &path, &content)
}

#[tauri::command]
fn sandbox_save_generated_binary(
    chat_id: String,
    path: String,
    content_base64: String,
) -> Result<(), String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let bytes = STANDARD
        .decode(content_base64.as_bytes())
        .map_err(|e| format!("Некорректные данные файла: {e}"))?;
    sandbox_write_bytes(&chat_id, &path, &bytes)
}

// Модели прямо предложено самой убирать за собой неактуальные версии
// файлов (см. системный промпт и описание delete_file ниже) — жёсткие
// лимиты выше всё равно подстрахуют, если она этого не сделает.
fn sandbox_delete_file(chat_id: &str, rel_path: &str) -> Result<(), String> {
    let p = sandbox_resolve(chat_id, rel_path)?;
    if !p.is_file() {
        return Err(format!(
            "Файл «{rel_path}» не найден в песочнице этого диалога."
        ));
    }
    std::fs::remove_file(&p).map_err(|e| format!("Не удалось удалить «{rel_path}»: {e}"))
}

// Скачивает картинку по ссылке (обычно найденной через find_images) прямо
// в песочницу диалога. Проверяем реальный Content-Type ответа, а не
// доверяем расширению в самой ссылке — иначе под видом "картинки" можно
// было бы затащить в песочницу произвольный файл. Расширение итогового
// файла берётся из Content-Type, а не из предложенного имени — это тоже
// защита от подмены. Тот же общий лимит на файл (SANDBOX_MAX_FILE_BYTES),
// что и у write_file, и то же автоматическое вытеснение старых файлов при
// нехватке места в общем потолке песочницы.
async fn sandbox_download_image(
    chat_id: &str,
    url: &str,
    suggested_name: &str,
) -> Result<String, String> {
    if !(url.starts_with("http://") || url.starts_with("https://")) {
        return Err("Ссылка на изображение должна начинаться с http:// или https://".into());
    }
    let client = reqwest::Client::new();
    let resp = client
        .get(url)
        .timeout(Duration::from_secs(20))
        .send()
        .await
        .map_err(|e| format!("Не удалось скачать изображение: {e}"))?;
    if !resp.status().is_success() {
        return Err(format!(
            "Сервер вернул ошибку при скачивании изображения: {}",
            resp.status()
        ));
    }
    let content_type = resp
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();
    let ext = match content_type.split(';').next().unwrap_or("").trim() {
        "image/png" => "png",
        "image/jpeg" | "image/jpg" => "jpg",
        "image/gif" => "gif",
        "image/bmp" => "bmp",
        "image/webp" => "webp",
        other => {
            return Err(format!(
                "По этой ссылке не изображение (Content-Type: {other})."
            ))
        }
    };
    let bytes = resp
        .bytes()
        .await
        .map_err(|e| format!("Обрыв соединения при скачивании изображения: {e}"))?;
    if bytes.len() > SANDBOX_MAX_FILE_BYTES {
        return Err(format!(
            "Изображение слишком большое для песочницы (лимит {} КБ).",
            SANDBOX_MAX_FILE_BYTES / 1000
        ));
    }
    let base: String = suggested_name
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    let base = if base.is_empty() {
        "image".to_string()
    } else {
        base
    };
    let final_name = format!("{base}.{ext}");

    sandbox_enforce_total_cap(bytes.len() as u64);
    let p = sandbox_resolve(chat_id, &final_name)?;
    std::fs::write(&p, &bytes).map_err(|e| format!("Не удалось сохранить изображение: {e}"))?;
    Ok(final_name)
}

// Читает картинку из песочницы диалога и отдаёт как data URL — для показа
// миниатюры в чате (тот же формат, что read_image_base64 для вложений
// пользователя, но путь берётся из песочницы конкретного диалога, а не с
// произвольного диска).
#[tauri::command]
fn sandbox_read_image(chat_id: String, filename: String) -> Result<String, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let p = sandbox_resolve(&chat_id, &filename)?;
    let ext = p
        .extension()
        .and_then(|x| x.to_str())
        .unwrap_or("")
        .to_lowercase();
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "bmp" => "image/bmp",
        "webp" => "image/webp",
        _ => return Err("unsupported_format".into()),
    };
    let bytes = std::fs::read(&p).map_err(|e| format!("Не удалось прочитать изображение: {e}"))?;
    Ok(format!("data:{mime};base64,{}", STANDARD.encode(bytes)))
}

#[tauri::command]
fn sandbox_list(chat_id: String) -> Result<Vec<String>, String> {
    sandbox_list_files(&chat_id)
}

// Открывает папку песочницы этого диалога в Finder — так пользователь
// может забрать файл или отредактировать его в любой другой программе.
#[tauri::command]
fn sandbox_reveal(chat_id: String) -> Result<(), String> {
    let root = sandbox_dir(&chat_id);
    std::fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    Command::new("open")
        .arg(&root)
        .status()
        .map_err(|e| e.to_string())?;
    Ok(())
}

// Вызывается при удалении диалога из интерфейса — песочница диалога больше
// никому не нужна, поэтому сразу освобождаем место, а не копим мусор.
#[tauri::command]
fn sandbox_delete_all(chat_id: String) -> Result<(), String> {
    let root = sandbox_dir(&chat_id);
    if root.exists() {
        std::fs::remove_dir_all(&root).map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
fn sandbox_open_file(chat_id: String, filename: String) -> Result<(), String> {
    let path = sandbox_resolve(&chat_id, &filename)?;
    if !path.is_file() {
        return Err("Файл не найден.".into());
    }
    let ok = Command::new("open")
        .arg(path)
        .status()
        .map_err(|e| e.to_string())?
        .success();
    if ok {
        Ok(())
    } else {
        Err("Не удалось открыть файл.".into())
    }
}

// Удаляет выбранные временные изображения после следующего ответа. Имена
// проходят через тот же безопасный resolver; ошибки отсутствующих файлов
// игнорируются, потому что общий лимит мог вытеснить старый файл раньше.
#[tauri::command]
fn sandbox_delete_files(chat_id: String, filenames: Vec<String>) -> Result<(), String> {
    for name in filenames {
        if let Ok(path) = sandbox_resolve(&chat_id, &name) {
            if path.is_file() {
                let _ = std::fs::remove_file(path);
            }
        }
    }
    Ok(())
}

// Разбирает аргументы вызова инструмента в JSON-объект независимо от того,
// прислал ли движок их строкой (стандарт OpenAI function-calling) или уже
// готовым объектом — оба варианта встречаются на практике.
fn tool_call_args(call: &serde_json::Value) -> serde_json::Value {
    let raw = &call["function"]["arguments"];
    if let Some(s) = raw.as_str() {
        serde_json::from_str(s).unwrap_or(serde_json::json!({}))
    } else {
        raw.clone()
    }
}

fn sandbox_tools_defs() -> Vec<serde_json::Value> {
    vec![
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "list_files",
            "description": "Показывает список файлов, уже сохранённых в песочнице этого диалога.",
            "parameters": { "type": "object", "properties": {} }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "read_file",
            "description": "Читает текстовое содержимое файла из песочницы этого диалога — используй перед тем, как дорабатывать уже сохранённый файл.",
            "parameters": {
              "type": "object",
              "properties": { "path": { "type": "string", "description": "Имя файла в песочнице, например notes.md или script.py" } },
              "required": ["path"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "write_file",
            "description": "ОБЯЗАТЕЛЬНО вызывай, когда пользователь просит создать, сохранить, записать или подготовить файл. Создаёт либо полностью перезаписывает файл в песочнице. Передавай полное готовое содержимое, а не объяснение.",
            "parameters": {
              "type": "object",
              "properties": {
                "path": { "type": "string", "description": "Имя файла, например script.py" },
                "content": { "type": "string", "description": "Полное новое содержимое файла" }
              },
              "required": ["path", "content"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "delete_file",
            "description": "Удаляет файл из песочницы этого диалога — используй, когда файл больше не нужен: заменил его новой версией под другим именем, результат устарел, или он был промежуточным черновиком. Место в песочнице ограничено, поэтому убирай за собой неактуальное, а не оставляй все версии подряд.",
            "parameters": {
              "type": "object",
              "properties": { "path": { "type": "string", "description": "Имя файла для удаления" } },
              "required": ["path"]
            }
          }
        }),
    ]
}

// Описание инструмента (формат function-calling OpenAI): модель сама решает,
// вызывать ли его, и сама формулирует поисковый запрос. Работает одинаково
// и для Groq, и для локального движка AmIgo — оба говорят на OpenAI-протоколе.
fn web_search_tool_def() -> serde_json::Value {
    serde_json::json!({
      "type": "function",
      "function": {
        "name": "web_search",
        "description": "Ищет свежую информацию в интернете: новости, текущие события, цены, курсы, даты и факты, которых может не быть в твоих знаниях. Вызывай, когда вопрос требует актуальных или проверяемых данных.",
        "parameters": {
          "type": "object",
          "properties": { "query": { "type": "string", "description": "Поисковый запрос на языке вопроса пользователя" } },
          "required": ["query"]
        }
      }
    })
}

fn read_webpage_tool_def() -> serde_json::Value {
    serde_json::json!({
      "type": "function",
      "function": {
        "name": "read_webpage",
        "description": "Читает содержимое конкретной веб-страницы. Вызывай только когда пользователь дал ссылку или по результатам поиска нужно понять содержимое сайта; не вызывай для обычных вопросов.",
        "parameters": {
          "type": "object",
          "properties": { "url": { "type": "string", "description": "Полный URL страницы, начиная с https://" } },
          "required": ["url"]
        }
      }
    })
}

// find_images/download_image доступны только вместе с песочницей (нужен
// chat_id — картинка сохраняется в песочницу конкретного диалога) и только
// когда включён поиск (нужен интернет) — см. сборку списка инструментов в
// chat_stream_inner.
fn image_tools_defs() -> Vec<serde_json::Value> {
    vec![
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "find_images",
            "description": "Ищет в интернете картинки по запросу и возвращает до нескольких ссылок на них. Сами картинки этим не скачиваются — чтобы показать картинку пользователю, вставить её в презентацию или другой документ, после этого вызови download_image с понравившейся ссылкой.",
            "parameters": {
              "type": "object",
              "properties": { "query": { "type": "string", "description": "Что искать, на языке запроса пользователя" } },
              "required": ["query"]
            }
          }
        }),
        serde_json::json!({
          "type": "function",
          "function": {
            "name": "download_image",
            "description": "Скачивает картинку по ссылке (обычно найденной через find_images) в песочницу этого диалога — так её можно показать пользователю или вставить в презентацию/документ. Если нужно несколько картинок — вызови этот инструмент несколько раз, по одному разу на каждую ссылку.",
            "parameters": {
              "type": "object",
              "properties": {
                "url": { "type": "string", "description": "Прямая ссылка на файл картинки" },
                "name": { "type": "string", "description": "Короткое имя файла без расширения, например kotik или eiffel_tower" }
              },
              "required": ["url", "name"]
            }
          }
        }),
    ]
}

// Собирает поток OpenAI SSE и сразу передаёт текстовые токены во фронтенд.
// Одновременно умеет собирать частичные tool_calls: Groq и llama-server
// присылают имя/аргументы функции кусочками в delta.tool_calls.
struct OpenAIStreamResult {
    content: String,
    tool_calls: Vec<serde_json::Value>,
}

async fn collect_openai_stream(
    app: &tauri::AppHandle,
    state: &ChatState,
    response: reqwest::Response,
    show_thinking: bool,
) -> Result<OpenAIStreamResult, String> {
    // Некоторые версии OpenAI-совместимых серверов игнорируют stream:true
    // при tools и возвращают обычный JSON. Обрабатываем его как корректный
    // fallback, чтобы ответ не превращался в пустую строку.
    let content_type = response
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_ascii_lowercase();
    if content_type.contains("application/json") && !content_type.contains("text/event-stream") {
        let data: serde_json::Value = response.json().await.map_err(|e| e.to_string())?;
        let message = &data["choices"][0]["message"];
        let content = message["content"].as_str().unwrap_or("").to_string();
        if !content.is_empty() {
            let _ = app.emit(
                "chat-chunk",
                ChatChunk {
                    content: content.clone(),
                },
            );
        }
        let tool_calls = message["tool_calls"]
            .as_array()
            .cloned()
            .unwrap_or_default();
        return Ok(OpenAIStreamResult {
            content,
            tool_calls,
        });
    }

    let mut stream = response.bytes_stream();
    let mut buffer: Vec<u8> = Vec::new();
    let mut full = String::new();
    let mut calls: std::collections::BTreeMap<usize, (String, String, String)> =
        std::collections::BTreeMap::new();
    let mut thinking_active = false;

    'outer: while let Some(item) = stream.next().await {
        if state.stop.load(Ordering::SeqCst) {
            break;
        }
        let bytes = item.map_err(|e| e.to_string())?;
        buffer.extend_from_slice(&bytes);
        while let Some(pos) = buffer.iter().position(|b| *b == b'\n') {
            let line = String::from_utf8_lossy(&buffer[..pos]).trim().to_string();
            buffer.drain(..=pos);
            if line.is_empty() {
                continue;
            }
            let json_str = if let Some(stripped) = line.strip_prefix("data:") {
                let stripped = stripped.trim();
                if stripped == "[DONE]" {
                    break 'outer;
                }
                stripped
            } else {
                line.as_str()
            };
            let Ok(data) = serde_json::from_str::<serde_json::Value>(json_str) else {
                continue;
            };
            let delta = &data["choices"][0]["delta"];
            let reasoning = delta["reasoning"]
                .as_str()
                .or_else(|| delta["reasoning_content"].as_str())
                .unwrap_or("");
            if show_thinking && !reasoning.is_empty() && !thinking_active {
                thinking_active = true;
                let _ = app.emit(
                    "chat-status",
                    StatusEvent {
                        kind: "thinking".into(),
                        active: true,
                    },
                );
            }
            let text = delta["content"].as_str().unwrap_or("");
            if !text.is_empty() {
                if thinking_active {
                    thinking_active = false;
                    let _ = app.emit(
                        "chat-status",
                        StatusEvent {
                            kind: "thinking".into(),
                            active: false,
                        },
                    );
                }
                full.push_str(text);
                let _ = app.emit(
                    "chat-chunk",
                    ChatChunk {
                        content: text.to_string(),
                    },
                );
            }
            if let Some(parts) = delta["tool_calls"].as_array() {
                for part in parts {
                    let index = part["index"].as_u64().unwrap_or(0) as usize;
                    let entry = calls
                        .entry(index)
                        .or_insert_with(|| (String::new(), String::new(), String::new()));
                    if let Some(id) = part["id"].as_str() {
                        entry.0.push_str(id);
                    }
                    if let Some(name) = part["function"]["name"].as_str() {
                        entry.1.push_str(name);
                    }
                    if let Some(args) = part["function"]["arguments"].as_str() {
                        entry.2.push_str(args);
                    }
                }
            }
            if state.stop.load(Ordering::SeqCst) {
                break 'outer;
            }
        }
    }
    if thinking_active {
        let _ = app.emit(
            "chat-status",
            StatusEvent {
                kind: "thinking".into(),
                active: false,
            },
        );
    }
    let tool_calls = calls
        .into_iter()
        .map(|(index, (id, name, arguments))| {
            serde_json::json!({
              "index": index,
              "id": if id.is_empty() { format!("call_{index}") } else { id },
              "type": "function",
              "function": { "name": name, "arguments": arguments }
            })
        })
        .collect();
    Ok(OpenAIStreamResult {
        content: full,
        tool_calls,
    })
}

// Конвертирует сообщения в OpenAI-формат с поддержкой изображений
// (data-URL в content-массиве) — общая логика для Groq и локального движка.
fn to_openai_messages(messages: &[ChatMessage]) -> Vec<serde_json::Value> {
    messages
        .iter()
        .map(|m| {
            if m.images.is_empty() {
                serde_json::json!({ "role": m.role, "content": m.content })
            } else {
                let mut parts: Vec<serde_json::Value> =
                    vec![serde_json::json!({ "type": "text", "text": m.content })];
                for img in &m.images {
                    parts.push(serde_json::json!({
                      "type": "image_url",
                      "image_url": { "url": format!("data:image/jpeg;base64,{img}") }
                    }));
                }
                serde_json::json!({ "role": m.role, "content": parts })
            }
        })
        .collect()
}

// Цикл tool-calling: до двух раундов, где модель может попросить поиск
// и/или операцию с файлами песочницы (стандартный OpenAI-протокол function
// calling), затем обязательный финальный раунд — обычный стрим текста без
// предложения новых инструментов. Работает одинаково для Groq и для
// локального движка AmIgo — отличаются только url, bearer-токен и набор
// доступных инструментов (tools передаётся вызывающим кодом: sandbox-
// инструменты только для local, web_search только если включён поиск).
async fn chat_with_tools_openai(
    app: &tauri::AppHandle,
    state: &ChatState,
    req: &ChatRequest,
    url: &str,
    bearer: Option<String>,
    tools: Vec<serde_json::Value>,
) -> Result<String, String> {
    let client = reqwest::Client::new();
    let mut messages: Vec<serde_json::Value> = to_openai_messages(&req.messages);

    for round in 0..3 {
        if state.stop.load(Ordering::SeqCst) {
            return Ok(String::new());
        }
        let is_final_round = round == 2;

        let mut payload = serde_json::json!({ "model": req.model, "messages": messages, "temperature": req.temperature.unwrap_or(0.7) });
        payload["stream"] = serde_json::json!(true);
        if req.think == Some(true) {
            payload["reasoning_effort"] = serde_json::json!("high");
        } else if req.think == Some(false) {
            if req.provider == "local" {
                payload["chat_template_kwargs"] = serde_json::json!({"enable_thinking": false});
            } else {
                payload["reasoning_effort"] = serde_json::json!("low");
            }
        }
        if !is_final_round {
            payload["tools"] = serde_json::json!(tools);
            payload["tool_choice"] = serde_json::json!("auto");
            if req.provider != "local" {
                payload["parallel_tool_calls"] = serde_json::json!(true);
            }
        }

        let mut builder = client.post(url).timeout(Duration::from_secs(300));
        if let Some(b) = &bearer {
            builder = builder.bearer_auth(b);
        }
        let response = builder
      .json(&payload)
      .send()
      .await
      .map_err(|_| {
        if req.provider == "local" {
          "connection_error: Локальный движок AmIgo не отвечает. Попробуйте выбрать модель ещё раз.".to_string()
        } else {
          "connection_error: Не удалось связаться с Groq. Проверьте интернет-соединение.".to_string()
        }
      })?;

        if !response.status().is_success() {
            let status = response.status();
            let text = response.text().await.unwrap_or_default();
            let hint = serde_json::from_str::<serde_json::Value>(&text)
                .ok()
                .and_then(|v| v["error"]["message"].as_str().map(|s| s.to_string()))
                .unwrap_or(text);
            return Err(format!("Ошибка сервера ({status}): {hint}"));
        }

        let streamed =
            collect_openai_stream(app, state, response, req.think != Some(false)).await?;
        let tool_calls = streamed.tool_calls;
        if is_final_round || tool_calls.is_empty() {
            return Ok(streamed.content);
        }

        messages.push(serde_json::json!({
          "role": "assistant",
          "content": streamed.content,
          "tool_calls": tool_calls.clone(),
        }));

        // Жёсткие потолки на РЕАЛЬНЫЕ вызовы за один раунд ответа — отдельно
        // для поиска (защита дневной квоты Tavily) и отдельно для файловых
        // операций (защита от того, что модель начнёт бесконечно перечитывать/
        // переписывать файлы в одном ответе). Сверх потолка — не выполняем
        // вызов, а прямо говорим об этом модели тем же протоколом (ответ
        // инструмента), а не молча игнорируем: так модель не "зависает" в
        // ожидании ответа, а видит явную причину и отвечает текстом.
        const MAX_SEARCHES_PER_ROUND: usize = 2;
        const MAX_FILE_OPS_PER_ROUND: usize = 6;
        const MAX_IMAGE_OPS_PER_ROUND: usize = 4;
        let mut search_count = 0usize;
        let mut file_op_count = 0usize;
        let mut image_op_count = 0usize;

        // "Работа с файлами" — на весь раунд, если в нём есть хоть одна
        // файловая операция (включая поиск/скачивание картинок — они тоже
        // ложатся в песочницу), а не на каждый отдельный вызов: иначе статус
        // мигал бы включаясь/выключаясь между вызовами внутри одного ответа.
        let has_file_ops = tool_calls.iter().any(|c| {
            matches!(
                c["function"]["name"].as_str(),
                Some(
                    "list_files"
                        | "read_file"
                        | "write_file"
                        | "delete_file"
                        | "find_images"
                        | "download_image"
                )
            )
        });
        if has_file_ops {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "files".into(),
                    active: true,
                },
            );
        }

        // Карточки с именем файла/картинки показываем только ПОСЛЕ того, как
        // работа с файлами в этом раунде полностью завершится (см. ниже) —
        // пока горит статус "Работа с файлами", что именно затронуто, не
        // раскрываем. kind во втором элементе — "file" или "image" (влияет на
        // то, покажет ли фронтенд миниатюру или обычную карточку с именем).
        let mut pending_file_events: Vec<(String, bool)> = Vec::new(); // (path, removed) — обычные файлы
        let mut pending_image_events: Vec<String> = Vec::new(); // имена файлов скачанных картинок

        for call in &tool_calls {
            let name = call["function"]["name"].as_str().unwrap_or("");
            let id = call["id"].as_str().unwrap_or("").to_string();

            let tool_content: String = match name {
                "web_search" => {
                    search_count += 1;
                    if search_count > MAX_SEARCHES_PER_ROUND {
                        "Достигнут лимит одновременных поисков за один ответ. Ответь на основе уже найденного, не запрашивай больше поисков в этом сообщении.".to_string()
                    } else {
                        let args = tool_call_args(call);
                        let query = args["query"].as_str().unwrap_or("").to_string();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: query.clone(),
                                sources: vec![],
                                done: false,
                            },
                        );
                        let search_result = tavily_search(&query).await;
                        let sources = search_result.clone().unwrap_or_default();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: query.clone(),
                                sources,
                                done: true,
                            },
                        );
                        match search_result {
                            Err(e) => format!("Поиск не удался: {e}"),
                            Ok(s) if s.is_empty() => "Поиск не дал результатов.".to_string(),
                            Ok(s) => s
                                .iter()
                                .enumerate()
                                .map(|(i, r)| {
                                    format!("{}. {} ({})\n{}", i + 1, r.title, r.url, r.content)
                                })
                                .collect::<Vec<_>>()
                                .join("\n\n"),
                        }
                    }
                }
                "read_webpage" => {
                    search_count += 1;
                    if search_count > MAX_SEARCHES_PER_ROUND {
                        "Достигнут лимит обращений к интернету за один ответ. Ответь на основе уже полученных данных.".to_string()
                    } else {
                        let args = tool_call_args(call);
                        let page_url = args["url"].as_str().unwrap_or("").trim().to_string();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: page_url.clone(),
                                sources: vec![],
                                done: false,
                            },
                        );
                        let result = if page_url.starts_with("http://")
                            || page_url.starts_with("https://")
                        {
                            tavily_extract(&page_url).await
                        } else {
                            Err("Некорректный URL страницы.".into())
                        };
                        let sources = result
                            .as_ref()
                            .ok()
                            .map(|content| {
                                vec![SearchSource {
                                    title: page_url.clone(),
                                    url: page_url.clone(),
                                    content: content.chars().take(500).collect(),
                                }]
                            })
                            .unwrap_or_default();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: page_url.clone(),
                                sources,
                                done: true,
                            },
                        );
                        match result {
                            Ok(content) => format!("Содержимое страницы {page_url}:\n{content}"),
                            Err(e) => format!("Не удалось прочитать страницу: {e}"),
                        }
                    }
                }
                "find_images" => {
                    search_count += 1;
                    if search_count > MAX_SEARCHES_PER_ROUND {
                        "Достигнут лимит одновременных поисков за один ответ. Ответь на основе уже найденного, не запрашивай больше поисков в этом сообщении.".to_string()
                    } else {
                        let args = tool_call_args(call);
                        let query = args["query"].as_str().unwrap_or("").trim().to_string();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: query.clone(),
                                sources: vec![],
                                done: false,
                            },
                        );
                        let result = tavily_image_search(&query).await;
                        let sources = result
                            .as_ref()
                            .ok()
                            .map(|urls| {
                                urls.iter()
                                    .enumerate()
                                    .map(|(i, url)| SearchSource {
                                        title: format!("Изображение {}", i + 1),
                                        url: url.clone(),
                                        content: String::new(),
                                    })
                                    .collect()
                            })
                            .unwrap_or_default();
                        let _ = app.emit(
                            "chat-search",
                            SearchEvent {
                                query: query.clone(),
                                sources,
                                done: true,
                            },
                        );
                        match result {
                            Err(e) => format!("Поиск изображений не удался: {e}"),
                            Ok(urls) if urls.is_empty() => {
                                "Картинок по этому запросу не нашлось.".to_string()
                            }
                            Ok(urls) => urls
                                .iter()
                                .enumerate()
                                .map(|(i, u)| format!("{}. {u}", i + 1))
                                .collect::<Vec<_>>()
                                .join("\n"),
                        }
                    }
                }
                "list_files" | "read_file" | "write_file" | "delete_file" | "download_image" => {
                    if name == "download_image" {
                        image_op_count += 1;
                    } else {
                        file_op_count += 1;
                    }
                    if file_op_count > MAX_FILE_OPS_PER_ROUND {
                        "Достигнут лимит операций с файлами за один ответ. Ответь тем, что уже есть, не запрашивай больше файловых операций в этом сообщении.".to_string()
                    } else if image_op_count > MAX_IMAGE_OPS_PER_ROUND {
                        "Достигнут лимит скачиваний картинок за один ответ. Используй уже скачанные, не запрашивай больше в этом сообщении.".to_string()
                    } else {
                        let args = tool_call_args(call);
                        match name {
                            "list_files" => match sandbox_list_files(&req.chat_id) {
                                Ok(v) if v.is_empty() => {
                                    "Песочница этого диалога пока пуста.".to_string()
                                }
                                Ok(v) => format!("Файлы в песочнице: {}", v.join(", ")),
                                Err(e) => format!("Ошибка: {e}"),
                            },
                            "read_file" => {
                                let path = args["path"].as_str().unwrap_or("").to_string();
                                match sandbox_read_file(&req.chat_id, &path) {
                                    Ok(content) => content,
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            "write_file" => {
                                let path = args["path"].as_str().unwrap_or("").to_string();
                                let content = args["content"].as_str().unwrap_or("").to_string();
                                match sandbox_write_file(&req.chat_id, &path, &content) {
                                    Ok(()) => {
                                        pending_file_events.push((path.clone(), false));
                                        format!("Файл «{path}» сохранён в песочнице этого диалога.")
                                    }
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            "delete_file" => {
                                let path = args["path"].as_str().unwrap_or("").to_string();
                                match sandbox_delete_file(&req.chat_id, &path) {
                                    Ok(()) => {
                                        pending_file_events.push((path.clone(), true));
                                        format!("Файл «{path}» удалён из песочницы.")
                                    }
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            "download_image" => {
                                let url = args["url"].as_str().unwrap_or("").to_string();
                                let img_name = args["name"].as_str().unwrap_or("image").to_string();
                                match sandbox_download_image(&req.chat_id, &url, &img_name).await {
                                    Ok(saved_name) => {
                                        pending_image_events.push(saved_name.clone());
                                        format!(
                                            "Картинка сохранена в песочнице как «{saved_name}»."
                                        )
                                    }
                                    Err(e) => format!("Ошибка: {e}"),
                                }
                            }
                            _ => unreachable!(),
                        }
                    }
                }
                _ => "Неизвестный инструмент.".to_string(),
            };

            messages.push(
                serde_json::json!({ "role": "tool", "tool_call_id": id, "content": tool_content }),
            );
        }

        // Статус "Работа с файлами" выключаем, и только теперь — после него —
        // показываем карточки затронутых файлов и миниатюры картинок, если они были.
        if has_file_ops {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "files".into(),
                    active: false,
                },
            );
        }
        for (path, removed) in pending_file_events {
            let _ = app.emit("sandbox-file", serde_json::json!({ "chat_id": req.chat_id, "path": path, "removed": removed, "kind": "file" }));
        }
        for filename in pending_image_events {
            let _ = app.emit("sandbox-file", serde_json::json!({ "chat_id": req.chat_id, "path": filename, "removed": false, "kind": "image" }));
        }
    }

    Ok(String::new())
}

// Потоковая генерация: печатает ответ по мере поступления токенов.
// Каждый кусочек текста отправляется во фронтенд событием "chat-chunk".
// Возвращает полный текст ответа (на случай если фронтенд что-то пропустил).
// И локальный движок AmIgo, и Groq говорят на одном OpenAI-протоколе —
// отличаются только адресом и наличием bearer-токена.
async fn chat_stream_inner(
    app: &tauri::AppHandle,
    state: &ChatState,
    req: ChatRequest,
) -> Result<String, String> {
    let search_enabled = req.web_search.unwrap_or(true) && keychain_get_tavily().is_ok();
    // Песочница файлов — только в локальном режиме ("без интернета" по
    // условию задачи) и только когда запрос реально привязан к диалогу
    // (chat_id непустой) — иначе служебные запросы вроде фонового сжатия
    // истории в резюме тоже получили бы доступ к файловым инструментам,
    // а им это не нужно и только добавило бы лишних раундов задержки.
    let sandbox_enabled = req.provider == "local" && !req.chat_id.is_empty();

    // Mentis 3 умеет "видеть", только когда сервер запущен в режиме зрения
    // (--mmproj) — а по умолчанию она в быстром текстовом режиме с ускорением
    // (--model-draft), так как совмещать оба флага llama-server не даёт (см.
    // model_defs). Проверяем нужен ли режим зрения ДЛЯ ЭТОГО КОНКРЕТНОГО
    // сообщения ещё до выбора пути (обычный / с инструментами) — если сервер
    // сейчас не в том режиме, переключаем его и ждём готовности прямо здесь.
    let is_vision_model = req.provider == "local" && req.model == "mentis-3";
    let has_images = is_vision_model && req.messages.iter().any(|m| !m.images.is_empty());
    if req.provider == "local" {
        // Один режим на весь запрос. Не убиваем и не перезапускаем llama-server
        // между анализом фото и генерацией ответа: такой двухэтапный сценарий
        // мог оборвать соединение. Фото + ответ целиком идут через mmproj;
        // draft включится только перед следующим отдельным текстовым запросом.
        if has_images {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "vision".into(),
                    active: true,
                },
            );
        }
        ensure_server_mode(app, state, &req.model, has_images).await?;
    }

    let (url, bearer): (String, Option<String>) = if req.provider == "local" {
        (
            format!("http://127.0.0.1:{LOCAL_PORT}/v1/chat/completions"),
            None,
        )
    } else {
        (
            "https://api.groq.com/openai/v1/chat/completions".to_string(),
            Some(keychain_get()?),
        )
    };

    let mut tools: Vec<serde_json::Value> = Vec::new();
    if sandbox_enabled {
        tools.extend(sandbox_tools_defs());
    }
    if search_enabled {
        tools.push(web_search_tool_def());
        tools.push(read_webpage_tool_def());
    }
    if sandbox_enabled && search_enabled {
        tools.extend(image_tools_defs());
    }

    if !tools.is_empty() {
        let result = chat_with_tools_openai(app, state, &req, &url, bearer, tools).await;
        if has_images {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "vision".into(),
                    active: false,
                },
            );
        }
        return result;
    }

    let temperature = req.temperature.unwrap_or(0.6);
    let oai_messages = to_openai_messages(&req.messages);
    let mut payload = serde_json::json!({ "model": req.model, "messages": oai_messages, "stream": true, "temperature": temperature });
    if req.think == Some(true) {
        payload["reasoning_effort"] = serde_json::json!("high");
    } else if req.think == Some(false) {
        if req.provider == "local" {
            payload["chat_template_kwargs"] = serde_json::json!({"enable_thinking": false});
        } else {
            payload["reasoning_effort"] = serde_json::json!("low");
        }
    }

    let client = reqwest::Client::new();
    let mut builder = client.post(&url).timeout(Duration::from_secs(300));
    if let Some(b) = &bearer {
        builder = builder.bearer_auth(b);
    }
    let response = builder.json(&payload).send().await.map_err(|_| {
    if req.provider == "local" {
      "connection_error: Локальный движок AmIgo не отвечает. Попробуйте выбрать модель ещё раз.".to_string()
    } else {
      "connection_error: Не удалось связаться с Groq. Проверьте интернет-соединение.".to_string()
    }
  })?;

    if !response.status().is_success() {
        if has_images {
            let _ = app.emit(
                "chat-status",
                StatusEvent {
                    kind: "vision".into(),
                    active: false,
                },
            );
        }
        let status = response.status();
        let text = response.text().await.unwrap_or_default();
        let hint = serde_json::from_str::<serde_json::Value>(&text)
            .ok()
            .and_then(|v| v["error"]["message"].as_str().map(|s| s.to_string()))
            .unwrap_or(text);
        return Err(format!("Ошибка сервера ({status}): {hint}"));
    }

    let mut stream = response.bytes_stream();
    let mut buffer: Vec<u8> = Vec::new();
    let mut full = String::new();
    let mut thinking_active = false;

    'outer: while let Some(item) = stream.next().await {
        if state.stop.load(Ordering::SeqCst) {
            break;
        }
        let bytes = item.map_err(|e| e.to_string())?;
        buffer.extend_from_slice(&bytes);

        while let Some(pos) = buffer.iter().position(|b| *b == b'\n') {
            let line = String::from_utf8_lossy(&buffer[..pos]).trim().to_string();
            buffer.drain(..=pos);
            if line.is_empty() {
                continue;
            }

            let json_str: &str = if let Some(stripped) = line.strip_prefix("data:") {
                let stripped = stripped.trim();
                if stripped == "[DONE]" {
                    break 'outer;
                }
                stripped
            } else {
                &line
            };

            if let Ok(data) = serde_json::from_str::<serde_json::Value>(json_str) {
                let thinking = data["choices"][0]["delta"]["reasoning"]
                    .as_str()
                    .or_else(|| data["choices"][0]["delta"]["reasoning_content"].as_str())
                    .unwrap_or("");
                let delta = data["choices"][0]["delta"]["content"]
                    .as_str()
                    .unwrap_or("");
                if req.think != Some(false) && !thinking.is_empty() && !thinking_active {
                    thinking_active = true;
                    let _ = app.emit(
                        "chat-status",
                        StatusEvent {
                            kind: "thinking".into(),
                            active: true,
                        },
                    );
                }
                if !delta.is_empty() {
                    if thinking_active {
                        thinking_active = false;
                        let _ = app.emit(
                            "chat-status",
                            StatusEvent {
                                kind: "thinking".into(),
                                active: false,
                            },
                        );
                    }
                    full.push_str(delta);
                    let _ = app.emit(
                        "chat-chunk",
                        ChatChunk {
                            content: delta.to_string(),
                        },
                    );
                }
            }

            if state.stop.load(Ordering::SeqCst) {
                break 'outer;
            }
        }
    }
    if thinking_active {
        let _ = app.emit(
            "chat-status",
            StatusEvent {
                kind: "thinking".into(),
                active: false,
            },
        );
    }
    if has_images {
        let _ = app.emit(
            "chat-status",
            StatusEvent {
                kind: "vision".into(),
                active: false,
            },
        );
    }
    Ok(full)
}

async fn persist_local_metrics(state: &ChatState) {
    let client = reqwest::Client::new();
    if let Ok(resp) = client
        .get(format!("http://127.0.0.1:{LOCAL_PORT}/metrics"))
        .timeout(Duration::from_secs(2))
        .send()
        .await
    {
        if resp.status().is_success() {
            if let Ok(text) = resp.text().await {
                let mut drafted = 0f64;
                let mut accepted = 0f64;
                for line in text.lines() {
                    if line.starts_with("llamacpp:spec_decode_num_draft_tokens_total ") {
                        drafted = line
                            .split_whitespace()
                            .last()
                            .and_then(|v| v.parse().ok())
                            .unwrap_or(0.0);
                    } else if line.starts_with("llamacpp:spec_decode_num_accepted_tokens_total ") {
                        accepted = line
                            .split_whitespace()
                            .last()
                            .and_then(|v| v.parse().ok())
                            .unwrap_or(0.0);
                    }
                }
                if state.server_draft_requested.load(Ordering::SeqCst) {
                    state
                        .server_speculative
                        .store(drafted > 0.0, Ordering::SeqCst);
                }
                let ratio = if drafted > 0.0 {
                    accepted * 100.0 / drafted
                } else {
                    0.0
                };
                let summary = format!(
                    "speculative={}\ndraft_tokens={}\naccepted_tokens={}\nacceptance_percent={:.2}\n",
                    drafted > 0.0, drafted as u64, accepted as u64, ratio
                );
                let _ = std::fs::write(models_dir().join("spec-decoding-result.txt"), summary);
                let _ = std::fs::write(models_dir().join("spec-decoding-metrics.txt"), text);
            }
        }
    }
}

#[tauri::command]
async fn chat_stream(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    req: ChatRequest,
) -> Result<String, String> {
    state.stop.store(false, Ordering::SeqCst);
    state.busy.store(true, Ordering::SeqCst);
    let is_local = req.provider == "local";

    let result = chat_stream_inner(&app, &state, req).await;
    if is_local {
        persist_local_metrics(&state).await;
    }

    state.busy.store(false, Ordering::SeqCst);
    if state.pending_unload.swap(false, Ordering::SeqCst) {
        kill_local_server(&state);
    }
    result
}

// Служебное завершение без событий chat-chunk/status. Используется для
// фонового резюме длинного диалога: его токены не должны попасть в новый
// пользовательский ответ, если пользователь уже открыл другой чат.
#[tauri::command]
async fn chat_complete_silent(
    app: tauri::AppHandle,
    state: tauri::State<'_, ChatState>,
    req: ChatRequest,
) -> Result<String, String> {
    state.stop.store(false, Ordering::SeqCst);
    if req.provider == "local" {
        ensure_server_mode(&app, &state, &req.model, false).await?;
    }
    let (url, bearer): (String, Option<String>) = if req.provider == "local" {
        (
            format!("http://127.0.0.1:{LOCAL_PORT}/v1/chat/completions"),
            None,
        )
    } else {
        (
            "https://api.groq.com/openai/v1/chat/completions".to_string(),
            Some(keychain_get()?),
        )
    };
    let payload = serde_json::json!({
        "model": req.model,
        "messages": to_openai_messages(&req.messages),
        "stream": false,
        "temperature": req.temperature.unwrap_or(0.3)
    });
    let client = reqwest::Client::new();
    let mut builder = client.post(url).timeout(Duration::from_secs(300));
    if let Some(token) = bearer {
        builder = builder.bearer_auth(token);
    }
    let response = builder
        .json(&payload)
        .send()
        .await
        .map_err(|e| e.to_string())?;
    if !response.status().is_success() {
        return Err(format!(
            "Служебный запрос завершился с кодом {}",
            response.status()
        ));
    }
    let data: serde_json::Value = response.json().await.map_err(|e| e.to_string())?;
    Ok(data["choices"][0]["message"]["content"]
        .as_str()
        .unwrap_or("")
        .to_string())
}

// Разбирает word/document.xml без внешних XML-библиотек (в духе clean_rtf
// выше): следит только за тегами <w:t>/<w:tab/>/<w:br/>/<w:cr/>/</w:p>/</w:tr>,
// которые нужны, чтобы восстановить читаемый текст — с настоящими абзацами
// и табуляцией, а не всё содержимое одной строкой через пробел, как раньше.
fn extract_docx_text(xml: &str) -> String {
    let mut out = String::new();
    let mut in_text = false;
    let mut rest = xml;
    while let Some(lt) = rest.find('<') {
        if in_text && lt > 0 {
            out.push_str(&rest[..lt]);
        }
        rest = &rest[lt + 1..];
        let gt = match rest.find('>') {
            Some(g) => g,
            None => break,
        };
        let tag = &rest[..gt];
        rest = &rest[gt + 1..];

        let closing = tag.starts_with('/');
        let body = tag.trim_start_matches('/').trim_end_matches('/').trim();
        let name = body.split(|c: char| c.is_whitespace()).next().unwrap_or("");

        match name {
            "w:t" => in_text = !closing,
            "w:tab" => out.push('\t'),
            "w:br" | "w:cr" => out.push('\n'),
            "w:p" if closing => out.push('\n'),
            "w:tr" if closing => out.push('\n'),
            _ => {}
        }
    }
    if in_text {
        out.push_str(rest);
    }

    let decoded = out
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'");

    // Схлопывает больше одной подряд пустой строки в одну (пустые <w:p>
    // между абзацами иначе дают много лишних переносов).
    let mut cleaned = String::new();
    let mut blank_run = 0;
    for line in decoded.lines() {
        let line = line.trim_end();
        if line.trim().is_empty() {
            blank_run += 1;
            if blank_run <= 1 {
                cleaned.push('\n');
            }
        } else {
            blank_run = 0;
            cleaned.push_str(line);
            cleaned.push('\n');
        }
    }
    cleaned.trim().to_string()
}

// Очень упрощённый разбор RTF: вырезает управляющие слова/группы фигурных
// скобок, оставляя читаемый текст. Не претендует на полную точность (это
// не полноценный RTF-парсер), но для заметок и писем этого достаточно.
fn clean_rtf(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    let mut depth = 0i32;
    while let Some(c) = chars.next() {
        match c {
            '{' => depth += 1,
            '}' => depth -= 1,
            '\\' => {
                let mut word = String::new();
                while let Some(&n) = chars.peek() {
                    if n.is_ascii_alphabetic() {
                        word.push(n);
                        chars.next();
                    } else {
                        break;
                    }
                }
                while let Some(&n) = chars.peek() {
                    if n.is_ascii_digit() || n == '-' {
                        chars.next();
                    } else {
                        break;
                    }
                }
                if chars.peek() == Some(&' ') {
                    chars.next();
                }
                if word == "par" || word == "line" {
                    out.push('\n');
                } else if word == "tab" {
                    out.push('\t');
                }
            }
            _ if depth <= 1 => out.push(c),
            _ => {}
        }
    }
    out
}

// Расширения, которые читаем как обычный текст без специальной обработки —
// исходный код на любом популярном языке, конфиги, разметка, логи и т.п.
const PLAIN_TEXT_EXTS: &[&str] = &[
    "txt", "md", "markdown", "csv", "tsv", "json", "jsonl", "yaml", "yml", "toml", "ini", "cfg",
    "conf", "env", "xml", "svg", "html", "htm", "css", "scss", "less", "log", "rst", "tex", "js",
    "jsx", "ts", "tsx", "mjs", "cjs", "py", "rb", "rs", "go", "java", "kt", "kts", "swift", "c",
    "h", "cpp", "cc", "hpp", "cs", "php", "sql", "sh", "bash", "zsh", "ps1", "lua", "pl", "r",
    "scala", "dart", "vue", "svelte",
];

#[tauri::command]
fn extract_document(path: String) -> Result<String, String> {
    let p = std::path::Path::new(&path);
    let ext = p
        .extension()
        .and_then(|x| x.to_str())
        .unwrap_or("")
        .to_lowercase();
    if PLAIN_TEXT_EXTS.contains(&ext.as_str()) {
        return std::fs::read_to_string(p).map_err(|e| format!("Не удалось прочитать файл: {e}"));
    }
    if ext == "pdf" {
        return pdf_extract::extract_text(p).map_err(|e| format!("Не удалось прочитать PDF: {e}"));
    }
    if ext == "docx" {
        let f = std::fs::File::open(p).map_err(|e| format!("Не удалось прочитать файл: {e}"))?;
        let mut z = zip::ZipArchive::new(f).map_err(|e| e.to_string())?;
        let mut x = String::new();
        z.by_name("word/document.xml")
            .map_err(|e| e.to_string())?
            .read_to_string(&mut x)
            .map_err(|e| e.to_string())?;
        return Ok(extract_docx_text(&x));
    }
    if ext == "rtf" {
        let raw =
            std::fs::read_to_string(p).map_err(|e| format!("Не удалось прочитать файл: {e}"))?;
        return Ok(clean_rtf(&raw));
    }
    Err("unsupported_format".into())
}

// Читает картинку с диска и возвращает data URL (data:image/...;base64,...) —
// используется для миниатюры карточки вложения во фронтенде. Base64-часть
// без префикса отдельно уходит модели через поле images в ChatMessage.
#[tauri::command]
fn read_image_base64(path: String) -> Result<String, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let p = std::path::Path::new(&path);
    let ext = p
        .extension()
        .and_then(|x| x.to_str())
        .unwrap_or("")
        .to_lowercase();
    // Локальный движок AmIgo (llama.cpp/mtmd) декодирует изображения через
    // stb_image, который умеет JPEG/PNG/BMP/GIF (и ещё пару редких форматов),
    // но НЕ умеет WebP и TIFF — попытка их скормить модели заканчивается
    // ошибкой decode уже внутри движка, что выглядит как необъяснимый сбой.
    // Поэтому отсекаем нечитаемые форматы здесь же, с понятной причиной.
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "bmp" => "image/bmp",
        // HEIC/HEIF, WebP, TIFF и прочие форматы без декодера в движке — явный
        // код ошибки, чтобы фронтенд показал понятный тост, а не сырое сообщение.
        _ => return Err("unsupported_format".into()),
    };
    let bytes = std::fs::read(p).map_err(|e| format!("Не удалось прочитать изображение: {e}"))?;
    Ok(format!("data:{mime};base64,{}", STANDARD.encode(bytes)))
}

// Только Mentis 3 умеет "видеть" — Nage 1.5 текстовая. Список моделей
// фиксирован (см. model_defs), поэтому проверка простая, без сетевых запросов.
#[tauri::command]
fn model_supports_vision(model: String) -> bool {
    model == "mentis-3"
}

// Сохраняет текст (например, код или документ из ответа модели) в файл,
// путь к которому пользователь выбрал через системный диалог "Сохранить как".
#[tauri::command]
fn save_file(path: String, content: String) -> Result<(), String> {
    std::fs::write(&path, content).map_err(|e| format!("Не удалось сохранить файл: {e}"))
}

// Сохраняет бинарный файл (PDF, PPTX, DOCX, XLSX и т.п.), который фронтенд
// собрал в памяти из лёгкого текстового описания модели (см. src/fileGenerators.js)
// и передал сюда как base64-строку. save_file для этого не подходит, потому
// что пишет содержимое как UTF-8 текст и испортил бы бинарный формат.
#[tauri::command]
fn save_binary_file(path: String, content_base64: String) -> Result<(), String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let bytes = STANDARD
        .decode(content_base64.as_bytes())
        .map_err(|e| format!("Некорректные данные файла: {e}"))?;
    std::fs::write(&path, bytes).map_err(|e| format!("Не удалось сохранить файл: {e}"))
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .manage(ChatState::default())
        .invoke_handler(tauri::generate_handler![
            chat_stream,
            chat_complete_silent,
            stop_generation,
            save_groq_key,
            extract_document,
            save_file,
            save_binary_file,
            switch_model,
            list_models,
            download_model,
            warm_model,
            read_image_base64,
            model_supports_vision,
            save_tavily_key,
            has_tavily_key,
            sandbox_list,
            sandbox_reveal,
            sandbox_delete_all,
            sandbox_read_image,
            sandbox_delete_files,
            sandbox_open_file,
            sandbox_import_file,
            sandbox_save_generated_text,
            sandbox_save_generated_binary
        ])
        .setup(|_app| {
            // Сжатие простаивающих диалогов в песочнице (не трогали сутки) — один
            // раз при старте, в фоне, не блокируя открытие окна.
            tauri::async_runtime::spawn(async {
                sandbox_compress_idle();
            });
            Ok(())
        })
        // Автоматическое управление локальным сервером: греем при возврате в
        // приложение, останавливаем при сворачивании/переключении на другое
        // приложение и при закрытии (⌘Q) — модель на диске остаётся, освобождается
        // только ОЗУ (сервер — обычный дочерний процесс, его можно просто убить).
        .on_window_event(|window, event| match event {
            tauri::WindowEvent::CloseRequested { api, .. } => {
                api.prevent_close();
                let app = window.app_handle().clone();
                tauri::async_runtime::spawn(async move {
                    let state = app.state::<ChatState>();
                    finish_then_unload(&state).await;
                    app.exit(0);
                });
            }
            tauri::WindowEvent::Focused(focused) => {
                let focused = *focused;
                let app = window.app_handle().clone();
                tauri::async_runtime::spawn(async move {
                    let state = app.state::<ChatState>();
                    if focused {
                        // Возврат отменяет отложенную выгрузку, если генерация ещё идёт.
                        state.pending_unload.store(false, Ordering::SeqCst);
                        warm_active_model(&app, &state).await;
                    } else if state.busy.load(Ordering::SeqCst) {
                        // Сначала закончить ответ/задачу, затем освободить память.
                        state.pending_unload.store(true, Ordering::SeqCst);
                    } else {
                        kill_local_server(&state);
                    }
                });
            }
            _ => {}
        })
        .run(tauri::generate_context!())
        .expect("Ошибка запуска AmIgo");
}

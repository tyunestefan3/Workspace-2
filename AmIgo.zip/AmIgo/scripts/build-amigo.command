#!/bin/zsh
# Собирает AmIgo.app + AmIgo.dmg. Первый запуск может занять несколько минут.
set -e
cd "$(dirname "$0")/.."

if ! command -v cargo >/dev/null; then
  echo "Rust не найден. Выполните в Terminal: brew install rust"
  exit 1
fi

ARCH="$(uname -m)"
if [[ "$ARCH" != "arm64" ]]; then
  echo "AmIgo на MLX собирается только для Apple Silicon (arm64)."
  exit 1
fi
if ! command -v python3 >/dev/null; then
  echo "Для MLX нужен Python 3.10+. Выполните: brew install python"
  exit 1
fi

WHISPER_WHEEL="whisper_cpp_cli-0.0.3-py3-none-macosx_11_0_arm64.whl"
WHISPER_SHA="6c9cb1d10770da5b7f92c54c2ace29142694b5b392c274db1d95ce1d2f6223d2"
WHISPER_URL="https://files.pythonhosted.org/packages/fd/eb/4d1a96d887b62fdddc58e3e0c9c94f673b54cd9fc025329340f9c4d052bc/whisper_cpp_cli-0.0.3-py3-none-macosx_11_0_arm64.whl"

CACHE_DIR="$HOME/Library/Caches/AmIgo"
mkdir -p "$CACHE_DIR"

WHISPER_ARCHIVE="$CACHE_DIR/$WHISPER_WHEEL"
valid_whisper_archive() {
  [[ -f "$WHISPER_ARCHIVE" ]] || return 1
  [[ "$(shasum -a 256 "$WHISPER_ARCHIVE" | awk '{print $1}')" == "$WHISPER_SHA" ]]
}
if ! valid_whisper_archive; then
  rm -f "$WHISPER_ARCHIVE"
  echo "Скачиваю проверенный локальный модуль распознавания аудио ($ARCH)…"
  curl -L --fail --retry 3 --connect-timeout 20 "$WHISPER_URL" -o "$WHISPER_ARCHIVE"
fi
if ! valid_whisper_archive; then
  echo "Контрольная сумма модуля распознавания аудио не совпала."
  exit 1
fi

BIN_DIR="src-tauri/bin"
rm -rf "$BIN_DIR"
mkdir -p "$BIN_DIR"
# whisper.cpp — локальное распознавание аудио. MLX ставится при первом запуске
# в ~/Library/Application Support/AmIgo/mlx-env и не пакуется в DMG.
unzip -p "$WHISPER_ARCHIVE" 'whisper_cpp_cli-0.0.3.data/scripts/whisper-cpp' > "$BIN_DIR/whisper-cpp"
chmod 755 "$BIN_DIR/whisper-cpp"
codesign --force --sign - "$BIN_DIR/whisper-cpp" >/dev/null 2>&1 || true

echo "Движок AmIgo: MLX (mlx-vlm) + whisper-cpp ($ARCH)"

npm install
# Создаём .icns из утверждённой иконки перед сборкой.
zsh scripts/make-macos-icon.command

# Tauri добавляет к DMG версию и архитектуру. Перед сборкой убираем старые
# образы, а свежий результат ниже переименовываем в понятный AmIgo.dmg.
DMG_DIR="src-tauri/target/release/bundle/dmg"
mkdir -p "$DMG_DIR"
rm -f "$DMG_DIR"/*.dmg(N)

npm run tauri build

DMG_FILES=("$DMG_DIR"/*.dmg(N))
if (( ${#DMG_FILES[@]} > 0 )); then
  mv -f "$DMG_FILES[1]" "$DMG_DIR/AmIgo.dmg"
fi

# Финальная проверка того, что отправляемый DMG самодостаточен.
APP_DIR="src-tauri/target/release/bundle/macos/AmIgo.app"
FINAL_DMG="$DMG_DIR/AmIgo.dmg"
[[ -d "$APP_DIR" ]] || { echo "AmIgo.app не найден после сборки"; exit 1; }
[[ -s "$FINAL_DMG" ]] || { echo "AmIgo.dmg не создан"; exit 1; }
[[ -x "$APP_DIR/Contents/Resources/bin/whisper-cpp" ]] || {
  echo "В AmIgo.app отсутствует встроенный модуль распознавания аудио"
  exit 1
}
ICON_FILES=("$APP_DIR/Contents/Resources"/*.icns(N))
(( ${#ICON_FILES[@]} > 0 )) || { echo "В AmIgo.app отсутствует иконка .icns"; exit 1; }
APP_EXECUTABLES=("$APP_DIR/Contents/MacOS"/*(N*))
(( ${#APP_EXECUTABLES[@]} > 0 )) || { echo "В AmIgo.app отсутствует исполняемый файл"; exit 1; }

echo "Проверка DMG пройдена: приложение, иконка и whisper-cpp находятся внутри. MLX ставится при первом запуске."
echo "Проверка аудио пройдена: whisper-cpp находится внутри приложения."
echo "Сборка завершена. Приложение: $APP_DIR"
echo "Образ для отправки: $FINAL_DMG"
open "$DMG_DIR" || true

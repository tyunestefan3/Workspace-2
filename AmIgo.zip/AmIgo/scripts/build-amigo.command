#!/bin/zsh
# Собирает AmIgo.app + AmIgo.dmg. Первый запуск может занять несколько минут.
set -e
cd "$(dirname "$0")/.."

if ! command -v cargo >/dev/null; then
  echo "Rust не найден. Выполните в Terminal: brew install rust"
  exit 1
fi

# Используем зафиксированную и проверенную сборку llama.cpp. Homebrew latest
# больше не влияет на совместимость speculative decoding после обновлений.
LLAMA_BUILD="b10441"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64)
    ASSET="llama-${LLAMA_BUILD}-bin-macos-arm64.tar.gz"
    EXPECTED_SHA="a1665593b241af9bd302ac33b0cc9d252a507038e174b6fbc2763e71dff1ddb5"
    ;;
  x86_64)
    ASSET="llama-${LLAMA_BUILD}-bin-macos-x64.tar.gz"
    EXPECTED_SHA="540e66a464483ad7cdd53780cc48819d5be314d61d0aefae3514af2dddff0ee7"
    ;;
  *)
    echo "Неподдерживаемая архитектура Mac: $ARCH"
    exit 1
    ;;
esac

CACHE_DIR="$HOME/Library/Caches/AmIgo"
ARCHIVE="$CACHE_DIR/$ASSET"
URL="https://github.com/ggml-org/llama.cpp/releases/download/$LLAMA_BUILD/$ASSET"
mkdir -p "$CACHE_DIR"

valid_archive() {
  [[ -f "$ARCHIVE" ]] || return 1
  [[ "$(shasum -a 256 "$ARCHIVE" | awk '{print $1}')" == "$EXPECTED_SHA" ]]
}
if ! valid_archive; then
  rm -f "$ARCHIVE"
  echo "Скачиваю проверенный движок AmIgo ($LLAMA_BUILD, $ARCH)…"
  curl -L --fail --retry 3 --connect-timeout 20 "$URL" -o "$ARCHIVE"
fi
if ! valid_archive; then
  echo "Контрольная сумма llama-server не совпала. Сборка остановлена."
  exit 1
fi

TMP_ENGINE="$(mktemp -d -t amigo-llama)"
trap 'rm -rf "$TMP_ENGINE"' EXIT
tar -xzf "$ARCHIVE" -C "$TMP_ENGINE"
ENGINE_DIR="$(find "$TMP_ENGINE" -type f -name llama-server -print -quit | xargs dirname)"

BIN_DIR="src-tauri/bin"
BIN_TARGET="$BIN_DIR/llama-server"
rm -rf "$BIN_DIR"
mkdir -p "$BIN_DIR"
/bin/cp -f "$ENGINE_DIR/llama-server" "$BIN_TARGET"
for dylib in "$ENGINE_DIR"/*.dylib(N); do
  /bin/cp -fL "$dylib" "$BIN_DIR/${dylib:t}"
done
chmod 755 "$BIN_TARGET" "$BIN_DIR"/*.dylib(N)
for macho in "$BIN_TARGET" "$BIN_DIR"/*.dylib(N); do
  codesign --force --sign - "$macho" >/dev/null 2>&1 || true
done

# Сборка не продолжается, если бинарник или нужные spec-флаги не работают.
HELP_OUTPUT="$(DYLD_LIBRARY_PATH="$BIN_DIR" "$BIN_TARGET" --help 2>&1)"
for required in "--spec-type" "--spec-draft-model" "--spec-draft-n-max" "--metrics"; do
  if ! printf '%s' "$HELP_OUTPUT" | grep -q -- "$required"; then
    echo "В проверенном llama-server отсутствует $required"
    exit 1
  fi
done

echo "Движок AmIgo подготовлен: llama.cpp $LLAMA_BUILD ($ARCH, со всеми dylib)"

npm install
# Создаём .icns из утверждённой иконки перед сборкой.
zsh scripts/make-macos-icon.command

# Tauri добавляет к DMG версию и архитектуру. Перед сборкой убираем старые
# образы, а свежий результат ниже переименовываем в понятный AmIgo.dmg.
DMG_DIR="src-tauri/target/release/bundle/dmg"
mkdir -p "$DMG_DIR"
rm -f "$DMG_DIR"/*.dmg(N)

npm run tauri build

DMG_FILES=("$DMG_DIR"/*.dmg(N))
if (( ${#DMG_FILES[@]} > 0 )); then
  mv -f "$DMG_FILES[1]" "$DMG_DIR/AmIgo.dmg"
fi

echo "Сборка завершена. Приложение: src-tauri/target/release/bundle/macos/AmIgo.app"
echo "Образ для отправки: $DMG_DIR/AmIgo.dmg"
open "$DMG_DIR" || true

export const CONTINUE_RE = /^(?:\/)?(?:продолжай|продолжи|продолжение|continue|go\s+on|дальше)(?:\s*[,—-]?\s*(?:пожалуйста|please|с\s+места\s+остановки))?[.!…\s]*$/i;

const TOPIC_SWITCH_RE = /^(?:а\s+)?(?:теперь|другая\s+тема|новая\s+тема|новый\s+вопрос|сменим\s+тему|смени\s+тему|перейд[её]м\s+(?:к|на)|давай\s+(?:о|про|обсудим)|отдельный\s+вопрос)(?=\s|:|[,.!?—-]|$)/i;
const FOLLOWUP_START_RE = /^(?:а|и|но|также|ещ[её]|тогда|поэтому|почему|зачем|как|какие?|какая|какой|кто|что|где|когда|сколько|можешь|уточни|подробнее|это|этот|эта|он|она|они)(?=\s|:|[,.!?—-]|$)/i;
const TOPIC_STOP_WORDS = new Set(['который','которая','которые','чтобы','этого','этому','можно','нужно','будет','только','очень','пожалуйста','расскажи','сделай','помоги','такое','такой','такая']);

export function isUnusedChat(chat) {
  if (!chat) return false;
  const hasMessages = (chat.messages || []).some(
    (message) => (message.content || '').trim() || (message.attachments || []).length
  );
  return !hasMessages
    && !(chat.pendingAttachments || []).length
    && !(chat.draft || '').trim();
}

export function nextChatId(chats, now = Date.now()) {
  return Math.max(now, ...(chats || []).map((chat) => Number(chat.id) || 0)) + 1;
}

function topicWords(text) {
  return new Set(
    (String(text || '').toLocaleLowerCase('ru').match(/[a-zа-яё0-9]{4,}/giu) || [])
      .filter((word) => !TOPIC_STOP_WORDS.has(word))
  );
}

const TOOL_CALL_NAMES_RE = /(?:list_files|read_file|write_file|delete_file|copy_code_to_file|check_syntax|validate_project|merge_files|web_search|read_webpage|find_images|download_image|download_file)/i;

export function looksLikeToolCallPayload(text) {
  const source = String(text || '').trim();
  if (!source) return false;
  if (/<\/?tool_call>/i.test(source)) return true;
  if (!/name/i.test(source) || !/arguments/i.test(source)) return false;
  return TOOL_CALL_NAMES_RE.test(source);
}

export function stripLeakedToolCalls(text) {
  let next = String(text || '');
  next = next.replace(/<tool_call>[\s\S]*?<\/tool_call>/gi, '');
  next = next.replace(/(```|~~~)(?:json|jsonc|javascript|js)?[^\n]*\n([\s\S]*?)\1/gi, (full, _fence, body) => (
    looksLikeToolCallPayload(body) ? '' : full
  ));
  // Сырой JSON вызова инструмента без ограждения: { "name": "list_files", "arguments": {} }
  next = next.replace(/\{\s*["']name["']\s*:\s*["']?[a-z_]+["']?[\s\S]{0,400}?["']arguments["']\s*:\s*[\s\S]{0,2000}?\}/gi, (full) => (
    looksLikeToolCallPayload(full) ? '' : full
  ));
  return next.replace(/\n{3,}/g, '\n\n').trim();
}

export function isUnlimitedCreationTask(text, attachments = []) {
  const source = String(text || '').toLocaleLowerCase('ru');
  if (/(?:создай|создать|напиши|сгенерируй|сделай|разработай|доработай|измени|исправь|перепиши|переделай|подготовь)[\s\S]{0,100}(?:код|файл|скрипт|программ|сайт|страниц|html|css|javascript|typescript|python|json|проект|презентац|pptx|pdf|docx|xlsx|документ|таблиц)/i.test(source)) return true;
  if (/(?:код|файл|скрипт|программа|сайт|презентация|документ)[\s\S]{0,60}(?:создай|напиши|сгенерируй|сделай|доработай|измени|исправь|перепиши|переделай)/i.test(source)) return true;
  if (/(?:объедини|склей|собери|слить|merge|combine|concat)[\s\S]{0,80}файл/i.test(source)) return true;
  if (/файл[\s\S]{0,80}(?:объедини|склей|собери|в один)/i.test(source)) return true;
  if (/\b[\w.-]+\.(?:html?|css|js|jsx|ts|tsx|py|rb|rs|go|java|kt|swift|c|cpp|h|hpp|cs|php|sql|sh|zsh|json|ya?ml|toml|md|pdf|pptx|docx|xlsx)\b/i.test(source)) return true;
  return attachments.some((attachment) => attachment?.sandboxPath)
    && /(?:измени|доработай|исправь|перепиши|переделай|обработай|объедини|склей)/i.test(source);
}

export function shouldStartNewTopic(chat, text, attachments = []) {
  const clean = String(text || '').trim();
  if (!clean || CONTINUE_RE.test(clean)) return false;
  if (TOPIC_SWITCH_RE.test(clean)) return true;
  if (FOLLOWUP_START_RE.test(clean) || attachments.length) return false;

  const previous = [...(chat?.messages || [])]
    .reverse()
    .find((message) => message.role === 'user' && (message.content || '').trim());
  if (!previous) return false;
  const currentWords = topicWords(clean);
  const previousWords = topicWords(previous.content);
  if (currentWords.size < 8 || previousWords.size < 5) return false;
  const overlap = [...currentWords].filter((word) => previousWords.has(word)).length;
  return overlap === 0;
}

export function convertPlainQuestionsToSurvey(text) {
  const source = String(text || '').trim();
  if (!source || !source.includes('?')) return source;
  if (/(```|~~~)\s*question/i.test(source) || /["']question["']\s*:/i.test(source)) return source;
  // Не переписываем ответы с кодом: вопросительный знак внутри программы не
  // должен превращать весь ответ в опрос.
  if (/(```|~~~)/.test(source)) return source;

  const lines = source.split('\n');
  const candidates = [];
  const consumed = new Set();
  let current = null;

  for (let index = 0; index < lines.length; index++) {
    const raw = lines[index].trim();
    if (!raw) { current = null; continue; }
    const cleaned = raw
      .replace(/^#{1,6}\s*/, '')
      .replace(/^\s*(?:[-*•]|\d+[.)])\s+/, '')
      .replace(/^\*\*(.*?)\*\*$/, '$1')
      .trim();
    const pieces = cleaned.match(/[^?]{3,500}\?/g)?.map((part) => part.trim()) || [];
    if (pieces.length) {
      for (const question of pieces) {
        current = { question, multiple: false, options: [] };
        candidates.push(current);
      }
      consumed.add(index);
      continue;
    }
    const option = /^\s*(?:[-*•]|\d+[.)])\s+(.{1,180})$/.exec(raw);
    if (current && option) {
      current.options.push(option[1].trim());
      consumed.add(index);
    } else {
      current = null;
    }
  }

  if (!candidates.length) return source;
  const cue = /(?:уточн|ответьте|выберите|нужно знать|перед тем как|чтобы (?:сделать|подготовить|продолжить)|несколько вопросов|подскажите)/i.test(source);
  const shortQuestionResponse = source.length <= 800 && source.endsWith('?');
  if (candidates.length < 2 && !cue && !shortQuestionResponse) return source;

  const prefix = lines
    .filter((_, index) => !consumed.has(index))
    .join('\n')
    .trim();
  const payload = candidates.slice(0, 8).map((item) => ({
    question: item.question.slice(0, 500),
    multiple: item.options.length > 1 && /(?:несколько|все подходящие|можно выбрать)/i.test(item.question),
    options: [...new Set(item.options)].slice(0, 8),
  }));
  const block = `\`\`\`question\n${JSON.stringify(payload, null, 2)}\n\`\`\``;
  return prefix ? `${prefix}\n\n${block}` : block;
}

function stripContinuationPreamble(value) {
  let next = String(value || '').replace(
    /^\s*(?:#{1,3}\s*)?(?:продолжение|продолжаю|continue|continuation)\s*[:.\-–—]*\s*/i,
    ''
  );
  // Модель иногда оборачивает продолжение обычного Markdown-ответа в новый
  // ```markdown. Это не новый файл и не должно попадать внутрь сообщения.
  let unwrapped = false;
  next = next.replace(/^\s*(?:```|~~~)(?:markdown|md|text|txt)\s*\n/i, () => {
    unwrapped = true;
    return '';
  });
  if (unwrapped && /\n\s*(?:```|~~~)\s*$/.test(next)) {
    next = next.replace(/\n\s*(?:```|~~~)\s*$/, '');
  }
  return next;
}

function normalizedContinuation(value) {
  return String(value || '')
    .toLocaleLowerCase('ru')
    .replace(/(?:```|~~~)(?:markdown|md|text|txt)?/g, '')
    .replace(/[*_#>`~]/g, ' ')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function continuationLooksRestarted(existing, incoming) {
  const base = normalizedContinuation(existing);
  const next = normalizedContinuation(stripContinuationPreamble(incoming));
  if (base.length < 30 || next.length < 24) return false;
  const probeLength = Math.min(100, base.length, next.length);
  let common = 0;
  while (common < probeLength && base[common] === next[common]) common++;
  if (common >= Math.min(48, probeLength)) return true;
  const baseWords = base.split(' ').slice(0, 10).join(' ');
  return baseWords.length >= 30 && next.startsWith(baseWords);
}

function tokenContinuationCut(base, next) {
  const wordRe = /[\p{L}\p{N}_]+/gu;
  const baseWords = Array.from(base.matchAll(wordRe));
  const nextWords = Array.from(next.matchAll(wordRe));
  const anchor = baseWords.slice(-10).map((match) => match[0].toLocaleLowerCase('ru'));
  if (anchor.length < 6 || anchor.join('').length < 30) return -1;
  for (let index = nextWords.length - anchor.length; index >= 0; index--) {
    let equal = true;
    for (let offset = 0; offset < anchor.length; offset++) {
      if (nextWords[index + offset][0].toLocaleLowerCase('ru') !== anchor[offset]) {
        equal = false;
        break;
      }
    }
    if (equal) {
      const last = nextWords[index + anchor.length - 1];
      return last.index + last[0].length;
    }
  }
  return -1;
}

export function cleanContinuationStart(existing, incoming) {
  const base = String(existing || '');
  let next = stripContinuationPreamble(incoming);
  if (!next) return '';

  // Нормальное продолжение иногда повторяет небольшой хвост предыдущего ответа.
  const max = Math.min(1600, base.length, next.length);
  for (const size of [max, 1200, 800, 500, 320, 200, 120, 80, 48, 32, 24]) {
    if (size <= 0 || size > max) continue;
    const suffix = base.slice(-size);
    const at = next.lastIndexOf(suffix);
    if (at !== -1) return next.slice(at + size);
  }

  // Если модель начала ответ заново, удаляем уже существующий точный префикс.
  let common = 0;
  const commonMax = Math.min(base.length, next.length);
  while (common < commonMax && base[common] === next[common]) common++;
  if (common === next.length) return '';
  if (common === base.length) return next.slice(common);

  // Последняя страховка допускает отличия в Markdown и пунктуации: ищем в
  // новом ответе последние слова уже написанного фрагмента и продолжаем после них.
  const tokenCut = tokenContinuationCut(base, next);
  if (tokenCut !== -1) return next.slice(tokenCut);
  return next;
}


// Последняя страховка от двойной доставки одного и того же полного ответа
// (например, SSE + повторная выдача накопленного буфера). Не трогает обычные
// повторы слов: убирается только полностью идентичная вторая половина.
export function collapseRepeatedWholeResponse(text) {
  const source = String(text || '').trim();
  if (source.length < 80) return source;
  const probe = source.slice(0, Math.min(80, Math.floor(source.length / 3)));
  let position = source.indexOf(probe, Math.max(40, Math.floor(source.length * 0.35)));
  const restartPositions = [];
  while (position !== -1) {
    restartPositions.push(position);
    const first = source.slice(0, position).trim();
    const second = source.slice(position).trim();
    if (first.length >= 40 && first === second) return first;
    position = source.indexOf(probe, position + 1);
  }
  // Если начало ответа встретилось ещё раз, модель перезапустила генерацию.
  // Оставляем последнюю, наиболее новую версию от повторного заголовка до конца.
  if (restartPositions.length) {
    const restarted = source.slice(restartPositions[restartPositions.length - 1]).trim();
    if (restarted.length >= 80) return restarted;
  }
  return source;
}

export function isConciseCapabilityQuestion(text) {
  const source = String(text || '').trim();
  if (!source || source.length > 140 || /подроб|полный список|все возможност/i.test(source)) return false;
  return /^(?:расскажи[, ]*)?(?:что (?:ты )?умеешь|какие у тебя возможности|чем (?:ты )?можешь помочь)[.!?…\s]*$/iu.test(source);
}


function normalizedProseKey(value) {
  return String(value || '')
    .toLocaleLowerCase('ru')
    .replace(/```[\s\S]*?```/g, '')
    .replace(/[*_`~>#|\[\]()]/g, ' ')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function proseSimilarity(a, b) {
  const aWords = new Set(normalizedProseKey(a).split(' ').filter((word) => word.length >= 3));
  const bWords = new Set(normalizedProseKey(b).split(' ').filter((word) => word.length >= 3));
  if (aWords.size < 8 || bWords.size < 8) return 0;
  let common = 0;
  for (const word of aWords) if (bWords.has(word)) common++;
  const union = new Set([...aWords, ...bWords]).size || 1;
  const ratio = aWords.size / bWords.size;
  if (ratio < 0.7 || ratio > 1.43) return 0;
  return common / union;
}

// Удаляет повторные прозаические абзацы и соседние одинаковые предложения,
// но никогда не меняет fenced-код, JSON вопросов или содержимое файлов.
export function removeRepeatedProse(text) {
  const source = String(text || '');
  const pieces = source.split(/((?:```|~~~)[\s\S]*?(?:```|~~~))/g);
  const seenParagraphs = [];
  const result = pieces.map((piece, index) => {
    if (index % 2 === 1 || /^(?:```|~~~)/.test(piece.trimStart())) return piece;
    const paragraphs = piece.split(/(\n{2,})/);
    return paragraphs.map((paragraph) => {
      if (/^\n{2,}$/.test(paragraph) || !paragraph.trim()) return paragraph;
      const key = normalizedProseKey(paragraph);
      if (key.length >= 50) {
        const repeated = seenParagraphs.some((previous) => previous.key === key
          || proseSimilarity(previous.text, paragraph) >= 0.88);
        if (repeated) return '';
        seenParagraphs.push({ key, text: paragraph });
      }
      // Не перестраиваем Markdown-таблицы и списки: их переносы значимы.
      if (paragraph.includes('\n')) return paragraph;
      // Без regexp-lookbehind: WebView старых поддерживаемых macOS тоже
      // должна разбирать этот код при запуске приложения.
      const sentenceParts = paragraph.match(/[^.!?…]+[.!?…]+|[^.!?…]+$/gu) || [paragraph];
      const seenSentences = new Set();
      return sentenceParts.filter((sentence) => {
        const sentenceKey = normalizedProseKey(sentence);
        if (sentenceKey.length < 24) return true;
        if (seenSentences.has(sentenceKey)) return false;
        seenSentences.add(sentenceKey);
        return true;
      }).map((sentence) => sentence.trim()).join(' ');
    }).join('');
  }).join('');
  return result.replace(/\n{3,}/g, '\n\n').trim();
}

// Не даёт обычному текстовому вопросу мелькнуть перед тем, как финальная
// обработка превратит его в интерактивную карточку. Скрывается только текущая
// фраза, начинающаяся как вопрос к пользователю; остальной ответ стримится.
export function hideStreamingQuestionDraft(text) {
  const source = String(text || '');
  if (!source || /(```|~~~)\s*question/i.test(source)) return source;
  const openFences = (source.match(/(?:```|~~~)/g) || []).length;
  if (openFences % 2 === 1) return source;
  let paragraphStart = 0;
  for (const match of source.matchAll(/\n{2,}/gu)) paragraphStart = match.index + match[0].length;
  const tail = source.slice(paragraphStart);
  const questionStart = /^(?:а\s+)?(?:какой|какая|какие|какое|который|что|где|когда|зачем|почему|сколько|нужно ли|следует ли|хотите ли|вы хотите|можете ли|подскажите|уточните|выберите|для какого|для какой|для каких|в каком|в какой)(?=\s|[?!.,:]|$)/iu;
  let offset = paragraphStart;
  for (const line of tail.split('\n')) {
    const starts = [0];
    for (const boundary of line.matchAll(/[.!…]\s+/gu)) starts.push(boundary.index + boundary[0].length);
    for (const sentenceStart of starts) {
      const plainSentence = line.slice(sentenceStart)
        .replace(/^\s*(?:#{1,6}|[-*•]|\d+[.)]|>)\s*/, '')
        .replace(/[*_`]/g, '')
        .trimStart();
      if (questionStart.test(plainSentence) || (plainSentence.includes('?') && sentenceStart === starts[starts.length - 1])) {
        return source.slice(0, offset + sentenceStart).trimEnd();
      }
    }
    offset += line.length + 1;
  }
  return source;
}

export function areUserQuestionsEquivalent(a, b) {
  const key = (value) => String(value || '')
    .toLocaleLowerCase('ru')
    .replace(/[*_`~>#|\[\]()]/g, ' ')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const leftKey = key(a);
  const rightKey = key(b);
  if (!leftKey || !rightKey) return false;
  if (leftKey === rightKey) return true;
  const left = new Set(leftKey.split(' ').filter(Boolean));
  const right = new Set(rightKey.split(' ').filter(Boolean));
  let common = 0;
  for (const word of left) if (right.has(word)) common++;
  const union = new Set([...left, ...right]).size || 1;
  return common >= 2 && common / union >= 0.72;
}

// Context Builder: собирает запрос модели в бюджет токенов.
// Transformer видит только token IDs; этот слой решает knapsack:
// что обязательно, что обрезать, что выкинуть. UI не затрагивается.

export function estimateTokens(text) {
  const source = String(text || '');
  if (!source) return 0;
  // С запасом для смешанного RU/EN, чтобы паковать меньше, чем влезет.
  return Math.ceil(source.length / 2.5);
}

export function contextBudget({
  numCtx,
  hasImages = false,
  imageCount = 0,
  reserveOutput,
  provider = 'local',
} = {}) {
  const ctx = Number(numCtx) > 0 ? Number(numCtx) : (provider === 'local' ? 12_288 : 32_768);
  const images = hasImages ? Math.max(1, Number(imageCount) || 1) * 900 : 0;
  const output = Number(reserveOutput) > 0
    ? Number(reserveOutput)
    : (hasImages ? 2_048 : 4_096);
  const tools = provider === 'local' ? 1_400 : 500;
  return Math.max(1_600, ctx - output - images - tools);
}

export function clipToTokens(text, maxTokens) {
  const source = String(text || '');
  if (maxTokens <= 0) return '';
  if (estimateTokens(source) <= maxTokens) return source;
  const marker = '\n[обрезано по бюджету токенов]';
  const markerTokens = estimateTokens(marker);
  const bodyTokens = Math.max(1, maxTokens - markerTokens);
  const maxChars = Math.max(0, Math.floor(bodyTokens * 2.5));
  return `${source.slice(0, maxChars).trimEnd()}${marker}`;
}

export function splitBudget(total, { systemShare = 0.38 } = {}) {
  const system = Math.max(400, Math.floor(total * systemShare));
  const history = Math.max(600, total - system);
  return { system, history };
}

// Берём суффикс диалога, всегда оставляя последнее сообщение пользователя.
export function selectRecentMessages(messages, budgetTokens, {
  lastUserMax = 2_200,
  otherMax = 800,
} = {}) {
  const list = Array.isArray(messages) ? messages : [];
  if (!list.length || budgetTokens <= 0) {
    return { kept: [], dropped: list.length, used: 0 };
  }

  const lastUserIdx = list.map((message) => message.role).lastIndexOf('user');
  const clipped = list.map((message, index) => ({
    ...message,
    content: clipToTokens(message.content || '', index === lastUserIdx ? lastUserMax : otherMax),
  }));

  const kept = [];
  let used = 0;
  const tryTake = (message, front) => {
    const cost = estimateTokens(message.content) + 8;
    if (used + cost > budgetTokens && kept.length) return false;
    used += cost;
    if (front) kept.unshift(message);
    else kept.push(message);
    return true;
  };

  if (lastUserIdx < 0) {
    for (let index = clipped.length - 1; index >= 0; index -= 1) {
      if (!tryTake(clipped[index], true)) break;
    }
    return { kept, dropped: list.length - kept.length, used };
  }

  tryTake(clipped[lastUserIdx], true);
  for (let index = lastUserIdx - 1; index >= 0; index -= 1) {
    if (!tryTake(clipped[index], true)) break;
  }
  for (let index = lastUserIdx + 1; index < clipped.length; index += 1) {
    if (!tryTake(clipped[index], false)) break;
  }
  return { kept, dropped: list.length - kept.length, used };
}

export function packPrompt({ system, messages, budget, lastUserMax, otherMax }) {
  const { system: systemBudget, history: historyBudget } = splitBudget(budget);
  const packedSystem = clipToTokens(system, systemBudget);
  const history = selectRecentMessages(messages, historyBudget, { lastUserMax, otherMax });
  return {
    system: packedSystem,
    messages: history.kept,
    dropped: history.dropped,
    used: estimateTokens(packedSystem) + history.used,
    budget,
  };
}

// Отдельный канал для фрагментов файлов: они не должны вытеснять
// системные правила и не должны съедать текущий вопрос пользователя.
export function packTurn({
  system,
  evidence = '',
  messages,
  budget,
  lastUserMax,
  otherMax,
} = {}) {
  const total = Math.max(1_600, Number(budget) || 0);
  const hasEvidence = !!String(evidence || '').trim();
  const systemShare = hasEvidence ? 0.28 : 0.36;
  const evidenceShare = hasEvidence ? 0.30 : 0;
  const systemBudget = Math.max(350, Math.floor(total * systemShare));
  const evidenceBudget = hasEvidence ? Math.max(400, Math.floor(total * evidenceShare)) : 0;
  const historyBudget = Math.max(500, total - systemBudget - evidenceBudget);
  const packedSystem = clipToTokens(system, systemBudget);
  const packedEvidence = hasEvidence ? clipToTokens(evidence, evidenceBudget) : '';
  const history = selectRecentMessages(messages, historyBudget, { lastUserMax, otherMax });
  return {
    system: packedSystem,
    evidence: packedEvidence,
    messages: history.kept,
    dropped: history.dropped,
    used: estimateTokens(packedSystem) + estimateTokens(packedEvidence) + history.used,
    budget: total,
  };
}

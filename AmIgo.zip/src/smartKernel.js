// Ядро вокруг модели: маршруты, факты, sampler.
// 4B/9B умнеют, когда задача собрана за них, а не свалена в промпт.

import { tokenize } from './retriever.js';

export function expandSearchQuery(text) {
  const source = String(text || '');
  const quoted = [...source.matchAll(/[«"']([^«"']{2,80})[»"']/g)].map((match) => match[1].trim());
  const files = [...source.matchAll(/\b[\w./-]+\.(?:pdf|docx?|pptx?|xlsx?|txt|md|csv|json|py|js|jsx|ts|tsx|html|css|rs|go|java)\b/gi)]
    .map((match) => match[0]);
  const numbers = source.match(/\d+(?:[.,]\d+)?%?|\d{1,2}[./]\d{1,2}[./]\d{2,4}/g) || [];
  const tokens = tokenize(source);
  const seen = new Set();
  const parts = [];
  for (const part of [...quoted, ...files, ...numbers, ...tokens]) {
    const key = String(part).toLocaleLowerCase('ru');
    if (!key || seen.has(key)) continue;
    seen.add(key);
    parts.push(part);
  }
  return parts.join(' ').slice(0, 400);
}

export function mentionedFilenames(text, files = []) {
  const lower = String(text || '').toLocaleLowerCase('ru');
  if (!lower.trim()) return [];
  return (files || []).filter((name) => {
    const base = String(name || '').split(/[\\/]/).pop();
    if (!base) return false;
    const needle = base.toLocaleLowerCase('ru');
    return lower.includes(needle) || lower.includes(needle.replace(/\.[^.]+$/, ''));
  });
}

export function extractDurableFacts(messages) {
  const facts = [];
  const seen = new Set();
  const add = (line) => {
    const key = line.toLocaleLowerCase('ru');
    if (seen.has(key)) return;
    seen.add(key);
    facts.push(line);
  };
  for (const message of messages || []) {
    if (message.role !== 'user') continue;
    const text = String(message.content || '');
    const name = text.match(/(?:меня зовут|моё имя|мое имя|зови меня)\s+([A-ZА-ЯЁ][\p{L}'-]+(?:\s+[A-ZА-ЯЁ][\p{L}'-]+)?)/iu);
    if (name) add(`Имя: ${name[1]}`);
    const work = text.match(/я работа(?:ю|ю как)\s+([^.!?\n]{3,70})/i);
    if (work) add(`Работа: ${work[1].trim().replace(/[.,;]+$/, '')}`);
    const prefer = text.match(/я (?:предпочитаю|люблю)\s+([^.!?\n]{3,70})/i);
    if (prefer) add(`Предпочтение: ${prefer[1].trim().replace(/[.,;]+$/, '')}`);
    const live = text.match(/я живу\s+(?:в|на)\s+([^.!?\n]{2,40})/i);
    if (live) add(`Город: ${live[1].trim().replace(/[.,;]+$/, '')}`);
  }
  return facts.slice(0, 8);
}

export function looksLikeGroundingFailure(text) {
  const source = String(text || '');
  if (!source.trim()) return false;
  if (/(?:во фрагмент|согласно (?:файлу|документу)|в «[^»]+»|источник \d)/i.test(source)) return false;
  return /не (?:могу|удалось) (?:прочитат|открыт|получить доступ|увидеть)|нет доступа|файл(?:а|ов)? нет|не вижу (?:файл|документ|вложен)|не прикрепл|не получил(?:а|о)? (?:файл|документ)|у меня нет[\s\S]{0,40}файл/i.test(source);
}

export function samplerForIntent(intent, effort = {}) {
  const baseTemp = Number(effort.temperature) > 0 ? Number(effort.temperature) : 0.55;
  const maxTokens = Number(effort.max_tokens) > 0 ? Number(effort.max_tokens) : 8192;
  if (intent === 'file_qa') return { temperature: Math.min(baseTemp, 0.28), max_tokens: maxTokens };
  if (intent === 'capability') return { temperature: 0.35, max_tokens: 384 };
  if (intent === 'code') return { temperature: Math.min(baseTemp, 0.42), max_tokens: maxTokens };
  if (intent === 'search') return { temperature: Math.min(baseTemp, 0.4), max_tokens: maxTokens };
  if (intent === 'vision' || intent === 'vision_files') return { temperature: Math.min(baseTemp, 0.45), max_tokens: maxTokens };
  // Разбор/объяснение: чуть холоднее разговора — точность важнее живости,
  // полный бюджет токенов на структурный ответ.
  if (intent === 'explain') return { temperature: Math.min(baseTemp, 0.5), max_tokens: maxTokens };
  return { temperature: baseTemp, max_tokens: maxTokens };
}

// Сложный запрос, с которым «сразу отвечай» у небольшой локальной модели
// распадается: несколько вопросов подряд, длинная постановка или явная
// просьба о структуре. На такой ход main.js делает тихий СКРЫТЫЙ план
// ответа — технический аналог рассуждения про себя у облачных сервисов
// (пользователю план не показывается).
export function needsDeliberatePlan(text = '') {
  const source = String(text || '');
  const lower = source.toLocaleLowerCase('ru');
  if ((source.match(/\?/g) || []).length >= 2) return true;
  if (source.trim().length >= 260) return true;
  return /(?:составь план|план действий|пошагов|по шагам|этапы|этапам|структурируй|roadmap|стратеги|с чего начать|все варианты|все стороны|каждый аспект|как лучше (?:сделать|организовать|построить|начать)|как правильно (?:сделать|организовать|построить))/i.test(lower);
}
